INSERT INTO `accounting`.`account` (`id`, `version`, `account_type`, `activated_date`, `created_date`, `currency_code`, `employer_id`, `in_arrears`, `status`, `submission_status`, `system`) VALUES ('100041', '0', 'System', '2012-07-01 00:00:00', '2012-07-01 00:00:00', 'ZAR', '1', 0, 'Active', 'NotApplicable', 1);

INSERT INTO `accounting`.`tx_chart` (`id`, `name`) VALUES ('1034', 'recognised cheque fee');


INSERT INTO `accounting`.`account_configuration` (`id`, `version`, `account_id`, `chart_id`, `descr`, `name`) VALUES ('100044', '0', '100041', '1034', 'recognised cheque fee', 'recognised cheque fee');
