-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: masterdata
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `masterdata`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `masterdata` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;

USE `masterdata`;

--
-- Table structure for table `account_application`
--

DROP TABLE IF EXISTS `account_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_application` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_application_aud`
--

DROP TABLE IF EXISTS `account_application_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_application_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKDE2A6D2FDF74E053` (`REV`),
  CONSTRAINT `FKDE2A6D2FDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `address_line_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `months_at_residence` int(11) DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_type_id` bigint(20) NOT NULL,
  `city_id` bigint(20) DEFAULT NULL,
  `region_id` bigint(20) DEFAULT NULL,
  `residence_type_id` bigint(20) DEFAULT NULL,
  `resident_status_id` bigint(20) DEFAULT NULL,
  `suburb_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBB979BF48F6BBFAC` (`address_type_id`),
  KEY `FKBB979BF4A32FC90` (`residence_type_id`),
  KEY `FKBB979BF415471431` (`region_id`),
  KEY `FKBB979BF436525A91` (`suburb_id`),
  KEY `FKBB979BF4736F85B2` (`resident_status_id`),
  KEY `FKBB979BF4505F3E91` (`city_id`),
  CONSTRAINT `FKBB979BF4505F3E91` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FKBB979BF415471431` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`),
  CONSTRAINT `FKBB979BF436525A91` FOREIGN KEY (`suburb_id`) REFERENCES `suburb` (`id`),
  CONSTRAINT `FKBB979BF4736F85B2` FOREIGN KEY (`resident_status_id`) REFERENCES `resident_status` (`id`),
  CONSTRAINT `FKBB979BF48F6BBFAC` FOREIGN KEY (`address_type_id`) REFERENCES `address_type` (`id`),
  CONSTRAINT `FKBB979BF4A32FC90` FOREIGN KEY (`residence_type_id`) REFERENCES `residence_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `address_type`
--

DROP TABLE IF EXISTS `address_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent`
--

DROP TABLE IF EXISTS `agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent` (
  `active` bit(1) DEFAULT NULL,
  `agent_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `eligible_for_commission` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `agent_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK587430535710DFD` (`id`),
  KEY `FK5874305C29632A5` (`agent_type_id`),
  CONSTRAINT `FK5874305C29632A5` FOREIGN KEY (`agent_type_id`) REFERENCES `agent_type` (`id`),
  CONSTRAINT `FK587430535710DFD` FOREIGN KEY (`id`) REFERENCES `person_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent_aud`
--

DROP TABLE IF EXISTS `agent_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `agent_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `eligible_for_commission` bit(1) DEFAULT NULL,
  `agent_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK9AA0E27621902F91` (`id`,`REV`),
  CONSTRAINT `FK9AA0E27621902F91` FOREIGN KEY (`id`, `REV`) REFERENCES `person_role_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agent_type`
--

DROP TABLE IF EXISTS `agent_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agent_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `applicable_product`
--

DROP TABLE IF EXISTS `applicable_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applicable_product` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `excluded` bit(1) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `division_id` bigint(20) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3091F84F60447A1A` (`employer_id`),
  KEY `FK3091F84FC3A1DCDA` (`division_id`),
  CONSTRAINT `FK3091F84FC3A1DCDA` FOREIGN KEY (`division_id`) REFERENCES `division` (`id`),
  CONSTRAINT `FK3091F84F60447A1A` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_approval_status`
--

DROP TABLE IF EXISTS `application_approval_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_approval_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_approval_status_aud`
--

DROP TABLE IF EXISTS `application_approval_status_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_approval_status_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK2F9372F0DF74E053` (`REV`),
  CONSTRAINT `FK2F9372F0DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_decision`
--

DROP TABLE IF EXISTS `application_decision`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_decision` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `approved` bit(1) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK892255EBB85F88C3` (`loan_application_id`),
  CONSTRAINT `FK892255EBB85F88C3` FOREIGN KEY (`loan_application_id`) REFERENCES `loan_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_decision_aud`
--

DROP TABLE IF EXISTS `application_decision_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_decision_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `approved` bit(1) DEFAULT NULL,
  `decision_date` datetime DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE30C125CDF74E053` (`REV`),
  CONSTRAINT `FKE30C125CDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_decision_reason`
--

DROP TABLE IF EXISTS `application_decision_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_decision_reason` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `application_decision_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD5EDCB18646ED525` (`application_decision_id`),
  CONSTRAINT `FKD5EDCB18646ED525` FOREIGN KEY (`application_decision_id`) REFERENCES `application_decision` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_decision_reason_aud`
--

DROP TABLE IF EXISTS `application_decision_reason_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_decision_reason_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `application_decision_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK458F2909DF74E053` (`REV`),
  CONSTRAINT `FK458F2909DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_status_reason`
--

DROP TABLE IF EXISTS `application_status_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_status_reason` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `application_status_reason_aud`
--

DROP TABLE IF EXISTS `application_status_reason_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `application_status_reason_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK409D2F73DF74E053` (`REV`),
  CONSTRAINT `FK409D2F73DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `approval`
--

DROP TABLE IF EXISTS `approval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `approval` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_time_created` datetime DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `statusCode` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `step_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `check_list_item_document_id` bigint(20) DEFAULT NULL,
  `check_list_item_reason_code_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK46A5664338CE8ED9` (`check_list_item_document_id`),
  KEY `FK46A5664314084946` (`check_list_item_reason_code_id`),
  CONSTRAINT `FK46A5664314084946` FOREIGN KEY (`check_list_item_reason_code_id`) REFERENCES `check_list_item_reason_code` (`id`),
  CONSTRAINT `FK46A5664338CE8ED9` FOREIGN KEY (`check_list_item_document_id`) REFERENCES `check_list_item_document` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank`
--

DROP TABLE IF EXISTS `bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank` (
  `enabled` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `bank_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2E063C9E07B20A` (`bank_type_id`),
  KEY `FK2E063C17FBE4CA` (`id`),
  CONSTRAINT `FK2E063C17FBE4CA` FOREIGN KEY (`id`) REFERENCES `financial_institution` (`id`),
  CONSTRAINT `FK2E063C9E07B20A` FOREIGN KEY (`bank_type_id`) REFERENCES `bank_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_account`
--

DROP TABLE IF EXISTS `bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_account` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_holder` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_account_status_id` bigint(20) DEFAULT NULL,
  `bank_account_type_id` bigint(20) DEFAULT NULL,
  `bank_branch_id` bigint(20) DEFAULT NULL,
  `party_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK93353B2ACDE0D50A` (`bank_branch_id`),
  KEY `FK93353B2A88AEC1FF` (`bank_account_status_id`),
  KEY `FK93353B2A2CCABA3F` (`bank_account_type_id`),
  KEY `FK93353B2A57D50E23` (`party_id`),
  CONSTRAINT `FK93353B2A57D50E23` FOREIGN KEY (`party_id`) REFERENCES `party` (`id`),
  CONSTRAINT `FK93353B2A2CCABA3F` FOREIGN KEY (`bank_account_type_id`) REFERENCES `bank_account_type` (`id`),
  CONSTRAINT `FK93353B2A88AEC1FF` FOREIGN KEY (`bank_account_status_id`) REFERENCES `bank_account_status` (`id`),
  CONSTRAINT `FK93353B2ACDE0D50A` FOREIGN KEY (`bank_branch_id`) REFERENCES `bank_branch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_account_number_configuration`
--

DROP TABLE IF EXISTS `bank_account_number_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_account_number_configuration` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `bank_account_digit_quantity` int(11) DEFAULT NULL,
  `branch_code_digit_offset` int(11) DEFAULT NULL,
  `branch_code_digit_quantity` int(11) DEFAULT NULL,
  `bank_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE0F18C75D76C0F1` (`bank_id`),
  CONSTRAINT `FKE0F18C75D76C0F1` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_account_status`
--

DROP TABLE IF EXISTS `bank_account_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_account_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_account_type`
--

DROP TABLE IF EXISTS `bank_account_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_account_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_branch`
--

DROP TABLE IF EXISTS `bank_branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_branch` (
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `bank_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKFF04E105B790E4D9` (`id`),
  KEY `FKFF04E105D76C0F1` (`bank_id`),
  CONSTRAINT `FKFF04E105D76C0F1` FOREIGN KEY (`bank_id`) REFERENCES `bank` (`id`),
  CONSTRAINT `FKFF04E105B790E4D9` FOREIGN KEY (`id`) REFERENCES `organisation_unit` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_type`
--

DROP TABLE IF EXISTS `bank_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bayport_colombia_payroll_deduction_loan_application`
--

DROP TABLE IF EXISTS `bayport_colombia_payroll_deduction_loan_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bayport_colombia_payroll_deduction_loan_application` (
  `trading_entity_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK20C08C148245C441` (`id`),
  CONSTRAINT `FK20C08C148245C441` FOREIGN KEY (`id`) REFERENCES `payroll_deduction_loan_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blacklist`
--

DROP TABLE IF EXISTS `blacklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blacklist` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list`
--

DROP TABLE IF EXISTS `check_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list` (
  `id` bigint(20) NOT NULL,
  `created` datetime DEFAULT NULL,
  `definition_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `target_resource_id` bigint(20) DEFAULT NULL,
  `target_resource_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `task_id` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `target_resource_name` (`target_resource_name`,`target_resource_id`,`definition_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_definition`
--

DROP TABLE IF EXISTS `check_list_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_definition` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `source_resource_id` bigint(20) DEFAULT NULL,
  `source_resource_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`,`source_resource_name`,`source_resource_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item`
--

DROP TABLE IF EXISTS `check_list_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item` (
  `id` bigint(20) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_order` bigint(20) DEFAULT NULL,
  `required` bit(1) DEFAULT NULL,
  `check_list_id` bigint(20) DEFAULT NULL,
  `check_list_item_definition_id` bigint(20) DEFAULT NULL,
  `process_variable_key` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_updated` datetime DEFAULT NULL,
  `username` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2F356B9D911BC019` (`check_list_item_definition_id`),
  KEY `FK2F356B9D3597DD73` (`check_list_id`),
  CONSTRAINT `FK2F356B9D3597DD73` FOREIGN KEY (`check_list_id`) REFERENCES `check_list` (`id`),
  CONSTRAINT `FK2F356B9D911BC019` FOREIGN KEY (`check_list_item_definition_id`) REFERENCES `check_list_item_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_check_box`
--

DROP TABLE IF EXISTS `check_list_item_check_box`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_check_box` (
  `checked` bit(1) NOT NULL,
  `reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `reason_code_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK16F513F28C60EA9C` (`id`),
  KEY `FK16F513F28D3F9464` (`reason_code_id`),
  CONSTRAINT `FK16F513F28D3F9464` FOREIGN KEY (`reason_code_id`) REFERENCES `check_list_item_reason_code` (`id`),
  CONSTRAINT `FK16F513F28C60EA9C` FOREIGN KEY (`id`) REFERENCES `check_list_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_check_box_definition`
--

DROP TABLE IF EXISTS `check_list_item_check_box_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_check_box_definition` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE786EBC04449CECF` (`id`),
  CONSTRAINT `FKE786EBC04449CECF` FOREIGN KEY (`id`) REFERENCES `check_list_item_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_check_box_info`
--

DROP TABLE IF EXISTS `check_list_item_check_box_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_check_box_info` (
  `info` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `info_trigger_type` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK89FB0DB5624E15F` (`id`),
  CONSTRAINT `FK89FB0DB5624E15F` FOREIGN KEY (`id`) REFERENCES `check_list_item_check_box` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_check_box_info_definition`
--

DROP TABLE IF EXISTS `check_list_item_check_box_info_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_check_box_info_definition` (
  `info_trigger_type` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6912533724466DD2` (`id`),
  CONSTRAINT `FK6912533724466DD2` FOREIGN KEY (`id`) REFERENCES `check_list_item_check_box_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_definition`
--

DROP TABLE IF EXISTS `check_list_item_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_definition` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `enabled` bit(1) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item_order` bigint(20) DEFAULT NULL,
  `required` bit(1) NOT NULL,
  `check_list_definition_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKAA23AB35582B6F7E` (`check_list_definition_id`),
  CONSTRAINT `FKAA23AB35582B6F7E` FOREIGN KEY (`check_list_definition_id`) REFERENCES `check_list_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_document`
--

DROP TABLE IF EXISTS `check_list_item_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_document` (
  `approval_required` bit(1) DEFAULT NULL,
  `approved` bit(1) NOT NULL,
  `document_reference` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `required_approval_met` bit(1) NOT NULL,
  `required_approval_role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded` tinyblob,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD87F577D8C60EA9C` (`id`),
  CONSTRAINT `FKD87F577D8C60EA9C` FOREIGN KEY (`id`) REFERENCES `check_list_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_document_definition`
--

DROP TABLE IF EXISTS `check_list_item_document_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_document_definition` (
  `approval_required` bit(1) NOT NULL,
  `required_approval_role` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK577993554449CECF` (`id`),
  CONSTRAINT `FK577993554449CECF` FOREIGN KEY (`id`) REFERENCES `check_list_item_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_document_history`
--

DROP TABLE IF EXISTS `check_list_item_document_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_document_history` (
  `id` bigint(20) NOT NULL,
  `document_reference` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded` datetime DEFAULT NULL,
  `check_list_item_document` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK547215D26665939` (`check_list_item_document`),
  CONSTRAINT `FK547215D26665939` FOREIGN KEY (`check_list_item_document`) REFERENCES `check_list_item_document` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `check_list_item_reason_code`
--

DROP TABLE IF EXISTS `check_list_item_reason_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `check_list_item_reason_code` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cheque_number_allocation`
--

DROP TABLE IF EXISTS `cheque_number_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cheque_number_allocation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `allocation_time` datetime DEFAULT NULL,
  `cheque_number` int(11) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payable_type_id` bigint(20) DEFAULT NULL,
  `range_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKFE0308F84F642578` (`range_id`),
  KEY `FKFE0308F873D338E7` (`payable_type_id`),
  CONSTRAINT `FKFE0308F873D338E7` FOREIGN KEY (`payable_type_id`) REFERENCES `payable_type` (`id`),
  CONSTRAINT `FKFE0308F84F642578` FOREIGN KEY (`range_id`) REFERENCES `cheque_number_range` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cheque_number_range`
--

DROP TABLE IF EXISTS `cheque_number_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cheque_number_range` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `first_number` int(11) NOT NULL,
  `last_number` int(11) NOT NULL,
  `next_available` int(11) DEFAULT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCC36D2251F499A0A` (`bank_account_id`),
  CONSTRAINT `FKCC36D2251F499A0A` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2E996B15471431` (`region_id`),
  CONSTRAINT `FK2E996B15471431` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKAF12F3CBF90F4B40` (`id`),
  CONSTRAINT `FKAF12F3CBF90F4B40` FOREIGN KEY (`id`) REFERENCES `party_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_aud`
--

DROP TABLE IF EXISTS `client_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK41BAC03C45781354` (`id`,`REV`),
  CONSTRAINT `FK41BAC03C45781354` FOREIGN KEY (`id`, `REV`) REFERENCES `party_role_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_credit_bureau_listing`
--

DROP TABLE IF EXISTS `client_credit_bureau_listing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_credit_bureau_listing` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `reference_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registered_date` datetime DEFAULT NULL,
  `credit_bureau_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK304018514D1BC84D` (`credit_bureau_id`),
  CONSTRAINT `FK304018514D1BC84D` FOREIGN KEY (`credit_bureau_id`) REFERENCES `credit_bureau` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_reference`
--

DROP TABLE IF EXISTS `client_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_reference` (
  `employer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relationship_months` int(11) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verified` bit(1) DEFAULT NULL,
  `verified_date` datetime DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `client_reference_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK17B52BD7E55660B2` (`client_reference_type_id`),
  KEY `FK17B52BD735710DFD` (`id`),
  CONSTRAINT `FK17B52BD735710DFD` FOREIGN KEY (`id`) REFERENCES `person_role` (`id`),
  CONSTRAINT `FK17B52BD7E55660B2` FOREIGN KEY (`client_reference_type_id`) REFERENCES `client_reference_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_reference_type`
--

DROP TABLE IF EXISTS `client_reference_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_reference_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission`
--

DROP TABLE IF EXISTS `commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `monthly_effective_min` decimal(19,2) DEFAULT NULL,
  `per_loan_fixed` decimal(19,2) DEFAULT NULL,
  `percent_loan_value` decimal(19,2) DEFAULT NULL,
  `agent_id` bigint(20) NOT NULL,
  `commission_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3CB17CEB48B8B95A` (`agent_id`),
  KEY `FK3CB17CEBCEE47129` (`commission_type_id`),
  CONSTRAINT `FK3CB17CEBCEE47129` FOREIGN KEY (`commission_type_id`) REFERENCES `commission_type` (`id`),
  CONSTRAINT `FK3CB17CEB48B8B95A` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_aud`
--

DROP TABLE IF EXISTS `commission_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `monthly_effective_min` decimal(19,2) DEFAULT NULL,
  `per_loan_fixed` decimal(19,2) DEFAULT NULL,
  `percent_loan_value` decimal(19,2) DEFAULT NULL,
  `agent_id` bigint(20) DEFAULT NULL,
  `commission_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK5CAFB95CDF74E053` (`REV`),
  CONSTRAINT `FK5CAFB95CDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_payment_schedule_type`
--

DROP TABLE IF EXISTS `commission_payment_schedule_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_payment_schedule_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_structure`
--

DROP TABLE IF EXISTS `commission_structure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_structure` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `minimum_active_loans` int(11) DEFAULT NULL,
  `per_loan_fixed` decimal(19,2) DEFAULT NULL,
  `per_loan_percent_value` float DEFAULT NULL,
  `per_month_fixed` decimal(19,2) DEFAULT NULL,
  `per_month_percent_value` float DEFAULT NULL,
  `commission_payment_schedule_type_id` bigint(20) NOT NULL,
  `deduction_arrangement_relationship_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF7D4BB1FD1126428` (`deduction_arrangement_relationship_id`),
  KEY `FKF7D4BB1F3761D4B9` (`commission_payment_schedule_type_id`),
  CONSTRAINT `FKF7D4BB1F3761D4B9` FOREIGN KEY (`commission_payment_schedule_type_id`) REFERENCES `commission_payment_schedule_type` (`id`),
  CONSTRAINT `FKF7D4BB1FD1126428` FOREIGN KEY (`deduction_arrangement_relationship_id`) REFERENCES `deduction_arrangement_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commission_type`
--

DROP TABLE IF EXISTS `commission_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commission_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `confirmation_detail_type`
--

DROP TABLE IF EXISTS `confirmation_detail_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `confirmation_detail_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `confirmation_detail_type_aud`
--

DROP TABLE IF EXISTS `confirmation_detail_type_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `confirmation_detail_type_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK9AC84FDF74E053` (`REV`),
  CONSTRAINT `FK9AC84FDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `id` bigint(20) NOT NULL,
  `contact_role_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK38B7242035710DFD` (`id`),
  KEY `FK38B72420798E86A3` (`contact_role_id`),
  CONSTRAINT `FK38B72420798E86A3` FOREIGN KEY (`contact_role_id`) REFERENCES `contact_role` (`id`),
  CONSTRAINT `FK38B7242035710DFD` FOREIGN KEY (`id`) REFERENCES `person_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_number`
--

DROP TABLE IF EXISTS `contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_number` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE5A6D048B7FF5255` (`contact_number_type_id`),
  CONSTRAINT `FKE5A6D048B7FF5255` FOREIGN KEY (`contact_number_type_id`) REFERENCES `contact_number_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_number_type`
--

DROP TABLE IF EXISTS `contact_number_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_number_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_role`
--

DROP TABLE IF EXISTS `contact_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_role` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `currency_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK39175796AB91C151` (`currency_id`),
  CONSTRAINT `FK39175796AB91C151` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `courier_company`
--

DROP TABLE IF EXISTS `courier_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courier_company` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `credit_bureau`
--

DROP TABLE IF EXISTS `credit_bureau`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_bureau` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `credit_bureau_status`
--

DROP TABLE IF EXISTS `credit_bureau_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_bureau_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `credit_bureau_status_aud`
--

DROP TABLE IF EXISTS `credit_bureau_status_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_bureau_status_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKEE53FA02DF74E053` (`REV`),
  CONSTRAINT `FKEE53FA02DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `credit_reference`
--

DROP TABLE IF EXISTS `credit_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_reference` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `entity_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmation_detail_type_id` bigint(20) DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK96674185B85F88C3` (`loan_application_id`),
  KEY `FK9667418531FCC8B2` (`confirmation_detail_type_id`),
  CONSTRAINT `FK9667418531FCC8B2` FOREIGN KEY (`confirmation_detail_type_id`) REFERENCES `confirmation_detail_type` (`id`),
  CONSTRAINT `FK96674185B85F88C3` FOREIGN KEY (`loan_application_id`) REFERENCES `loan_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `credit_reference_aud`
--

DROP TABLE IF EXISTS `credit_reference_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credit_reference_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_person` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_contacted` datetime DEFAULT NULL,
  `entity_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmation_detail_type_id` bigint(20) DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKA65DA0F6DF74E053` (`REV`),
  CONSTRAINT `FKA65DA0F6DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_field`
--

DROP TABLE IF EXISTS `custom_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `custom_field_definition_id` bigint(20) NOT NULL,
  `employment_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2ACD76AC8F19F4F8` (`custom_field_definition_id`),
  KEY `FK2ACD76AC8AA6CBB2` (`employment_id`),
  CONSTRAINT `FK2ACD76AC8AA6CBB2` FOREIGN KEY (`employment_id`) REFERENCES `employment` (`id`),
  CONSTRAINT `FK2ACD76AC8F19F4F8` FOREIGN KEY (`custom_field_definition_id`) REFERENCES `custom_field_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `custom_field_definition`
--

DROP TABLE IF EXISTS `custom_field_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_field_definition` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `required` bit(1) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `employer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK150F70C660447A1A` (`employer_id`),
  CONSTRAINT `FK150F70C660447A1A` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_arrangement_relationship`
--

DROP TABLE IF EXISTS `deduction_arrangement_relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_arrangement_relationship` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK836CDBE7E0F92202` (`id`),
  CONSTRAINT `FK836CDBE7E0F92202` FOREIGN KEY (`id`) REFERENCES `party_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_authorisation`
--

DROP TABLE IF EXISTS `deduction_authorisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_authorisation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `auth_centralised` bit(1) DEFAULT NULL,
  `does_submission` bit(1) DEFAULT NULL,
  `employer_auth_required` bit(1) DEFAULT NULL,
  `gives_affordability` bit(1) DEFAULT NULL,
  `set_aside` bit(1) DEFAULT NULL,
  `signature_document` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verifies_labour_information` bit(1) DEFAULT NULL,
  `deduction_arrangement_relationship_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK64D051C6D1126428` (`deduction_arrangement_relationship_id`),
  CONSTRAINT `FK64D051C6D1126428` FOREIGN KEY (`deduction_arrangement_relationship_id`) REFERENCES `deduction_arrangement_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_configuration`
--

DROP TABLE IF EXISTS `deduction_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_configuration` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `day_in_period_payment_due` int(11) DEFAULT NULL,
  `day_in_period_submissions_due` int(11) DEFAULT NULL,
  `deduction_frequency` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `errors_delivered` bit(1) DEFAULT NULL,
  `errors_delivery_day` int(11) DEFAULT NULL,
  `errors_delivery_method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `errors_digital_format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `errors_email_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_means` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receipting_delivery_method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `submissions_delivery_method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `submissions_digital_format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `submissions_email_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deduction_arrangement_relationship_id` bigint(20) NOT NULL,
  `minimum_takehome_amount` bigint(20) DEFAULT NULL,
  `takehome_eligibility_amount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK368BD29CD1126428` (`deduction_arrangement_relationship_id`),
  CONSTRAINT `FK368BD29CD1126428` FOREIGN KEY (`deduction_arrangement_relationship_id`) REFERENCES `deduction_arrangement_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_configuration_supporting_checklist`
--

DROP TABLE IF EXISTS `deduction_configuration_supporting_checklist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_configuration_supporting_checklist` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `expected_target` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `deduction_configuration_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK81FA9BDD8C8357A7` (`deduction_configuration_id`),
  CONSTRAINT `FK81FA9BDD8C8357A7` FOREIGN KEY (`deduction_configuration_id`) REFERENCES `deduction_configuration` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_configuration_supporting_document`
--

DROP TABLE IF EXISTS `deduction_configuration_supporting_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_configuration_supporting_document` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `line_item_definition_id` bigint(20) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `required` bit(1) NOT NULL,
  `deduction_configuration_supporting_checklist_id` bigint(20) NOT NULL,
  `deduction_configuration_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK15C16404400BBD47` (`deduction_configuration_supporting_checklist_id`),
  KEY `FK15C164048C8357A7` (`deduction_configuration_id`),
  CONSTRAINT `FK15C164048C8357A7` FOREIGN KEY (`deduction_configuration_id`) REFERENCES `deduction_configuration` (`id`),
  CONSTRAINT `FK15C16404400BBD47` FOREIGN KEY (`deduction_configuration_supporting_checklist_id`) REFERENCES `deduction_configuration_supporting_checklist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK328E4352B790E4D9` (`id`),
  CONSTRAINT `FK328E4352B790E4D9` FOREIGN KEY (`id`) REFERENCES `organisation_unit` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement_detail`
--

DROP TABLE IF EXISTS `disbursement_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement_detail` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `detail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_reference` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `option_id` bigint(20) DEFAULT NULL,
  `option_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `disbursement_type_id` bigint(20) NOT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK402AF52FB85F88C3` (`loan_application_id`),
  KEY `FK402AF52F48ECCF73` (`disbursement_type_id`),
  CONSTRAINT `FK402AF52F48ECCF73` FOREIGN KEY (`disbursement_type_id`) REFERENCES `disbursement_type` (`id`),
  CONSTRAINT `FK402AF52FB85F88C3` FOREIGN KEY (`loan_application_id`) REFERENCES `loan_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement_detail_aud`
--

DROP TABLE IF EXISTS `disbursement_detail_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement_detail_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `detail` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_reference` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `option_id` bigint(20) DEFAULT NULL,
  `option_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `disbursement_type_id` bigint(20) DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK9A6B6FA0DF74E053` (`REV`),
  CONSTRAINT `FK9A6B6FA0DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement_type`
--

DROP TABLE IF EXISTS `disbursement_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement_type_aud`
--

DROP TABLE IF EXISTS `disbursement_type_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement_type_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK7AB22989DF74E053` (`REV`),
  CONSTRAINT `FK7AB22989DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `division`
--

DROP TABLE IF EXISTS `division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `division` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK15BD30ADB790E4D9` (`id`),
  CONSTRAINT `FK15BD30ADB790E4D9` FOREIGN KEY (`id`) REFERENCES `organisation_unit` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `document_type`
--

DROP TABLE IF EXISTS `document_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `dto_to_class_binding`
--

DROP TABLE IF EXISTS `dto_to_class_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dto_to_class_binding` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `class_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dto_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relevant_entity_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `education_level`
--

DROP TABLE IF EXISTS `education_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `education_level` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `email_address`
--

DROP TABLE IF EXISTS `email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_address` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4722E6AE35710DFD` (`id`),
  CONSTRAINT `FK4722E6AE35710DFD` FOREIGN KEY (`id`) REFERENCES `person_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer`
--

DROP TABLE IF EXISTS `employer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer` (
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `divisionId` bigint(20) DEFAULT NULL,
  `employee_count` int(11) DEFAULT NULL,
  `founding_date` datetime DEFAULT NULL,
  `registration_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `separate_paypoint` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `city_id` bigint(20) DEFAULT NULL,
  `employer_type_id` bigint(20) DEFAULT NULL,
  `industry_id` bigint(20) DEFAULT NULL,
  `region_id` bigint(20) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4722E6BBF90F4B40` (`id`),
  KEY `FK4722E6BBBAF1AC72` (`industry_id`),
  KEY `FK4722E6BB15471431` (`region_id`),
  KEY `FK4722E6BB8846B908` (`employer_type_id`),
  KEY `FK4722E6BB505F3E91` (`city_id`),
  CONSTRAINT `FK4722E6BB15471431` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`),
  CONSTRAINT `FK4722E6BB505F3E91` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FK4722E6BB8846B908` FOREIGN KEY (`employer_type_id`) REFERENCES `employer_type` (`id`),
  CONSTRAINT `FK4722E6BBBAF1AC72` FOREIGN KEY (`industry_id`) REFERENCES `industry` (`id`),
  CONSTRAINT `FK4722E6BBF90F4B40` FOREIGN KEY (`id`) REFERENCES `party_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer_application`
--

DROP TABLE IF EXISTS `employer_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_application` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `deduction_arrangement_relationship_id` bigint(20) DEFAULT NULL,
  `employer_application_approval_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_application_status_reason_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_application_status_reason_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCD4009CC1BD0E4F1` (`employer_application_status_reason_id`),
  CONSTRAINT `FKCD4009CC1BD0E4F1` FOREIGN KEY (`employer_application_status_reason_id`) REFERENCES `employer_application_status_reason` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer_application_aud`
--

DROP TABLE IF EXISTS `employer_application_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_application_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `deduction_arrangement_relationship_id` bigint(20) DEFAULT NULL,
  `employer_application_approval_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_application_status_reason_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_application_status_reason_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKB77AEDBDDF74E053` (`REV`),
  CONSTRAINT `FKB77AEDBDDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer_application_status_reason`
--

DROP TABLE IF EXISTS `employer_application_status_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_application_status_reason` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer_application_status_reason_aud`
--

DROP TABLE IF EXISTS `employer_application_status_reason_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_application_status_reason_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK8A478CEFDF74E053` (`REV`),
  CONSTRAINT `FK8A478CEFDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer_deduction_code`
--

DROP TABLE IF EXISTS `employer_deduction_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_deduction_code` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `issue_date` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `validity_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `validity_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deduction_arrangement_relationship_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD1E3178BD1126428` (`deduction_arrangement_relationship_id`),
  CONSTRAINT `FKD1E3178BD1126428` FOREIGN KEY (`deduction_arrangement_relationship_id`) REFERENCES `deduction_arrangement_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer_type`
--

DROP TABLE IF EXISTS `employer_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employment`
--

DROP TABLE IF EXISTS `employment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employment` (
  `employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `termination_reason_id` bigint(20) DEFAULT NULL,
  `occupation_id` bigint(20) DEFAULT NULL,
  `job_position_id` bigint(20) DEFAULT NULL,
  `occupation_status_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA07A3ECE0F92202` (`id`),
  KEY `FKA07A3EC35C73F6B` (`termination_reason_id`),
  KEY `FKA07A3ECF7DD0D51_idx` (`occupation_id`),
  KEY `FKA07A3ECA8AEEBFD_idx` (`job_position_id`),
  KEY `FKA07A3ECB24EF5E8_idx` (`occupation_status_id`),
  CONSTRAINT `FKA07A3ECF7DD0D51` FOREIGN KEY (`occupation_id`) REFERENCES `occupation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKA07A3ECA8AEEBFD` FOREIGN KEY (`job_position_id`) REFERENCES `job_position` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKA07A3ECB24EF5E8` FOREIGN KEY (`occupation_status_id`) REFERENCES `occupation_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FKA07A3EC35C73F6B` FOREIGN KEY (`termination_reason_id`) REFERENCES `termination_reason` (`id`),
  CONSTRAINT `FKA07A3ECE0F92202` FOREIGN KEY (`id`) REFERENCES `party_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `financial_institution`
--

DROP TABLE IF EXISTS `financial_institution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `financial_institution` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE49A5B02CC9773C2` (`id`),
  CONSTRAINT `FKE49A5B02CC9773C2` FOREIGN KEY (`id`) REFERENCES `organisation_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `first_instalment_schedule`
--

DROP TABLE IF EXISTS `first_instalment_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `first_instalment_schedule` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `cut_off_date` datetime DEFAULT NULL,
  `feid_date` datetime DEFAULT NULL,
  `enable` bit(1) DEFAULT NULL,
  `employer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE24DD6F860447A1A` (`employer_id`),
  CONSTRAINT `FKE24DD6F860447A1A` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fixed_term_loan_application`
--

DROP TABLE IF EXISTS `fixed_term_loan_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixed_term_loan_application` (
  `installment_amount` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `loan_duration_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9A739D69307EC045` (`id`),
  KEY `FK9A739D698CEA84D1` (`loan_duration_id`),
  CONSTRAINT `FK9A739D698CEA84D1` FOREIGN KEY (`loan_duration_id`) REFERENCES `loan_duration` (`id`),
  CONSTRAINT `FK9A739D69307EC045` FOREIGN KEY (`id`) REFERENCES `loan_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fixed_term_loan_application_aud`
--

DROP TABLE IF EXISTS `fixed_term_loan_application_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fixed_term_loan_application_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `installment_amount` bigint(20) DEFAULT NULL,
  `loan_duration_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKD3516ADA9E6B7DD9` (`id`,`REV`),
  CONSTRAINT `FKD3516ADA9E6B7DD9` FOREIGN KEY (`id`, `REV`) REFERENCES `loan_application_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gender`
--

DROP TABLE IF EXISTS `gender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gender` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `guarantor`
--

DROP TABLE IF EXISTS `guarantor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guarantor` (
  `current_employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF4C1BFCBF90F4B40` (`id`),
  CONSTRAINT `FKF4C1BFCBF90F4B40` FOREIGN KEY (`id`) REFERENCES `party_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `guarantor_aud`
--

DROP TABLE IF EXISTS `guarantor_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guarantor_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `current_employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK3B238C3C45781354` (`id`,`REV`),
  CONSTRAINT `FK3B238C3C45781354` FOREIGN KEY (`id`, `REV`) REFERENCES `party_role_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hibernate_sequences`
--

DROP TABLE IF EXISTS `hibernate_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequences` (
  `sequence_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `next_val` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`sequence_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `id_type`
--

DROP TABLE IF EXISTS `id_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `id_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `industry`
--

DROP TABLE IF EXISTS `industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industry` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `instrumentation`
--

DROP TABLE IF EXISTS `instrumentation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instrumentation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `param_string` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `param_date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `param_integer` int(10) unsigned NOT NULL DEFAULT '0',
  `param_boolean` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `job_position`
--

DROP TABLE IF EXISTS `job_position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_position` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `labour_environment`
--

DROP TABLE IF EXISTS `labour_environment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `labour_environment` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `anticipated_retrenched_employee_count` int(11) DEFAULT NULL,
  `average_employment_period` int(11) DEFAULT NULL,
  `contract_worker_count` int(11) DEFAULT NULL,
  `fulltime_employer_count` int(11) DEFAULT NULL,
  `in_first_year_employee_count` int(11) DEFAULT NULL,
  `last_year_retrenched_employee_count` int(11) DEFAULT NULL,
  `loan_scheme_employee_count` int(11) DEFAULT NULL,
  `pensioned_worker_count` int(11) DEFAULT NULL,
  `temporary_worker_count` int(11) DEFAULT NULL,
  `undefined_worker_count` int(11) DEFAULT NULL,
  `employer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1466207360447A1A` (`employer_id`),
  CONSTRAINT `FK1466207360447A1A` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lawyer`
--

DROP TABLE IF EXISTS `lawyer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lawyer` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lending_arrangement_relationship`
--

DROP TABLE IF EXISTS `lending_arrangement_relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lending_arrangement_relationship` (
  `id` bigint(20) NOT NULL,
  `deduction_arrangement_relationship_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1C074F79D1126428` (`deduction_arrangement_relationship_id`),
  KEY `FK1C074F79E0F92202` (`id`),
  CONSTRAINT `FK1C074F79E0F92202` FOREIGN KEY (`id`) REFERENCES `party_relationship` (`id`),
  CONSTRAINT `FK1C074F79D1126428` FOREIGN KEY (`deduction_arrangement_relationship_id`) REFERENCES `deduction_arrangement_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_application`
--

DROP TABLE IF EXISTS `loan_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_application` (
  `account_id` bigint(20) DEFAULT NULL,
  `application_status_reason_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `contract_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `disbursement_amount` bigint(20) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `loan_amount` bigint(20) DEFAULT NULL,
  `loan_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `selected_product_id` bigint(20) DEFAULT NULL,
  `total_payable` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `agent_id` bigint(20) DEFAULT NULL,
  `application_approval_status_id` bigint(20) DEFAULT NULL,
  `application_status_reason` bigint(20) DEFAULT NULL,
  `credit_bureau_status_id` bigint(20) DEFAULT NULL,
  `outlet_id` bigint(20) DEFAULT NULL,
  `application_creator` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6893408187691ACA` (`application_approval_status_id`),
  KEY `FK68934081C6A120D4` (`id`),
  KEY `FK68934081C666B0DA` (`outlet_id`),
  KEY `FK68934081F5D33FB2` (`application_status_reason`),
  KEY `FK6893408148B8B95A` (`agent_id`),
  KEY `FK689340819017A3A6` (`credit_bureau_status_id`),
  CONSTRAINT `FK6893408148B8B95A` FOREIGN KEY (`agent_id`) REFERENCES `agent` (`id`),
  CONSTRAINT `FK6893408187691ACA` FOREIGN KEY (`application_approval_status_id`) REFERENCES `application_approval_status` (`id`),
  CONSTRAINT `FK689340819017A3A6` FOREIGN KEY (`credit_bureau_status_id`) REFERENCES `credit_bureau_status` (`id`),
  CONSTRAINT `FK68934081C666B0DA` FOREIGN KEY (`outlet_id`) REFERENCES `outlet` (`id`),
  CONSTRAINT `FK68934081C6A120D4` FOREIGN KEY (`id`) REFERENCES `account_application` (`id`),
  CONSTRAINT `FK68934081F5D33FB2` FOREIGN KEY (`application_status_reason`) REFERENCES `application_status_reason` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_application_aud`
--

DROP TABLE IF EXISTS `loan_application_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_application_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `application_status_reason_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `contract_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `disbursement_amount` bigint(20) DEFAULT NULL,
  `last_updated` datetime DEFAULT NULL,
  `loan_amount` bigint(20) DEFAULT NULL,
  `loan_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `selected_product_id` bigint(20) DEFAULT NULL,
  `total_payable` bigint(20) DEFAULT NULL,
  `agent_id` bigint(20) DEFAULT NULL,
  `application_approval_status_id` bigint(20) DEFAULT NULL,
  `application_status_reason` bigint(20) DEFAULT NULL,
  `credit_bureau_status_id` bigint(20) DEFAULT NULL,
  `outlet_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK7439C1F2A43CFEE8` (`id`,`REV`),
  CONSTRAINT `FK7439C1F2A43CFEE8` FOREIGN KEY (`id`, `REV`) REFERENCES `account_application_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_duration`
--

DROP TABLE IF EXISTS `loan_duration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_duration` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `loan_duration_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE62D4803F3079058` (`loan_duration_type_id`),
  CONSTRAINT `FKE62D4803F3079058` FOREIGN KEY (`loan_duration_type_id`) REFERENCES `loan_duration_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_duration_aud`
--

DROP TABLE IF EXISTS `loan_duration_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_duration_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `loan_duration_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKFEA03874DF74E053` (`REV`),
  CONSTRAINT `FKFEA03874DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_duration_type`
--

DROP TABLE IF EXISTS `loan_duration_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_duration_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_duration_type_aud`
--

DROP TABLE IF EXISTS `loan_duration_type_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_duration_type_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK1E3A48E7DF74E053` (`REV`),
  CONSTRAINT `FK1E3A48E7DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_guarantee_relationship`
--

DROP TABLE IF EXISTS `loan_guarantee_relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_guarantee_relationship` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7C288ABEE0F92202` (`id`),
  CONSTRAINT `FK7C288ABEE0F92202` FOREIGN KEY (`id`) REFERENCES `party_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lookup_index`
--

DROP TABLE IF EXISTS `lookup_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookup_index` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `lookup_entity` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lookup_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_property_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_lookup_index` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF785C1ADC525AE23` (`parent_lookup_index`),
  CONSTRAINT `FKF785C1ADC525AE23` FOREIGN KEY (`parent_lookup_index`) REFERENCES `lookup_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `marital_status`
--

DROP TABLE IF EXISTS `marital_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marital_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `note` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_time_created` datetime DEFAULT NULL,
  `note` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `processname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `taskid` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `taskname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dto_to_class_binding_id` bigint(20) NOT NULL,
  `task_definition_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK33AFF28B9C506F` (`dto_to_class_binding_id`),
  CONSTRAINT `FK33AFF28B9C506F` FOREIGN KEY (`dto_to_class_binding_id`) REFERENCES `dto_to_class_binding` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `occupation`
--

DROP TABLE IF EXISTS `occupation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `occupation_status`
--

DROP TABLE IF EXISTS `occupation_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupation_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organisation`
--

DROP TABLE IF EXISTS `organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisation` (
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sales_tax_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tax_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3A5300DA10F1762A` (`id`),
  CONSTRAINT `FK3A5300DA10F1762A` FOREIGN KEY (`id`) REFERENCES `party` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organisation_role`
--

DROP TABLE IF EXISTS `organisation_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisation_role` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBAFDB0BBF90F4B40` (`id`),
  CONSTRAINT `FKBAFDB0BBF90F4B40` FOREIGN KEY (`id`) REFERENCES `party_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organisation_role_aud`
--

DROP TABLE IF EXISTS `organisation_role_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisation_role_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKAF1D852C45781354` (`id`,`REV`),
  CONSTRAINT `FKAF1D852C45781354` FOREIGN KEY (`id`, `REV`) REFERENCES `party_role_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organisation_unit`
--

DROP TABLE IF EXISTS `organisation_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisation_unit` (
  `id` bigint(20) NOT NULL,
  `parent_organisation_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBAFF09C9CC9773C2` (`id`),
  KEY `FKBAFF09C94387F9EF` (`parent_organisation_id`),
  CONSTRAINT `FKBAFF09C94387F9EF` FOREIGN KEY (`parent_organisation_id`) REFERENCES `parent_organisation` (`id`),
  CONSTRAINT `FKBAFF09C9CC9773C2` FOREIGN KEY (`id`) REFERENCES `organisation_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organisation_unit_aud`
--

DROP TABLE IF EXISTS `organisation_unit_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisation_unit_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `parent_organisation_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKAD8FA73A4FD42AD6` (`id`,`REV`),
  CONSTRAINT `FKAD8FA73A4FD42AD6` FOREIGN KEY (`id`, `REV`) REFERENCES `organisation_role_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `outlet`
--

DROP TABLE IF EXISTS `outlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outlet` (
  `enabled` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `trading_entity_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC411080DB790E4D9` (`id`),
  KEY `FKC411080D90B3037D` (`trading_entity_id`),
  CONSTRAINT `FKC411080D90B3037D` FOREIGN KEY (`trading_entity_id`) REFERENCES `trading_entity` (`id`),
  CONSTRAINT `FKC411080DB790E4D9` FOREIGN KEY (`id`) REFERENCES `organisation_unit` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `outlet_aud`
--

DROP TABLE IF EXISTS `outlet_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `outlet_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `trading_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKC530E37E4FF1386D` (`id`,`REV`),
  CONSTRAINT `FKC530E37E4FF1386D` FOREIGN KEY (`id`, `REV`) REFERENCES `organisation_unit_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `packed_document`
--

DROP TABLE IF EXISTS `packed_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packed_document` (
  `id` bigint(20) NOT NULL,
  `check_list_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `deduction_batch_id` bigint(20) DEFAULT NULL,
  `deduction_batch_line_id` bigint(20) DEFAULT NULL,
  `destination_document_reference` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `document_pack_status` varchar(31) COLLATE utf8_unicode_ci DEFAULT NULL,
  `loan_account_id` bigint(20) DEFAULT NULL,
  `source_document_reference` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `target_type` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `parent_organisation`
--

DROP TABLE IF EXISTS `parent_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent_organisation` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK11BC464FCC9773C2` (`id`),
  CONSTRAINT `FK11BC464FCC9773C2` FOREIGN KEY (`id`) REFERENCES `organisation_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_address`
--

DROP TABLE IF EXISTS `party_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_address` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `address_id` bigint(20) NOT NULL,
  `party_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9F41179BD504E523` (`address_id`),
  KEY `FK9F41179B57D50E23` (`party_id`),
  CONSTRAINT `FK9F41179B57D50E23` FOREIGN KEY (`party_id`) REFERENCES `party` (`id`),
  CONSTRAINT `FK9F41179BD504E523` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_contact_number`
--

DROP TABLE IF EXISTS `party_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_contact_number` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  `party_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK36513AC1E5FBC524` (`contact_number_id`),
  KEY `FK36513AC157D50E23` (`party_id`),
  CONSTRAINT `FK36513AC157D50E23` FOREIGN KEY (`party_id`) REFERENCES `party` (`id`),
  CONSTRAINT `FK36513AC1E5FBC524` FOREIGN KEY (`contact_number_id`) REFERENCES `contact_number` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_email_address`
--

DROP TABLE IF EXISTS `party_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_email_address` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `email_address_id` bigint(20) NOT NULL,
  `party_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB3B414B857D50E23` (`party_id`),
  KEY `FKB3B414B8FFACD438` (`email_address_id`),
  CONSTRAINT `FKB3B414B8FFACD438` FOREIGN KEY (`email_address_id`) REFERENCES `email_address` (`id`),
  CONSTRAINT `FKB3B414B857D50E23` FOREIGN KEY (`party_id`) REFERENCES `party` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_relationship`
--

DROP TABLE IF EXISTS `party_relationship`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_relationship` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `party_relationship_type_id` bigint(20) DEFAULT NULL,
  `party_role_id_from` bigint(20) NOT NULL,
  `party_role_id_to` bigint(20) NOT NULL,
  `status_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKEF692AF1AD438C34` (`party_role_id_to`),
  KEY `FKEF692AF171620063` (`party_role_id_from`),
  KEY `FKEF692AF181F07DB3` (`party_relationship_type_id`),
  KEY `FKEF692AF1A1BCF2B6` (`status_type_id`),
  CONSTRAINT `FKEF692AF1A1BCF2B6` FOREIGN KEY (`status_type_id`) REFERENCES `status_type` (`id`),
  CONSTRAINT `FKEF692AF171620063` FOREIGN KEY (`party_role_id_from`) REFERENCES `party_role` (`id`),
  CONSTRAINT `FKEF692AF181F07DB3` FOREIGN KEY (`party_relationship_type_id`) REFERENCES `party_relationship_type` (`id`),
  CONSTRAINT `FKEF692AF1AD438C34` FOREIGN KEY (`party_role_id_to`) REFERENCES `party_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_relationship_type`
--

DROP TABLE IF EXISTS `party_relationship_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_relationship_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_type_id_from` bigint(20) DEFAULT NULL,
  `role_type_id_to` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK96724BC8E0986142` (`role_type_id_to`),
  KEY `FK96724BC8B1CC9871` (`role_type_id_from`),
  CONSTRAINT `FK96724BC8B1CC9871` FOREIGN KEY (`role_type_id_from`) REFERENCES `party_role_type` (`id`),
  CONSTRAINT `FK96724BC8E0986142` FOREIGN KEY (`role_type_id_to`) REFERENCES `party_role_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_role`
--

DROP TABLE IF EXISTS `party_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_role` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `party_id` bigint(20) NOT NULL,
  `role_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1C92FE2F2968D876` (`role_type_id`),
  KEY `FK1C92FE2F57D50E23` (`party_id`),
  CONSTRAINT `FK1C92FE2F57D50E23` FOREIGN KEY (`party_id`) REFERENCES `party` (`id`),
  CONSTRAINT `FK1C92FE2F2968D876` FOREIGN KEY (`role_type_id`) REFERENCES `party_role_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_role_aud`
--

DROP TABLE IF EXISTS `party_role_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_role_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `party_id` bigint(20) DEFAULT NULL,
  `role_type_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK81A6F8A0DF74E053` (`REV`),
  CONSTRAINT `FK81A6F8A0DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `party_role_type`
--

DROP TABLE IF EXISTS `party_role_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `party_role_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payable_bank_account`
--

DROP TABLE IF EXISTS `payable_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payable_bank_account` (
  `payable_type_id` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  PRIMARY KEY (`payable_type_id`,`bank_account_id`),
  KEY `FK326AC64773D338E7` (`payable_type_id`),
  KEY `FK326AC6471F499A0A` (`bank_account_id`),
  CONSTRAINT `FK326AC6471F499A0A` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_account` (`id`),
  CONSTRAINT `FK326AC64773D338E7` FOREIGN KEY (`payable_type_id`) REFERENCES `payable_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payable_type`
--

DROP TABLE IF EXISTS `payable_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payable_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_deduction_client`
--

DROP TABLE IF EXISTS `payroll_deduction_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_deduction_client` (
  `active` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4BE218BF376F5726` (`id`),
  CONSTRAINT `FK4BE218BF376F5726` FOREIGN KEY (`id`) REFERENCES `client` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_deduction_client_aud`
--

DROP TABLE IF EXISTS `payroll_deduction_client_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_deduction_client_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `active` bit(1) DEFAULT NULL,
  `current_employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `previous_employee_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE7C64B30FB83BC3A` (`id`,`REV`),
  CONSTRAINT `FKE7C64B30FB83BC3A` FOREIGN KEY (`id`, `REV`) REFERENCES `client_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_deduction_loan_application`
--

DROP TABLE IF EXISTS `payroll_deduction_loan_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_deduction_loan_application` (
  `id` bigint(20) NOT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `guarantor_id` bigint(20) DEFAULT NULL,
  `client_ID_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guarantor_ID_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guarantor_required` bit(1) DEFAULT NULL,
  `lending_arrangement_relationship_id` bigint(20) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA1BFC4752D1D791` (`id`),
  KEY `FKA1BFC4754EA5B9A` (`guarantor_id`),
  KEY `FKA1BFC475362C28FA` (`client_id`),
  CONSTRAINT `FKA1BFC4752D1D791` FOREIGN KEY (`id`) REFERENCES `fixed_term_loan_application` (`id`),
  CONSTRAINT `FKA1BFC475362C28FA` FOREIGN KEY (`client_id`) REFERENCES `payroll_deduction_client` (`id`),
  CONSTRAINT `FKA1BFC4754EA5B9A` FOREIGN KEY (`guarantor_id`) REFERENCES `guarantor` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payroll_deduction_loan_application_aud`
--

DROP TABLE IF EXISTS `payroll_deduction_loan_application_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payroll_deduction_loan_application_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `guarantor_id` bigint(20) DEFAULT NULL,
  `client_status_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guarantor_status_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `guarantor_required` bit(1) DEFAULT NULL,
  `lending_arrangement_relationship_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK7ADB2BE6578A0F25` (`id`,`REV`),
  CONSTRAINT `FK7ADB2BE6578A0F25` FOREIGN KEY (`id`, `REV`) REFERENCES `fixed_term_loan_application_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payslip`
--

DROP TABLE IF EXISTS `payslip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payslip` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `affordability` bigint(20) NOT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `employment_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD11F05E88AA6CBB2` (`employment_id`),
  CONSTRAINT `FKD11F05E88AA6CBB2` FOREIGN KEY (`employment_id`) REFERENCES `employment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payslip_line_item`
--

DROP TABLE IF EXISTS `payslip_line_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payslip_line_item` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `value` bigint(20) DEFAULT NULL,
  `payslip_id` bigint(20) NOT NULL,
  `payslip_line_item_definition_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD94D1AE799CFBD99` (`payslip_line_item_definition_id`),
  KEY `FKD94D1AE7B9FA0A42` (`payslip_id`),
  CONSTRAINT `FKD94D1AE7B9FA0A42` FOREIGN KEY (`payslip_id`) REFERENCES `payslip` (`id`),
  CONSTRAINT `FKD94D1AE799CFBD99` FOREIGN KEY (`payslip_line_item_definition_id`) REFERENCES `payslip_line_item_definition` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payslip_line_item_definition`
--

DROP TABLE IF EXISTS `payslip_line_item_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payslip_line_item_definition` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `required` bit(1) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `weight_percent` float DEFAULT NULL,
  `employer_id` bigint(20) NOT NULL,
  `payslip_line_item_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK451269AB43155B79` (`payslip_line_item_type_id`),
  KEY `FK451269AB60447A1A` (`employer_id`),
  CONSTRAINT `FK451269AB60447A1A` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`),
  CONSTRAINT `FK451269AB43155B79` FOREIGN KEY (`payslip_line_item_type_id`) REFERENCES `payslip_line_item_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payslip_line_item_type`
--

DROP TABLE IF EXISTS `payslip_line_item_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payslip_line_item_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `birth_date` datetime DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dependants` int(11) DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_issue_date` datetime DEFAULT NULL,
  `id_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_maiden_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_expire_date` datetime DEFAULT NULL,
  `passport_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suffix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_years_work_experience` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `birth_city_id` bigint(20) DEFAULT NULL,
  `education_level_id` bigint(20) DEFAULT NULL,
  `gender_id` bigint(20) DEFAULT NULL,
  `id_issue_city_id` bigint(20) DEFAULT NULL,
  `id_type_id` bigint(20) DEFAULT NULL,
  `marital_status_id` bigint(20) DEFAULT NULL,
  `occupation_id` bigint(20) DEFAULT NULL,
  `job_position_id` bigint(20) DEFAULT NULL,
  `occupation_status_id` bigint(20) DEFAULT NULL,
  `title_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC4E39B55CCC6511` (`gender_id`),
  KEY `FKC4E39B5510F1762A` (`id`),
  KEY `FKC4E39B55D5656A2C` (`marital_status_id`),
  KEY `FKC4E39B55A8AEEBFD` (`job_position_id`),
  KEY `FKC4E39B559C9DF907` (`id_issue_city_id`),
  KEY `FKC4E39B55F7DD0D51` (`occupation_id`),
  KEY `FKC4E39B55A1B780E3` (`title_id`),
  KEY `FKC4E39B55B24EF5E8` (`occupation_status_id`),
  KEY `FKC4E39B5577F7CB08` (`id_type_id`),
  KEY `FKC4E39B5580ED3B20` (`education_level_id`),
  KEY `FKC4E39B558DE02B11` (`birth_city_id`),
  CONSTRAINT `FKC4E39B558DE02B11` FOREIGN KEY (`birth_city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FKC4E39B5510F1762A` FOREIGN KEY (`id`) REFERENCES `party` (`id`),
  CONSTRAINT `FKC4E39B5577F7CB08` FOREIGN KEY (`id_type_id`) REFERENCES `id_type` (`id`),
  CONSTRAINT `FKC4E39B5580ED3B20` FOREIGN KEY (`education_level_id`) REFERENCES `education_level` (`id`),
  CONSTRAINT `FKC4E39B559C9DF907` FOREIGN KEY (`id_issue_city_id`) REFERENCES `city` (`id`),
  CONSTRAINT `FKC4E39B55A1B780E3` FOREIGN KEY (`title_id`) REFERENCES `title` (`id`),
  CONSTRAINT `FKC4E39B55A8AEEBFD` FOREIGN KEY (`job_position_id`) REFERENCES `job_position` (`id`),
  CONSTRAINT `FKC4E39B55B24EF5E8` FOREIGN KEY (`occupation_status_id`) REFERENCES `occupation_status` (`id`),
  CONSTRAINT `FKC4E39B55CCC6511` FOREIGN KEY (`gender_id`) REFERENCES `gender` (`id`),
  CONSTRAINT `FKC4E39B55D5656A2C` FOREIGN KEY (`marital_status_id`) REFERENCES `marital_status` (`id`),
  CONSTRAINT `FKC4E39B55F7DD0D51` FOREIGN KEY (`occupation_id`) REFERENCES `occupation` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `person_role`
--

DROP TABLE IF EXISTS `person_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person_role` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE6A16B20F90F4B40` (`id`),
  CONSTRAINT `FKE6A16B20F90F4B40` FOREIGN KEY (`id`) REFERENCES `party_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `person_role_aud`
--

DROP TABLE IF EXISTS `person_role_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person_role_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK93E3851145781354` (`id`,`REV`),
  CONSTRAINT `FK93E3851145781354` FOREIGN KEY (`id`, `REV`) REFERENCES `party_role_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `policy_code`
--

DROP TABLE IF EXISTS `policy_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `policy_code` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `additional_data` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `selected` bit(1) DEFAULT NULL,
  `deduction_arrangement_relationship_id` bigint(20) NOT NULL,
  `policy_code_definition_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK810D30DAD1126428` (`deduction_arrangement_relationship_id`),
  KEY `FK810D30DAA24A3D4C` (`policy_code_definition_id`),
  CONSTRAINT `FK810D30DAA24A3D4C` FOREIGN KEY (`policy_code_definition_id`) REFERENCES `policy_code_definition` (`id`),
  CONSTRAINT `FK810D30DAD1126428` FOREIGN KEY (`deduction_arrangement_relationship_id`) REFERENCES `deduction_arrangement_relationship` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `policy_code_definition`
--

DROP TABLE IF EXISTS `policy_code_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `policy_code_definition` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `additional_data_required` bit(1) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `field_description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `field_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipting_date`
--

DROP TABLE IF EXISTS `receipting_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipting_date` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_due` datetime DEFAULT NULL,
  `deduction_configuration_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK925E68238C8357A7` (`deduction_configuration_id`),
  CONSTRAINT `FK925E68238C8357A7` FOREIGN KEY (`deduction_configuration_id`) REFERENCES `deduction_configuration` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery`
--

DROP TABLE IF EXISTS `recovery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `recovery_note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recovery_results_note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  `recovery_reason_id` bigint(20) NOT NULL,
  `recovery_results_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD05E7F95B85F88C3` (`loan_application_id`),
  KEY `FKD05E7F957BAB479` (`recovery_results_id`),
  KEY `FKD05E7F952B480DB` (`recovery_reason_id`),
  CONSTRAINT `FKD05E7F952B480DB` FOREIGN KEY (`recovery_reason_id`) REFERENCES `recovery_reason` (`id`),
  CONSTRAINT `FKD05E7F957BAB479` FOREIGN KEY (`recovery_results_id`) REFERENCES `recovery_results` (`id`),
  CONSTRAINT `FKD05E7F95B85F88C3` FOREIGN KEY (`loan_application_id`) REFERENCES `loan_application` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_aud`
--

DROP TABLE IF EXISTS `recovery_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `recovery_note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recovery_results_note` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  `recovery_reason_id` bigint(20) DEFAULT NULL,
  `recovery_results_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK77675706DF74E053` (`REV`),
  CONSTRAINT `FK77675706DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_reason`
--

DROP TABLE IF EXISTS `recovery_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery_reason` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recovery_reason_category_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3EE94E2EE5A25998` (`recovery_reason_category_id`),
  CONSTRAINT `FK3EE94E2EE5A25998` FOREIGN KEY (`recovery_reason_category_id`) REFERENCES `recovery_reason_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_reason_aud`
--

DROP TABLE IF EXISTS `recovery_reason_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery_reason_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `recovery_reason_category_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKF047311FDF74E053` (`REV`),
  CONSTRAINT `FKF047311FDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_reason_category`
--

DROP TABLE IF EXISTS `recovery_reason_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery_reason_category` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_reason_category_aud`
--

DROP TABLE IF EXISTS `recovery_reason_category_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery_reason_category_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKC90BCE60DF74E053` (`REV`),
  CONSTRAINT `FKC90BCE60DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_results`
--

DROP TABLE IF EXISTS `recovery_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery_results` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recovery_results_aud`
--

DROP TABLE IF EXISTS `recovery_results_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recovery_results_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKC1D4213DDF74E053` (`REV`),
  CONSTRAINT `FKC1D4213DDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` bigint(20) NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC84826F4C5F0A9E3` (`country_id`),
  CONSTRAINT `FKC84826F4C5F0A9E3` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `residence_type`
--

DROP TABLE IF EXISTS `residence_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `residence_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resident_status`
--

DROP TABLE IF EXISTS `resident_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resident_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revinfo`
--

DROP TABLE IF EXISTS `revinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revinfo` (
  `REV` int(11) NOT NULL AUTO_INCREMENT,
  `REVTSTMP` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permission` (
  `role_id` bigint(20) NOT NULL,
  `permission_id` bigint(20) NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `FKBD40D5384DD88172` (`role_id`),
  KEY `FKBD40D538DD4E5CD2` (`permission_id`),
  CONSTRAINT `FKBD40D538DD4E5CD2` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`id`),
  CONSTRAINT `FKBD40D5384DD88172` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `salary_scale`
--

DROP TABLE IF EXISTS `salary_scale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salary_scale` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `salary_from` decimal(19,2) DEFAULT NULL,
  `salary_to` decimal(19,2) DEFAULT NULL,
  `employer_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK816369560447A1A` (`employer_id`),
  CONSTRAINT `FK816369560447A1A` FOREIGN KEY (`employer_id`) REFERENCES `employer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `status_type`
--

DROP TABLE IF EXISTS `status_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `submission_date`
--

DROP TABLE IF EXISTS `submission_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submission_date` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_due` datetime DEFAULT NULL,
  `deduction_configuration_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE2909CC18C8357A7` (`deduction_configuration_id`),
  CONSTRAINT `FKE2909CC18C8357A7` FOREIGN KEY (`deduction_configuration_id`) REFERENCES `deduction_configuration` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `suburb`
--

DROP TABLE IF EXISTS `suburb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suburb` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCADC5F25505F3E91` (`city_id`),
  CONSTRAINT `FKCADC5F25505F3E91` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_bank_account`
--

DROP TABLE IF EXISTS `system_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_bank_account` (
  `balance` bigint(20) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `system_bank_account_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK73B9773A5FB838D5` (`id`),
  CONSTRAINT `FK73B9773A5FB838D5` FOREIGN KEY (`id`) REFERENCES `bank_account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `currency_locale` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `timezone_offset` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `system_settings_ibfk_1` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `termination_reason`
--

DROP TABLE IF EXISTS `termination_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `termination_reason` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_party`
--

DROP TABLE IF EXISTS `third_party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_party` (
  `enabled` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1A321A0E17FBE4CA` (`id`),
  CONSTRAINT `FK1A321A0E17FBE4CA` FOREIGN KEY (`id`) REFERENCES `financial_institution` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `title`
--

DROP TABLE IF EXISTS `title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `title` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `trading_entity`
--

DROP TABLE IF EXISTS `trading_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trading_entity` (
  `id` bigint(20) NOT NULL,
  `entity_identifier` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA9ABC4C1CC9773C2` (`id`),
  CONSTRAINT `FKA9ABC4C1CC9773C2` FOREIGN KEY (`id`) REFERENCES `organisation_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `union_rep`
--

DROP TABLE IF EXISTS `union_rep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `union_rep` (
  `member_count` int(11) DEFAULT NULL,
  `union_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDC1B3F2D35710DFD` (`id`),
  CONSTRAINT `FKDC1B3F2D35710DFD` FOREIGN KEY (`id`) REFERENCES `person_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `job_position_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK36EBCB35710DFD` (`id`),
  KEY `FK36EBCBA8AEEBFD` (`job_position_id`),
  CONSTRAINT `FK36EBCBA8AEEBFD` FOREIGN KEY (`job_position_id`) REFERENCES `job_position` (`id`),
  CONSTRAINT `FK36EBCB35710DFD` FOREIGN KEY (`id`) REFERENCES `person_role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `FK143BF46A4DD88172` (`role_id`),
  KEY `FK143BF46A8B6EC01A` (`user_id`),
  CONSTRAINT `FK143BF46A8B6EC01A` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK143BF46A4DD88172` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `visiting_agent`
--

DROP TABLE IF EXISTS `visiting_agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `visiting_agent` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 15:51:23
