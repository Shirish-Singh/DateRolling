USE collections;
LOCK TABLES `lookup_index` WRITE;
/*!40000 ALTER TABLE `lookup_index` DISABLE KEYS */;
DELETE FROM `lookup_index` WHERE id in (55,56);
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`) 
VALUES
(55,'rahult',0,'com.qualica.flexifin.collections.domain.ContactScriptTemplate','ContactScriptTemplate','contactAttemptType',54),
(56,'rahult',0,'com.qualica.flexifin.collections.domain.CollectionInstanceSeverity','CollectionInstanceSeverity',NULL,NULL);
/*!40000 ALTER TABLE `lookup_index` ENABLE KEYS */;
UNLOCK TABLES;