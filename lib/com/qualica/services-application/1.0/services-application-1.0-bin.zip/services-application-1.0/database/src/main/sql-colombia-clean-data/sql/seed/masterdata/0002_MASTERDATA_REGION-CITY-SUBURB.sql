USE `masterdata`;

SET character_set_client = utf8;
--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1000001,NULL,0,'USA Dollars','','USA Dollars','US'),(1000002,NULL,0,'Bolivar','','Bolivar','BS'),(1000003,NULL,0,'Euro','','Euro','EUR');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1000001,NULL,0,'Ecuador','','Ecuador',NULL,'Ecuatoriano',1000001),(1000002,NULL,0,'Venezuela','','Venezuela',NULL,'Venezolano',1000002),(1000003,NULL,0,'Italia','','Italia',NULL,'Italiano',1000003);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;
