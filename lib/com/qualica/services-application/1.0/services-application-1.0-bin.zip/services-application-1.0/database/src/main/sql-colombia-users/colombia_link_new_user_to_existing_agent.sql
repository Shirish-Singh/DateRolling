-- find the Agent to link a new user to:

-- select p.first_name, p.last_name , p.id as partyId, a.id as agentId  from agent a join party_role pr on a.id = pr.id join person p on p.id = pr.party_id where p.first_name ='Agent';
-- +------------+-----------+---------+---------+
-- | first_name | last_name | partyId | agentId |
-- +------------+-----------+---------+---------+
-- | Agent      | Inbox     | 1000001 | 1000001 |
-- +------------+-----------+---------+---------+

-- create a party_role, person_role and user heirarchy and link to the same party as the agent.
INSERT INTO `PARTY_ROLE` (id, party_id, role_type_id, from_date, version) VALUES (6300001, 1000001, 10003, "2012-01-01", 0);
INSERT INTO `PERSON_ROLE` (id) VALUES (6300001);
INSERT INTO `USER` (id, job_position_id, username, password, enabled) VALUES (6300001,5,'agentInbox','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true);

-- add the AgentRestricted and User permissions (roles containing just those permissions)
INSERT INTO `user_role` (user_id,role_id) VALUES (6300001,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (6300001,2);
