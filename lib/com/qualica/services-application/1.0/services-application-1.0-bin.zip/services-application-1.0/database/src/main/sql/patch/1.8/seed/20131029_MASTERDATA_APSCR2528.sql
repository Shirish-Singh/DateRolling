use masterdata;

SET foreign_key_checks = 0;

DELETE FROM role_permission WHERE permission_id IN (2001,2002,3003,3004,3005,3028,3029,3030,3032);
DELETE FROM role_permission WHERE permission_id BETWEEN 3100 AND 3116;

DELETE FROM permission WHERE id IN (2001,2002,3003,3004,3005,3028,3029,3030,3032);
DELETE FROM permission WHERE id BETWEEN 3100 AND 3116;

DELETE FROM role WHERE id BETWEEN 129 AND 130;
DELETE FROM role WHERE id BETWEEN 200 AND 203;

INSERT INTO permission (id, modified_by, version, name) VALUES (3100, 'Hrishikesh', 0, 'ui.collections_downloading_batch');
INSERT INTO permission (id, modified_by, version, name) VALUES (3101, 'Hrishikesh', 0, 'ui.collections_assign_agent');
INSERT INTO permission (id, modified_by, version, name) VALUES (3102, 'Hrishikesh', 0, 'wf.reviewEscalation');
INSERT INTO permission (id, modified_by, version, name) VALUES (3103, 'Hrishikesh', 0, 'wf.identifyCollectionInstanceSeverity');
INSERT INTO permission (id, modified_by, version, name) VALUES (3104, 'Hrishikesh', 0, 'wf.sueDebtor');
INSERT INTO permission (id, modified_by, version, name) VALUES (3105, 'Hrishikesh', 0, 'wf.phoneDebtor');
INSERT INTO permission (id, modified_by, version, name) VALUES (3106, 'Hrishikesh', 0, 'ui.collections_case_search');
INSERT INTO permission (id, modified_by, version, name) VALUES (3107, 'Hrishikesh', 0, 'wf.assignCollectionAgent');
INSERT INTO permission (id, modified_by, version, name) VALUES (3108, 'Hrishikesh', 0, 'ui.collections_credit_listing_batch');
INSERT INTO permission (id, modified_by, version, name) VALUES (3109, 'Hrishikesh', 0, 'ui.collections_configuration');
INSERT INTO permission (id, modified_by, version, name) VALUES (3110, 'Hrishikesh', 0, 'ui.collections_discounts');
INSERT INTO permission (id, modified_by, version, name) VALUES (3111, 'Hrishikesh', 0, 'ui.collections_download_csv');
INSERT INTO permission (id, modified_by, version, name) VALUES (3112, 'Hrishikesh', 0, 'ui.change_collection_status');
INSERT INTO permission (id, modified_by, version, name) VALUES (3113, 'Hrishikesh', 0, 'wf.uploadProofOfPayment');
INSERT INTO permission (id, modified_by, version, name) VALUES (3114, 'Hrishikesh', 0, 'wf.assignCollectionCase');
INSERT INTO permission (id, modified_by, version, name) VALUES (3115, 'Hrishikesh', 0, 'wf.assignVisitingAgent');
INSERT INTO permission (id, modified_by, version, name) VALUES (3116, 'Hrishikesh', 0, 'wf.visitDebtor');


INSERT INTO role (id, modified_by, version, name) VALUES (200, 'Hrishikesh', 0, 'CollectionAgent');
INSERT INTO role (id, modified_by, version, name) VALUES (201, 'Hrishikesh', 0, 'CollectionCoordinator');
INSERT INTO role (id, modified_by, version, name) VALUES (202, 'Hrishikesh', 0, 'CollectionHead');
INSERT INTO role (id, modified_by, version, name) VALUES (203, 'Hrishikesh', 0, 'CollectionVisitingAgent');


-- Collection Agent (old id 130)
INSERT INTO role_permission (role_id, permission_id) VALUES (200, 3104);
INSERT INTO role_permission (role_id, permission_id) VALUES (200, 3105);
INSERT INTO role_permission (role_id, permission_id) VALUES (200, 3106);
INSERT INTO role_permission (role_id, permission_id) VALUES (200, 3112);
INSERT INTO role_permission (role_id, permission_id) VALUES (200, 3113);
INSERT INTO role_permission (role_id, permission_id) VALUES (200, 3115);

-- Collection Visiting Agent (old id 130)
INSERT INTO role_permission (role_id, permission_id) VALUES (203, 3116);


-- Collection Co-Ordinator (old id 129)
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3101);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3102);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3103);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3104);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3106);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3107);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3110);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3111);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3112);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3114);
INSERT INTO role_permission (role_id, permission_id) VALUES (201, 3115);

-- Collection Head
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3101);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3102);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3103);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3104);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3106);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3107);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3109);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3110);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3111);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3112);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3114);
INSERT INTO role_permission (role_id, permission_id) VALUES (202, 3115);


-- Assigning roles to current users if not assigned
UPDATE user_role SET role_id = 200 WHERE role_id = 130;
UPDATE user_role SET role_id = 201 WHERE role_id = 129;


SET foreign_key_checks = 1;
