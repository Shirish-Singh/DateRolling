use flexifinproduct;
-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: flexifinproduct
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `REVINFO`
--

LOCK TABLES `REVINFO` WRITE;
/*!40000 ALTER TABLE `REVINFO` DISABLE KEYS */;
/*!40000 ALTER TABLE `REVINFO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fee`
--

LOCK TABLES `fee` WRITE;
/*!40000 ALTER TABLE `fee` DISABLE KEYS */;
INSERT INTO `fee` (`type`, `id`, `modified_by`, `version`, `name`, `value`, `value_type`, `collection_frequency`, `collection_number`, `inclusive`, `recognition_plan`, `attracts_arrears`, `archived`, `enabled`, `balance_allocation_allowed`, `aval_allowed`, `insurance_allowed`, `partial_allowed`) VALUES ('Insurance',1,'N.Willemse',0,'Insurance',0.018000000,'PrincipalInterest',NULL,NULL,NULL,NULL,'\0',NULL,NULL,NULL,NULL,NULL,NULL),('Aval',2,'N.Willemse',0,'Aval',0.343900000,'PrincipalInterest',NULL,NULL,NULL,NULL,'\0',NULL,NULL,NULL,NULL,NULL,NULL),('AdminFeeAmortised',3,'N.Willemse',0,'Admin Fee Amortised',0.010000000,'PrincipalPercentage',NULL,NULL,NULL,NULL,'\0',NULL,NULL,NULL,NULL,NULL,NULL),('GPF',4,'S.Singh',0,'GPF',0.010000000,'PrincipalPercentage',NULL,NULL,NULL,NULL,'\0',NULL,NULL,NULL,NULL,NULL,NULL),('IAF',5,'R.Tiwari',0,'IAF',0.010000000,'PrincipalPercentage',NULL,NULL,NULL,NULL,'\0',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fee_mapping`
--

LOCK TABLES `fee_mapping` WRITE;
/*!40000 ALTER TABLE `fee_mapping` DISABLE KEYS */;
INSERT INTO `fee_mapping` (`id`, `modified_by`, `version`, `default_boolean`, `default_option`, `domain_property`, `enable_item`, `fee_type`, `option_name`, `options`, `show_item`) VALUES (100001,NULL,0,NULL,'OnceOff','collectionFrequency','\0','AdminFeeAmortised','com.qualica.flexifin.product.shared.CollectionFrequency','OnceOff',''),(100002,NULL,0,NULL,NULL,'collectionNumber','\0','AdminFeeAmortised',NULL,NULL,'\0'),(100003,NULL,0,'\0',NULL,'inclusive','\0','AdminFeeAmortised',NULL,NULL,''),(100004,NULL,0,NULL,'AmortisedCurve','recognitionPlan','\0','AdminFeeAmortised','com.qualica.flexifin.product.shared.RecognitionPlan','AmortisedCurve',''),(100005,NULL,0,NULL,'PrincipalPercentage','valueType','','AdminFeeAmortised','com.qualica.flexifin.product.shared.FeeValueType','FixedAmount|PrincipalPercentage',''),(100006,NULL,0,'\0',NULL,'partialInterestRate','\0','AdminFeeAmortised',NULL,NULL,'\0'),(100007,NULL,0,'\0',NULL,'avalInterestRate','\0','AdminFeeAmortised',NULL,NULL,'\0'),(100008,NULL,0,'\0',NULL,'insuranceInterestRate','\0','AdminFeeAmortised',NULL,NULL,'\0'),(100009,NULL,0,NULL,'OnceOff','collectionFrequency','\0','Aval','com.qualica.flexifin.product.shared.CollectionFrequency','OnceOff',''),(100010,NULL,0,NULL,NULL,'collectionNumber','\0','Aval',NULL,NULL,'\0'),(100011,NULL,0,'\0',NULL,'inclusive','\0','Aval',NULL,NULL,''),(100012,NULL,0,NULL,'AmortisedCurve','recognitionPlan','\0','Aval','com.qualica.flexifin.product.shared.RecognitionPlan','AmortisedCurve',''),(100013,NULL,0,NULL,'PrincipalInterest','valueType','\0','Aval','com.qualica.flexifin.product.shared.FeeValueType','PrincipalInterest',''),(100014,NULL,0,'\0',NULL,'partialInterestRate','\0','Aval',NULL,NULL,'\0'),(100015,NULL,0,'\0',NULL,'avalInterestRate','\0','Aval',NULL,NULL,'\0'),(100016,NULL,0,'\0',NULL,'insuranceInterestRate','\0','Aval',NULL,NULL,'\0'),(100017,NULL,0,NULL,'OnceOff','collectionFrequency','\0','Insurance','com.qualica.flexifin.product.shared.CollectionFrequency','OnceOff',''),(100018,NULL,0,NULL,NULL,'collectionNumber','\0','Insurance',NULL,NULL,'\0'),(100019,NULL,0,'\0',NULL,'inclusive','\0','Insurance',NULL,NULL,''),(100020,NULL,0,NULL,'AmortisedCurve','recognitionPlan','\0','Insurance','com.qualica.flexifin.product.shared.RecognitionPlan','AmortisedCurve',''),(100021,NULL,0,NULL,'PrincipalInterest','valueType','\0','Insurance','com.qualica.flexifin.product.shared.FeeValueType','PrincipalInterest',''),(100022,NULL,0,'\0',NULL,'partialInterestRate','\0','Insurance',NULL,NULL,'\0'),(100023,NULL,0,'\0',NULL,'avalInterestRate','\0','Insurance',NULL,NULL,'\0'),(100024,NULL,0,'\0',NULL,'insuranceInterestRate','\0','Insurance',NULL,NULL,'\0'),(100025,NULL,0,NULL,'OnceOff','collectionFrequency','\0','GPF','com.qualica.flexifin.product.shared.CollectionFrequency','OnceOff',''),(100026,NULL,0,NULL,NULL,'collectionNumber','\0','GPF',NULL,NULL,'\0'),(100027,NULL,0,'\0',NULL,'inclusive','\0','GPF',NULL,NULL,''),(100028,NULL,0,NULL,'Immediate','recognitionPlan','\0','GPF','com.qualica.flexifin.product.shared.RecognitionPlan','Immediate',''),(100029,NULL,0,NULL,NULL,'valueType','\0','GPF',NULL,NULL,'\0'),(100030,NULL,0,'',NULL,'partialInterestRate','','GPF',NULL,NULL,''),(100031,NULL,0,'',NULL,'avalInterestRate','','GPF',NULL,NULL,''),(100032,NULL,0,'',NULL,'insuranceInterestRate','','GPF',NULL,NULL,''),(100033,NULL,0,NULL,'OnceOff','collectionFrequency','\0','IAF','com.qualica.flexifin.product.shared.CollectionFrequency','OnceOff',''),(100034,NULL,0,NULL,NULL,'collectionNumber','\0','IAF',NULL,NULL,'\0'),(100035,NULL,0,'',NULL,'inclusive','\0','IAF',NULL,NULL,''),(100036,NULL,0,NULL,'Immediate','recognitionPlan','\0','IAF','com.qualica.flexifin.product.shared.RecognitionPlan','Immediate',''),(100037,NULL,0,NULL,NULL,'valueType','\0','IAF',NULL,NULL,'\0'),(100038,NULL,0,'',NULL,'partialInterestRate','','IAF',NULL,NULL,''),(100039,NULL,0,'',NULL,'avalInterestRate','','IAF',NULL,NULL,''),(100040,NULL,0,'',NULL,'insuranceInterestRate','','IAF',NULL,NULL,'');
/*!40000 ALTER TABLE `fee_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `hibernate_sequences`
--

LOCK TABLES `hibernate_sequences` WRITE;
/*!40000 ALTER TABLE `hibernate_sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `hibernate_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `interest_rate`
--

LOCK TABLES `interest_rate` WRITE;
/*!40000 ALTER TABLE `interest_rate` DISABLE KEYS */;
INSERT INTO `interest_rate` (`type`, `id`, `modified_by`, `version`, `fixed_rate`, `current_rate`, `from_date`, `name`) VALUES ('FixedRate',1,'N.Willemse',0,2.138100000,2.138100000,NULL,NULL);
/*!40000 ALTER TABLE `interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `linked_rate_history`
--

LOCK TABLES `linked_rate_history` WRITE;
/*!40000 ALTER TABLE `linked_rate_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `linked_rate_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_product`
--

LOCK TABLES `loan_product` WRITE;
/*!40000 ALTER TABLE `loan_product` DISABLE KEYS */;
INSERT INTO `loan_product` (`max_amount_cents`, `max_term_months`, `min_amount_cents`, `min_term_months`, `rate_delta`, `step_amount_cents`, `step_term_months`, `target_rate`, `id`, `product_applicability_id`, `interest_rate_id`, `arrears_rate`, `arrears_trigger_cycle`, `arrears_type`, `cheque_fee`, `enabled`, `grace_period_fee_days`, `interes_anticipado_fee_days`, `recognition_mode`, `arrears_interest_type`) VALUES (10000000000,6,200000000,6,NULL,NULL,NULL,2.138100000,1,2,1,NULL,NULL,NULL,NULL,NULL,0,0,'OnActivation',NULL),(10000000000,18,200000000,18,NULL,NULL,NULL,2.138100000,2,2,1,NULL,NULL,NULL,NULL,NULL,0,0,'OnActivation',NULL);
/*!40000 ALTER TABLE `loan_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `lookup_index`
--

LOCK TABLES `lookup_index` WRITE;
/*!40000 ALTER TABLE `lookup_index` DISABLE KEYS */;
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`) VALUES (101,NULL,0,'com.qualica.flexifin.product.domain.core.FeeMapping','FeeMapping',NULL,NULL);
/*!40000 ALTER TABLE `lookup_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `organisation_role_organisation_role_product`
--

LOCK TABLES `organisation_role_organisation_role_product` WRITE;
/*!40000 ALTER TABLE `organisation_role_organisation_role_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `organisation_role_organisation_role_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `organisation_role_product`
--

LOCK TABLES `organisation_role_product` WRITE;
/*!40000 ALTER TABLE `organisation_role_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `organisation_role_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`id`, `modified_by`, `version`, `account_processing_day`, `account_processing_day_of_month`, `currency`, `description`, `name`, `archived`) VALUES (1,'N.Willemse',0,'PeriodEnd',NULL,'COP','18 Month Loan','Bayport 6','\0'),(2,'N.Willemse',0,'PeriodEnd',NULL,'COP','6 Month Loan','Bayport 18','\0');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product_applicability`
--

LOCK TABLES `product_applicability` WRITE;
/*!40000 ALTER TABLE `product_applicability` DISABLE KEYS */;
INSERT INTO `product_applicability` (`id`, `modified_by`, `version`, `name`, `description`, `enabled`) VALUES (1,'nithiag',0,'All clients',NULL,NULL),(2,'nithiag',0,'Organisational clients',NULL,NULL),(3,'nithiag',0,'Non-organisational clients',NULL,NULL);
/*!40000 ALTER TABLE `product_applicability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
INSERT INTO `product_category` (`id`, `modified_by`, `version`, `code`, `name`, `parent_category_id`, `description`, `enabled`) VALUES (1,'nithiag',0,'Financial','Financial product',NULL,NULL,NULL),(2,'nithiag',0,'Loan','Loan product',1,NULL,NULL),(3,'nithiag',0,'Unsecured','Unsecured loan',2,NULL,NULL),(4,'nithiag',0,'Secured','Secured loan',2,NULL,NULL);
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product_classification`
--

LOCK TABLES `product_classification` WRITE;
/*!40000 ALTER TABLE `product_classification` DISABLE KEYS */;
INSERT INTO `product_classification` (`id`, `modified_by`, `version`, `category_id`, `product_id`) VALUES (1,'N.Willemse',0,4,1),(2,'N.Willemse',0,4,2);
/*!40000 ALTER TABLE `product_classification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product_fee`
--

LOCK TABLES `product_fee` WRITE;
/*!40000 ALTER TABLE `product_fee` DISABLE KEYS */;
INSERT INTO `product_fee` (`id`, `modified_by`, `version`, `value`, `value_type`, `from_date`, `to_date`, `fee_id`, `product_id`, `arrears_type`, `collection_Frequency`, `recognition_plan`, `collection_number`, `name`, `balance_allocation_allowed`, `aval_allowed`, `insurance_allowed`, `partial_allowed`, `months`) VALUES (1,'N.Willemse',0,0.018000000,'PrincipalInterest','2012-08-15',NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,'N.Willemse',0,0.343900000,'PrincipalInterest','2012-08-15',NULL,2,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,'N.Willemse',0,0.010000000,'PrincipalPercentage','2012-08-15',NULL,3,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,'N.Willemse',0,0.018000000,'PrincipalInterest','2012-08-15',NULL,1,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,'N.Willemse',0,0.343900000,'PrincipalInterest','2012-08-15',NULL,2,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,'N.Willemse',0,0.010000000,'PrincipalPercentage','2012-08-15',NULL,3,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `product_fee` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 16:09:04
