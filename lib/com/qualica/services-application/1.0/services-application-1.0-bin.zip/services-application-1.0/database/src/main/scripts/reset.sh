#!/bin/sh

echo "Dropping $3 database"

mysql --user=$1 --password=$2 -e "drop database if exists $3;"

for file in ../sql/schema/$3/*.sql
do
  echo "Running ${file}"
  mysql --user=$1 --password=$2 < $file
done

echo "Finished resetting $3 database"


for file in ../sql/seed/$3/*.sql
do
  echo "Running ${file}"
  mysql --user=$1 --password=$2 < $file
done

echo "Finished seeding $3 database"
