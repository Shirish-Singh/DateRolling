use collections;
SET character_set_client = utf8;
-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: collections
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


LOCK TABLES `contact_attempt_type` WRITE;
/*!40000 ALTER TABLE `contact_attempt_type` DISABLE KEYS */;
UPDATE contact_attempt_type SET id = 1, modified_by = '', version = 0, description = 'Teléfono', enabled = true, name = 'Teléfono', is_active = true WHERE id = 1;
UPDATE contact_attempt_type SET id = 2, modified_by = '', version = 0, description = 'Correo electrónico', enabled = true, name = 'Correo electrónico', is_active = true WHERE id = 2;
UPDATE contact_attempt_type SET id = 3, modified_by = '', version = 0, description = 'Carta', enabled = true, name = 'Carta', is_active = true WHERE id = 3;
UPDATE contact_attempt_type SET id = 4, modified_by = '', version = 0, description = 'Visita', enabled = true, name = 'Visita', is_active = true WHERE id = 4;
UPDATE contact_attempt_type SET id = 5, modified_by = '', version = 0, description = 'Proceso legal', enabled = true, name = 'Proceso legal', is_active = true WHERE id = 5;
UPDATE contact_attempt_type SET id = 6, modified_by = 'hrishikesh', version = 0, description = 'INBOUND', enabled = false, name = 'INBOUND', is_active = false WHERE id = 6;
/*!40000 ALTER TABLE `contact_attempt_type` ENABLE KEYS */;
UNLOCK TABLES;
