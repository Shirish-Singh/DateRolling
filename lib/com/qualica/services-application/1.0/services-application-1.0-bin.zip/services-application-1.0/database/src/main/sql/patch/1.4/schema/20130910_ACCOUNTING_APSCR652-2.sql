USE accounting;

ALTER TABLE `accounting`.`agreement_term_admin_fee_payroll` CHANGE COLUMN `interest_rate` `interest_rate` double default null;
