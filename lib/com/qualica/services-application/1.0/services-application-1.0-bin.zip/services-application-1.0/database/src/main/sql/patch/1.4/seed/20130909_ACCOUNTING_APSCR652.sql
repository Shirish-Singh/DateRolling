USE accounting;

LOCK TABLES `tx_chart` WRITE;
/*!40000 ALTER TABLE `tx_chart` DISABLE KEYS */;
DELETE FROM `tx_chart` WHERE id in (1030);
INSERT INTO `tx_chart` (`id`, `name`) VALUES
(1030,'Bank');
/*!40000 ALTER TABLE `tx_chart` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
DELETE FROM `account` WHERE id in (100034);
INSERT INTO `account` (`id`, `modified_by`, `version`, `account_type`, `activated_date`, `created_date`, `currency_code`, `employer_id`, `in_arrears`, `initialised_date`, `status`, `submission_attempt`, `submission_status`, `system`, `account_reason_code_history_id`, `lending_trading_entity_id`) VALUES
(100034,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `account_configuration` WRITE;
/*!40000 ALTER TABLE `account_configuration` DISABLE KEYS */;
DELETE FROM `account_configuration` WHERE id in (100036);
INSERT INTO `account_configuration` (`id`, `modified_by`, `version`, `account_id`, `chart_id`, `descr`, `name`) VALUES
(100036,NULL,0,100034,1030,'bank','bank');
/*!40000 ALTER TABLE `account_configuration` ENABLE KEYS */;
UNLOCK TABLES;



