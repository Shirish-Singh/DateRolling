use masterdata;

SET foreign_key_checks = 0;

-- Delete old duplicate job positions

DELETE FROM masterdata.job_position WHERE name = 'ABOGADO' and id = 1002;
DELETE FROM masterdata.job_position WHERE name = 'ANALISTA COMPRA DE CARTERA' and id = 1003;
DELETE FROM masterdata.job_position WHERE name = 'ANALISTA DE CONTROL DE CALIDAD' and id = 1005;
DELETE FROM masterdata.job_position WHERE name = 'ANALISTA DE CREDITO' and id = 1007;
DELETE FROM masterdata.job_position WHERE name = 'ANALISTA JUNIOR DE PROYECTOS' and id = 1009;
DELETE FROM masterdata.job_position WHERE name = 'ANALISTA DE RECAUDOS' and id = 1010;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR ADMINISTRATIVO' and id = 1014;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR COMERCIAL' and id = 1016;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR COMPRAS DE CARTERA' and id = 1017;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE ARCHIVO' and id = 1019;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE COBRANZAS' and id = 1020;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE INCORPORACIONES' and id = 1022;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE RECUPERACION' and id = 1023;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE REFERENCIACION' and id = 1024;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE TESORERIA' and id = 1027;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE VISACION' and id = 1028;
DELETE FROM masterdata.job_position WHERE name = 'COORDINADOR COMERCIAL' and id = 1032;
DELETE FROM masterdata.job_position WHERE name = 'COORDINADOR COMPRA DE CARTERA' and id = 1035;
DELETE FROM masterdata.job_position WHERE name = 'COORDINADOR DE COBRANZA' and id = 1036;
DELETE FROM masterdata.job_position WHERE name = 'COORDINADOR DE CREDITO' and id = 1038;
DELETE FROM masterdata.job_position WHERE name = 'COORDINADOR INCORPORACIONES' and id = 1040;
DELETE FROM masterdata.job_position WHERE name = 'DIRECTOR COMERCIAL REGIONAL' and id = 1047;
DELETE FROM masterdata.job_position WHERE name = 'DIRECTOR CREDITO Y CARTERA' and id = 1048;
DELETE FROM masterdata.job_position WHERE name = 'GERENTE CREDITO Y CARTERA' and id = 1050;
DELETE FROM masterdata.job_position WHERE name = 'GERENTE DE INCORPORACIONES Y COBRANZAS' and id = 1051;
DELETE FROM masterdata.job_position WHERE name = 'GERENTE GENERAL' and id = 1052;
DELETE FROM masterdata.job_position WHERE name = 'GERENTE NACIONAL DE VENTAS' and id = 1053;
DELETE FROM masterdata.job_position WHERE name = 'LIDER DE CAPACITACION' and id = 1055;
DELETE FROM masterdata.job_position WHERE name = 'MANAGEMENT TRAINEE' and id = 1056;
DELETE FROM masterdata.job_position WHERE name = 'VERIFICADOR DOCUMENTAL' and id = 1061;
DELETE FROM masterdata.job_position WHERE name = 'DIRECTOR DE OPERACIONES' and id = 1062;
DELETE FROM masterdata.job_position WHERE name = 'ANALISTA SENIOR DE REPORTES' and id = 1064;
DELETE FROM masterdata.job_position WHERE name = 'DIRECTOR FINANCIERO' and id = 1065;
DELETE FROM masterdata.job_position WHERE name = 'COORDINADOR DE CARTERA' and id = 1068;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE TESORERIA' and id = 1149;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE TESORERIA' and id = 1150;
DELETE FROM masterdata.job_position WHERE name = 'AUXILIAR DE TESORERIA' and id = 1151;


INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002','0','ABOGADO','ABOGADO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003','0','ANALISTA COMPRA DE CARTERA','ANALISTA COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005','0','ANALISTA DE CONTROL DE CALIDAD','ANALISTA DE CONTROL DE CALIDAD',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1007','0','ANALISTA DE CREDITO','ANALISTA DE CREDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1009','0','ANALISTA JUNIOR DE PROYECTOS','ANALISTA JUNIOR DE PROYECTOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1010','0','ANALISTA DE RECAUDOS','ANALISTA DE RECAUDOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1014','0','AUXILIAR ADMINISTRATIVO','AUXILIAR ADMINISTRATIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1016','0','AUXILIAR COMERCIAL','AUXILIAR COMERCIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1017','0','AUXILIAR COMPRAS DE CARTERA','AUXILIAR COMPRAS DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1019','0','AUXILIAR DE ARCHIVO','AUXILIAR DE ARCHIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1020','0','AUXILIAR DE COBRANZAS','AUXILIAR DE COBRANZAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1022','0','AUXILIAR DE INCORPORACIONES','AUXILIAR DE INCORPORACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1023','0','AUXILIAR DE RECUPERACION','AUXILIAR DE RECUPERACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1024','0','AUXILIAR DE REFERENCIACION','AUXILIAR DE REFERENCIACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1027','0','AUXILIAR DE TESORERIA','AUXILIAR DE TESORERIA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1028','0','AUXILIAR DE VISACION','AUXILIAR DE VISACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1032','0','COORDINADOR COMERCIAL','COORDINADOR COMERCIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1035','0','COORDINADOR COMPRA DE CARTERA','COORDINADOR COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1036','0','COORDINADOR DE COBRANZA','COORDINADOR DE COBRANZA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1038','0','COORDINADOR DE CREDITO','COORDINADOR DE CREDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1040','0','COORDINADOR INCORPORACIONES','COORDINADOR INCORPORACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1047','0','DIRECTOR COMERCIAL REGIONAL','DIRECTOR COMERCIAL REGIONAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1048','0','DIRECTOR CREDITO Y CARTERA','DIRECTOR CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1050','0','GERENTE CREDITO Y CARTERA','GERENTE CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1051','0','GERENTE DE INCORPORACIONES Y COBRANZAS','GERENTE DE INCORPORACIONES Y COBRANZAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1052','0','GERENTE GENERAL','GERENTE GENERAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1053','0','GERENTE NACIONAL DE VENTAS','GERENTE NACIONAL DE VENTAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1055','0','LIDER DE CAPACITACION','LIDER DE CAPACITACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1056','0','MANAGEMENT TRAINEE','MANAGEMENT TRAINEE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1061','0','VERIFICADOR DOCUMENTAL','VERIFICADOR DOCUMENTAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1062','0','DIRECTOR DE OPERACIONES','DIRECTOR DE OPERACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1064','0','ANALISTA SENIOR DE REPORTES','ANALISTA SENIOR DE REPORTES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1065','0','DIRECTOR FINANCIERO','DIRECTOR FINANCIERO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1068','0','COORDINADOR DE CARTERA','COORDINADOR DE CARTERA',1);


SET foreign_key_checks = 1;

