SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.add_column_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.add_column_fk(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100),
  IN colType VARCHAR(100),
  IN defaultValue VARCHAR(100),
  IN fkSymbol VARCHAR(100),
  IN refTable VARCHAR(100),
  IN refColName VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` ADD COLUMN `', colName ,'` ', colType, ' default null');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('UPDATE `accounting`.`', tableName ,'` SET `', colName ,'` = ', defaultValue);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` CHANGE COLUMN `', colName, '` `', colName ,'` ', colType, ' not null');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` ADD CONSTRAINT `', fkSymbol, '` FOREIGN KEY `', fkSymbol ,'` (`', colName, '`) REFERENCES `', refTable, '` (`', refColName, '`)');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;


  END IF;
END ;$$

DELIMITER ;

CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_immediate_r_payroll', 'settlement_write_off_account_id', 'bigint(20)', '100017','20130913adminimmediatewriteoffaccount' , 'account', 'id') ;
CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_immediate_r_payroll', 'settlement_write_off_chart_id', 'bigint(20)', '1015', '20130913adminimmediatewriteoffchart', 'tx_chart', 'id') ;
CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud', 'settlement_write_off_account_id', 'bigint(20)', '100017','20130913adminimmediatewriteoffaccount_aud' , 'account', 'id') ;
CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud', 'settlement_write_off_chart_id', 'bigint(20)', '1015', '20130913adminimmediatewriteoffchart_aud', 'tx_chart', 'id') ;

CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_amortised_r_payroll', 'settlement_write_off_account_id', 'bigint(20)', '100017','20130913writeoffaccount' , 'account', 'id') ;
CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_amortised_r_payroll', 'settlement_write_off_chart_id', 'bigint(20)', '1015', '20130913writeoffchart', 'tx_chart', 'id') ;
CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud', 'settlement_write_off_account_id', 'bigint(20)', '100017','20130913writeoffaccount_aud' , 'account', 'id') ;
CALL accounting.add_column_fk('agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud', 'settlement_write_off_chart_id', 'bigint(20)', '1015', '20130913writeoffchart_aud', 'tx_chart', 'id') ;

DROP PROCEDURE IF EXISTS accounting.add_column_fk ;

SET SQL_MODE=@OLD_SQL_MODE ;

