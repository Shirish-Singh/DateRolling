use accounting;

UPDATE `accounting`.`disbursement_reason_code` SET `enabled`=0 WHERE `id`='1';
UPDATE `accounting`.`disbursement_reason_code` SET `enabled`=0 WHERE `id`='2';
