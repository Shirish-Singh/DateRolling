USE masterdata;
SET character_set_client = utf8;
SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM `masterdata`.`party` where id  = 1; 
DELETE FROM `masterdata`.`person` where id  = 1;
DELETE FROM `masterdata`.`PARTY_ROLE` where id  = 1;
DELETE FROM `masterdata`.`PERSON_ROLE` where id  = 1;
DELETE FROM `masterdata`.`USER` where id  = 1;
DELETE FROM `masterdata`.`user_role` where user_id  = 1;

/*  Administrator */
INSERT INTO `masterdata`.`party`(`id`, version) VALUES (1, 0);
INSERT INTO `masterdata`.`person` (id, id_number, passport_number, birth_date, last_name, first_name, dependants, mother_maiden_name)  VALUES (1, '0000','0000','1968-01-30 00:00:00', 'Administrator', 'Administrator', 0, null);
INSERT INTO `masterdata`.`PARTY_ROLE` (id, party_id, role_type_id, version) VALUES (1, 1, 10003 , 0);
INSERT INTO `masterdata`.`PERSON_ROLE` (id) VALUES (1);
INSERT INTO `masterdata`.`USER` (id, username, password, enabled)  VALUES (1,'admin','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true);

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
INSERT INTO `user_role` (`user_id`, `role_id`) VALUES (1,401);
INSERT INTO `user_role` (`user_id`, `role_id`) VALUES (1,450);
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

SET FOREIGN_KEY_CHECKS = 1;