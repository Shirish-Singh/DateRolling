use masterdata;
SET character_set_client = utf8;
SET FOREIGN_KEY_CHECKS = 0;

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4075);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4076);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4076);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4077);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4077);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4077);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4078);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(418,4079);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(419,4079);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(440,4080);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(443,4081);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(444,4082);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(443,4083);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(441,4084);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(442,4084);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(425,4085);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(426,4085);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(427,4085);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(430,4086);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(430,4087);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(440,4087);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(405,4089);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(406,4089);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4090);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(409,4089);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(443,4090);

SET FOREIGN_KEY_CHECKS = 1;











