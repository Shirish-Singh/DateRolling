USE accounting;

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
DELETE FROM `configuration` WHERE id in (10012);
INSERT INTO `configuration` (`id`, `version`, `name`, `value`) VALUES
(10012, 0, 'arrears_threshold_in_cents', '100');
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;