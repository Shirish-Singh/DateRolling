USE masterdata;

DELETE FROM user_role WHERE user_id = 13001 AND role_id = 300;
INSERT INTO user_role (user_id, role_id) VALUES (13001, 300);