USE accounting;

ALTER TABLE agreement_action_disbursement_3_party_m CHANGE COLUMN expiry_date expiry_date DATE DEFAULT NULL;
ALTER TABLE agreement_action_disbursement_3_party_m_aud CHANGE COLUMN expiry_date expiry_date DATE DEFAULT NULL;

ALTER TABLE settlement_quote_confirmation CHANGE COLUMN expiry_date expiry_date DATE DEFAULT NULL;

