use masterdata;
SET foreign_key_checks = 0;
DELETE FROM `check_list_item_document_definition` WHERE id in (121);
DELETE FROM `check_list_item_definition` WHERE id in (121);
DELETE FROM `check_list_definition` WHERE id in (31);
SET foreign_key_checks = 1;

LOCK TABLES `check_list_definition` WRITE;
/*!40000 ALTER TABLE `check_list_definition` DISABLE KEYS */;
insert into check_list_definition (id, name, source_resource_id, source_resource_name, version) values
(31, 'employerApplicationResponse', null, null, 1);
/*!40000 ALTER TABLE `check_list_definition` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `check_list_item_definition` WRITE;
/*!40000 ALTER TABLE `check_list_item_definition` DISABLE KEYS */;
insert into check_list_item_definition (id, name, description, item_order, required, check_list_definition_id, enabled, version) values
(121, 'Respuesta de la Pagaduria', 'Respuesta de la Pagaduria', 1, false,  31, true, 1);
/*!40000 ALTER TABLE `check_list_item_definition` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `check_list_item_document_definition` WRITE;
/*!40000 ALTER TABLE `check_list_item_document_definition` DISABLE KEYS */;
insert into check_list_item_document_definition (id, approval_required, required_approval_role) values
(121, false, null);
/*!40000 ALTER TABLE `check_list_item_document_definition` ENABLE KEYS */;
UNLOCK TABLES;





