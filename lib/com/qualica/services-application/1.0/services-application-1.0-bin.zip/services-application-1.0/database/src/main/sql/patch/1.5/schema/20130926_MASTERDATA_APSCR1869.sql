USE masterdata;

ALTER TABLE disbursement_detail CHANGE COLUMN expiry_date expiry_date DATE DEFAULT NULL;
ALTER TABLE disbursement_detail_aud CHANGE COLUMN expiry_date expiry_date DATE DEFAULT NULL;

