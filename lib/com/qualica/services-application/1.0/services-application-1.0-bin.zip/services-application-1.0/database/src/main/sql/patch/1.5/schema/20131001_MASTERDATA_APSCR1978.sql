USE masterdata;

ALTER TABLE loan_application CHANGE COLUMN completion_date completion_date DATE DEFAULT NULL;
ALTER TABLE loan_application_aud CHANGE COLUMN completion_date completion_date DATE DEFAULT NULL;
