use datamigration;

ALTER TABLE `datamigration`.`staging_client` CHANGE COLUMN `colombia_client_id` `employed_from` DATETIME NULL DEFAULT NULL  ;