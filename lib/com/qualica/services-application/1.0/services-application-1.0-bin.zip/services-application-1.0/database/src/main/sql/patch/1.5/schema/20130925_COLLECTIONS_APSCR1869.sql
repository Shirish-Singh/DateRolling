USE collections;

ALTER TABLE collection_case CHANGE COLUMN arrears_from_date arrears_from_date date default null;
ALTER TABLE collection_case_aud CHANGE COLUMN arrears_from_date arrears_from_date date default null;