INSERT INTO `masterdata`.`permission` (`id`, `modified_by`, `version`, `name`) VALUES ('3033', 'N.Willemse', '0', 'ThirdPartyManagedClerk');
INSERT INTO `masterdata`.`permission` (`id`, `modified_by`, `version`, `name`) VALUES ('3034', 'N.Willemse', '0', 'ThirdPartyManagedExternalClerk');
INSERT INTO `masterdata`.`permission` (`id`, `modified_by`, `version`, `name`) VALUES ('3035', 'N.Willemse', '0', 'ThirdPartyManagedAnalyst');
INSERT INTO `masterdata`.`permission` (`id`, `modified_by`, `version`, `name`) VALUES ('3036', 'N.Willemse', '0', 'ThirdPartyManagedUploadClerk');


INSERT INTO `masterdata`.`role_permission` (`role_id`, `permission_id`) VALUES ('1', '3033');
INSERT INTO `masterdata`.`role_permission` (`role_id`, `permission_id`) VALUES ('1', '3034');
INSERT INTO `masterdata`.`role_permission` (`role_id`, `permission_id`) VALUES ('1', '3035');
INSERT INTO `masterdata`.`role_permission` (`role_id`, `permission_id`) VALUES ('1', '3036');
