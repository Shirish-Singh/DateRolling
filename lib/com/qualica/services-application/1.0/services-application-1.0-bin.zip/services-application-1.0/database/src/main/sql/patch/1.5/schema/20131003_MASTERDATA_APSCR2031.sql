USE masterdata;

ALTER TABLE credit_reference CHANGE COLUMN date_contacted date_contacted DATE DEFAULT NULL;
ALTER TABLE credit_reference_aud CHANGE COLUMN date_contacted date_contacted DATE DEFAULT NULL;
