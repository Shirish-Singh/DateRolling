#!/bin/sh

echo "Adding role and permissions to database"

for file in ../sql/role_permission/*.sql
do
  echo "Running ${file}"
  mysql --user=$1 --password=$2 < $file
done

echo "Finished adding role and permissions"