CREATE DATABASE  IF NOT EXISTS `datamigration` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `datamigration`;
SET FOREIGN_KEY_CHECKS=0;
--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `region_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2E996BD2C8F4B` (`region_id`),
  CONSTRAINT `FK2E996BD2C8F4B` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nationality` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `currency_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK391757964004DDEB` (`currency_id`),
  CONSTRAINT `FK391757964004DDEB` FOREIGN KEY (`currency_id`) REFERENCES `currency` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currency` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_agents`
--

DROP TABLE IF EXISTS `file_uploader_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_agents` (
  `file_uploader_id` bigint(20) NOT NULL,
  `agent_id` bigint(20) NOT NULL,
  UNIQUE KEY `agent_id` (`agent_id`),
  KEY `FKD81AD83CDA0572E0` (`file_uploader_id`),
  KEY `FKD81AD83CBA03DF69` (`agent_id`),
  CONSTRAINT `FKD81AD83CBA03DF69` FOREIGN KEY (`agent_id`) REFERENCES `staging_agent` (`agent_id`),
  CONSTRAINT `FKD81AD83CDA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_agents`
--

LOCK TABLES `file_uploader_agents` WRITE;
/*!40000 ALTER TABLE `file_uploader_agents` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_banks`
--

DROP TABLE IF EXISTS `file_uploader_banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_banks` (
  `file_uploader_id` bigint(20) NOT NULL,
  `bank_id` bigint(20) NOT NULL,
  UNIQUE KEY `bank_id` (`bank_id`),
  KEY `FKFEC209C9DA0572E0` (`file_uploader_id`),
  KEY `FKFEC209C9E6D43A8B` (`bank_id`),
  CONSTRAINT `FKFEC209C9E6D43A8B` FOREIGN KEY (`bank_id`) REFERENCES `staging_bank` (`bank_id`),
  CONSTRAINT `FKFEC209C9DA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_banks`
--

LOCK TABLES `file_uploader_banks` WRITE;
/*!40000 ALTER TABLE `file_uploader_banks` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_client`
--

DROP TABLE IF EXISTS `file_uploader_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_client` (
  `file_uploader_id` bigint(20) NOT NULL,
  `client_id` bigint(20) NOT NULL,
  UNIQUE KEY `client_id` (`client_id`),
  KEY `FKDBCCADF9DA0572E0` (`file_uploader_id`),
  KEY `FKDBCCADF97E0ACBEB` (`client_id`),
  CONSTRAINT `FKDBCCADF97E0ACBEB` FOREIGN KEY (`client_id`) REFERENCES `staging_client` (`client_id`),
  CONSTRAINT `FKDBCCADF9DA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_client`
--

LOCK TABLES `file_uploader_client` WRITE;
/*!40000 ALTER TABLE `file_uploader_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_employer`
--

DROP TABLE IF EXISTS `file_uploader_employer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_employer` (
  `file_uploader_id` bigint(20) NOT NULL,
  `employer_id` bigint(20) NOT NULL,
  UNIQUE KEY `employer_id` (`employer_id`),
  KEY `FK2C56CD69786665AB` (`employer_id`),
  KEY `FK2C56CD69DA0572E0` (`file_uploader_id`),
  CONSTRAINT `FK2C56CD69DA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`),
  CONSTRAINT `FK2C56CD69786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_employer`
--

LOCK TABLES `file_uploader_employer` WRITE;
/*!40000 ALTER TABLE `file_uploader_employer` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_employer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_error`
--

DROP TABLE IF EXISTS `file_uploader_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_error` (
  `file_uploader_id` bigint(20) NOT NULL,
  `file_uploader_error_id` bigint(20) NOT NULL,
  UNIQUE KEY `file_uploader_error_id` (`file_uploader_error_id`),
  KEY `FKFEF41A1ADA0572E0` (`file_uploader_id`),
  KEY `FKFEF41A1A1CABAD11` (`file_uploader_error_id`),
  CONSTRAINT `FKFEF41A1A1CABAD11` FOREIGN KEY (`file_uploader_error_id`) REFERENCES `master_data_file_uploader_error` (`file_uploader_error_id`),
  CONSTRAINT `FKFEF41A1ADA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_error`
--

LOCK TABLES `file_uploader_error` WRITE;
/*!40000 ALTER TABLE `file_uploader_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_outlet`
--

DROP TABLE IF EXISTS `file_uploader_outlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_outlet` (
  `file_uploader_id` bigint(20) NOT NULL,
  `outlet_id` bigint(20) NOT NULL,
  UNIQUE KEY `outlet_id` (`outlet_id`),
  KEY `FKF0CAC23BDA0572E0` (`file_uploader_id`),
  KEY `FKF0CAC23B7E804CAB` (`outlet_id`),
  CONSTRAINT `FKF0CAC23B7E804CAB` FOREIGN KEY (`outlet_id`) REFERENCES `staging_outlet` (`outlet_id`),
  CONSTRAINT `FKF0CAC23BDA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_outlet`
--

LOCK TABLES `file_uploader_outlet` WRITE;
/*!40000 ALTER TABLE `file_uploader_outlet` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_outlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_third_party`
--

DROP TABLE IF EXISTS `file_uploader_third_party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_third_party` (
  `file_uploader_id` bigint(20) NOT NULL,
  `third_party_id` bigint(20) NOT NULL,
  UNIQUE KEY `third_party_id` (`third_party_id`),
  KEY `FKACFB8CA0DA0572E0` (`file_uploader_id`),
  KEY `FKACFB8CA083B3E43C` (`third_party_id`),
  CONSTRAINT `FKACFB8CA083B3E43C` FOREIGN KEY (`third_party_id`) REFERENCES `staging_third_party` (`third_party_id`),
  CONSTRAINT `FKACFB8CA0DA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_third_party`
--

LOCK TABLES `file_uploader_third_party` WRITE;
/*!40000 ALTER TABLE `file_uploader_third_party` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_third_party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file_uploader_users`
--

DROP TABLE IF EXISTS `file_uploader_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `file_uploader_users` (
  `file_uploader_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  UNIQUE KEY `user_id` (`user_id`),
  KEY `FKFFD5D61ADA0572E0` (`file_uploader_id`),
  KEY `FKFFD5D61AF22F1C2B` (`user_id`),
  CONSTRAINT `FKFFD5D61AF22F1C2B` FOREIGN KEY (`user_id`) REFERENCES `staging_user` (`user_id`),
  CONSTRAINT `FKFFD5D61ADA0572E0` FOREIGN KEY (`file_uploader_id`) REFERENCES `master_data_file_uploader` (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploader_users`
--

LOCK TABLES `file_uploader_users` WRITE;
/*!40000 ALTER TABLE `file_uploader_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `file_uploader_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loanbook_upload_paymenthistory_account`
--

DROP TABLE IF EXISTS `loanbook_upload_paymenthistory_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loanbook_upload_paymenthistory_account` (
  `loanbook_upload_id` bigint(20) NOT NULL,
  `payment_history_id` int(11) NOT NULL,
  UNIQUE KEY `payment_history_id` (`payment_history_id`),
  KEY `FKAD9DD8D457A22F57` (`loanbook_upload_id`),
  KEY `FKAD9DD8D4BBD9813E` (`payment_history_id`),
  CONSTRAINT `FKAD9DD8D4BBD9813E` FOREIGN KEY (`payment_history_id`) REFERENCES `staging_payment_history` (`payment_history_id`),
  CONSTRAINT `FKAD9DD8D457A22F57` FOREIGN KEY (`loanbook_upload_id`) REFERENCES `staging_loanbook_upload` (`loanbook_upload_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loanbook_upload_paymenthistory_account`
--

LOCK TABLES `loanbook_upload_paymenthistory_account` WRITE;
/*!40000 ALTER TABLE `loanbook_upload_paymenthistory_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `loanbook_upload_paymenthistory_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loanbook_upload_staging_account`
--

DROP TABLE IF EXISTS `loanbook_upload_staging_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loanbook_upload_staging_account` (
  `loanbook_upload_id` bigint(20) NOT NULL,
  `account_id` int(11) NOT NULL,
  UNIQUE KEY `account_id` (`account_id`),
  KEY `FKE5D7331157A22F57` (`loanbook_upload_id`),
  KEY `FKE5D733115839F6A9` (`account_id`),
  CONSTRAINT `FKE5D733115839F6A9` FOREIGN KEY (`account_id`) REFERENCES `staging_account` (`account_id`),
  CONSTRAINT `FKE5D7331157A22F57` FOREIGN KEY (`loanbook_upload_id`) REFERENCES `staging_loanbook_upload` (`loanbook_upload_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loanbook_upload_staging_account`
--

LOCK TABLES `loanbook_upload_staging_account` WRITE;
/*!40000 ALTER TABLE `loanbook_upload_staging_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `loanbook_upload_staging_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manage_look_up`
--

DROP TABLE IF EXISTS `manage_look_up`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manage_look_up` (
  `manage_look_up_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_exported_to_flexifin` bit(1) DEFAULT NULL,
  `look_up_type` int(11) NOT NULL,
  `number_of_rows` int(11) DEFAULT NULL,
  `country` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `uploaded_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded_file` longblob NOT NULL,
  `uploaded_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`manage_look_up_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manage_look_up`
--

LOCK TABLES `manage_look_up` WRITE;
/*!40000 ALTER TABLE `manage_look_up` DISABLE KEYS */;
/*!40000 ALTER TABLE `manage_look_up` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manage_look_up_suburb`
--

DROP TABLE IF EXISTS `manage_look_up_suburb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manage_look_up_suburb` (
  `manage_look_up_id` bigint(20) NOT NULL,
  `id` bigint(20) NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `FK5696B9C3A8EA5962` (`manage_look_up_id`),
  KEY `FK5696B9C3B525E51` (`id`),
  CONSTRAINT `FK5696B9C3B525E51` FOREIGN KEY (`id`) REFERENCES `suburb` (`id`),
  CONSTRAINT `FK5696B9C3A8EA5962` FOREIGN KEY (`manage_look_up_id`) REFERENCES `manage_look_up` (`manage_look_up_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manage_look_up_suburb`
--

LOCK TABLES `manage_look_up_suburb` WRITE;
/*!40000 ALTER TABLE `manage_look_up_suburb` DISABLE KEYS */;
/*!40000 ALTER TABLE `manage_look_up_suburb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manage_look_up_user_role`
--

DROP TABLE IF EXISTS `manage_look_up_user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manage_look_up_user_role` (
  `manage_look_up_id` bigint(20) NOT NULL,
  `user_role_id` bigint(20) NOT NULL,
  UNIQUE KEY `user_role_id` (`user_role_id`),
  KEY `FK5F732D0CA8EA5962` (`manage_look_up_id`),
  KEY `FK5F732D0C1DF90F11` (`user_role_id`),
  CONSTRAINT `FK5F732D0C1DF90F11` FOREIGN KEY (`user_role_id`) REFERENCES `user_role` (`user_role_id`),
  CONSTRAINT `FK5F732D0CA8EA5962` FOREIGN KEY (`manage_look_up_id`) REFERENCES `manage_look_up` (`manage_look_up_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manage_look_up_user_role`
--

LOCK TABLES `manage_look_up_user_role` WRITE;
/*!40000 ALTER TABLE `manage_look_up_user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `manage_look_up_user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_file_uploader`
--

DROP TABLE IF EXISTS `master_data_file_uploader`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_data_file_uploader` (
  `file_uploader_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_sheet_type` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_exported_to_flexifin` bit(1) DEFAULT NULL,
  `master_data_sheet` longblob NOT NULL,
  `number_of_rows` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `uploaded_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`file_uploader_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_file_uploader`
--

LOCK TABLES `master_data_file_uploader` WRITE;
/*!40000 ALTER TABLE `master_data_file_uploader` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_file_uploader` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_data_file_uploader_error`
--

DROP TABLE IF EXISTS `master_data_file_uploader_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_data_file_uploader_error` (
  `file_uploader_error_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `column_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `row_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`file_uploader_error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_data_file_uploader_error`
--

LOCK TABLES `master_data_file_uploader_error` WRITE;
/*!40000 ALTER TABLE `master_data_file_uploader_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_data_file_uploader_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_look_up_type`
--

DROP TABLE IF EXISTS `master_look_up_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_look_up_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `look_up_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_look_up_type`
--

LOCK TABLES `master_look_up_type` WRITE;
/*!40000 ALTER TABLE `master_look_up_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_look_up_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `master_look_up_type_value`
--

DROP TABLE IF EXISTS `master_look_up_type_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `master_look_up_type_value` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `flexi_fin_id` int(11) DEFAULT NULL,
  `look_up_type_value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `version` int(11) NOT NULL,
  `master_look_up_type_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF45C5BADF47433E9` (`master_look_up_type_id`),
  CONSTRAINT `FKF45C5BADF47433E9` FOREIGN KEY (`master_look_up_type_id`) REFERENCES `master_look_up_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `master_look_up_type_value`
--

LOCK TABLES `master_look_up_type_value` WRITE;
/*!40000 ALTER TABLE `master_look_up_type_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `master_look_up_type_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `country_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC84826F4CABA9209` (`country_id`),
  CONSTRAINT `FKC84826F4CABA9209` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `user_role_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`role_id`),
  KEY `FK3580761DF90F11` (`user_role_id`),
  CONSTRAINT `FK3580761DF90F11` FOREIGN KEY (`user_role_id`) REFERENCES `user_role` (`user_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_account`
--

DROP TABLE IF EXISTS `staging_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_account` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_fee_in_arrears` double DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `anticipated_interest` double DEFAULT NULL,
  `arrears_interest` double DEFAULT NULL,
  `arrears_rate` double DEFAULT NULL,
  `aval` double DEFAULT NULL,
  `aval_rate` double DEFAULT NULL,
  `capital_balance` double DEFAULT NULL,
  `capital_in_arrears` double DEFAULT NULL,
  `cheques` double DEFAULT NULL,
  `collectionFIMSA` double DEFAULT NULL,
  `comprehensive_rate` double DEFAULT NULL,
  `current_interest` double DEFAULT NULL,
  `current_interest_rate` double DEFAULT NULL,
  `employer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `fees` double DEFAULT NULL,
  `filing_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_instalment_date` datetime DEFAULT NULL,
  `flexifin_account_id` bigint(20) DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `grace_period_applied` int(11) DEFAULT NULL,
  `identification` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `insurance` double DEFAULT NULL,
  `insurance_rate` double DEFAULT NULL,
  `net_disbursed_amount` double DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `term` int(11) DEFAULT NULL,
  `total_arrears` double DEFAULT NULL,
  `uploaded_sheet_linenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_account`
--

LOCK TABLES `staging_account` WRITE;
/*!40000 ALTER TABLE `staging_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_address`
--

DROP TABLE IF EXISTS `staging_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_address` (
  `address_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `address_line_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_line_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `months_at_residence` int(11) DEFAULT NULL,
  `postal_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `region` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `residence_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `resident_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suburb` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_address`
--

LOCK TABLES `staging_address` WRITE;
/*!40000 ALTER TABLE `staging_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_agent`
--

DROP TABLE IF EXISTS `staging_agent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_agent` (
  `agent_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `active` bit(1) DEFAULT NULL,
  `agent_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `agent_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `eligible_for_commission` bit(1) DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `migration_status` int(11) DEFAULT NULL,
  `outlet_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded_agent_sheet_line_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_agent`
--

LOCK TABLES `staging_agent` WRITE;
/*!40000 ALTER TABLE `staging_agent` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_agent_address`
--

DROP TABLE IF EXISTS `staging_agent_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_agent_address` (
  `agent_id` bigint(20) NOT NULL,
  `address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`agent_id`,`address_id`),
  UNIQUE KEY `address_id` (`address_id`),
  KEY `FK424D17B6D9CECD49` (`address_id`),
  KEY `FK424D17B6BA03DF69` (`agent_id`),
  CONSTRAINT `FK424D17B6BA03DF69` FOREIGN KEY (`agent_id`) REFERENCES `staging_agent` (`agent_id`),
  CONSTRAINT `FK424D17B6D9CECD49` FOREIGN KEY (`address_id`) REFERENCES `staging_address` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_agent_address`
--

LOCK TABLES `staging_agent_address` WRITE;
/*!40000 ALTER TABLE `staging_agent_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_agent_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_agent_bank_account`
--

DROP TABLE IF EXISTS `staging_agent_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_agent_bank_account` (
  `agent_id` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  PRIMARY KEY (`agent_id`,`bank_account_id`),
  UNIQUE KEY `bank_account_id` (`bank_account_id`),
  KEY `FK24C0C8A8BA03DF69` (`agent_id`),
  KEY `FK24C0C8A85EF6FF30` (`bank_account_id`),
  CONSTRAINT `FK24C0C8A85EF6FF30` FOREIGN KEY (`bank_account_id`) REFERENCES `staging_bank_account` (`bank_account_id`),
  CONSTRAINT `FK24C0C8A8BA03DF69` FOREIGN KEY (`agent_id`) REFERENCES `staging_agent` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_agent_bank_account`
--

LOCK TABLES `staging_agent_bank_account` WRITE;
/*!40000 ALTER TABLE `staging_agent_bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_agent_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_agent_contact_number`
--

DROP TABLE IF EXISTS `staging_agent_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_agent_contact_number` (
  `agent_id` bigint(20) NOT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  PRIMARY KEY (`agent_id`,`contact_number_id`),
  UNIQUE KEY `contact_number_id` (`contact_number_id`),
  KEY `FK4284F646EFE478CA` (`contact_number_id`),
  KEY `FK4284F646BA03DF69` (`agent_id`),
  CONSTRAINT `FK4284F646BA03DF69` FOREIGN KEY (`agent_id`) REFERENCES `staging_agent` (`agent_id`),
  CONSTRAINT `FK4284F646EFE478CA` FOREIGN KEY (`contact_number_id`) REFERENCES `staging_contact_number` (`contact_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_agent_contact_number`
--

LOCK TABLES `staging_agent_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_agent_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_agent_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_agent_email_address`
--

DROP TABLE IF EXISTS `staging_agent_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_agent_email_address` (
  `agent_id` bigint(20) NOT NULL,
  `email_address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`agent_id`,`email_address_id`),
  UNIQUE KEY `email_address_id` (`email_address_id`),
  KEY `FK72085493BA03DF69` (`agent_id`),
  KEY `FK72085493B5AC13D2` (`email_address_id`),
  CONSTRAINT `FK72085493B5AC13D2` FOREIGN KEY (`email_address_id`) REFERENCES `staging_email_address` (`email_address_id`),
  CONSTRAINT `FK72085493BA03DF69` FOREIGN KEY (`agent_id`) REFERENCES `staging_agent` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_agent_email_address`
--

LOCK TABLES `staging_agent_email_address` WRITE;
/*!40000 ALTER TABLE `staging_agent_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_agent_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_agent_person`
--

DROP TABLE IF EXISTS `staging_agent_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_agent_person` (
  `agent_id` bigint(20) NOT NULL,
  `person_id` bigint(20) NOT NULL,
  PRIMARY KEY (`agent_id`,`person_id`),
  UNIQUE KEY `person_id` (`person_id`),
  KEY `FK138E9F53383427AB` (`person_id`),
  KEY `FK138E9F53BA03DF69` (`agent_id`),
  CONSTRAINT `FK138E9F53BA03DF69` FOREIGN KEY (`agent_id`) REFERENCES `staging_agent` (`agent_id`),
  CONSTRAINT `FK138E9F53383427AB` FOREIGN KEY (`person_id`) REFERENCES `staging_person` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_agent_person`
--

LOCK TABLES `staging_agent_person` WRITE;
/*!40000 ALTER TABLE `staging_agent_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_agent_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_bank`
--

DROP TABLE IF EXISTS `staging_bank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_bank` (
  `bank_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_active` bit(1) DEFAULT NULL,
  `bank_branch_flexi_fin_id` bigint(20) DEFAULT NULL,
  `bank_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `uploaded_bank_sheet_line_number` int(11) DEFAULT NULL,
  `migration_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_bank`
--

LOCK TABLES `staging_bank` WRITE;
/*!40000 ALTER TABLE `staging_bank` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_bank_account`
--

DROP TABLE IF EXISTS `staging_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_bank_account` (
  `bank_account_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account_holder` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_account_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank_branch` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`bank_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_bank_account`
--

LOCK TABLES `staging_bank_account` WRITE;
/*!40000 ALTER TABLE `staging_bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_bank_address`
--

DROP TABLE IF EXISTS `staging_bank_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_bank_address` (
  `bank_id` bigint(20) NOT NULL,
  `address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`bank_id`,`address_id`),
  UNIQUE KEY `address_id` (`address_id`),
  KEY `FK47771675D9CECD49` (`address_id`),
  KEY `FK47771675E6D43A8B` (`bank_id`),
  CONSTRAINT `FK47771675E6D43A8B` FOREIGN KEY (`bank_id`) REFERENCES `staging_bank` (`bank_id`),
  CONSTRAINT `FK47771675D9CECD49` FOREIGN KEY (`address_id`) REFERENCES `staging_address` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_bank_address`
--

LOCK TABLES `staging_bank_address` WRITE;
/*!40000 ALTER TABLE `staging_bank_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_bank_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_bank_contact_number`
--

DROP TABLE IF EXISTS `staging_bank_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_bank_contact_number` (
  `bank_id` bigint(20) NOT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  PRIMARY KEY (`bank_id`,`contact_number_id`),
  UNIQUE KEY `contact_number_id` (`contact_number_id`),
  KEY `FKB8C1B2A7EFE478CA` (`contact_number_id`),
  KEY `FKB8C1B2A7E6D43A8B` (`bank_id`),
  CONSTRAINT `FKB8C1B2A7E6D43A8B` FOREIGN KEY (`bank_id`) REFERENCES `staging_bank` (`bank_id`),
  CONSTRAINT `FKB8C1B2A7EFE478CA` FOREIGN KEY (`contact_number_id`) REFERENCES `staging_contact_number` (`contact_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_bank_contact_number`
--

LOCK TABLES `staging_bank_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_bank_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_bank_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_bank_email_address`
--

DROP TABLE IF EXISTS `staging_bank_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_bank_email_address` (
  `bank_id` bigint(20) NOT NULL,
  `email_address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`bank_id`,`email_address_id`),
  UNIQUE KEY `email_address_id` (`email_address_id`),
  KEY `FK1B020812E6D43A8B` (`bank_id`),
  KEY `FK1B020812B5AC13D2` (`email_address_id`),
  CONSTRAINT `FK1B020812B5AC13D2` FOREIGN KEY (`email_address_id`) REFERENCES `staging_email_address` (`email_address_id`),
  CONSTRAINT `FK1B020812E6D43A8B` FOREIGN KEY (`bank_id`) REFERENCES `staging_bank` (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_bank_email_address`
--

LOCK TABLES `staging_bank_email_address` WRITE;
/*!40000 ALTER TABLE `staging_bank_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_bank_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_bank_organisation`
--

DROP TABLE IF EXISTS `staging_bank_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_bank_organisation` (
  `bank_id` bigint(20) NOT NULL,
  `organisation_id` bigint(20) NOT NULL,
  PRIMARY KEY (`bank_id`,`organisation_id`),
  UNIQUE KEY `organisation_id` (`organisation_id`),
  KEY `FK4D30EEF9E6D43A8B` (`bank_id`),
  KEY `FK4D30EEF9F786ECCB` (`organisation_id`),
  CONSTRAINT `FK4D30EEF9F786ECCB` FOREIGN KEY (`organisation_id`) REFERENCES `staging_organisation` (`organisation_id`),
  CONSTRAINT `FK4D30EEF9E6D43A8B` FOREIGN KEY (`bank_id`) REFERENCES `staging_bank` (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_bank_organisation`
--

LOCK TABLES `staging_bank_organisation` WRITE;
/*!40000 ALTER TABLE `staging_bank_organisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_bank_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_check_list_item_defition`
--

DROP TABLE IF EXISTS `staging_check_list_item_defition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_check_list_item_defition` (
  `check_list_item_defition_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order_number` bigint(20) DEFAULT NULL,
  `required` bit(1) DEFAULT NULL,
  PRIMARY KEY (`check_list_item_defition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_check_list_item_defition`
--

LOCK TABLES `staging_check_list_item_defition` WRITE;
/*!40000 ALTER TABLE `staging_check_list_item_defition` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_check_list_item_defition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_client`
--

DROP TABLE IF EXISTS `staging_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_client` (
  `client_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `colombia_account_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `colombia_client_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `current_employer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flexi_fin_client_id` bigint(20) DEFAULT NULL,
  `flexi_fin_employer_id` bigint(20) DEFAULT NULL,
  `migration_status` int(11) DEFAULT NULL,
  `prevoius_employer_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded_client_sheet_line_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_client`
--

LOCK TABLES `staging_client` WRITE;
/*!40000 ALTER TABLE `staging_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_client_address`
--

DROP TABLE IF EXISTS `staging_client_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_client_address` (
  `client_id` bigint(20) NOT NULL,
  `address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`client_id`,`address_id`),
  UNIQUE KEY `address_id` (`address_id`),
  KEY `FK570CB404D9CECD49` (`address_id`),
  KEY `FK570CB4047E0ACBEB` (`client_id`),
  CONSTRAINT `FK570CB4047E0ACBEB` FOREIGN KEY (`client_id`) REFERENCES `staging_client` (`client_id`),
  CONSTRAINT `FK570CB404D9CECD49` FOREIGN KEY (`address_id`) REFERENCES `staging_address` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_client_address`
--

LOCK TABLES `staging_client_address` WRITE;
/*!40000 ALTER TABLE `staging_client_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_client_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_client_bank_account`
--

DROP TABLE IF EXISTS `staging_client_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_client_bank_account` (
  `client_id` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  PRIMARY KEY (`client_id`,`bank_account_id`),
  UNIQUE KEY `bank_account_id` (`bank_account_id`),
  KEY `FKE87CAD1A7E0ACBEB` (`client_id`),
  KEY `FKE87CAD1A5EF6FF30` (`bank_account_id`),
  CONSTRAINT `FKE87CAD1A5EF6FF30` FOREIGN KEY (`bank_account_id`) REFERENCES `staging_bank_account` (`bank_account_id`),
  CONSTRAINT `FKE87CAD1A7E0ACBEB` FOREIGN KEY (`client_id`) REFERENCES `staging_client` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_client_bank_account`
--

LOCK TABLES `staging_client_bank_account` WRITE;
/*!40000 ALTER TABLE `staging_client_bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_client_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_client_contact_number`
--

DROP TABLE IF EXISTS `staging_client_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_client_contact_number` (
  `client_id` bigint(20) NOT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  PRIMARY KEY (`client_id`,`contact_number_id`),
  UNIQUE KEY `contact_number_id` (`contact_number_id`),
  KEY `FK6D98638EFE478CA` (`contact_number_id`),
  KEY `FK6D986387E0ACBEB` (`client_id`),
  CONSTRAINT `FK6D986387E0ACBEB` FOREIGN KEY (`client_id`) REFERENCES `staging_client` (`client_id`),
  CONSTRAINT `FK6D98638EFE478CA` FOREIGN KEY (`contact_number_id`) REFERENCES `staging_contact_number` (`contact_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_client_contact_number`
--

LOCK TABLES `staging_client_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_client_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_client_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_client_email_address`
--

DROP TABLE IF EXISTS `staging_client_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_client_email_address` (
  `client_id` bigint(20) NOT NULL,
  `email_address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`client_id`,`email_address_id`),
  UNIQUE KEY `email_address_id` (`email_address_id`),
  KEY `FK25C8FE617E0ACBEB` (`client_id`),
  KEY `FK25C8FE61B5AC13D2` (`email_address_id`),
  CONSTRAINT `FK25C8FE61B5AC13D2` FOREIGN KEY (`email_address_id`) REFERENCES `staging_email_address` (`email_address_id`),
  CONSTRAINT `FK25C8FE617E0ACBEB` FOREIGN KEY (`client_id`) REFERENCES `staging_client` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_client_email_address`
--

LOCK TABLES `staging_client_email_address` WRITE;
/*!40000 ALTER TABLE `staging_client_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_client_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_client_person`
--

DROP TABLE IF EXISTS `staging_client_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_client_person` (
  `client_id` bigint(20) NOT NULL,
  `person_id` bigint(20) NOT NULL,
  PRIMARY KEY (`client_id`,`person_id`),
  UNIQUE KEY `person_id` (`person_id`),
  KEY `FKB9634145383427AB` (`person_id`),
  KEY `FKB96341457E0ACBEB` (`client_id`),
  CONSTRAINT `FKB96341457E0ACBEB` FOREIGN KEY (`client_id`) REFERENCES `staging_client` (`client_id`),
  CONSTRAINT `FKB9634145383427AB` FOREIGN KEY (`person_id`) REFERENCES `staging_person` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_client_person`
--

LOCK TABLES `staging_client_person` WRITE;
/*!40000 ALTER TABLE `staging_client_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_client_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_contact_number`
--

DROP TABLE IF EXISTS `staging_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_contact_number` (
  `contact_number_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contact_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  PRIMARY KEY (`contact_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_contact_number`
--

LOCK TABLES `staging_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_custom_field_definition`
--

DROP TABLE IF EXISTS `staging_custom_field_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_custom_field_definition` (
  `custom_field_definition_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `required` bit(1) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`custom_field_definition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_custom_field_definition`
--

LOCK TABLES `staging_custom_field_definition` WRITE;
/*!40000 ALTER TABLE `staging_custom_field_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_custom_field_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_deduction_authorisation`
--

DROP TABLE IF EXISTS `staging_deduction_authorisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_deduction_authorisation` (
  `deduction_authorisation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `authorisation_centralised` bit(1) DEFAULT NULL,
  `does_submission` bit(1) DEFAULT NULL,
  `employer_authorisation_required` bit(1) DEFAULT NULL,
  `gives_affordability` bit(1) DEFAULT NULL,
  `set_aside` bit(1) DEFAULT NULL,
  `signature_document` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verifies_labour_information` bit(1) DEFAULT NULL,
  PRIMARY KEY (`deduction_authorisation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_deduction_authorisation`
--

LOCK TABLES `staging_deduction_authorisation` WRITE;
/*!40000 ALTER TABLE `staging_deduction_authorisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_deduction_authorisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_deduction_configuration`
--

DROP TABLE IF EXISTS `staging_deduction_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_deduction_configuration` (
  `deduction_configuration_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `account` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bank` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `day_in_period_payment_due` bigint(20) DEFAULT NULL,
  `day_in_period_submissions_due` bigint(20) DEFAULT NULL,
  `deduction_frequency` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_errors_delivered` bit(1) DEFAULT NULL,
  `errors_delivery_day` bigint(20) DEFAULT NULL,
  `errors_delivery_method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `errors_digital_format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `errors_email_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `minimum_take_home_amount` bigint(20) DEFAULT NULL,
  `payment_means` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receipting_delivery_method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `submissions_delivery_method` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `submissions_digital_format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `submissions_email_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `take_home_eligibility_amount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`deduction_configuration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_deduction_configuration`
--

LOCK TABLES `staging_deduction_configuration` WRITE;
/*!40000 ALTER TABLE `staging_deduction_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_deduction_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_email_address`
--

DROP TABLE IF EXISTS `staging_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_email_address` (
  `email_address_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  PRIMARY KEY (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_email_address`
--

LOCK TABLES `staging_email_address` WRITE;
/*!40000 ALTER TABLE `staging_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer`
--

DROP TABLE IF EXISTS `staging_employer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer` (
  `employer_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `employer_count` int(11) DEFAULT NULL,
  `employer_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `founding_date` datetime DEFAULT NULL,
  `industry` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lending_entity` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `migration_status` int(11) DEFAULT NULL,
  `registration_no` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `separate_pay_point` bit(1) DEFAULT NULL,
  `uploaded_employer_sheet_line_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer`
--

LOCK TABLES `staging_employer` WRITE;
/*!40000 ALTER TABLE `staging_employer` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_address`
--

DROP TABLE IF EXISTS `staging_employer_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_address` (
  `employer_id` bigint(20) NOT NULL,
  `address_id` bigint(20) NOT NULL,
  UNIQUE KEY `address_id` (`address_id`),
  KEY `FK5AB6A5F4786665AB` (`employer_id`),
  KEY `FK5AB6A5F4D9CECD49` (`address_id`),
  CONSTRAINT `FK5AB6A5F4D9CECD49` FOREIGN KEY (`address_id`) REFERENCES `staging_address` (`address_id`),
  CONSTRAINT `FK5AB6A5F4786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_address`
--

LOCK TABLES `staging_employer_address` WRITE;
/*!40000 ALTER TABLE `staging_employer_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_bank_account`
--

DROP TABLE IF EXISTS `staging_employer_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_bank_account` (
  `employer_id` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  UNIQUE KEY `bank_account_id` (`bank_account_id`),
  KEY `FK9FEC712A786665AB` (`employer_id`),
  KEY `FK9FEC712A5EF6FF30` (`bank_account_id`),
  CONSTRAINT `FK9FEC712A5EF6FF30` FOREIGN KEY (`bank_account_id`) REFERENCES `staging_bank_account` (`bank_account_id`),
  CONSTRAINT `FK9FEC712A786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_bank_account`
--

LOCK TABLES `staging_employer_bank_account` WRITE;
/*!40000 ALTER TABLE `staging_employer_bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_check_list_item_defition`
--

DROP TABLE IF EXISTS `staging_employer_check_list_item_defition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_check_list_item_defition` (
  `employer_id` bigint(20) NOT NULL,
  `check_list_item_defition_id` bigint(20) NOT NULL,
  UNIQUE KEY `check_list_item_defition_id` (`check_list_item_defition_id`),
  KEY `FK218FEA7A786665AB` (`employer_id`),
  KEY `FK218FEA7A6013953B` (`check_list_item_defition_id`),
  CONSTRAINT `FK218FEA7A6013953B` FOREIGN KEY (`check_list_item_defition_id`) REFERENCES `staging_check_list_item_defition` (`check_list_item_defition_id`),
  CONSTRAINT `FK218FEA7A786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_check_list_item_defition`
--

LOCK TABLES `staging_employer_check_list_item_defition` WRITE;
/*!40000 ALTER TABLE `staging_employer_check_list_item_defition` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_check_list_item_defition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_contact_number`
--

DROP TABLE IF EXISTS `staging_employer_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_contact_number` (
  `employer_id` bigint(20) NOT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  UNIQUE KEY `contact_number_id` (`contact_number_id`),
  KEY `FKA1688648786665AB` (`employer_id`),
  KEY `FKA1688648EFE478CA` (`contact_number_id`),
  CONSTRAINT `FKA1688648EFE478CA` FOREIGN KEY (`contact_number_id`) REFERENCES `staging_contact_number` (`contact_number_id`),
  CONSTRAINT `FKA1688648786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_contact_number`
--

LOCK TABLES `staging_employer_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_employer_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_custom_field_definition`
--

DROP TABLE IF EXISTS `staging_employer_custom_field_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_custom_field_definition` (
  `employer_id` bigint(20) NOT NULL,
  `custom_field_definition_id` bigint(20) NOT NULL,
  UNIQUE KEY `custom_field_definition_id` (`custom_field_definition_id`),
  KEY `FK38DA7AC6FDFD8B3F` (`custom_field_definition_id`),
  KEY `FK38DA7AC6786665AB` (`employer_id`),
  CONSTRAINT `FK38DA7AC6786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`),
  CONSTRAINT `FK38DA7AC6FDFD8B3F` FOREIGN KEY (`custom_field_definition_id`) REFERENCES `staging_custom_field_definition` (`custom_field_definition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_custom_field_definition`
--

LOCK TABLES `staging_employer_custom_field_definition` WRITE;
/*!40000 ALTER TABLE `staging_employer_custom_field_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_custom_field_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_deduction_code`
--

DROP TABLE IF EXISTS `staging_employer_deduction_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_deduction_code` (
  `employer_deduction_code_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `end_date` datetime DEFAULT NULL,
  `issue_date` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `validity_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `validity_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`employer_deduction_code_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_deduction_code`
--

LOCK TABLES `staging_employer_deduction_code` WRITE;
/*!40000 ALTER TABLE `staging_employer_deduction_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_deduction_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_email_address`
--

DROP TABLE IF EXISTS `staging_employer_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_email_address` (
  `employer_id` bigint(20) NOT NULL,
  `email_address_id` bigint(20) NOT NULL,
  UNIQUE KEY `email_address_id` (`email_address_id`),
  KEY `FK5C51BC51786665AB` (`employer_id`),
  KEY `FK5C51BC51B5AC13D2` (`email_address_id`),
  CONSTRAINT `FK5C51BC51B5AC13D2` FOREIGN KEY (`email_address_id`) REFERENCES `staging_email_address` (`email_address_id`),
  CONSTRAINT `FK5C51BC51786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_email_address`
--

LOCK TABLES `staging_employer_email_address` WRITE;
/*!40000 ALTER TABLE `staging_employer_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_labour_envirnment`
--

DROP TABLE IF EXISTS `staging_employer_labour_envirnment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_labour_envirnment` (
  `employer_id` bigint(20) NOT NULL,
  `labour_envirnment_id` bigint(20) NOT NULL,
  UNIQUE KEY `labour_envirnment_id` (`labour_envirnment_id`),
  KEY `FK6BB24556786665AB` (`employer_id`),
  KEY `FK6BB24556515E01E7` (`labour_envirnment_id`),
  CONSTRAINT `FK6BB24556515E01E7` FOREIGN KEY (`labour_envirnment_id`) REFERENCES `staging_labour_envirnment` (`labour_envirnment_id`),
  CONSTRAINT `FK6BB24556786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_labour_envirnment`
--

LOCK TABLES `staging_employer_labour_envirnment` WRITE;
/*!40000 ALTER TABLE `staging_employer_labour_envirnment` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_labour_envirnment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_organisation`
--

DROP TABLE IF EXISTS `staging_employer_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_organisation` (
  `employer_id` bigint(20) NOT NULL,
  `organisation_id` bigint(20) NOT NULL,
  UNIQUE KEY `organisation_id` (`organisation_id`),
  KEY `FK470A36DA786665AB` (`employer_id`),
  KEY `FK470A36DAF786ECCB` (`organisation_id`),
  CONSTRAINT `FK470A36DAF786ECCB` FOREIGN KEY (`organisation_id`) REFERENCES `staging_organisation` (`organisation_id`),
  CONSTRAINT `FK470A36DA786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_organisation`
--

LOCK TABLES `staging_employer_organisation` WRITE;
/*!40000 ALTER TABLE `staging_employer_organisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_payslip_line_item_definition`
--

DROP TABLE IF EXISTS `staging_employer_payslip_line_item_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_payslip_line_item_definition` (
  `employer_id` bigint(20) NOT NULL,
  `payslip_line_item_definition_id` bigint(20) NOT NULL,
  UNIQUE KEY `payslip_line_item_definition_id` (`payslip_line_item_definition_id`),
  KEY `FKD89D9FAB786665AB` (`employer_id`),
  KEY `FKD89D9FAB24E0D860` (`payslip_line_item_definition_id`),
  CONSTRAINT `FKD89D9FAB24E0D860` FOREIGN KEY (`payslip_line_item_definition_id`) REFERENCES `staging_payslip_line_item_definition` (`payslip_line_item_definition_id`),
  CONSTRAINT `FKD89D9FAB786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_payslip_line_item_definition`
--

LOCK TABLES `staging_employer_payslip_line_item_definition` WRITE;
/*!40000 ALTER TABLE `staging_employer_payslip_line_item_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_payslip_line_item_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_staging_employer_deduction_authorisation`
--

DROP TABLE IF EXISTS `staging_employer_staging_employer_deduction_authorisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_staging_employer_deduction_authorisation` (
  `employer_id` bigint(20) NOT NULL,
  `deduction_authorisation_id` bigint(20) NOT NULL,
  UNIQUE KEY `deduction_authorisation_id` (`deduction_authorisation_id`),
  KEY `FKC70591C6786665AB` (`employer_id`),
  KEY `FKC70591C65D614200` (`deduction_authorisation_id`),
  CONSTRAINT `FKC70591C65D614200` FOREIGN KEY (`deduction_authorisation_id`) REFERENCES `staging_deduction_authorisation` (`deduction_authorisation_id`),
  CONSTRAINT `FKC70591C6786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_staging_employer_deduction_authorisation`
--

LOCK TABLES `staging_employer_staging_employer_deduction_authorisation` WRITE;
/*!40000 ALTER TABLE `staging_employer_staging_employer_deduction_authorisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_staging_employer_deduction_authorisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_staging_employer_deduction_code`
--

DROP TABLE IF EXISTS `staging_employer_staging_employer_deduction_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_staging_employer_deduction_code` (
  `employer_id` bigint(20) NOT NULL,
  `employer_deduction_code_id` bigint(20) NOT NULL,
  UNIQUE KEY `employer_deduction_code_id` (`employer_deduction_code_id`),
  KEY `FKE6D7FD87786665AB` (`employer_id`),
  KEY `FKE6D7FD87DF0D15` (`employer_deduction_code_id`),
  CONSTRAINT `FKE6D7FD87DF0D15` FOREIGN KEY (`employer_deduction_code_id`) REFERENCES `staging_employer_deduction_code` (`employer_deduction_code_id`),
  CONSTRAINT `FKE6D7FD87786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_staging_employer_deduction_code`
--

LOCK TABLES `staging_employer_staging_employer_deduction_code` WRITE;
/*!40000 ALTER TABLE `staging_employer_staging_employer_deduction_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_staging_employer_deduction_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_staging_employer_deduction_configuration`
--

DROP TABLE IF EXISTS `staging_employer_staging_employer_deduction_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_staging_employer_deduction_configuration` (
  `employer_id` bigint(20) NOT NULL,
  `deduction_configuration_id` bigint(20) NOT NULL,
  UNIQUE KEY `deduction_configuration_id` (`deduction_configuration_id`),
  KEY `FK98C1129C786665AB` (`employer_id`),
  KEY `FK98C1129CFA128A40` (`deduction_configuration_id`),
  CONSTRAINT `FK98C1129CFA128A40` FOREIGN KEY (`deduction_configuration_id`) REFERENCES `staging_deduction_configuration` (`deduction_configuration_id`),
  CONSTRAINT `FK98C1129C786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_staging_employer_deduction_configuration`
--

LOCK TABLES `staging_employer_staging_employer_deduction_configuration` WRITE;
/*!40000 ALTER TABLE `staging_employer_staging_employer_deduction_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_staging_employer_deduction_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_labour_envirnment`
--

DROP TABLE IF EXISTS `staging_labour_envirnment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_labour_envirnment` (
  `labour_envirnment_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `anticipated_retrenched_employee_count` int(11) DEFAULT NULL,
  `average_employment_period` int(11) DEFAULT NULL,
  `contract_worker_count` int(11) DEFAULT NULL,
  `full_time_employer_count` int(11) DEFAULT NULL,
  `in_first_year_employee_count` int(11) DEFAULT NULL,
  `last_year_retrenched_employee_count` int(11) DEFAULT NULL,
  `loan_scheme_employee_count` int(11) DEFAULT NULL,
  `pensioned_worker_count` int(11) DEFAULT NULL,
  `temporary_worker_count` int(11) DEFAULT NULL,
  `undefined_worker_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`labour_envirnment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_labour_envirnment`
--

LOCK TABLES `staging_labour_envirnment` WRITE;
/*!40000 ALTER TABLE `staging_labour_envirnment` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_labour_envirnment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_loan_book_upload_error`
--

DROP TABLE IF EXISTS `staging_loan_book_upload_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_loan_book_upload_error` (
  `loanbook_upload_id` bigint(20) NOT NULL,
  `loanbook_upload_error_id` bigint(20) NOT NULL,
  UNIQUE KEY `loanbook_upload_error_id` (`loanbook_upload_error_id`),
  KEY `FK5BAFF6D557A22F57` (`loanbook_upload_id`),
  KEY `FK5BAFF6D5B46EB0E` (`loanbook_upload_error_id`),
  CONSTRAINT `FK5BAFF6D5B46EB0E` FOREIGN KEY (`loanbook_upload_error_id`) REFERENCES `staging_loanbook_upload_error` (`loanbook_upload_error_id`),
  CONSTRAINT `FK5BAFF6D557A22F57` FOREIGN KEY (`loanbook_upload_id`) REFERENCES `staging_loanbook_upload` (`loanbook_upload_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_loan_book_upload_error`
--

LOCK TABLES `staging_loan_book_upload_error` WRITE;
/*!40000 ALTER TABLE `staging_loan_book_upload_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_loan_book_upload_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_loanbook_upload`
--

DROP TABLE IF EXISTS `staging_loanbook_upload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_loanbook_upload` (
  `loanbook_upload_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `data_sheet_type` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `is_exported_to_flexifin` bit(1) DEFAULT NULL,
  `loanbook_data_sheet` longblob NOT NULL,
  `number_of_rows` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `uploaded_by` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uploaded_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `year` datetime DEFAULT NULL,
  PRIMARY KEY (`loanbook_upload_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_loanbook_upload`
--

LOCK TABLES `staging_loanbook_upload` WRITE;
/*!40000 ALTER TABLE `staging_loanbook_upload` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_loanbook_upload` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_loanbook_upload_error`
--

DROP TABLE IF EXISTS `staging_loanbook_upload_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_loanbook_upload_error` (
  `loanbook_upload_error_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `coloumn_value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `column_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `error_message` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `row_number` int(11) DEFAULT NULL,
  PRIMARY KEY (`loanbook_upload_error_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_loanbook_upload_error`
--

LOCK TABLES `staging_loanbook_upload_error` WRITE;
/*!40000 ALTER TABLE `staging_loanbook_upload_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_loanbook_upload_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_organisation`
--

DROP TABLE IF EXISTS `staging_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_organisation` (
  `organisation_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sales_tax_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tax_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`organisation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_organisation`
--

LOCK TABLES `staging_organisation` WRITE;
/*!40000 ALTER TABLE `staging_organisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_outlet`
--

DROP TABLE IF EXISTS `staging_outlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_outlet` (
  `outlet_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `uploaded_outlet_sheet_line_number` int(11) DEFAULT NULL,
  `migration_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`outlet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_outlet`
--

LOCK TABLES `staging_outlet` WRITE;
/*!40000 ALTER TABLE `staging_outlet` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_outlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_outlet_address`
--

DROP TABLE IF EXISTS `staging_outlet_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_outlet_address` (
  `outlet_id` bigint(20) NOT NULL,
  `address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`outlet_id`,`address_id`),
  UNIQUE KEY `address_id` (`address_id`),
  KEY `FK205B6646D9CECD49` (`address_id`),
  KEY `FK205B66467E804CAB` (`outlet_id`),
  CONSTRAINT `FK205B66467E804CAB` FOREIGN KEY (`outlet_id`) REFERENCES `staging_outlet` (`outlet_id`),
  CONSTRAINT `FK205B6646D9CECD49` FOREIGN KEY (`address_id`) REFERENCES `staging_address` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_outlet_address`
--

LOCK TABLES `staging_outlet_address` WRITE;
/*!40000 ALTER TABLE `staging_outlet_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_outlet_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_outlet_contact_number`
--

DROP TABLE IF EXISTS `staging_outlet_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_outlet_contact_number` (
  `outlet_id` bigint(20) NOT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  PRIMARY KEY (`outlet_id`,`contact_number_id`),
  UNIQUE KEY `contact_number_id` (`contact_number_id`),
  KEY `FK230C25B6EFE478CA` (`contact_number_id`),
  KEY `FK230C25B67E804CAB` (`outlet_id`),
  CONSTRAINT `FK230C25B67E804CAB` FOREIGN KEY (`outlet_id`) REFERENCES `staging_outlet` (`outlet_id`),
  CONSTRAINT `FK230C25B6EFE478CA` FOREIGN KEY (`contact_number_id`) REFERENCES `staging_contact_number` (`contact_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_outlet_contact_number`
--

LOCK TABLES `staging_outlet_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_outlet_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_outlet_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_outlet_email_address`
--

DROP TABLE IF EXISTS `staging_outlet_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_outlet_email_address` (
  `outlet_id` bigint(20) NOT NULL,
  `email_address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`outlet_id`,`email_address_id`),
  UNIQUE KEY `email_address_id` (`email_address_id`),
  KEY `FKF52577237E804CAB` (`outlet_id`),
  KEY `FKF5257723B5AC13D2` (`email_address_id`),
  CONSTRAINT `FKF5257723B5AC13D2` FOREIGN KEY (`email_address_id`) REFERENCES `staging_email_address` (`email_address_id`),
  CONSTRAINT `FKF52577237E804CAB` FOREIGN KEY (`outlet_id`) REFERENCES `staging_outlet` (`outlet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_outlet_email_address`
--

LOCK TABLES `staging_outlet_email_address` WRITE;
/*!40000 ALTER TABLE `staging_outlet_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_outlet_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_outlet_organisation`
--

DROP TABLE IF EXISTS `staging_outlet_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_outlet_organisation` (
  `outlet_id` bigint(20) NOT NULL,
  `organisation_id` bigint(20) NOT NULL,
  PRIMARY KEY (`outlet_id`,`organisation_id`),
  UNIQUE KEY `organisation_id` (`organisation_id`),
  KEY `FK964AD9C87E804CAB` (`outlet_id`),
  KEY `FK964AD9C8F786ECCB` (`organisation_id`),
  CONSTRAINT `FK964AD9C8F786ECCB` FOREIGN KEY (`organisation_id`) REFERENCES `staging_organisation` (`organisation_id`),
  CONSTRAINT `FK964AD9C87E804CAB` FOREIGN KEY (`outlet_id`) REFERENCES `staging_outlet` (`outlet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_outlet_organisation`
--

LOCK TABLES `staging_outlet_organisation` WRITE;
/*!40000 ALTER TABLE `staging_outlet_organisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_outlet_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_payment_history`
--

DROP TABLE IF EXISTS `staging_payment_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_payment_history` (
  `payment_history_id` int(11) NOT NULL AUTO_INCREMENT,
  `filing_number` int(11) DEFAULT NULL,
  `flexifin_account_id` bigint(20) DEFAULT NULL,
  `received_amount` double DEFAULT NULL,
  `received_date` datetime DEFAULT NULL,
  `staging_account_id` int(11) DEFAULT NULL,
  `uploaded_sheet_linenumber` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`payment_history_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_payment_history`
--

LOCK TABLES `staging_payment_history` WRITE;
/*!40000 ALTER TABLE `staging_payment_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_payment_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_payslip_line_item_definition`
--

DROP TABLE IF EXISTS `staging_payslip_line_item_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_payslip_line_item_definition` (
  `payslip_line_item_definition_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payslip_line_item_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `required` bit(1) DEFAULT NULL,
  `sort_order` int(11) DEFAULT NULL,
  `weight_percent` float DEFAULT NULL,
  PRIMARY KEY (`payslip_line_item_definition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_payslip_line_item_definition`
--

LOCK TABLES `staging_payslip_line_item_definition` WRITE;
/*!40000 ALTER TABLE `staging_payslip_line_item_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_payslip_line_item_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_person`
--

DROP TABLE IF EXISTS `staging_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_person` (
  `person_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `birth_city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_date` datetime DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `comments` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dependants` int(11) DEFAULT NULL,
  `education_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_issued_city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_issue_date` datetime DEFAULT NULL,
  `id_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marital_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mother_maiden_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `occupation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `occupation_position` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `occupation_status` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport_expire_date` datetime DEFAULT NULL,
  `passport_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `suffix` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tittle` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_years_work_experience` int(11) DEFAULT NULL,
  PRIMARY KEY (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_person`
--

LOCK TABLES `staging_person` WRITE;
/*!40000 ALTER TABLE `staging_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_third_party`
--

DROP TABLE IF EXISTS `staging_third_party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_third_party` (
  `third_party_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `uploaded_third_party_sheet_line_number` int(11) DEFAULT NULL,
  `migration_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`third_party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_third_party`
--

LOCK TABLES `staging_third_party` WRITE;
/*!40000 ALTER TABLE `staging_third_party` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_third_party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_third_party_address`
--

DROP TABLE IF EXISTS `staging_third_party_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_third_party_address` (
  `third_party_id` bigint(20) NOT NULL,
  `address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`third_party_id`,`address_id`),
  UNIQUE KEY `address_id` (`address_id`),
  KEY `FK7296A8BFD9CECD49` (`address_id`),
  KEY `FK7296A8BF83B3E43C` (`third_party_id`),
  CONSTRAINT `FK7296A8BF83B3E43C` FOREIGN KEY (`third_party_id`) REFERENCES `staging_third_party` (`third_party_id`),
  CONSTRAINT `FK7296A8BFD9CECD49` FOREIGN KEY (`address_id`) REFERENCES `staging_address` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_third_party_address`
--

LOCK TABLES `staging_third_party_address` WRITE;
/*!40000 ALTER TABLE `staging_third_party_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_third_party_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_third_party_contact_number`
--

DROP TABLE IF EXISTS `staging_third_party_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_third_party_contact_number` (
  `third_party_id` bigint(20) NOT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  PRIMARY KEY (`third_party_id`,`contact_number_id`),
  UNIQUE KEY `contact_number_id` (`contact_number_id`),
  KEY `FKF70D91DEFE478CA` (`contact_number_id`),
  KEY `FKF70D91D83B3E43C` (`third_party_id`),
  CONSTRAINT `FKF70D91D83B3E43C` FOREIGN KEY (`third_party_id`) REFERENCES `staging_third_party` (`third_party_id`),
  CONSTRAINT `FKF70D91DEFE478CA` FOREIGN KEY (`contact_number_id`) REFERENCES `staging_contact_number` (`contact_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_third_party_contact_number`
--

LOCK TABLES `staging_third_party_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_third_party_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_third_party_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_third_party_email_address`
--

DROP TABLE IF EXISTS `staging_third_party_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_third_party_email_address` (
  `third_party_id` bigint(20) NOT NULL,
  `email_address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`third_party_id`,`email_address_id`),
  UNIQUE KEY `email_address_id` (`email_address_id`),
  KEY `FKCB393ADCB5AC13D2` (`email_address_id`),
  KEY `FKCB393ADC83B3E43C` (`third_party_id`),
  CONSTRAINT `FKCB393ADC83B3E43C` FOREIGN KEY (`third_party_id`) REFERENCES `staging_third_party` (`third_party_id`),
  CONSTRAINT `FKCB393ADCB5AC13D2` FOREIGN KEY (`email_address_id`) REFERENCES `staging_email_address` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_third_party_email_address`
--

LOCK TABLES `staging_third_party_email_address` WRITE;
/*!40000 ALTER TABLE `staging_third_party_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_third_party_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_third_party_organisation`
--

DROP TABLE IF EXISTS `staging_third_party_organisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_third_party_organisation` (
  `third_party_id` bigint(20) NOT NULL,
  `organisation_id` bigint(20) NOT NULL,
  PRIMARY KEY (`third_party_id`,`organisation_id`),
  UNIQUE KEY `organisation_id` (`organisation_id`),
  KEY `FKDF433AEFF786ECCB` (`organisation_id`),
  KEY `FKDF433AEF83B3E43C` (`third_party_id`),
  CONSTRAINT `FKDF433AEF83B3E43C` FOREIGN KEY (`third_party_id`) REFERENCES `staging_third_party` (`third_party_id`),
  CONSTRAINT `FKDF433AEFF786ECCB` FOREIGN KEY (`organisation_id`) REFERENCES `staging_organisation` (`organisation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_third_party_organisation`
--

LOCK TABLES `staging_third_party_organisation` WRITE;
/*!40000 ALTER TABLE `staging_third_party_organisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_third_party_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_user`
--

DROP TABLE IF EXISTS `staging_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_user` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `job_position_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `migration_status` int(11) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `uploaded_user_sheet_line_number` int(11) DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_user`
--

LOCK TABLES `staging_user` WRITE;
/*!40000 ALTER TABLE `staging_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_user_address`
--

DROP TABLE IF EXISTS `staging_user_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_user_address` (
  `user_id` bigint(20) NOT NULL,
  `address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`address_id`),
  UNIQUE KEY `address_id` (`address_id`),
  KEY `FKC904FD04D9CECD49` (`address_id`),
  KEY `FKC904FD04F22F1C2B` (`user_id`),
  CONSTRAINT `FKC904FD04F22F1C2B` FOREIGN KEY (`user_id`) REFERENCES `staging_user` (`user_id`),
  CONSTRAINT `FKC904FD04D9CECD49` FOREIGN KEY (`address_id`) REFERENCES `staging_address` (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_user_address`
--

LOCK TABLES `staging_user_address` WRITE;
/*!40000 ALTER TABLE `staging_user_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_user_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_user_bank_account`
--

DROP TABLE IF EXISTS `staging_user_bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_user_bank_account` (
  `user_id` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`bank_account_id`),
  UNIQUE KEY `bank_account_id` (`bank_account_id`),
  KEY `FK834A041AF22F1C2B` (`user_id`),
  KEY `FK834A041A5EF6FF30` (`bank_account_id`),
  CONSTRAINT `FK834A041A5EF6FF30` FOREIGN KEY (`bank_account_id`) REFERENCES `staging_bank_account` (`bank_account_id`),
  CONSTRAINT `FK834A041AF22F1C2B` FOREIGN KEY (`user_id`) REFERENCES `staging_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_user_bank_account`
--

LOCK TABLES `staging_user_bank_account` WRITE;
/*!40000 ALTER TABLE `staging_user_bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_user_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_user_contact_number`
--

DROP TABLE IF EXISTS `staging_user_contact_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_user_contact_number` (
  `user_id` bigint(20) NOT NULL,
  `contact_number_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`contact_number_id`),
  UNIQUE KEY `contact_number_id` (`contact_number_id`),
  KEY `FK23AD1D38EFE478CA` (`contact_number_id`),
  KEY `FK23AD1D38F22F1C2B` (`user_id`),
  CONSTRAINT `FK23AD1D38F22F1C2B` FOREIGN KEY (`user_id`) REFERENCES `staging_user` (`user_id`),
  CONSTRAINT `FK23AD1D38EFE478CA` FOREIGN KEY (`contact_number_id`) REFERENCES `staging_contact_number` (`contact_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_user_contact_number`
--

LOCK TABLES `staging_user_contact_number` WRITE;
/*!40000 ALTER TABLE `staging_user_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_user_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_user_email_address`
--

DROP TABLE IF EXISTS `staging_user_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_user_email_address` (
  `user_id` bigint(20) NOT NULL,
  `email_address_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`email_address_id`),
  UNIQUE KEY `email_address_id` (`email_address_id`),
  KEY `FKE4A68761F22F1C2B` (`user_id`),
  KEY `FKE4A68761B5AC13D2` (`email_address_id`),
  CONSTRAINT `FKE4A68761B5AC13D2` FOREIGN KEY (`email_address_id`) REFERENCES `staging_email_address` (`email_address_id`),
  CONSTRAINT `FKE4A68761F22F1C2B` FOREIGN KEY (`user_id`) REFERENCES `staging_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_user_email_address`
--

LOCK TABLES `staging_user_email_address` WRITE;
/*!40000 ALTER TABLE `staging_user_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_user_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_user_person`
--

DROP TABLE IF EXISTS `staging_user_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_user_person` (
  `user_id` bigint(20) NOT NULL,
  `person_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_id`,`person_id`),
  UNIQUE KEY `person_id` (`person_id`),
  KEY `FK72BDD845383427AB` (`person_id`),
  KEY `FK72BDD845F22F1C2B` (`user_id`),
  CONSTRAINT `FK72BDD845F22F1C2B` FOREIGN KEY (`user_id`) REFERENCES `staging_user` (`user_id`),
  CONSTRAINT `FK72BDD845383427AB` FOREIGN KEY (`person_id`) REFERENCES `staging_person` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_user_person`
--

LOCK TABLES `staging_user_person` WRITE;
/*!40000 ALTER TABLE `staging_user_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_user_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suburb`
--

DROP TABLE IF EXISTS `suburb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suburb` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `flexi_fin_id` bigint(20) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `city_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCADC5F2529BCB82B` (`city_id`),
  CONSTRAINT `FKCADC5F2529BCB82B` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suburb`
--

LOCK TABLES `suburb` WRITE;
/*!40000 ALTER TABLE `suburb` DISABLE KEYS */;
/*!40000 ALTER TABLE `suburb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `flexifin_user_id` bigint(20) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Table structure for table `staging_submission_date`
--

DROP TABLE IF EXISTS `staging_submission_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_submission_date` (
  `submission_date_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_due` datetime DEFAULT NULL,
  PRIMARY KEY (`submission_date_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_submission_date`
--

LOCK TABLES `staging_submission_date` WRITE;
/*!40000 ALTER TABLE `staging_submission_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_submission_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_receipting_date`
--

DROP TABLE IF EXISTS `staging_receipting_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_receipting_date` (
  `receipting_date_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date_due` datetime DEFAULT NULL,
  PRIMARY KEY (`receipting_date_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_receipting_date`
--

LOCK TABLES `staging_receipting_date` WRITE;
/*!40000 ALTER TABLE `staging_receipting_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_receipting_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_first_instalment_schedule`
--

DROP TABLE IF EXISTS `staging_first_instalment_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_first_instalment_schedule` (
  `first_instalment_schedule_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cut_off_date` datetime DEFAULT NULL,
  `feid_date` datetime DEFAULT NULL,
  PRIMARY KEY (`first_instalment_schedule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_first_instalment_schedule`
--

LOCK TABLES `staging_first_instalment_schedule` WRITE;
/*!40000 ALTER TABLE `staging_first_instalment_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_first_instalment_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_submission_date`
--

DROP TABLE IF EXISTS `staging_employer_submission_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_submission_date` (
  `deduction_configuration_id` bigint(20) NOT NULL,
  `submission_date_id` bigint(20) NOT NULL,
  UNIQUE KEY `submission_date_id` (`submission_date_id`),
  KEY `FK9F05A6C1FA128A40` (`deduction_configuration_id`),
  KEY `FK9F05A6C1DC927B84` (`submission_date_id`),
  CONSTRAINT `FK9F05A6C1DC927B84` FOREIGN KEY (`submission_date_id`) REFERENCES `staging_submission_date` (`submission_date_id`),
  CONSTRAINT `FK9F05A6C1FA128A40` FOREIGN KEY (`deduction_configuration_id`) REFERENCES `staging_deduction_configuration` (`deduction_configuration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_submission_date`
--

LOCK TABLES `staging_employer_submission_date` WRITE;
/*!40000 ALTER TABLE `staging_employer_submission_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_submission_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_first_instalment_schedule`
--

DROP TABLE IF EXISTS `staging_employer_first_instalment_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_first_instalment_schedule` (
  `employer_id` bigint(20) NOT NULL,
  `first_instalment_schedule_id` bigint(20) NOT NULL,
  UNIQUE KEY `first_instalment_schedule_id` (`first_instalment_schedule_id`),
  KEY `FK3F7E60F8786665AB` (`employer_id`),
  KEY `FK3F7E60F8E2141227` (`first_instalment_schedule_id`),
  CONSTRAINT `FK3F7E60F8E2141227` FOREIGN KEY (`first_instalment_schedule_id`) REFERENCES `staging_first_instalment_schedule` (`first_instalment_schedule_id`),
  CONSTRAINT `FK3F7E60F8786665AB` FOREIGN KEY (`employer_id`) REFERENCES `staging_employer` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_first_instalment_schedule`
--

LOCK TABLES `staging_employer_first_instalment_schedule` WRITE;
/*!40000 ALTER TABLE `staging_employer_first_instalment_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_first_instalment_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `staging_employer_receipting_date`
--

DROP TABLE IF EXISTS `staging_employer_receipting_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `staging_employer_receipting_date` (
  `deduction_configuration_id` bigint(20) NOT NULL,
  `receipting_date_id` bigint(20) NOT NULL,
  UNIQUE KEY `receipting_date_id` (`receipting_date_id`),
  KEY `FK4ED37223FA128A40` (`deduction_configuration_id`),
  KEY `FK4ED3722399939D40` (`receipting_date_id`),
  CONSTRAINT `FK4ED3722399939D40` FOREIGN KEY (`receipting_date_id`) REFERENCES `staging_receipting_date` (`receipting_date_id`),
  CONSTRAINT `FK4ED37223FA128A40` FOREIGN KEY (`deduction_configuration_id`) REFERENCES `staging_deduction_configuration` (`deduction_configuration_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staging_employer_receipting_date`
--

LOCK TABLES `staging_employer_receipting_date` WRITE;
/*!40000 ALTER TABLE `staging_employer_receipting_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `staging_employer_receipting_date` ENABLE KEYS */;
UNLOCK TABLES;


-- this line should be at the end of file.
SET FOREIGN_KEY_CHECKS=1