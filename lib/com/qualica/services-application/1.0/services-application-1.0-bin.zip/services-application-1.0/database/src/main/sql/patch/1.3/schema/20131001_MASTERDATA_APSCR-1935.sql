SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE masterdata;

DROP PROCEDURE IF EXISTS masterdata.add_column ;

DELIMITER $$

CREATE PROCEDURE masterdata.add_column(
  IN tableName VARCHAR(100) character set utf8,
  IN colName VARCHAR(100) character set utf8,
  IN colType VARCHAR(100) character set utf8,
  IN defaultValue VARCHAR(100) character set utf8
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'masterdata'
      )
  THEN


      SET @Statement = CONCAT('ALTER TABLE `masterdata`.`', tableName ,'` ADD COLUMN `', colName, '` ', colType, ' not null ', defaultValue);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;



CALL masterdata.add_column('payslip_line_item_definition', 'deleted', 'bit(1)', 'DEFAULT 0');

DROP PROCEDURE IF EXISTS masterdata.add_column ;

SET SQL_MODE=@OLD_SQL_MODE ;