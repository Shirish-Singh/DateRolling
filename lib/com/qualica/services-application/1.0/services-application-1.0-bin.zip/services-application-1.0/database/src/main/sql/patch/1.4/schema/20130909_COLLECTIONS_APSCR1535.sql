use collections;

DROP PROCEDURE IF EXISTS collections.add_column ;

DELIMITER $$

CREATE PROCEDURE collections.add_column(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100),
  IN colType VARCHAR(100),
  IN defaultValue VARCHAR(100),
  IN afterColName VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'collections'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` ADD COLUMN `', colName ,'` ', colType, ' default null AFTER ',afterColName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

-- Alter collection_case table
CALL collections.add_column('collection_case', 'assigned_agent_id', 'BIGINT(20)', 'NULL', 'entity_id') ;
CALL collections.add_column('collection_case', 'employer_id', 'BIGINT(20)', 'NULL', 'assigned_agent_id') ;
CALL collections.add_column('collection_case', 'branch_id', 'BIGINT(20)', 'NULL', 'employer_id') ;
CALL collections.add_column('collection_case', 'region_id', 'BIGINT(20)', 'NULL', 'branch_id') ;
CALL collections.add_column('collection_case', 'city_id', 'BIGINT(20)', 'NULL', 'region_id') ;
CALL collections.add_column('collection_case', 'suburb_id', 'BIGINT(20)', 'NULL', 'city_id') ;
CALL collections.add_column('collection_case', 'loan_amount', 'BIGINT(20)', 'NULL', 'suburb_id') ;
CALL collections.add_column('collection_case', 'outstanding_loan_amount', 'BIGINT(20)', 'NULL', 'loan_amount') ;
CALL collections.add_column('collection_case', 'loan_application_id', 'BIGINT(20)', 'NULL', 'outstanding_loan_amount') ;
CALL collections.add_column('collection_case', 'loan_issue_year', 'INT(4)', 'NULL', 'loan_application_id') ;
CALL collections.add_column('collection_case', 'loan_cycle', 'INT(4)', 'NULL', 'loan_issue_year') ;
CALL collections.add_column('collection_case', 'birth_date', 'datetime', 'NULL', 'loan_cycle') ;
CALL collections.add_column('collection_case', 'recency', 'VARCHAR(255)', 'NULL', 'birth_date') ;

-- Alter collection_case_aud table
CALL collections.add_column('collection_case_aud', 'assigned_agent_id', 'BIGINT(20)', 'NULL', 'entity_id') ;
CALL collections.add_column('collection_case_aud', 'employer_id', 'BIGINT(20)', 'NULL', 'assigned_agent_id') ;
CALL collections.add_column('collection_case_aud', 'branch_id', 'BIGINT(20)', 'NULL', 'employer_id') ;
CALL collections.add_column('collection_case_aud', 'region_id', 'BIGINT(20)', 'NULL', 'branch_id') ;
CALL collections.add_column('collection_case_aud', 'city_id', 'BIGINT(20)', 'NULL', 'region_id') ;
CALL collections.add_column('collection_case_aud', 'suburb_id', 'BIGINT(20)', 'NULL', 'city_id') ;
CALL collections.add_column('collection_case_aud', 'loan_amount', 'BIGINT(20)', 'NULL', 'suburb_id') ;
CALL collections.add_column('collection_case_aud', 'outstanding_loan_amount', 'BIGINT(20)', 'NULL', 'loan_amount') ;
CALL collections.add_column('collection_case_aud', 'loan_application_id', 'BIGINT(20)', 'NULL', 'outstanding_loan_amount') ;
CALL collections.add_column('collection_case_aud', 'loan_issue_year', 'INT(4)', 'NULL', 'loan_application_id') ;
CALL collections.add_column('collection_case_aud', 'loan_cycle', 'INT(4)', 'NULL', 'loan_issue_year') ;
CALL collections.add_column('collection_case_aud', 'birth_date', 'datetime', 'NULL', 'loan_cycle') ;
CALL collections.add_column('collection_case_aud', 'recency', 'VARCHAR(255)', 'NULL', 'birth_date') ;




DROP PROCEDURE IF EXISTS collections.add_column ;

