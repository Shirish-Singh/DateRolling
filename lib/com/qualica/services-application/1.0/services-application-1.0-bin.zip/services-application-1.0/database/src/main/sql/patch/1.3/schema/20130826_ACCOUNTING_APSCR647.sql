SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_table ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_table(
  IN tableName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE table_name = tableName
      )
  THEN
      SET @Statement = CONCAT('DROP TABLE `accounting`.`', tableName, '`');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;
  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_table('agreement_action_cooloff');
CALL accounting.drop_table('agreement_action_cooloff_aud');
CALL accounting.drop_table('agreement_action_refund');
CALL accounting.drop_table('agreement_action_refund_aud');
CALL accounting.drop_table('agreement_action_settle');
CALL accounting.drop_table('agreement_action_settle_aud');
CALL accounting.drop_table('agreement_action_write_off');
CALL accounting.drop_table('agreement_action_write_off_aud');
CALL accounting.drop_table('agreement_query_collectibe');
CALL accounting.drop_table('agreement_query_collectibe_aud');
CALL accounting.drop_table('agreement_term_adhoc_fee_fixed_i');
CALL accounting.drop_table('agreement_term_adhoc_fee_fixed_i_aud');
CALL accounting.drop_table('agreement_term_adhoc_fee_floating_i');
CALL accounting.drop_table('agreement_term_adhoc_fee_floating_i_aud');
CALL accounting.drop_table('agreement_term_adhoc_fee');
CALL accounting.drop_table('agreement_term_adhoc_fee_aud');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_i');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_i_aud');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_i_immediate_r');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_i_immediate_r_aud');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_t_fixed_i_payroll');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_t_flat_r');
CALL accounting.drop_table('agreement_term_admin_fee_fixed_t_flat_r_aud');
CALL accounting.drop_table('agreement_term_admin_fee_floating_i');
CALL accounting.drop_table('agreement_term_admin_fee_floating_i_aud');
CALL accounting.drop_table('agreement_term_instalment_ideal_repayment');
CALL accounting.drop_table('agreement_term_instalment_ideal_repayment_aud');
CALL accounting.drop_table('agreement_term_instalment_minimum_payment_due');
CALL accounting.drop_table('agreement_term_instalment_minimum_payment_due_aud');
CALL accounting.drop_table('agreement_term_principal_fixed_i_open_b');
CALL accounting.drop_table('agreement_term_principal_fixed_i_open_b_aud');
CALL accounting.drop_table('agreement_term_principal_fixed_t_fixed_i_payroll');
CALL accounting.drop_table('agreement_term_principal_fixed_t_fixed_i_payroll_aud');
CALL accounting.drop_table('agreement_term_principal_floating_i_open_b');
CALL accounting.drop_table('agreement_term_principal_floating_i_open_b_aud');
CALL accounting.drop_table('agreement_term_service_fee_fixed_i');
CALL accounting.drop_table('agreement_term_service_fee_fixed_i_aud');
CALL accounting.drop_table('agreement_term_service_fee_floating_i');
CALL accounting.drop_table('agreement_term_service_fee_floating_i_aud');
CALL accounting.drop_table('agreement_term_service_fee');
CALL accounting.drop_table('agreement_term_service_fee_aud');
CALL accounting.drop_table('settlement_settlement_line');
CALL accounting.drop_table('settlement_line');
CALL accounting.drop_table('settlement');


DROP PROCEDURE IF EXISTS accounting.drop_table ;

SET SQL_MODE=@OLD_SQL_MODE ;
