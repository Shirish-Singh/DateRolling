
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE collections;

DROP PROCEDURE IF EXISTS collections.alter_column ;

DELIMITER $$

CREATE PROCEDURE collections.alter_column(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'collections'
      )
  THEN
      SET @Statement = CONCAT('UPDATE `collections`.`', tableName, '` SET ', oldColName, ' = 0');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL collections.alter_column('promise_to_pay', 'collection_start_date', 'promise_to_pay_date', 'DATETIME NULL');

DROP PROCEDURE IF EXISTS collections.alter_column ;

SET SQL_MODE=@OLD_SQL_MODE ;
