use collections;

UPDATE `collections`.`collection_global_variable` SET `variable_name`='preventative_days_in_arrears_lower_limit', `display_name`='Preventative Days In Arrears Lower Limit', `variable_value`='1' WHERE `id`='1';
UPDATE `collections`.`collection_global_variable` SET `variable_name`='preventative_days_in_arrears_higher_limit', `display_name`='Preventative Days In Arrears Higher Limit', `variable_value`='30' WHERE `id`='2';
UPDATE `collections`.`collection_global_variable` SET `variable_name`='coersive_days_in_arrears_lower_limit', `display_name`='Coersive Days In Arrears Lower Limit', `variable_value`='31' WHERE `id`='3';
UPDATE `collections`.`collection_global_variable` SET `variable_name`='coersive_days_in_arrears_higher_limit', `display_name`='Coersive Days In Arrears Higher Limit', `variable_value`='60' WHERE `id`='4';


LOCK TABLES `collection_global_variable` WRITE;
/*!40000 ALTER TABLE `collection_global_variable` DISABLE KEYS */;
DELETE FROM `collection_global_variable` WHERE id in (13);
INSERT INTO `collections`.`collection_global_variable` (`id`, `version`, `variable_name`, `display_name`, `variable_value`, `editable_from_ui`)
VALUES (13, '0', 'prelegal_days_in_arrears_lower_limit', 'Pre Legal Days In Arrears Lower Limit', '61', 0);
/*!40000 ALTER TABLE `collection_global_variable` ENABLE KEYS */;
UNLOCK TABLES;

SET FOREIGN_KEY_CHECKS=0;

DELETE FROM `collections`.`lookup_index` WHERE lookup_entity = 'com.qualica.flexifin.collections.domain.CollectionInstanceSeverity' and `id`='50';

UPDATE `collections`.`lookup_index` SET `id`='50' WHERE lookup_entity = 'com.qualica.flexifin.collections.domain.CollectionCaseStatus' and  `id`='51';
UPDATE `collections`.`lookup_index` SET `id`='51', `parent_lookup_index`='50' WHERE lookup_entity = 'com.qualica.flexifin.collections.domain.CollectionCaseStatusReason' and  `id`='52';
UPDATE `collections`.`lookup_index` SET `id`='52', `parent_lookup_index`=null  WHERE lookup_entity = 'com.qualica.flexifin.collections.domain.CollectionInstanceStatus' and  `id`='53';
UPDATE `collections`.`lookup_index` SET `id`='53', `parent_lookup_index`='52' WHERE lookup_entity = 'com.qualica.flexifin.collections.domain.CollectionInstanceStatusReason' and  `id`='54';

UPDATE `collections`.`lookup_index` SET `parent_lookup_index`=null WHERE `id`='52';
UPDATE `collections`.`lookup_index` SET `parent_lookup_index`=null WHERE `id`='54';
UPDATE `collections`.`lookup_index` SET `id`='54', `parent_lookup_index`=null WHERE `id`='55';

SET FOREIGN_KEY_CHECKS=1;

UPDATE `collections`.`collections_dto_to_class_binding` SET `class_name`='com.qualica.flexifin.collections.domain.CollectionCase', `dto_name`='com.qualica.flexifin.collections.shared.dto.CollectionCaseDTO' WHERE `id`='1';

