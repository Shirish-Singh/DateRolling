use collections;

--
-- Dumping data for table `contact_script_template`
--

LOCK TABLES `contact_script_template` WRITE;
/*!40000 ALTER TABLE `contact_script_template` DISABLE KEYS */;

UPDATE `collections`.`contact_script_template` SET `name`='PROOF_OF_PAYMENT_RECEIVED', `contact_attempt_type_id`='6' WHERE `id`='2404';

UPDATE `collections`.`contact_script_template` SET `name`='PROOF_OF_PAYMENT_NOT_RECEIVED', `contact_attempt_type_id`='6' WHERE `id`='2451';

UPDATE `collections`.`contact_script_template` SET `contact_attempt_type_id`='6' WHERE `id`='2403';

UPDATE `collections`.`contact_script_template` SET `contact_attempt_type_id`='6' WHERE `id`='2401';

UPDATE `collections`.`contact_script_template` SET `template_content`='Mr./Mrs. ______,<br>Our system doesn\'t register the payment of the month ____, for an amount of $_____. Do you have the corresponding payslip or Payment Receipt as proof of payment?' WHERE `id`='112';

DELETE FROM `contact_script_template` WHERE id BETWEEN 1000 and 2000;

DELETE FROM `contact_script_template` WHERE id BETWEEN 3000 and 4000;

DELETE FROM `contact_script_template` WHERE id BETWEEN 131 and 147;

DELETE FROM `contact_script_template` WHERE id IN (201, 202, 203, 301, 302, 303, 2405, 2451);

INSERT INTO collections.`contact_script_template`
(`id`, `modified_by`, `version`, `description`, `enabled`, `is_active`, `name`, `label`, `template_content`, `contact_attempt_type_id`, `severity_id`, `debtor_type`, `workflow_outcome_name`, `script_outcome_state`, `entity_id`)
  VALUES
  (131,NULL,0,'PHONE','','','CALL_REFERENCE','Call Reference','Please carry out the collections phone call to  ______ ID______ issued _______ to the next numbers ____________.',1,NULL,NULL,NULL,'ACTIVE',2000),
  (132,NULL,0,'PHONE','','','CALL_CODEBTOR','Call Co-debtor','Please carry out the collections phone call to  ______ ID______ issued _______ to the next numbers ____________.',1,NULL,NULL,NULL,'ACTIVE',2000),
  (133,NULL,0,'PHONE','','','REFERENCE_AVAILABLE','Reference Available','My phone call is regarding the pay roll deduction loan granted to ________ by ______________. Do you know any contact details of _________?',1,NULL,NULL,NULL,'ACTIVE',2000),
  (134,NULL,0,'PHONE','','','CODEBTOR_AVAILABLE','Co-Debtor Available','My phone call is regarding the pay roll deduction loan granted to ________ by ______________. Do you know any contact details of _________?',1,NULL,NULL,NULL,'ACTIVE',2000),
  (135,NULL,0,'PHONE','','','UPDATE_DEBTOR_DETAILS','Update Debtor Details','Will you please provide the updated contact details (Phone, Email, Address) of the client?',1,NULL,NULL,NULL,'ACTIVE',2000),
  (136,NULL,0,'PHONE','','','PROOF_OF_PAYMENT_AVAILABLE','Proof of Payment Available','Please send us the corresponding payslips in order to apply them on our system.<br> This information can be sent to the mail ______ or via fax: 8050052 specifying the account holder name and ID.',1,NULL,NULL,NULL,'ACTIVE',2000),
  (137,NULL,0,'PHONE','','','PROOF_OF_PAYMENT_NOT_AVAILABLE','Proof of Payment Not Available','Please contact our outlet and consult with our customer representative to avoid arrears charges.',1,NULL,NULL,'NULL','ACTIVE',2000),
  (138,NULL,0,'PHONE','','','CALL_NEXT_AVAILABLE_NUMBER','Call Next Available Number','Carry out the collections phone call on next available number',1,NULL,NULL,NULL,'ACTIVE',2000),
  (139,NULL,0,'PHONE','','','PHONE_CODEBTOR','Call Co-Debtor','Please carry out the collections phone call to  ______ ID______ issued _______ to the next numbers ____________.',1,NULL,NULL,'CALL_CODEBTOR','INACTIVE',2000),
  (140,NULL,0,'PHONE','','','PHONE_REFERENCE','Call Reference','Please carry out the collections phone call to  ______ ID______ issued _______ to the next numbers ____________.',1,NULL,NULL,'CALL_REFERENCE','INACTIVE',2000),
  (141,NULL,0,'PHONE','','','PHONE_DEBTOR','Call Debtor','Please carry out the collections phone call to  ______ ID______ issued _______ to the next numbers ____________.',1,NULL,NULL,'CALL_DEBTOR','INACTIVE',2000),
  (142,NULL,0,'PHONE','','','CLIENT_DETAILS_AVAILABLE','Client Details Available','Update Client Details',1,NULL,NULL,NULL,'ACTIVE',2000),
  (143,NULL,0,'PHONE','','','CLIENT_DETAILS_NOT_AVAILABLE','Client Details Not Available','Update Client Details',1,NULL,NULL,NULL,'ACTIVE',2000),
  (144,NULL,0,'PHONE','','','REFERENCE_UNAVAILABLE','Reference Not Available','Reference Not Available',1,NULL,NULL,NULL,'ACTIVE',2000),
  (145,NULL,0,'PHONE','','','REFERENCE_DECEASED','Reference Deceased','Reference Deceased',1,NULL,NULL,NULL,'ACTIVE',2000),
  (146,NULL,0,'PHONE','','','CODEBTOR_UNAVAILABLE','CoDebtor Not Available','CoDebtor Not Available',1,NULL,NULL,NULL,'ACTIVE',2000),
  (147,NULL,0,'PHONE','','','CODEBTOR_DECEASED','CoDebtor Deceased','Reference Deceased',1,NULL,NULL,NULL,'ACTIVE',2000),
  (2405,NULL,0,'CHECK_PROOF_OF_PAYMENT','','','PROOF_OF_PAYMENT_NOT_RECEIVED','Proof of Payment Not Available','Continue collection process for the client',6,NULL,NULL,'no','INACTIVE',2000),
  (2451,NULL,0,'SUE_DEBTOR','','','SUE_DEBTOR','Sue debtor','Please start with Sue Debtor process and capture the outcome.',5,NULL,NULL,NULL,'ACTIVE',2000);

/*!40000 ALTER TABLE `contact_script_template` ENABLE KEYS */;
UNLOCK TABLES;

