USE accounting;

UPDATE account_configuration set descr = 'not used', name = 'not used' WHERE id = 100036;