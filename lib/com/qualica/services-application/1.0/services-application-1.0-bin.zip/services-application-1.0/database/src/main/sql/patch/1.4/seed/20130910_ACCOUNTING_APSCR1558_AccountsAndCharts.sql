INSERT INTO `accounting`.`account` (`id`, `version`, `account_type`, `activated_date`, `created_date`, `currency_code`, `employer_id`, `in_arrears`, `status`, `submission_status`, `system`) VALUES ('100038', '0', 'System', '2012-07-01 00:00:00', '2012-07-01 00:00:00', 'ZAR', '1', 0, 'Active', 'NotApplicable', 1);
INSERT INTO `accounting`.`account` (`id`, `version`, `account_type`, `activated_date`, `created_date`, `currency_code`, `employer_id`, `in_arrears`, `status`, `submission_status`, `system`) VALUES ('100039', '0', 'System', '2012-07-01 00:00:00', '2012-07-01 00:00:00', 'ZAR', '1', 0, 'Active', 'NotApplicable', 1);
INSERT INTO `accounting`.`account` (`id`, `version`, `account_type`, `activated_date`, `created_date`, `currency_code`, `employer_id`, `in_arrears`, `status`, `submission_status`, `system`) VALUES ('100040', '0', 'System', '2012-07-01 00:00:00', '2012-07-01 00:00:00', 'ZAR', '1', 0, 'Active', 'NotApplicable', 1);



INSERT INTO `accounting`.`tx_chart` (`id`, `name`) VALUES ('1031', 'IAF AVAL');
INSERT INTO `accounting`.`tx_chart` (`id`, `name`) VALUES ('1032', 'IAF Insurance');
INSERT INTO `accounting`.`tx_chart` (`id`, `name`) VALUES ('1033', 'IAF Collected');


INSERT INTO `accounting`.`account_configuration` (`id`, `version`, `account_id`, `chart_id`, `descr`, `name`) VALUES ('100041', '0', '100038', '1031', 'IAF AVAL Portion', 'IAF AVAL');
INSERT INTO `accounting`.`account_configuration` (`id`, `version`, `account_id`, `chart_id`, `descr`, `name`) VALUES ('100042', '0', '100039', '1032', 'IAF Insurance Portion', 'IAF Insurance');
INSERT INTO `accounting`.`account_configuration` (`id`, `version`, `account_id`, `chart_id`, `descr`, `name`) VALUES ('100043', '0', '100040', '1033', 'IAF Collected', 'IAF Collected');
