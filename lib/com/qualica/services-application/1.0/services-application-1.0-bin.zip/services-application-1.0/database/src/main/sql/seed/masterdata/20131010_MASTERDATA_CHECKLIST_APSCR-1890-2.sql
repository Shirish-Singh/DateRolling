use masterdata;
SET foreign_key_checks = 0;
DELETE FROM check_list_item_check_box_info_definition WHERE id in (124);
DELETE FROM check_list_item_check_box_definition WHERE id in (124,125,126,127);
DELETE FROM `check_list_item_document_definition` WHERE id in (122,123);
DELETE FROM `check_list_item_definition` WHERE id in (122,123,124,125,126,127);
SET foreign_key_checks = 1;

INSERT INTO `check_list_item_definition` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `item_order`, `required`, `check_list_definition_id`) VALUES
(122,NULL,1,'Con firma y huella del deudor',true,'Certificado de Cuenta',11,false,1),
(123,NULL,1,'Clientes cercanos a la fecha de pensión',true,'Certificado Pensional',12,false,1),
(124,NULL,1,'',true,'¿Número de descuentos que permite la pagaduría?',7,false,3),
(125,NULL,1,'Hacer click en caso de que aplique',true,'¿El código aplica para activos y pensionados?',8,false,3),
(126,NULL,1,'Hacer click en caso de que aplique',true,'¿Capacidad de pago por ley 1527?',9,false,3),
(127,NULL,1,'Hacer click en caso de que aplique',true,'¿Capacidad de pago respetando el 50% del salario básico?',10,false,3);

INSERT INTO `check_list_item_document_definition` (`approval_required`, `required_approval_role`, `id`) VALUES
('','manager', 122),
('','manager', 123);

update `check_list_item_document_definition` set approval_required = true,required_approval_role='manager' where id= 94;


INSERT INTO `check_list_item_check_box_definition` (`id`) VALUES (124),(125),(126),(127);
INSERT INTO `check_list_item_check_box_info_definition` (`info_trigger_type`, `id`) VALUES (0,124);

