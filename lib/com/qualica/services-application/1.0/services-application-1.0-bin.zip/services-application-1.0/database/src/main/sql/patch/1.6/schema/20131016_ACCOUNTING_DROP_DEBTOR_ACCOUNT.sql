SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_fk('agreement_term_admin_fee', 'FKDD27AD58338071A2') ;
CALL accounting.drop_fk('agreement_term_arrears', 'FK35B0BD00338071A2') ;
CALL accounting.drop_fk('agreement_term_principal', 'FK6FD39EF0338071A2') ;
CALL accounting.drop_fk('agreement_action_disbursement', 'FKEBFB72D5338071A2') ;
CALL accounting.drop_fk('agreement_action_payment', 'FK4ED447D2338071A2') ;
CALL accounting.drop_fk('agreement_action_cool_off', 'FK18BB632D9A0161AF') ;

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_column ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_column(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP COLUMN `', colName, '`');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_column('agreement_term_admin_fee', 'debtor_account_id') ;
CALL accounting.drop_column('agreement_term_admin_fee_aud', 'debtor_account_id') ;

CALL accounting.drop_column('agreement_term_arrears', 'debtor_account_id') ;
CALL accounting.drop_column('agreement_term_arrears_aud', 'debtor_account_id') ;

CALL accounting.drop_column('agreement_term_principal', 'debtor_account_id') ;
CALL accounting.drop_column('agreement_term_principal_aud', 'debtor_account_id') ;

CALL accounting.drop_column('agreement_action_disbursement', 'debtor_account_id') ;
CALL accounting.drop_column('agreement_action_disbursement_aud', 'debtor_account_id') ;

CALL accounting.drop_column('agreement_action_payment', 'debtor_account_id') ;
CALL accounting.drop_column('agreement_action_payment_aud', 'debtor_account_id') ;

CALL accounting.drop_column('agreement_action_cool_off', 'debtorAccount_id') ;
CALL accounting.drop_column('agreement_action_cool_off_aud', 'debtorAccount_id') ;

DROP PROCEDURE IF EXISTS accounting.drop_column ;

SET SQL_MODE=@OLD_SQL_MODE;



