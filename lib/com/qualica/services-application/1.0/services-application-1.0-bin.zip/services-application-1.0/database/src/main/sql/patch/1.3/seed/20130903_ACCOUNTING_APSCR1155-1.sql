USE accounting;

LOCK TABLES `account_configuration` WRITE;
/*!40000 ALTER TABLE `account_configuration` DISABLE KEYS */;
UPDATE `account_configuration` SET descr = 'grace period fee interest', name = 'grace period fee interest' WHERE id = 100024;
DELETE FROM `account_configuration` WHERE id in (100034, 100035);
INSERT INTO `account_configuration` (`id`, `modified_by`, `version`, `account_id`, `chart_id`, `descr`, `name`) VALUES
(100034,NULL,0,100032,1028,'grace period fee aval','grace period fee aval'),
(100035,NULL,0,100033,1029,'grace period fee insurance','grace period fee insurance');
/*!40000 ALTER TABLE `account_configuration` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
DELETE FROM `account` WHERE id in (100032, 100033);
INSERT INTO `account` (`id`, `modified_by`, `version`, `account_type`, `activated_date`, `created_date`, `currency_code`, `employer_id`, `in_arrears`, `initialised_date`, `status`, `submission_attempt`, `submission_status`, `system`, `account_reason_code_history_id`, `lending_trading_entity_id`) VALUES
(100032,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),
(100033,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `tx_chart` WRITE;
/*!40000 ALTER TABLE `tx_chart` DISABLE KEYS */;
DELETE FROM `tx_chart` WHERE id in (1028, 1029);
UPDATE `tx_chart` SET name = 'Grace Period Fee Interest' WHERE id = 1020;
INSERT INTO `tx_chart` (`id`, `name`) VALUES
(1028,'Grace Period Fee Aval'),
(1029,'Grace Period Fee Insurance');
/*!40000 ALTER TABLE `tx_chart` ENABLE KEYS */;
UNLOCK TABLES;

