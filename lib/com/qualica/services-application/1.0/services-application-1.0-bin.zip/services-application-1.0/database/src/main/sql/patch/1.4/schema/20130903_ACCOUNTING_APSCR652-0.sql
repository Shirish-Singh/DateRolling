USE accounting;

ALTER TABLE `accounting`.`agreement_term_admin_fee_gpf` CHANGE COLUMN `first_month_only` `first_month_only` bit(1) not null;
