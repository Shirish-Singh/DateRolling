use masterdata;

#Add User PartyRole  to agent parties
INSERT INTO `PARTY_ROLE` (id, party_id, role_type_id, from_date, version) VALUES
(66000330 , 1000330 ,10003, "2012-01-01", 0),
(66000331 , 1000331 ,10003, "2012-01-01", 0),
(66000332 , 1000332 ,10003, "2012-01-01", 0),
(66000333 , 1000333 ,10003, "2012-01-01", 0),
(66000334 , 1000334 ,10003, "2012-01-01", 0),
(66000336 , 1000336 ,10003, "2012-01-01", 0),
(66000350 , 1000350 ,10003, "2012-01-01", 0),
(66000361 , 1000361 ,10003, "2012-01-01", 0),
(66000372 , 1000372 ,10003, "2012-01-01", 0),
(66000374 , 1000374 ,10003, "2012-01-01", 0),
(66000387 , 1000387 ,10003, "2012-01-01", 0),
(66000397 , 1000397 ,10003, "2012-01-01", 0),
(66000398 , 1000398 ,10003, "2012-01-01", 0),
(66000401 , 1000401 ,10003, "2012-01-01", 0),
(66000420 , 1000420 ,10003, "2012-01-01", 0),
(66000421 , 1000421 ,10003, "2012-01-01", 0),
(66000422 , 1000422 ,10003, "2012-01-01", 0),
(66000425 , 1000425 ,10003, "2012-01-01", 0),
(66000428 , 1000428 ,10003, "2012-01-01", 0),
(66000429 , 1000429 ,10003, "2012-01-01", 0);


INSERT INTO `PERSON_ROLE` (id) VALUES
(66000330),
(66000331),
(66000332),
(66000333),
(66000334),
(66000336),
(66000350),
(66000361),
(66000372),
(66000374),
(66000387),
(66000397),
(66000398),
(66000401),
(66000420),
(66000421),
(66000422),
(66000425),
(66000428),
(66000429);

#password is 'password'
INSERT INTO `USER` (id, job_position_id, username, password, enabled) VALUES
(66000330 , 1000002 ,'ocampo.toro.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000331 , 1000002 ,'cortes.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000332 , 1000002 ,'molina.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000333 , 1000002 ,'contreras.mateus.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000334 , 1000002 ,'vargas.galindo.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000336 , 1000002 ,'rubiano.nieto.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000350 , 1000002 ,'florez.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000361 , 1000002 ,'castillo.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000372 , 1000002 ,'rodriguez.medina.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000374 , 1000002 ,'gonzalez.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000387 , 1000002 ,'pena.parra.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000397 , 1000002 ,'ariza.camacho.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000398 , 1000002 ,'moya.caicedo.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000401 , 1000002 ,'vargas.galindo.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000420 , 1000002 ,'rodriguez.suarez.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000421 , 1000002 ,'lopez.sanabria.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000422 , 1000002 ,'mendez.corredor.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000425 , 1000002 ,'hernandez.preciado.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000428 , 1000002 ,'ruiz.riveros.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true),
(66000429 , 1000002 ,'herrera.hernandez.agente','5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8', true);


#Add 'Agent Restricted' roles (AgentRestricted permission)
INSERT INTO `user_role` (user_id,role_id) VALUES (66000330,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000331,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000332,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000333,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000334,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000336,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000350,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000361,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000372,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000374,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000387,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000397,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000398,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000401,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000420,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000421,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000422,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000425,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000428,3);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000429,3);

#Add 'User' role ( ROLE_USER permission)
INSERT INTO `user_role` (user_id,role_id) VALUES (66000330,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000331,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000332,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000333,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000334,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000336,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000350,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000361,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000372,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000374,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000387,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000397,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000398,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000401,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000420,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000421,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000422,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000425,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000428,2);
INSERT INTO `user_role` (user_id,role_id) VALUES (66000429,2);

