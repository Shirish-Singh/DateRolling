USE `flexifinworkflow`;

ALTER TABLE `process_context`
ADD COLUMN `work_item` VARCHAR(255) NULL DEFAULT NULL  AFTER `parent_process_instance_id` ;