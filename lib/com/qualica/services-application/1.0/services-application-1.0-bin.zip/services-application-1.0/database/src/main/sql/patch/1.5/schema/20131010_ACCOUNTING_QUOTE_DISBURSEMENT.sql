use accounting;
ALTER TABLE quote_disbursement CHANGE COLUMN expiry_date expiry_date date default null;