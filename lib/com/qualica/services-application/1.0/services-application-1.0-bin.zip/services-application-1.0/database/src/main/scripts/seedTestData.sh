#!/bin/sh
# Use this file to run the DB patch scripts from ../sql/patch directory
# This file takes 3 parameters in sequence : username, password and release
#if no release is specified all releases will be run

if [ "$#" -eq 2 ]; then

for file in ../sql/patch/*
do
  if [ -d "${file}" ]; then
    echo "Checking directory ${file}"

    for sqlfile in $file/testData/*.sql
    do
      echo "Running ${sqlfile}"
      mysql --user=$1 --password=$2 < $sqlfile
    done

  fi
done

elif [ "$#" -eq 3 ]; then

    for file in ../sql/patch/$3/testData/*.sql
    do
      echo "Running ${file}"
      mysql --user=$1 --password=$2 < $file
    done

else

echo "Invalid number of arguments"

fi