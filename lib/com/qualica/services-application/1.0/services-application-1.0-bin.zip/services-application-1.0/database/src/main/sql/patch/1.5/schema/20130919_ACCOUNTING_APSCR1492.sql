SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';


USE accounting;



DROP PROCEDURE IF EXISTS accounting.drop_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_fk('employer_response_batch_result_line', 'FKDDA01CD7E4826858') ;
CALL accounting.drop_fk('employer_response_batch_result', 'FK5625D97CB8488D17') ;
CALL accounting.drop_fk('employer_response_column', 'FK12930790B8488D17') ;
CALL accounting.drop_fk('employer_response_batch_line', 'FK694D8D13B8488D17') ;
CALL accounting.drop_fk('employer_response_batch_line', 'FK694D8D136D146A31') ;


DROP PROCEDURE IF EXISTS accounting.drop_fk ;
SET SQL_MODE=@OLD_SQL_MODE;


--
-- Table structure for table `employer_response_batch`
--


DROP TABLE IF EXISTS `employer_response_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_response_batch` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `parse_error` bit(1) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `employer_response_batch_result`
--

DROP TABLE IF EXISTS `employer_response_batch_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_response_batch_result` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `employer_response_batch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5625D97CB8488D17` (`employer_response_batch_id`),
  CONSTRAINT `FK5625D97CB8488D17` FOREIGN KEY (`employer_response_batch_id`) REFERENCES `employer_response_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `employer_response_batch_result_line`
--

DROP TABLE IF EXISTS `employer_response_batch_result_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_response_batch_result_line` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `client_employee_number` varchar(255) DEFAULT NULL,
  `client_first_name` varchar(255) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `client_id_number` varchar(255) DEFAULT NULL,
  `client_last_name` varchar(255) DEFAULT NULL,
  `loan_account_id` bigint(20) DEFAULT NULL,
  `resubmit_to_submissions` bit(1) DEFAULT NULL,
  `send_to_collections` bit(1) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `employer_response_batch_result_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDDA01CD7E4826858` (`employer_response_batch_result_id`),
  CONSTRAINT `FKDDA01CD7E4826858` FOREIGN KEY (`employer_response_batch_result_id`) REFERENCES `employer_response_batch_result` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `employer_response_batch_line`
--

DROP TABLE IF EXISTS `employer_response_batch_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_response_batch_line` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `employee_number` varchar(255) DEFAULT NULL,
  `employer_response` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `identity_number` varchar(255) DEFAULT NULL,
  `installment_amount` varchar(255) DEFAULT NULL,
  `line_number` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `employer_response_batch_id` bigint(20) DEFAULT NULL,
  `employer_response_batch_result_line_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK694D8D136D146A31` (`employer_response_batch_result_line_id`),
  KEY `FK694D8D13B8488D17` (`employer_response_batch_id`),
  CONSTRAINT `FK694D8D13B8488D17` FOREIGN KEY (`employer_response_batch_id`) REFERENCES `employer_response_batch` (`id`),
  CONSTRAINT `FK694D8D136D146A31` FOREIGN KEY (`employer_response_batch_result_line_id`) REFERENCES `employer_response_batch_result_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;







--
-- Table structure for table `employer_response_column`
--

DROP TABLE IF EXISTS `employer_response_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_response_column` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_position` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `system_property` varchar(255) DEFAULT NULL,
  `employer_response_batch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK12930790B8488D17` (`employer_response_batch_id`),
  CONSTRAINT `FK12930790B8488D17` FOREIGN KEY (`employer_response_batch_id`) REFERENCES `employer_response_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;