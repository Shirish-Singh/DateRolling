SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.alter_column ;

DELIMITER $$

CREATE PROCEDURE accounting.alter_column(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.alter_column('timeline', 'accrued_fee_interest', 'accrued_fee_interest_list', 'varchar(255) default null') ;

DROP PROCEDURE IF EXISTS accounting.alter_column ;

SET SQL_MODE=@OLD_SQL_MODE ;

