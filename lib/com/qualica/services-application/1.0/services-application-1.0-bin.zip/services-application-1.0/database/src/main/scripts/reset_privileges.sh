#!/bin/bash

full_path="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )";
echo $full_path;
echo "Resetting privileges";
mysql -u$1 --password=$2 < "$full_path/../sql/reset_privileges.sql";
echo "Finished resetting privileges";
