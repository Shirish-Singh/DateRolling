SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE masterdata;

DROP PROCEDURE IF EXISTS masterdata.add_column ;

DELIMITER $$

CREATE PROCEDURE masterdata.add_column(
  IN tableName VARCHAR(100) character set utf8,
  IN columnName VARCHAR(100) character set utf8,
  IN columnType VARCHAR(100) character set utf8
)
  BEGIN
    IF NOT EXISTS (

        SELECT * FROM information_schema.COLUMNS
        WHERE column_name = columnName
              AND table_name = tableName
              AND table_schema = 'masterdata'
    )
    THEN
      SET @Statement = CONCAT('ALTER TABLE `masterdata`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;
    END IF;
  END ;$$

DELIMITER ;

CALL masterdata.add_column('loan_application_aud', 'application_creator', 'VARCHAR(255) COLLATE utf8_unicode_ci DEFAULT NULL ');
CALL masterdata.add_column('payroll_deduction_loan_application_aud', 'client_ID_status', 'VARCHAR(255) COLLATE utf8_unicode_ci DEFAULT NULL ');
CALL masterdata.add_column('payroll_deduction_loan_application_aud', 'employer_id', 'bigint(20) DEFAULT NULL');
CALL masterdata.add_column('payroll_deduction_loan_application_aud', 'guarantor_ID_status', 'VARCHAR(255) COLLATE utf8_unicode_ci DEFAULT NULL ');

DROP PROCEDURE IF EXISTS masterdata.add_columns ;

SET SQL_MODE=@OLD_SQL_MODE ;


