USE flexifinproduct;

ALTER TABLE `flexifinproduct`.`loan_product` ADD COLUMN `product_type` VARCHAR(255) NULL DEFAULT NULL  AFTER `id` ;

