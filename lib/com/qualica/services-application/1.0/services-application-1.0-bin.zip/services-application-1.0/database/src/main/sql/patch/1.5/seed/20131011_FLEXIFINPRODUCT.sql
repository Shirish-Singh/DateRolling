USE flexifinproduct;

update loan_product set cheque_fee_type = 'FixedCost' where cheque_fee_type = 'FIXED_COST';
update loan_product set cheque_fee_type = 'PercentageOfLoan' where cheque_fee_type = 'PERCENTAGE_OF_LOAN_AMOUNT';