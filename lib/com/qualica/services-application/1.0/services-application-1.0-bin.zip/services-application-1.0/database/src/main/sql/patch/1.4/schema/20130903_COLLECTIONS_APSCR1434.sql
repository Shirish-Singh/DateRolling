SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

use collections;

-- ALTER TABLE `collections`.`collection_instance` DROP FOREIGN KEY `FKAA1DA916EB02382E` ;

DROP PROCEDURE IF EXISTS collections.drop_fk ;

DELIMITER $$

CREATE PROCEDURE collections.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)  
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS 
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName 
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName 
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'collections'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL collections.drop_fk('collection_instance', 'FKAA1DA916EB02382E') ;

DROP PROCEDURE IF EXISTS collections.drop_fk ;


DROP PROCEDURE IF EXISTS collections.alter_column ;

DELIMITER $$

CREATE PROCEDURE collections.alter_column(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'collections'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL collections.alter_column('collection_instance', 'workflow_process_id', 'workflow_process_id', 'varchar(255) NULL') ;
CALL collections.alter_column('collection_instance', 'severity_id', 'collection_instance_severity', 'varchar(255) NOT NULL') ;
CALL collections.alter_column('collection_instance_aud', 'severity_id', 'collection_instance_severity', 'varchar(255) NULL DEFAULT NULL') ;



DROP PROCEDURE IF EXISTS collections.alter_column ;


DROP TABLE IF EXISTS `collections`.`collection_instance_severity`;
DROP TABLE IF EXISTS `collections`.`collection_instance_severity_aud`;



--
-- Table structure for table `promise_to_pay`
--

DROP TABLE IF EXISTS `promise_to_pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `promise_to_pay` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `agreed_amount` bigint(20) DEFAULT NULL,
  `calculated_amount` bigint(20) DEFAULT NULL,
  `expired` bit(1) DEFAULT NULL,
  `collection_start_date` datetime DEFAULT NULL,
  `collection_instance_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF927188857467C58` (`collection_instance_id`),
  CONSTRAINT `FKF927188857467C58` FOREIGN KEY (`collection_instance_id`) REFERENCES `collection_instance` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;



-- ALTER TABLE `collections`.`collections_note` ADD COLUMN `task_definition_key` VARCHAR(255) NULL  AFTER `dto_to_class_binding_id` ;

DROP PROCEDURE IF EXISTS collections.add_column ;

DELIMITER $$

CREATE PROCEDURE collections.add_column(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100),
  IN colType VARCHAR(100),
  IN defaultValue VARCHAR(100),
  IN afterColName VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'collections'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` ADD COLUMN `', colName ,'` ', colType, ' default null AFTER ',afterColName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL collections.add_column('collections_note', 'task_definition_key', 'VARCHAR(255)', 'NULL', 'dto_to_class_binding_id') ;

DROP PROCEDURE IF EXISTS collections.add_column ;

SET SQL_MODE=@OLD_SQL_MODE ;


