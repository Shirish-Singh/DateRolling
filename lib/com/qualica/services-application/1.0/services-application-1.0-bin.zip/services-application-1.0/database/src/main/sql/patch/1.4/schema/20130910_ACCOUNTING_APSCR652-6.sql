SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.add_column ;

DELIMITER $$

CREATE PROCEDURE accounting.add_column(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100),
  IN colType VARCHAR(100),
  IN defaultValue VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` ADD COLUMN `', colName, '` ', colType, ' default null');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('UPDATE `accounting`.`', tableName ,'` SET `', colName, '` = ''', defaultValue, '''');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;


      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` CHANGE COLUMN `', colName, '` `', colName, '` ', colType, ' not null');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;


  END IF;
END ;$$

DELIMITER ;

CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll', 'unrecognised_fee_interest_descr', 'varchar(255)', 'unrecognised fee') ;
CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll', 'recognised_fee_interest_descr', 'varchar(255)', 'recognised fee') ;

CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll_aud', 'unrecognised_fee_interest_descr', 'varchar(255)', 'unrecognised fee') ;
CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll_aud', 'recognised_fee_interest_descr', 'varchar(255)', 'recognised fee') ;
CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll_aud', 'unrecognised_fee_interest_account_id', 'bigint(20)', '100004');
CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll_aud', 'unrecognised_fee_interest_chart_id', 'bigint(20)', '1005');
CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll_aud', 'recognised_fee_interest_account_id', 'bigint(20)', '100004');
CALL accounting.add_column('agreement_term_admin_fee_fixed_t_partial_i_payroll_aud', 'recognised_fee_interest_chart_id', 'bigint(20)', '1005');


DROP PROCEDURE IF EXISTS accounting.add_column ;

SET SQL_MODE=@OLD_SQL_MODE ;

