use masterdata;
update check_list_item_definition set name = 'Proof of residence', description = 'Proof of residence not more than 3 months old',required=false, enabled=false where id = 1;
update check_list_item_definition set name = 'Presentation letter', description = 'Presentation letter',required=false,enabled=false where id = 2;
update check_list_item_definition set name = 'Chamber of Commerce certificate', description = 'Chamber of Commerce certificate',required=false,enabled=false where id = 3;
update check_list_item_definition set name = 'Legal history', description = 'Photocopy of the legal representativelegal history',required=false,enabled=false  where id = 4;
update check_list_item_definition set name = 'Inspection letter', description = 'Letter of the superintendent\'s inspection', required=false,enabled=false where id = 5;
update check_list_item_definition set name = 'Financial states', description = 'Financial states to 31 December 2012',required=false,enabled=false where id = 6;
update check_list_item_definition set name = 'RUT', description = 'RUT photocopy',required=false,enabled=false where id = 7;
update check_list_item_definition set name = 'Legal representative ID', description = 'Photocopy of the legal representative\'s id',required=false,enabled=false where id = 8;
update check_list_item_definition set name = 'Services and interest rates', description = 'Portfolio of services and interest rates applied',required=false,enabled=false where id = 9;
update check_list_item_definition set name = 'Statuses', description = 'Statuses',required=false,enabled=false where id = 10;
update check_list_item_definition set name = 'Accountant ID', description = 'Photocopy of the accountant\'s id',required=false,enabled=false where id = 11;
update check_list_item_definition set name = 'Accountant professional card', description = 'Photocopy of the accountant\'s professional card',required=false,enabled=false where id = 12;
update check_list_item_definition set name = 'Accountant disciplinary history', description = 'Certificate of the accountants disciplinary history',required=false,enabled=false where id = 13;
update check_list_item_definition set name = 'Software certificate', description = 'Technical certificate of the software',required=false,enabled=false where id = 14;
update check_list_item_definition set name = 'Bank certificate', description = 'Bank certificate',required=false,enabled=false where id = 15;
update check_list_item_definition set name = 'Employer codes', description = 'Photocopy of codes granted to the employer',required=false,enabled=false where id = 16;
update check_list_item_definition set name = 'Queue instalments', description = 'Does the employer save instalments in a queue',required=false, enabled=false where id = 17;
update check_list_item_definition set name = 'Third party settlements', description = 'Does the employer allow third party settlements',required=false, enabled=false where id = 18;
update check_list_item_definition set name = 'Payslips online', description = 'Does the employer make payslips available online',required=false, enabled=false where id = 19;
update check_list_item_definition set name = 'Payroll deduction contract', description = 'Does the employer keep a payroll deduction contract in the affordability confirmation',required=false, enabled=false where id = 20;
update check_list_item_definition set name = 'Confirm free investment loans', description = 'Does the employer confirm free investment loans',required=false, enabled=false where id = 21;
update check_list_item_definition set name = 'Confirm third party settlements', description = 'Does the employer confirm third party settlements',required=false, enabled=false where id = 22;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 23;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 24;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 25;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 26;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 27;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 28;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 29;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 30;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 31;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 32;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 33;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 34;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 35;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 36;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 37;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = 'Certified copy of I.D Document',required=true,enabled=true where id = 38;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 39;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 40;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 41;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 42;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 43;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 44;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 45;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 46;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 47;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 48;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 49;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 50;
update check_list_item_definition set name = 'Proof of residence', description = 'Photocopy of proof of residence',required=false,enabled=true where id = 51;
update check_list_item_definition set name = 'Confirm phone number', description = 'Is the phone number confirmed',required=false,enabled=true where id = 52;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 53;
update check_list_item_definition set name = 'Autorización Centrales De Riesgo', description = 'Firma y huella del cliente',required=true,enabled=true where id = 54;
update check_list_item_definition set name = 'Documento Centrales De Riesgo', description = 'Documento de centrales de riesgo',required=true,enabled=true where id = 55;
update check_list_item_definition set name = 'Respuesta Pagaduria', description = 'Documentos que entrega pagaduria',required=true,enabled=true where id = 56;
update check_list_item_definition set name = 'Auditoria Información Y Documentos Cliente', description = 'Hacer click si la auditoria es exitosa',required=true,enabled=true where id = 57;
update check_list_item_definition set name = 'Auditoria Referencias', description = 'Hacer click si la auditoria es exitosa',required=true,enabled=true where id = 58;
update check_list_item_definition set name = 'Auditoria Análisis de Credito', description = 'Hacer click si la auditoria es exitosa',required=true,enabled=true where id = 59;
update check_list_item_definition set name = 'Autorización Centrales De Riesgo', description = 'Firma y huella del codeudor',required=true,enabled=true where id = 60;
update check_list_item_definition set name = 'Documento Centrales De Riesgo', description = 'Documento de centrales de riesgo del codeudor',required=true,enabled=true where id = 61;
update check_list_item_definition set name = 'Cedula de Ciudadania', description = '3 Fotocopias ampliadas al 150% con firma y huella del deudor',required=true,enabled=true where id = 62;
update check_list_item_definition set name = 'Formato de Activación de Credito', description = 'Con firma y huella del cliente',required=true,enabled=true where id = 63;
update check_list_item_definition set name = '3 Libranzas', description = 'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella',required=true, enabled=true where id = 70;
update check_list_item_definition set name = '3 Pagarés y  Carta de Instrucciones', description = 'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella',required=true, enabled=true where id = 71;
update check_list_item_definition set name = 'FORMATO DE SOLICITUD ', description = 'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella',required=false, enabled=false where id = 72;
update check_list_item_definition set name = 'Formato Débito Automático', description = 'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella',required=true, enabled=true where id = 73;
update check_list_item_definition set name = 'Formato Seguro De Vida', description = 'Debidamente diligenciado sin tachones ni enmendaduras con firma',required=true, enabled=true where id = 74;
update check_list_item_definition set name = 'Formato de Libraval', description = 'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella',required=true, enabled=true where id = 75;
update check_list_item_definition set name = '2-3 Últimos Desprendibles de Pago', description = 'Con firma y huella',required=true, enabled=true where id = 76;
update check_list_item_definition set name = '3 ÃšLTIMOS DESPRENDIBLES DE PAGO', description = 'Con firma y huella',required=false, enabled=false where id = 77;
update check_list_item_definition set name = 'Certificación Laboral', description = 'No mayor a 30 dias con firma y huella (NO APLICA PARA PENSIONADOS)',required=false, enabled=true where id = 78;
update check_list_item_definition set name = 'Formato De Solicitud De Crédito', description = 'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella',required=true, enabled=true where id = 79;
update check_list_item_definition set name = 'Carta de presentación', description = 'Debidamente firmada por el representante legal',required=true, enabled=true where id = 81;
update check_list_item_definition set name = 'Certificado de cámara de comercio.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 82;
update check_list_item_definition set name = 'Fotocopia del certificado de antecedentes judiciales del representante legal.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 83;
update check_list_item_definition set name = 'Carta de sometimiento de inspección de la supersociedades.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 84;
update check_list_item_definition set name = 'Estados financieros a 31 de diciembre del último año.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 85;
update check_list_item_definition set name = 'Fotocopia del RUT.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 86;
update check_list_item_definition set name = 'Fotocopia cédula de ciudadanía representante legal.', description = 'Fotocopia legible al 150%',required=true, enabled=true where id = 87;
update check_list_item_definition set name = 'Portafolio de servicios y tasas de interés aplicadas.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 88;
update check_list_item_definition set name = 'Estatutos.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 89;
update check_list_item_definition set name = 'Fotocopia de la cédula de ciudadanía del contador.', description = 'Debidamente firmada por el representante legal',required=true, enabled=true where id = 90;
update check_list_item_definition set name = 'Fotocopia de la tarjeta profesional del contador.', description = 'Fotocopia legible al 150%',required=true, enabled=true where id = 91;
update check_list_item_definition set name = 'Certificado de antecedentes disciplinarios del contador.', description = 'Este documento debe estar actualizado',required=true, enabled=true where id = 92;
update check_list_item_definition set name = 'Certificación bancaria.', description = 'Este documento debe estar actualizado no mayor a 30 di­as',required=true, enabled=true where id = 93;
update check_list_item_definition set name = 'Fotocopia de códigos otorgados a la empresa.', description = 'Fotocopia Legible tamaño normal',required=true, enabled=true where id = 94;
update check_list_item_definition set name = '¿Al momento de la visación la pagaduría se queda con alguna libranza?', description = 'Hacer click en caso de que aplique',required=false, enabled=true where id = 95;
update check_list_item_definition set name = '¿La pagaduría guarda descuentos en cola?', description = 'Hacer click en caso de que aplique',required=false, enabled=true where id = 96;
update check_list_item_definition set name = '¿Se visa compra de cartera?', description = 'Hacer click en caso de que aplique',required=false, enabled=true where id = 97;
update check_list_item_definition set name = '¿Se consultan desprendibles de nómina por internet?', description = 'Hacer click en caso de que aplique',required=false, enabled=true where id = 98;
update check_list_item_definition set name = '¿Se visa libre inversión?', description = 'Hacer click en caso de que aplique',required=false, enabled=true where id = 99;
update check_list_item_definition set name = '¿Se visa compra de cartera?', description = 'Hacer click en caso de que aplique',required=false, enabled=true where id = 100;
update check_list_item_definition set name = 'Formato de Firmas Pagaduria', description = 'Formato de firmas en caso de visación',required=false,enabled=true where id = 120;
update check_list_item_definition set name = 'Respuesta de la Pagaduria', description = 'Respuesta de la Pagaduria',required=false,enabled=true where id = 121;
update check_list_item_definition set name = 'client_details_form', description = 'Client details form',required=true,enabled=true where id = 104444;
update check_list_item_definition set name = 'client_id_doc', description = 'Copy of Client Id Document',required=true,enabled=true where id = 204444;

 















