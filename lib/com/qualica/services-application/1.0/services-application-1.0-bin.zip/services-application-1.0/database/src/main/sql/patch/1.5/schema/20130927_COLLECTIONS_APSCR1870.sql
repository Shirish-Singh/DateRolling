USE collections;

ALTER TABLE collection_case CHANGE COLUMN birth_date birth_date DATE DEFAULT NULL;
ALTER TABLE collection_case_aud CHANGE COLUMN birth_date birth_date DATE DEFAULT NULL;

ALTER TABLE promise_to_pay CHANGE COLUMN promise_to_pay_date promise_to_pay_date DATE DEFAULT NULL;
