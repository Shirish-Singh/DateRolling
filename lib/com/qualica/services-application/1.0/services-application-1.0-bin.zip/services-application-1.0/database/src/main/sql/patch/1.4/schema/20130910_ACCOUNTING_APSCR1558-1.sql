-- use flexifinproduct;
-- alter table loan_product add column global bit (1);


SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.add_column_copy ;

DELIMITER $$

CREATE PROCEDURE accounting.add_column_copy(
  IN tableName VARCHAR(100),
  IN columnName VARCHAR(100),
  IN columnType VARCHAR(100),
  IN copyColName VARCHAR(100),
  IN refTable VARCHAR(100),
  IN refColName VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = columnName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('UPDATE `accounting`.`', tableName, '` SET `', columnName, '` = ', copyColName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName, '` CHANGE COLUMN `', columnName, '` `', columnName, '` ', columnType, ' NOT NULL');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` ADD CONSTRAINT FOREIGN KEY (`', columnName, '`) REFERENCES `', refTable, '` (`', refColName, '`)');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.add_column_copy('agreement_term_admin_fee_iaf', 'aval_account_id', 'BIGINT(20)', 'aval_account_id', 'account', 'id');
CALL accounting.add_column_copy('agreement_term_admin_fee_iaf', 'aval_chart_id', 'BIGINT(20)', 'aval_chart_id', 'tx_chart', 'id');
CALL accounting.add_column_copy('agreement_term_admin_fee_iaf', 'insurance_account_id', 'BIGINT(20)', 'insurance_account_id', 'account', 'id');
CALL accounting.add_column_copy('agreement_term_admin_fee_iaf', 'insurance_chart_id', 'BIGINT(20)', 'insurance_chart_id', 'tx_chart', 'id');
CALL accounting.add_column_copy('agreement_term_admin_fee_iaf', 'collected_account_id', 'BIGINT(20)', 'collected_account_id', 'account', 'id');
CALL accounting.add_column_copy('agreement_term_admin_fee_iaf', 'collected_chart_id', 'BIGINT(20)', 'collected_chart_id', 'tx_chart', 'id');

DROP PROCEDURE IF EXISTS accounting.add_column_copy ;

SET SQL_MODE=@OLD_SQL_MODE ;
