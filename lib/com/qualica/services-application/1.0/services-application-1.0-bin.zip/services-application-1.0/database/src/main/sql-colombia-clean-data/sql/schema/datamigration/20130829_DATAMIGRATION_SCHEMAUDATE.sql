USE datamigration;

ALTER TABLE `datamigration`.`staging_person` ADD COLUMN `id_issue_region` VARCHAR(255) NULL DEFAULT NULL  AFTER `total_years_work_experience` ,
ADD COLUMN `id_issue_suburb` VARCHAR(255) NULL DEFAULT NULL  AFTER `id_issue_region` ,
ADD COLUMN `birth_region` VARCHAR(255) NULL DEFAULT NULL  AFTER `id_issue_suburb` ,
ADD COLUMN `birth_suburb` VARCHAR(255) NULL  AFTER `birth_region` ;