SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE flexifinproduct;

DROP PROCEDURE IF EXISTS flexifinproduct.add_column ;

DELIMITER $$

CREATE PROCEDURE flexifinproduct.add_column(
  IN tableName VARCHAR(100),
  IN columnName VARCHAR(100),
  IN columnType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = columnName
      AND table_name = tableName
      AND table_schema = 'flexifinproduct'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `flexifinproduct`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  -- This is incorrect, creating a new migration script to update  patch/1.5/seed/20131010_FLEXIFINPRODUCT_APSCR2123.sql
      SET @Statement = CONCAT('UPDATE `flexifinproduct`.`', tableName, '` SET `', columnName, '` = 0');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `flexifinproduct`.`', tableName, '` CHANGE COLUMN `', columnName, '` `', columnName, '` ', columnType, ' NOT NULL');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL flexifinproduct.add_column('loan_product', 'cheque_fee_type', 'VARCHAR(255)');

DROP PROCEDURE IF EXISTS flexifinproduct.add_column ;

SET SQL_MODE=@OLD_SQL_MODE ;
