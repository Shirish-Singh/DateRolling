USE accounting;

ALTER TABLE account CHANGE COLUMN arrears_date arrears_date date default null;
ALTER TABLE account_aud CHANGE COLUMN arrears_date arrears_date date default null;