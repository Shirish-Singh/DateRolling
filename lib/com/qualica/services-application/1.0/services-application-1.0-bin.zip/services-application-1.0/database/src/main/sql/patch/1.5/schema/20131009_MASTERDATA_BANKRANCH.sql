USE masterdata;

ALTER TABLE `masterdata`.`bank_branch` ADD COLUMN `city_id` BIGINT(20) NULL DEFAULT NULL  AFTER `id` ;

