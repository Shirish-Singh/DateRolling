USE `accounting`;

--
-- Table structure for table `legacy_account`
--

DROP TABLE IF EXISTS `legacy_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `legacy_account` (
  `account_id` bigint(20) NOT NULL,
  `legacy_account_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`account_id`),
    CONSTRAINT `FK_LEGACY_ACCOUNT` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

