SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.add_column ;

DELIMITER $$

CREATE PROCEDURE accounting.add_column(
  IN tableName VARCHAR(100),
  IN columnName VARCHAR(100),
  IN columnType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = columnName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType, ' DEFAULT \'Created\' ');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.add_column('agreement_action', 'status', 'VARCHAR(255)');
CALL accounting.add_column('agreement_action_aud', 'status', 'VARCHAR(255)');

DROP PROCEDURE IF EXISTS accounting.add_column ;

SET SQL_MODE=@OLD_SQL_MODE ;
