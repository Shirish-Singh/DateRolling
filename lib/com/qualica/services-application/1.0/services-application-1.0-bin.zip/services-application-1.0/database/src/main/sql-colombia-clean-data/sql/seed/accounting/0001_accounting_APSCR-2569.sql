use accounting;

DELETE from deduct_column_desc where id BETWEEN   1000051 and  1000058;
DELETE from   deduct_column_source_property_desc where id BETWEEN 1001 And 1008;
DELETE from deduct_column_template where id =1;
INSERT INTO deduct_column_template (id, modified_by, version, custom_delimiter, description, employer_id, global, name) VALUES (1, 'sameer', 0, ',', 'PAYROLL DEDUCTION COLUMN TEMPLATE', null, true, 'PAYROLL DEDUCTION COLUMN TEMPLATE');


LOCK TABLES `deduct_column_source_property_desc` WRITE;
/*!40000 ALTER TABLE `deduct_column_source_property_desc` DISABLE KEYS */;


INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1001, null, 0, 2, 'Global');
INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1002, null, 0, 5, 'Global');
INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1003, null, 0, 23, 'Global');
INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1004, null, 0, 6, 'Global');
INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1005, null, 0, 15, 'Global');
INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1006, null, 0, 9, 'Global');
INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1007, null, 0, 25, 'Global');
INSERT INTO accounting.deduct_column_source_property_desc (id, modified_by, version, property_id, source_property_type) VALUES (1008, null, 0, 11, 'Global');

/*!40000 ALTER TABLE `deduct_column_source_property_desc` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `deduct_column_desc` WRITE;
/*!40000 ALTER TABLE `deduct_column_desc` DISABLE KEYS */;

INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000051, null, 0, '', '', false, 1, 1, 1001);
INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000052, null, 0, '', '', false, 2, 1, 1002);
INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000053, null, 0, '', '', false, 3, 1, 1003);
INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000054, null, 0, '', '', false, 4, 1, 1004);
INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000055, null, 0, '', '', false, 5, 1, 1005);
INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000056, null, 0, '', '', false, 6, 1, 1006);
INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000057, null, 0, '', '', false, 7, 1, 1007);
INSERT INTO accounting.deduct_column_desc (id, modified_by, version, default_value, file_column_name, ignored, position, deduct_column_id, deduct_column_source_property_desc_id) VALUES (1000058, null, 0, '', '', false, 8, 1, 1008);
/*!40000 ALTER TABLE `deduct_column_desc` ENABLE KEYS */;
UNLOCK TABLES;


