-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: flexifinproduct
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `flexifinproduct`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `flexifinproduct` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `flexifinproduct`;

--
-- Table structure for table `REVINFO`
--

DROP TABLE IF EXISTS `REVINFO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `REVINFO` (
  `REV` int(11) NOT NULL AUTO_INCREMENT,
  `REVTSTMP` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fee`
--

DROP TABLE IF EXISTS `fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee` (
  `type` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` decimal(19,9) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  `collection_frequency` varchar(255) DEFAULT NULL,
  `collection_number` int(11) DEFAULT NULL,
  `inclusive` bit(1) DEFAULT b'1',
  `recognition_plan` varchar(255) DEFAULT NULL,
  `attracts_arrears` bit(1) DEFAULT b'0',
  `archived` bit(1) DEFAULT b'0',
  `enabled` bit(1) DEFAULT NULL,
  `balance_allocation_allowed` bit(1) DEFAULT NULL,
  `aval_allowed` bit(1) DEFAULT NULL,
  `insurance_allowed` bit(1) DEFAULT NULL,
  `partial_allowed` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fee_mapping`
--

DROP TABLE IF EXISTS `fee_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee_mapping` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `default_boolean` bit(1) DEFAULT NULL,
  `default_option` varchar(255) DEFAULT NULL,
  `domain_property` varchar(255) NOT NULL,
  `enable_item` bit(1) DEFAULT NULL,
  `fee_type` varchar(255) NOT NULL,
  `option_name` varchar(255) DEFAULT NULL,
  `options` longtext,
  `show_item` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hibernate_sequences`
--

DROP TABLE IF EXISTS `hibernate_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequences` (
  `sequence_name` varchar(255) NOT NULL,
  `next_val` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`sequence_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interest_rate`
--

DROP TABLE IF EXISTS `interest_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interest_rate` (
  `type` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fixed_rate` decimal(19,9) DEFAULT NULL,
  `current_rate` decimal(19,9) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `linked_rate_history`
--

DROP TABLE IF EXISTS `linked_rate_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `linked_rate_history` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `from_date` date NOT NULL,
  `interest_rate` decimal(19,9) NOT NULL,
  `to_date` date NOT NULL,
  `linked_rate_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK51592C9B3F561F6B` (`linked_rate_id`),
  CONSTRAINT `FK51592C9B3F561F6B` FOREIGN KEY (`linked_rate_id`) REFERENCES `interest_rate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_product`
--

DROP TABLE IF EXISTS `loan_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_product` (
  `max_amount_cents` bigint(20) NOT NULL,
  `max_term_months` int(11) NOT NULL,
  `min_amount_cents` bigint(20) NOT NULL,
  `min_term_months` int(11) NOT NULL,
  `rate_delta` decimal(19,9) DEFAULT NULL,
  `step_amount_cents` bigint(20) DEFAULT NULL,
  `step_term_months` int(11) DEFAULT NULL,
  `target_rate` decimal(19,9) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `product_applicability_id` bigint(20) DEFAULT NULL,
  `interest_rate_id` bigint(20) DEFAULT NULL,
  `arrears_rate` decimal(19,9) DEFAULT NULL,
  `arrears_trigger_cycle` int(11) DEFAULT NULL,
  `arrears_type` varchar(45) DEFAULT NULL,
  `cheque_fee` bigint(20) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `grace_period_fee_days` int(11) DEFAULT NULL,
  `interes_anticipado_fee_days` int(11) DEFAULT NULL,
  `recognition_mode` varchar(255) NOT NULL,
  `arrears_interest_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8D7448A048E33B6` (`id`),
  KEY `FK8D7448A0FDEC91C3` (`interest_rate_id`),
  KEY `FK8D7448A0B2B18E0F` (`product_applicability_id`),
  CONSTRAINT `FK8D7448A048E33B6` FOREIGN KEY (`id`) REFERENCES `product` (`id`),
  CONSTRAINT `FK8D7448A0B2B18E0F` FOREIGN KEY (`product_applicability_id`) REFERENCES `product_applicability` (`id`),
  CONSTRAINT `FK8D7448A0FDEC91C3` FOREIGN KEY (`interest_rate_id`) REFERENCES `interest_rate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lookup_index`
--

DROP TABLE IF EXISTS `lookup_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookup_index` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `lookup_entity` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `lookup_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_property_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_lookup_index` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF785C1ADC525AE23` (`parent_lookup_index`),
  CONSTRAINT `FKF785C1ADC525AE23` FOREIGN KEY (`parent_lookup_index`) REFERENCES `lookup_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organisation_role_organisation_role_product`
--

DROP TABLE IF EXISTS `organisation_role_organisation_role_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisation_role_organisation_role_product` (
  `organisation_role_id` bigint(20) DEFAULT NULL,
  `organisation_role_product_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `organisation_product_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `organisation_role_product`
--

DROP TABLE IF EXISTS `organisation_role_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organisation_role_product` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fromDate` tinyblob,
  `organisation_role_id` bigint(20) DEFAULT NULL,
  `toDate` tinyblob,
  `product_id` bigint(20) DEFAULT NULL,
  `from_date` datetime DEFAULT NULL,
  `max_amount_cents` bigint(20) DEFAULT NULL,
  `max_term_months` int(11) DEFAULT NULL,
  `min_amount_cents` bigint(20) DEFAULT NULL,
  `min_takehome_cents` bigint(20) DEFAULT NULL,
  `min_term_months` int(11) DEFAULT NULL,
  `to_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF3B6FA8A6D0AF106` (`product_id`),
  CONSTRAINT `FKF3B6FA8A6D0AF106` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_processing_day` varchar(255) DEFAULT NULL,
  `account_processing_day_of_month` int(11) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `archived` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_applicability`
--

DROP TABLE IF EXISTS `product_applicability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_applicability` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_category` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_category_id` bigint(20) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `FKA0303E4E594AE0A0` (`parent_category_id`),
  CONSTRAINT `FKA0303E4E594AE0A0` FOREIGN KEY (`parent_category_id`) REFERENCES `product_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_classification`
--

DROP TABLE IF EXISTS `product_classification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_classification` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKEA057936E6FD28B5` (`category_id`),
  KEY `FKEA0579366D0AF106` (`product_id`),
  CONSTRAINT `FKEA0579366D0AF106` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `FKEA057936E6FD28B5` FOREIGN KEY (`category_id`) REFERENCES `product_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_fee`
--

DROP TABLE IF EXISTS `product_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_fee` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `value` decimal(19,9) DEFAULT NULL,
  `value_type` varchar(255) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `fee_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `arrears_type` varchar(255) DEFAULT NULL,
  `collection_Frequency` varchar(45) DEFAULT NULL,
  `recognition_plan` varchar(45) DEFAULT NULL,
  `collection_number` bigint(20) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `balance_allocation_allowed` bit(1) DEFAULT NULL,
  `aval_allowed` bit(1) DEFAULT NULL,
  `insurance_allowed` bit(1) DEFAULT NULL,
  `partial_allowed` bit(1) DEFAULT NULL,
  `months` int(5) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA71C78366D0AF106` (`product_id`),
  KEY `FKA71C783653320AB4` (`fee_id`),
  CONSTRAINT `FKA71C783653320AB4` FOREIGN KEY (`fee_id`) REFERENCES `fee` (`id`),
  CONSTRAINT `FKA71C78366D0AF106` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 15:51:06
