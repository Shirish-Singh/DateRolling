use accounting;
-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: accounting
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` (`id`, `modified_by`, `version`, `account_type`, `activated_date`, `created_date`, `currency_code`, `employer_id`, `in_arrears`, `initialised_date`, `status`, `submission_attempt`, `submission_status`, `system`, `account_reason_code_history_id`, `lending_trading_entity_id`) VALUES (100001,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100002,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100003,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100004,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100005,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100006,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100007,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100008,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100009,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100010,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100011,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100012,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100013,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100014,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100015,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100016,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100017,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100018,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100019,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100020,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100021,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100022,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100023,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100024,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100025,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100026,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100027,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100028,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100030,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL),(100031,NULL,0,'System','2012-07-01 00:00:00','2012-07-01 00:00:00','ZAR',1,'\0',NULL,'Active',NULL,'NotApplicable','',NULL,NULL);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_aud`
--

LOCK TABLES `account_aud` WRITE;
/*!40000 ALTER TABLE `account_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_configuration`
--

LOCK TABLES `account_configuration` WRITE;
/*!40000 ALTER TABLE `account_configuration` DISABLE KEYS */;
INSERT INTO `account_configuration` (`id`, `modified_by`, `version`, `account_id`, `chart_id`, `descr`, `name`) VALUES (100001,NULL,0,100001,1001,'bank disbursement','bank disbursement'),(100002,NULL,0,NULL,1002,'debtor control','debtor control'),(100003,NULL,0,100002,1003,'unrecognised interest','unrecognised interest'),(100004,NULL,0,100003,1004,'recognised interest','recognised interest'),(100005,NULL,0,100004,1005,'unrecognised fee','unrecognised fee'),(100006,NULL,0,100005,1006,'recognised fee','recognised fee'),(100007,NULL,0,100006,1007,'unrecognised fee interest','unrecognised fee interest'),(100008,NULL,0,100007,1008,'recognised fee interest','recognised fee interest'),(100009,NULL,0,100008,1009,'bank payment','bank payment'),(100010,NULL,0,100009,NULL,'not used','not used'),(100011,NULL,0,100010,NULL,'not used','not used'),(100012,NULL,0,100011,NULL,'not used','not used'),(100013,NULL,0,100012,1010,'debtor advance provision','debtor advance provision'),(100014,NULL,0,100013,1011,'disbursement suspense','disbursement suspense'),(100015,NULL,0,100014,1012,'cool off','cool off'),(100016,NULL,0,100015,1013,'write off','write off'),(100017,NULL,0,100016,1014,'settlement interest','settlement interest'),(100018,NULL,0,100017,1015,'settlement write off','settlement write off'),(100019,NULL,0,100018,NULL,'not used','not used'),(100020,NULL,0,100019,1016,'arrears interest','arrears interest'),(100021,NULL,0,100020,1017,'suspense','suspense'),(100022,NULL,0,100021,1018,'arrears penalty','arrears penalty'),(100023,NULL,0,100022,1019,'cheque fees','cheque fees'),(100024,NULL,0,100023,1020,'grace period fee','grace period fee'),(100025,NULL,0,100024,1021,'recognised aval fee interest','recognised aval fee interest'),(100026,NULL,0,100025,1022,'recognised insurance fee interest','recognised insurance fee interest'),(100027,NULL,0,100026,1023,'unrecognised aval fee interest','unrecognised aval fee interest'),(100028,NULL,0,100027,1024,'unrecognised insurance fee interest','unrecognised insurance fee interest'),(100029,NULL,0,100028,1025,'unrecognised principal','unrecognised principal'),(100031,NULL,0,100030,1026,'recognised Interes Anticipado Fee','recognised Interes Anticipado Fee'),(100032,NULL,0,100031,1027,'unrecognised Interes Anticipado Fee','unrecognised Interes Anticipado Fee');
/*!40000 ALTER TABLE `account_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_configuration_aud`
--

LOCK TABLES `account_configuration_aud` WRITE;
/*!40000 ALTER TABLE `account_configuration_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_configuration_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_quote`
--

LOCK TABLES `account_quote` WRITE;
/*!40000 ALTER TABLE `account_quote` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_quote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_quote_fee`
--

LOCK TABLES `account_quote_fee` WRITE;
/*!40000 ALTER TABLE `account_quote_fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_quote_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_reason_code`
--

LOCK TABLES `account_reason_code` WRITE;
/*!40000 ALTER TABLE `account_reason_code` DISABLE KEYS */;
INSERT INTO `account_reason_code` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `active`, `client_may_replace`, `new_loan_default`, `suspend_earnings`, `suspend_submissions`, `trigger_insurance_claim`, `reason_code_category_id`) VALUES (1,'import_data.sql',0,'Employee # incorrectly submitted','','A001','','\0','\0','','','\0',1),(2,'import_data.sql',0,'Employee # changed by employer','','A002','','\0','\0','','','\0',1),(3,'import_data.sql',0,'Incorrect Installment submitted','','A003','','\0','\0','','','\0',1),(4,'import_data.sql',0,'Loan incorrecly captured by employer','','A004','','\0','\0','','','\0',1),(5,'import_data.sql',0,'Affordability - Did not meet MTHP threshold','','A005','','\0','\0','','','\0',1),(6,'import_data.sql',0,'Multiple loans - Could not submit','','A006','','\0','\0','','','\0',1),(7,'import_data.sql',0,'Employee is on leave','','A007','','\0','\0','','','\0',1),(8,'import_data.sql',0,'Employer payrol system failure','','A008','','\0','\0','','','\0',1),(9,'import_data.sql',0,'Loan not included in submission','','A009','','\0','\0','','','\0',1),(10,'import_data.sql',0,'Employer indicates an administrative error','','A010','','\0','\0','','','\0',1),(11,'import_data.sql',0,'Client under administration','','A011','','\0','\0','','','\0',1),(12,'import_data.sql',0,'Zero Salary or Client Salary Locked','','A012','','\0','\0','','','\0',1),(13,'import_data.sql',0,'Leave without pay','','A013','','\0','\0','','','\0',1),(14,'import_data.sql',0,'Client employer in arrears','','A014','','\0','\0','','','\0',1),(15,'import_data.sql',0,'Unallocated. Loan to be posted','','A015','','\0','\0','','','\0',1),(16,'import_data.sql',0,'Client dismissed-resinstated by employer','','A016','','\0','\0','','','\0',1),(17,'import_data.sql',0,'Underpayment on outright settlement','','A017','','\0','\0','','','\0',1),(18,'import_data.sql',0,'Off Payroll Collections','','A018','','\0','\0','','','\0',1),(19,'import_data.sql',0,'Bank Account Insuficient Funds','','A019','','\0','\0','','','\0',1),(20,'import_data.sql',0,'Bank Card Details Incorrect','','A020','','\0','\0','','','\0',1),(21,'import_data.sql',0,'Bank Account Details Incorrect','','A021','','\0','\0','','','\0',1),(22,'import_data.sql',0,'Bank Account Debits Not Allowed','','A022','','\0','\0','','','\0',1),(23,'import_data.sql',0,'Bank Account Closed','','A023','','\0','\0','','','\0',1),(24,'import_data.sql',0,'Employee Service Transferred Delayed','','A024','','\0','\0','','','\0',1),(25,'import_data.sql',0,'Employee Number Duplicated on Payroll','','A025','','\0','\0','','','\0',1),(26,'import_data.sql',0,'Client Loan Written-off - Reinstated','','A026','','\0','\0','','','\0',1),(27,'import_data.sql',0,'3rd Party Settled Still Deducting','','A027','','\0','\0','','','\0',1),(28,'import_data.sql',0,'Employee resigned','','B001','','\0','\0','','','\0',2),(29,'import_data.sql',0,'Employee deceased','','B002','','\0','\0','','','\0',2),(30,'import_data.sql',0,'Employee retires (Normal retirement)','','B003','','\0','\0','','','\0',2),(31,'import_data.sql',0,'Employee retires (Early retirement)','','B004','','\0','\0','','','\0',2),(32,'import_data.sql',0,'Medically discharged','','B005','','\0','\0','','','\0',2),(33,'import_data.sql',0,'Absconded','','B006','','\0','\0','','','\0',2),(34,'import_data.sql',0,'Retrenched','','B007','','\0','\0','','','\0',2),(35,'import_data.sql',0,'Internal Fraud','','B008','','\0','\0','','','\0',2),(36,'import_data.sql',0,'External Fraud','','B009','','\0','\0','','','\0',2),(37,'import_data.sql',0,'Employer closed down','','B010','','\0','\0','','','\0',2),(38,'import_data.sql',0,'Client sequestrated','','B011','','\0','\0','','','\0',2),(39,'import_data.sql',0,'Ghost workers','','B012','','\0','\0','','','\0',2),(40,'import_data.sql',0,'Bad Debt, Misrepresentation','','B013','','\0','\0','','','\0',2),(41,'import_data.sql',0,'Employee Dismissed','','B014','','\0','\0','','','\0',2),(42,'import_data.sql',0,'Employee Discharged','','B015','','\0','\0','','','\0',2),(43,'import_data.sql',0,'Employee Contract Terminated','','B016','','\0','\0','','','\0',2),(44,'import_data.sql',0,'Temporal Disability','','B017','','\0','\0','','','\0',2),(45,'import_data.sql',0,'Incorrect Installment submitted','','C001','','\0','\0','','','\0',3),(46,'import_data.sql',0,'Loan incorrectly captured by employer','','C002','','\0','\0','','','\0',3),(47,'import_data.sql',0,'Loan settled, deduction not stopped','','C003','','\0','\0','','','\0',3),(48,'import_data.sql',0,'Employer error','','C004','','\0','\0','','','\0',3),(49,'import_data.sql',0,'Admin error','','C005','','\0','\0','','','\0',3),(50,'import_data.sql',0,'Employee Arrears Payment','','C006','','\0','\0','','','\0',3),(51,'import_data.sql',0,'Doubtful','','D001','','\0','\0','','','\0',4),(52,'import_data.sql',0,'Affordability - Did not meet MTHP threshold','','D002','','\0','\0','','','\0',4),(53,'import_data.sql',0,'Leave without pay','','D003','','\0','\0','','','\0',4),(54,'import_data.sql',0,'Employee resigned','','D004','','\0','\0','','','\0',4),(55,'import_data.sql',0,'Absconded','','D005','','\0','\0','','','\0',4),(56,'import_data.sql',0,'Employee Dismissed','','D006','','\0','\0','','','\0',4),(57,'import_data.sql',0,'Employee retires','','D007','','\0','\0','','','\0',4),(58,'import_data.sql',0,'Employee Contract Terminated','','D008','','\0','\0','','','\0',4),(59,'import_data.sql',0,'Employee Service Transferred Delayed','','D009','','\0','\0','','','\0',4),(60,'import_data.sql',0,'Employee Number Duplicated on Payroll','','D010','','\0','\0','','','\0',4),(61,'import_data.sql',0,'Employee deceased','','I001','','\0','\0','','','\0',5),(62,'import_data.sql',0,'Medically discharged','','I002','','\0','\0','','','\0',5),(63,'import_data.sql',0,'Employee Retrenched','','I003','','\0','\0','','','\0',5),(64,'import_data.sql',0,'Temporal Disability','','I004','','\0','\0','','','\0',5),(65,'import_data.sql',0,'Permanent Disability','','I005','','\0','\0','','','\0',5),(66,'import_data.sql',0,'Rescheduled, misrepresentation','','R001','','\0','\0','','','\0',6);
/*!40000 ALTER TABLE `account_reason_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_reason_code_category`
--

LOCK TABLES `account_reason_code_category` WRITE;
/*!40000 ALTER TABLE `account_reason_code_category` DISABLE KEYS */;
INSERT INTO `account_reason_code_category` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `active`) VALUES (1,'import.sql',0,'Category A','','A',''),(2,'import.sql',0,'Category B','','B',''),(3,'import.sql',0,'Category C','','C',''),(4,'import.sql',0,'Category D','','D',''),(5,'import.sql',0,'Category I','','I',''),(6,'import.sql',0,'Category R','','R','');
/*!40000 ALTER TABLE `account_reason_code_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_reason_code_history`
--

LOCK TABLES `account_reason_code_history` WRITE;
/*!40000 ALTER TABLE `account_reason_code_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_reason_code_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `accounting_document`
--

LOCK TABLES `accounting_document` WRITE;
/*!40000 ALTER TABLE `accounting_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `accounting_document_number`
--

LOCK TABLES `accounting_document_number` WRITE;
/*!40000 ALTER TABLE `accounting_document_number` DISABLE KEYS */;
INSERT INTO `accounting_document_number` (`document_type`, `next_number`) VALUES ('ExpenseVouncher',1),('Receipt',1);
/*!40000 ALTER TABLE `accounting_document_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `accounting_job`
--

LOCK TABLES `accounting_job` WRITE;
/*!40000 ALTER TABLE `accounting_job` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `accounting_period`
--

LOCK TABLES `accounting_period` WRITE;
/*!40000 ALTER TABLE `accounting_period` DISABLE KEYS */;
INSERT INTO `accounting_period` (`id`, `active`, `date_from`, `date_to`, `financial_year`, `name`) VALUES (10001,'','2012-06-01 00:00:00','2012-06-30 00:00:00','2012/2013','June 2012'),(10002,'','2012-07-01 00:00:00','2012-07-31 00:00:00','2012/2013','July 2012'),(10003,'','2012-08-01 00:00:00','2012-08-31 00:00:00','2012/2013','August 2012'),(10004,'','2012-09-01 00:00:00','2012-09-30 00:00:00','2012/2013','September 2012'),(10005,'','2012-10-01 00:00:00','2012-10-31 00:00:00','2012/2013','October 2012'),(10006,'','2012-11-01 00:00:00','2012-11-30 00:00:00','2012/2013','November 2012'),(10007,'','2012-12-01 00:00:00','2012-12-31 00:00:00','2012/2013','December 2012'),(10008,'','2013-01-01 00:00:00','2013-01-31 00:00:00','2013/2014','January 2013'),(10009,'','2013-02-01 00:00:00','2013-02-28 00:00:00','2013/2014','February 2013'),(10010,'','2013-03-01 00:00:00','2013-03-31 00:00:00','2013/2014','March 2013'),(10011,'','2013-04-01 00:00:00','2013-04-30 00:00:00','2013/2014','April 2013'),(10012,'','2013-05-01 00:00:00','2013-05-31 00:00:00','2013/2014','May 2013'),(10013,'','2013-06-01 00:00:00','2013-06-30 00:00:00','2013/2014','June 2013'),(10014,'','2013-07-01 00:00:00','2013-07-31 00:00:00','2013/2014','July 2013'),(10015,'','2013-08-01 00:00:00','2013-08-31 00:00:00','2013/2014','August 2013'),(10016,'','2013-09-01 00:00:00','2013-09-30 00:00:00','2013/2014','September 2013'),(10017,'','2013-10-01 00:00:00','2013-10-31 00:00:00','2013/2014','October 2013'),(10018,'','2013-11-01 00:00:00','2013-11-30 00:00:00','2013/2014','November 2013'),(10019,'','2013-12-01 00:00:00','2013-12-31 00:00:00','2013/2014','December 2013'),(10020,'','2014-01-01 00:00:00','2014-01-31 00:00:00','2014/2015','January 2014'),(10021,'','2014-02-01 00:00:00','2014-02-28 00:00:00','2014/2015','February 2014'),(10022,'','2014-03-01 00:00:00','2014-03-31 00:00:00','2014/2015','March 2014'),(10023,'','2014-04-01 00:00:00','2014-04-30 00:00:00','2014/2015','April 2014'),(10024,'','2014-05-01 00:00:00','2014-05-31 00:00:00','2014/2015','May 2014'),(10025,'','2014-06-01 00:00:00','2014-06-30 00:00:00','2014/2015','June 2014'),(10026,'','2014-07-01 00:00:00','2014-07-31 00:00:00','2014/2015','July 2014'),(10027,'','2014-08-01 00:00:00','2014-08-31 00:00:00','2014/2015','August 2014'),(10028,'','2014-09-01 00:00:00','2014-09-30 00:00:00','2014/2015','September 2014'),(10029,'','2014-10-01 00:00:00','2014-10-31 00:00:00','2014/2015','October 2014'),(10030,'','2014-11-01 00:00:00','2014-11-30 00:00:00','2014/2015','November 2014'),(10031,'','2014-12-01 00:00:00','2014-12-31 00:00:00','2014/2015','December 2014'),(10032,'','2015-01-01 00:00:00','2015-01-31 00:00:00','2015/2016','January 2015'),(10033,'','2015-02-01 00:00:00','2015-02-28 00:00:00','2015/2016','February 2015'),(10034,'','2015-03-01 00:00:00','2015-03-31 00:00:00','2015/2016','March 2015'),(10035,'','2015-04-01 00:00:00','2015-04-30 00:00:00','2015/2016','April 2015'),(10036,'','2015-05-01 00:00:00','2015-05-31 00:00:00','2015/2016','May 2015'),(10037,'','2015-06-01 00:00:00','2015-06-30 00:00:00','2015/2016','June 2015'),(10038,'','2015-07-01 00:00:00','2015-07-31 00:00:00','2015/2016','July 2015'),(10039,'','2015-08-01 00:00:00','2015-08-31 00:00:00','2015/2016','August 2015'),(10040,'','2015-09-01 00:00:00','2015-09-30 00:00:00','2015/2016','September 2015'),(10041,'','2015-10-01 00:00:00','2015-10-31 00:00:00','2015/2016','October 2015'),(10042,'','2015-11-01 00:00:00','2015-11-30 00:00:00','2015/2016','November 2015'),(10043,'','2015-12-01 00:00:00','2015-12-31 00:00:00','2015/2016','December 2015'),(10044,'','2016-01-01 00:00:00','2016-01-31 00:00:00','2016/2017','January 2016'),(10045,'','2016-02-01 00:00:00','2016-02-29 00:00:00','2016/2017','February 2016'),(10046,'','2016-03-01 00:00:00','2016-03-31 00:00:00','2016/2017','March 2016'),(10047,'','2016-04-01 00:00:00','2016-04-30 00:00:00','2016/2017','April 2016'),(10048,'','2016-05-01 00:00:00','2016-05-31 00:00:00','2016/2017','May 2016'),(10049,'','2016-06-01 00:00:00','2016-06-30 00:00:00','2016/2017','June 2016'),(10050,'','2016-07-01 00:00:00','2016-07-31 00:00:00','2016/2017','July 2016'),(10051,'','2016-08-01 00:00:00','2016-08-31 00:00:00','2016/2017','August 2016'),(10052,'','2016-09-01 00:00:00','2016-09-30 00:00:00','2016/2017','September 2016'),(10053,'','2016-10-01 00:00:00','2016-10-31 00:00:00','2016/2017','October 2016'),(10054,'','2016-11-01 00:00:00','2016-11-30 00:00:00','2016/2017','November 2016'),(10055,'','2016-12-01 00:00:00','2016-12-31 00:00:00','2016/2017','December 2016'),(10056,'','2017-01-01 00:00:00','2017-01-31 00:00:00','2017/2018','January 2017'),(10057,'','2017-02-01 00:00:00','2017-02-28 00:00:00','2017/2018','February 2017'),(10058,'','2017-03-01 00:00:00','2017-03-31 00:00:00','2017/2018','March 2017'),(10059,'','2017-04-01 00:00:00','2017-04-30 00:00:00','2017/2018','April 2017'),(10060,'','2017-05-01 00:00:00','2017-05-31 00:00:00','2017/2018','May 2017'),(10061,'','2017-06-01 00:00:00','2017-06-30 00:00:00','2017/2018','June 2017'),(10062,'','2017-07-01 00:00:00','2017-07-31 00:00:00','2017/2018','July 2017'),(10063,'','2017-08-01 00:00:00','2017-08-31 00:00:00','2017/2018','August 2017'),(10064,'','2017-09-01 00:00:00','2017-09-30 00:00:00','2017/2018','September 2017'),(10065,'','2017-10-01 00:00:00','2017-10-31 00:00:00','2017/2018','October 2017'),(10066,'','2017-11-01 00:00:00','2017-11-30 00:00:00','2017/2018','November 2017'),(10067,'','2017-12-01 00:00:00','2017-12-31 00:00:00','2017/2018','December 2017'),(10068,'','2018-01-01 00:00:00','2018-01-31 00:00:00','2018/2019','January 2018'),(10069,'','2018-02-01 00:00:00','2018-02-28 00:00:00','2018/2019','February 2018'),(10070,'','2018-03-01 00:00:00','2018-03-31 00:00:00','2018/2019','March 2018'),(10071,'','2018-04-01 00:00:00','2018-04-30 00:00:00','2018/2019','April 2018'),(10072,'','2018-05-01 00:00:00','2018-05-31 00:00:00','2018/2019','May 2018'),(10073,'','2018-06-01 00:00:00','2018-06-30 00:00:00','2018/2019','June 2018'),(10074,'','2018-07-01 00:00:00','2018-07-31 00:00:00','2018/2019','July 2018'),(10075,'','2018-08-01 00:00:00','2018-08-31 00:00:00','2018/2019','August 2018'),(10076,'','2018-09-01 00:00:00','2018-09-30 00:00:00','2018/2019','September 2018'),(10077,'','2018-10-01 00:00:00','2018-10-31 00:00:00','2018/2019','October 2018'),(10078,'','2018-11-01 00:00:00','2018-11-30 00:00:00','2018/2019','November 2018'),(10079,'','2018-12-01 00:00:00','2018-12-31 00:00:00','2018/2019','December 2018'),(10080,'','2008-11-01 00:00:00','2008-11-30 00:00:00','2008/2009','November 2008'),(10081,'','2008-12-01 00:00:00','2008-12-31 00:00:00','2008/2009','December 2008'),(10082,'','2009-01-01 00:00:00','2009-01-31 00:00:00','2009/2010','January 2009'),(10083,'','2009-02-01 00:00:00','2009-02-28 00:00:00','2009/2010','February 2009'),(10084,'','2009-03-01 00:00:00','2009-03-31 00:00:00','2009/2010','March 2009'),(10085,'','2009-04-01 00:00:00','2009-04-30 00:00:00','2009/2010','April 2009'),(10086,'','2009-05-01 00:00:00','2009-05-31 00:00:00','2009/2010','May 2009'),(10087,'','2009-06-01 00:00:00','2009-06-30 00:00:00','2009/2010','June 2009'),(10088,'','2009-07-01 00:00:00','2009-07-31 00:00:00','2009/2010','July 2009'),(10089,'','2009-08-01 00:00:00','2009-08-31 00:00:00','2009/2010','August 2009'),(10090,'','2009-09-01 00:00:00','2009-09-30 00:00:00','2009/2010','September 2009'),(10091,'','2009-10-01 00:00:00','2009-10-31 00:00:00','2009/2010','October 2009'),(10092,'','2009-11-01 00:00:00','2009-11-30 00:00:00','2009/2010','November 2009'),(10093,'','2009-12-01 00:00:00','2009-12-31 00:00:00','2009/2010','December 2009'),(10094,'','2010-01-01 00:00:00','2010-01-31 00:00:00','2010/2011','January 2010'),(10095,'','2010-02-01 00:00:00','2010-02-28 00:00:00','2010/2011','February 2010'),(10096,'','2010-03-01 00:00:00','2010-03-31 00:00:00','2010/2011','March 2010'),(10097,'','2010-04-01 00:00:00','2010-04-30 00:00:00','2010/2011','April 2010'),(10098,'','2010-05-01 00:00:00','2010-05-31 00:00:00','2010/2011','May 2010'),(10099,'','2010-06-01 00:00:00','2010-06-30 00:00:00','2010/2011','June 2010'),(10100,'','2010-07-01 00:00:00','2010-07-31 00:00:00','2010/2011','July 2010'),(10101,'','2010-08-01 00:00:00','2010-08-31 00:00:00','2010/2011','August 2010'),(10102,'','2010-09-01 00:00:00','2010-09-30 00:00:00','2010/2011','September 2010'),(10103,'','2010-10-01 00:00:00','2010-10-31 00:00:00','2010/2011','October 2010'),(10104,'','2010-11-01 00:00:00','2010-11-30 00:00:00','2010/2011','November 2010'),(10105,'','2010-12-01 00:00:00','2010-12-31 00:00:00','2010/2011','December 2010'),(10106,'','2011-01-01 00:00:00','2011-01-31 00:00:00','2011/2012','January 2011'),(10107,'','2011-02-01 00:00:00','2011-02-28 00:00:00','2011/2012','February 2011'),(10108,'','2011-03-01 00:00:00','2011-03-31 00:00:00','2011/2012','March 2011'),(10109,'','2011-04-01 00:00:00','2011-04-30 00:00:00','2011/2012','April 2011'),(10110,'','2011-05-01 00:00:00','2011-05-31 00:00:00','2011/2012','May 2011'),(10111,'','2011-06-01 00:00:00','2011-06-30 00:00:00','2011/2012','June 2011'),(10112,'','2011-07-01 00:00:00','2011-07-31 00:00:00','2011/2012','July 2011'),(10113,'','2011-08-01 00:00:00','2011-08-31 00:00:00','2011/2012','August 2011'),(10114,'','2011-09-01 00:00:00','2011-09-30 00:00:00','2011/2012','September 2011'),(10115,'','2011-10-01 00:00:00','2011-10-31 00:00:00','2011/2012','October 2011'),(10116,'','2011-11-01 00:00:00','2011-11-30 00:00:00','2011/2012','November 2011'),(10117,'','2011-12-01 00:00:00','2011-12-31 00:00:00','2011/2012','December 2011'),(10118,'','2012-01-01 00:00:00','2012-01-31 00:00:00','2012/2013','January 2012'),(10119,'','2012-02-01 00:00:00','2012-02-29 00:00:00','2012/2013','February 2012'),(10120,'','2012-03-01 00:00:00','2012-03-31 00:00:00','2012/2013','March 2012'),(10121,'','2012-04-01 00:00:00','2012-04-30 00:00:00','2012/2013','April 2012'),(10122,'','2012-05-01 00:00:00','2012-05-31 00:00:00','2012/2013','May 2012');
/*!40000 ALTER TABLE `accounting_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `accounting_period_aud`
--

LOCK TABLES `accounting_period_aud` WRITE;
/*!40000 ALTER TABLE `accounting_period_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_period_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement`
--

LOCK TABLES `agreement` WRITE;
/*!40000 ALTER TABLE `agreement` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action`
--

LOCK TABLES `agreement_action` WRITE;
/*!40000 ALTER TABLE `agreement_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_aud`
--

LOCK TABLES `agreement_action_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_cool_off`
--

LOCK TABLES `agreement_action_cool_off` WRITE;
/*!40000 ALTER TABLE `agreement_action_cool_off` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_cool_off` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement`
--

LOCK TABLES `agreement_action_disbursement` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_3_party`
--

LOCK TABLES `agreement_action_disbursement_3_party` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_3_party_aud`
--

LOCK TABLES `agreement_action_disbursement_3_party_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_3_party_m`
--

LOCK TABLES `agreement_action_disbursement_3_party_m` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party_m` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party_m` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_3_party_m_aud`
--

LOCK TABLES `agreement_action_disbursement_3_party_m_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party_m_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_3_party_m_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_aud`
--

LOCK TABLES `agreement_action_disbursement_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_cash`
--

LOCK TABLES `agreement_action_disbursement_cash` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_cash` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_cash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_cash_aud`
--

LOCK TABLES `agreement_action_disbursement_cash_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_cash_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_cash_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_eft`
--

LOCK TABLES `agreement_action_disbursement_eft` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_eft` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_eft` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_eft_aud`
--

LOCK TABLES `agreement_action_disbursement_eft_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_eft_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_eft_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_special`
--

LOCK TABLES `agreement_action_disbursement_special` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_special` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_special` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_disbursement_special_aud`
--

LOCK TABLES `agreement_action_disbursement_special_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_disbursement_special_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_disbursement_special_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_payment`
--

LOCK TABLES `agreement_action_payment` WRITE;
/*!40000 ALTER TABLE `agreement_action_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_refinance`
--

LOCK TABLES `agreement_action_refinance` WRITE;
/*!40000 ALTER TABLE `agreement_action_refinance` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_refinance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_refinance_aud`
--

LOCK TABLES `agreement_action_refinance_aud` WRITE;
/*!40000 ALTER TABLE `agreement_action_refinance_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_refinance_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_refund`
--

LOCK TABLES `agreement_action_refund` WRITE;
/*!40000 ALTER TABLE `agreement_action_refund` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_action_settle`
--

LOCK TABLES `agreement_action_settle` WRITE;
/*!40000 ALTER TABLE `agreement_action_settle` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_action_settle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_agreement_term`
--

LOCK TABLES `agreement_agreement_term` WRITE;
/*!40000 ALTER TABLE `agreement_agreement_term` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_agreement_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_agreement_term_aud`
--

LOCK TABLES `agreement_agreement_term_aud` WRITE;
/*!40000 ALTER TABLE `agreement_agreement_term_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_agreement_term_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_aud`
--

LOCK TABLES `agreement_aud` WRITE;
/*!40000 ALTER TABLE `agreement_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_bayport_legacy`
--

LOCK TABLES `agreement_bayport_legacy` WRITE;
/*!40000 ALTER TABLE `agreement_bayport_legacy` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_bayport_legacy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_bayport_legacy_aud`
--

LOCK TABLES `agreement_bayport_legacy_aud` WRITE;
/*!40000 ALTER TABLE `agreement_bayport_legacy_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_bayport_legacy_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query`
--

LOCK TABLES `agreement_query` WRITE;
/*!40000 ALTER TABLE `agreement_query` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_aud`
--

LOCK TABLES `agreement_query_aud` WRITE;
/*!40000 ALTER TABLE `agreement_query_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_collectible`
--

LOCK TABLES `agreement_query_collectible` WRITE;
/*!40000 ALTER TABLE `agreement_query_collectible` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_collectible` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_collectible_aud`
--

LOCK TABLES `agreement_query_collectible_aud` WRITE;
/*!40000 ALTER TABLE `agreement_query_collectible_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_collectible_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_instalment`
--

LOCK TABLES `agreement_query_instalment` WRITE;
/*!40000 ALTER TABLE `agreement_query_instalment` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_instalment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_instalment_aud`
--

LOCK TABLES `agreement_query_instalment_aud` WRITE;
/*!40000 ALTER TABLE `agreement_query_instalment_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_instalment_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_refinance`
--

LOCK TABLES `agreement_query_refinance` WRITE;
/*!40000 ALTER TABLE `agreement_query_refinance` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_refinance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_refinance_aud`
--

LOCK TABLES `agreement_query_refinance_aud` WRITE;
/*!40000 ALTER TABLE `agreement_query_refinance_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_refinance_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_settlement`
--

LOCK TABLES `agreement_query_settlement` WRITE;
/*!40000 ALTER TABLE `agreement_query_settlement` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_settlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_query_settlement_aud`
--

LOCK TABLES `agreement_query_settlement_aud` WRITE;
/*!40000 ALTER TABLE `agreement_query_settlement_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_query_settlement_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term`
--

LOCK TABLES `agreement_term` WRITE;
/*!40000 ALTER TABLE `agreement_term` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_adhoc_fee`
--

LOCK TABLES `agreement_term_adhoc_fee` WRITE;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_adhoc_fee_aud`
--

LOCK TABLES `agreement_term_adhoc_fee_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_adhoc_fee_fixed_i`
--

LOCK TABLES `agreement_term_adhoc_fee_fixed_i` WRITE;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_fixed_i` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_fixed_i` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_adhoc_fee_fixed_i_aud`
--

LOCK TABLES `agreement_term_adhoc_fee_fixed_i_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_fixed_i_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_fixed_i_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_adhoc_fee_floating_i`
--

LOCK TABLES `agreement_term_adhoc_fee_floating_i` WRITE;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_floating_i` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_floating_i` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_adhoc_fee_floating_i_aud`
--

LOCK TABLES `agreement_term_adhoc_fee_floating_i_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_floating_i_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_adhoc_fee_floating_i_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee`
--

LOCK TABLES `agreement_term_admin_fee` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_aud`
--

LOCK TABLES `agreement_term_admin_fee_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_aval`
--

LOCK TABLES `agreement_term_admin_fee_aval` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_aval` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_aval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_aval_aud`
--

LOCK TABLES `agreement_term_admin_fee_aval_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_aval_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_aval_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_i`
--

LOCK TABLES `agreement_term_admin_fee_fixed_i` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_i_aud`
--

LOCK TABLES `agreement_term_admin_fee_fixed_i_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_i_immediate_r`
--

LOCK TABLES `agreement_term_admin_fee_fixed_i_immediate_r` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i_immediate_r` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i_immediate_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_i_immediate_r_aud`
--

LOCK TABLES `agreement_term_admin_fee_fixed_i_immediate_r_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i_immediate_r_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_i_immediate_r_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_amortised_r_payroll`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_amortised_r_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_amortised_r_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_amortised_r_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_fixed_i_payroll`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_fixed_i_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_fixed_i_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_fixed_i_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_flat_r`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_flat_r` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_flat_r` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_flat_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_flat_r_aud`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_flat_r_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_flat_r_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_flat_r_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_immediate_r_payroll`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_immediate_r_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_immediate_r_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_immediate_r_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_partial_i_payroll`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_partial_i_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_partial_i_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_partial_i_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud`
--

LOCK TABLES `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_floating_i`
--

LOCK TABLES `agreement_term_admin_fee_floating_i` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_floating_i_aud`
--

LOCK TABLES `agreement_term_admin_fee_floating_i_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_floating_i_immediate_r`
--

LOCK TABLES `agreement_term_admin_fee_floating_i_immediate_r` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i_immediate_r` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i_immediate_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_floating_i_immediate_r_aud`
--

LOCK TABLES `agreement_term_admin_fee_floating_i_immediate_r_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i_immediate_r_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_floating_i_immediate_r_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_gpf`
--

LOCK TABLES `agreement_term_admin_fee_gpf` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_gpf` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_gpf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_iaf`
--

LOCK TABLES `agreement_term_admin_fee_iaf` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_iaf` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_iaf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_insurance`
--

LOCK TABLES `agreement_term_admin_fee_insurance` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_insurance` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_insurance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_insurance_aud`
--

LOCK TABLES `agreement_term_admin_fee_insurance_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_insurance_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_insurance_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_payroll`
--

LOCK TABLES `agreement_term_admin_fee_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_admin_fee_payroll_aud`
--

LOCK TABLES `agreement_term_admin_fee_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_admin_fee_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_admin_fee_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_arrears`
--

LOCK TABLES `agreement_term_arrears` WRITE;
/*!40000 ALTER TABLE `agreement_term_arrears` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_arrears` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_arrears_aud`
--

LOCK TABLES `agreement_term_arrears_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_arrears_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_arrears_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_arrears_fixed_r`
--

LOCK TABLES `agreement_term_arrears_fixed_r` WRITE;
/*!40000 ALTER TABLE `agreement_term_arrears_fixed_r` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_arrears_fixed_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_arrears_linked_r`
--

LOCK TABLES `agreement_term_arrears_linked_r` WRITE;
/*!40000 ALTER TABLE `agreement_term_arrears_linked_r` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_arrears_linked_r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_aud`
--

LOCK TABLES `agreement_term_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment`
--

LOCK TABLES `agreement_term_instalment` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment_aud`
--

LOCK TABLES `agreement_term_instalment_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment_ideal_repayment`
--

LOCK TABLES `agreement_term_instalment_ideal_repayment` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment_ideal_repayment` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment_ideal_repayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment_ideal_repayment_aud`
--

LOCK TABLES `agreement_term_instalment_ideal_repayment_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment_ideal_repayment_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment_ideal_repayment_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment_minimum_payment_due`
--

LOCK TABLES `agreement_term_instalment_minimum_payment_due` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment_minimum_payment_due` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment_minimum_payment_due` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment_minimum_payment_due_aud`
--

LOCK TABLES `agreement_term_instalment_minimum_payment_due_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment_minimum_payment_due_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment_minimum_payment_due_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment_payroll`
--

LOCK TABLES `agreement_term_instalment_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_instalment_payroll_aud`
--

LOCK TABLES `agreement_term_instalment_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_instalment_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_instalment_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal`
--

LOCK TABLES `agreement_term_principal` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_aud`
--

LOCK TABLES `agreement_term_principal_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_fixed_i_open_b`
--

LOCK TABLES `agreement_term_principal_fixed_i_open_b` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_i_open_b` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_i_open_b` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_fixed_i_open_b_aud`
--

LOCK TABLES `agreement_term_principal_fixed_i_open_b_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_i_open_b_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_i_open_b_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_fixed_t_fixed_i_payroll`
--

LOCK TABLES `agreement_term_principal_fixed_t_fixed_i_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_fixed_i_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_fixed_i_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_fixed_t_fixed_i_payroll_aud`
--

LOCK TABLES `agreement_term_principal_fixed_t_fixed_i_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_fixed_i_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_fixed_i_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_fixed_t_partial_i_payroll`
--

LOCK TABLES `agreement_term_principal_fixed_t_partial_i_payroll` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_partial_i_payroll` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_partial_i_payroll` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_fixed_t_partial_i_payroll_aud`
--

LOCK TABLES `agreement_term_principal_fixed_t_partial_i_payroll_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_partial_i_payroll_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_fixed_t_partial_i_payroll_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_floating_i_open_b`
--

LOCK TABLES `agreement_term_principal_floating_i_open_b` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_floating_i_open_b` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_floating_i_open_b` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_principal_floating_i_open_b_aud`
--

LOCK TABLES `agreement_term_principal_floating_i_open_b_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_principal_floating_i_open_b_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_principal_floating_i_open_b_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_service_fee`
--

LOCK TABLES `agreement_term_service_fee` WRITE;
/*!40000 ALTER TABLE `agreement_term_service_fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_service_fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_service_fee_aud`
--

LOCK TABLES `agreement_term_service_fee_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_service_fee_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_service_fee_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_service_fee_fixed_i`
--

LOCK TABLES `agreement_term_service_fee_fixed_i` WRITE;
/*!40000 ALTER TABLE `agreement_term_service_fee_fixed_i` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_service_fee_fixed_i` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_service_fee_fixed_i_aud`
--

LOCK TABLES `agreement_term_service_fee_fixed_i_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_service_fee_fixed_i_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_service_fee_fixed_i_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_service_fee_floating_i`
--

LOCK TABLES `agreement_term_service_fee_floating_i` WRITE;
/*!40000 ALTER TABLE `agreement_term_service_fee_floating_i` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_service_fee_floating_i` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agreement_term_service_fee_floating_i_aud`
--

LOCK TABLES `agreement_term_service_fee_floating_i_aud` WRITE;
/*!40000 ALTER TABLE `agreement_term_service_fee_floating_i_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agreement_term_service_fee_floating_i_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank_account`
--

LOCK TABLES `bank_account` WRITE;
/*!40000 ALTER TABLE `bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `base_rate`
--

LOCK TABLES `base_rate` WRITE;
/*!40000 ALTER TABLE `base_rate` DISABLE KEYS */;
INSERT INTO `base_rate` (`id`, `notes`, `effective_date`, `rate`, `termInMonths`, `version`, `modified_by`, `status`, `create_date`) VALUES (1,'DEFAULT BASE RATE','2000-01-01 00:00:00',5,12,1,'rgamboa','READY','2000-01-01 00:00:00');
/*!40000 ALTER TABLE `base_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `base_rate_aud`
--

LOCK TABLES `base_rate_aud` WRITE;
/*!40000 ALTER TABLE `base_rate_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `base_rate_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `column_template_column_descript`
--

LOCK TABLES `column_template_column_descript` WRITE;
/*!40000 ALTER TABLE `column_template_column_descript` DISABLE KEYS */;
/*!40000 ALTER TABLE `column_template_column_descript` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `column_template_column_descript_aud`
--

LOCK TABLES `column_template_column_descript_aud` WRITE;
/*!40000 ALTER TABLE `column_template_column_descript_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `column_template_column_descript_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`id`, `modified_by`, `version`, `name`, `value`) VALUES (10001,NULL,0,'settlement.penaltyDays','0'),(10002,NULL,0,'settlement.useInstalment','true'),(10003,NULL,0,'refinance.penaltyDays','0'),(10004,NULL,0,'refinance.useInstalment','true'),(10005,NULL,0,'paymentPriority','1016|1018|1004|1008|1006|1010|1021|1022'),(10006,NULL,0,'inactivityPeriodInDays','90'),(10007,NULL,0,'inactivityAmountVariance','500'),(10008,NULL,0,'refinance.expiryDays','30'),(10009,NULL,0,'trigger.batch.size','1000');
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduct_column_desc`
--

LOCK TABLES `deduct_column_desc` WRITE;
/*!40000 ALTER TABLE `deduct_column_desc` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduct_column_desc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduct_column_source_property_desc`
--

LOCK TABLES `deduct_column_source_property_desc` WRITE;
/*!40000 ALTER TABLE `deduct_column_source_property_desc` DISABLE KEYS */;
INSERT INTO `deduct_column_source_property_desc` (`id`, `modified_by`, `version`, `property_id`, `source_property_type`) VALUES (1,NULL,0,2,'Global'),(2,NULL,0,5,'Global'),(3,NULL,0,23,'Global'),(4,NULL,0,9,'Global'),(5,NULL,0,12,'Global'),(6,NULL,0,15,'Global'),(7,NULL,0,11,'Global');
/*!40000 ALTER TABLE `deduct_column_source_property_desc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduct_column_template`
--

LOCK TABLES `deduct_column_template` WRITE;
/*!40000 ALTER TABLE `deduct_column_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduct_column_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduct_column_template_source_property`
--

LOCK TABLES `deduct_column_template_source_property` WRITE;
/*!40000 ALTER TABLE `deduct_column_template_source_property` DISABLE KEYS */;
INSERT INTO `deduct_column_template_source_property` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `i18n_key`) VALUES (1,NULL,0,'Line Id','','lineId','sourceProperty.LineId'),(2,NULL,0,'Client Id','','clientId','sourceProperty.ClientId'),(3,NULL,0,'Client First Name','','clientFirstName','sourceProperty.ClientFirstName'),(4,NULL,0,'Client Last Name','','clientLastName','sourceProperty.ClientLastName'),(5,NULL,0,'Client Full Name','','clientFullName','sourceProperty.ClientFullName'),(6,NULL,0,'Client Id Number','','clientIdNumber','sourceProperty.ClientIdNumber'),(7,NULL,0,'Client Employee Number','','clientEmployeeNumber','sourceProperty.ClientEmployeeNumber'),(8,NULL,0,'Submission Attempt Number','','submissionAttemptNumber','sourceProperty.SubmissionAttemptNumber'),(9,NULL,0,'Loan AccountId','','loanAccountId','sourceProperty.LoanAccountId'),(10,NULL,0,'Loan Cycle','','loanCycle','sourceProperty.LoanCycle'),(11,NULL,0,'Loan Term','','loanTerm','sourceProperty.LoanTerm'),(12,NULL,0,'Loan Total','','loanTotal','sourceProperty.LoanTotal'),(13,NULL,0,'Generated Instalments','','generatedInstalments','sourceProperty.GeneratedInstalments'),(14,NULL,0,'Arrears','','arrears','sourceProperty.Arrears'),(15,NULL,0,'Instalment Amount','','instalmentAmount','sourceProperty.InstalmentAmount'),(16,NULL,0,'Division Name','','divisionName','sourceProperty.DivisionName'),(17,NULL,0,'Division Id ','','divisionId','sourceProperty.DivisionId'),(18,NULL,0,'BankAccount Id','','bankAccountId','sourceProperty.BankAccountId'),(19,NULL,0,'Bank Name','','bankName','sourceProperty.BankName'),(20,NULL,0,'Branch Code','','branchCode','sourceProperty.BranchCode'),(21,NULL,0,'Bank Account Number','','bankAccountNumber','sourceProperty.BankAccountNumber'),(22,NULL,0,'Employer Deduction Code','','employerDeductionCode','sourceProperty.EmployerDeductionCode'),(23,NULL,0,'Employer Name','','employerName','sourceProperty.EmployerName'),(24,NULL,0,'Payroll Deduction Contract Number','','payrollDeductionContractNumber','sourceProperty.PayrollDeductionContractNumber'),(25,NULL,0,'First Expected Instalment Date','','firstExpectedInstalmentDate','sourceProperty.FirstExpectedInstalmentDate'),(26,NULL,0,'Loan End Term Date','','loanEndTermDate','sourceProperty.LoanEndTermDate'),(27,NULL,0,'Third Party Managed Entity Name','','thirdPartyManagedEntityName','sourceProperty.ThirdPartyManagedEntityName'),(28,NULL,0,'Occupation Name','','occupationName','sourceProperty.OccupationName'),(29,NULL,0,'Employed Date','','employedDate','sourceProperty.EmployedDate'),(30,NULL,0,'Repayable Amount','','repayableAmount','sourceProperty.RepayableAmount'),(31,NULL,0,'Third Party Disbursements Dates','','thirdPartyDisbursementsDates','sourceProperty.ThirdPartyDisbursementsDates'),(32,NULL,0,'Final Disbursement Date','','finalDisbursementDate','sourceProperty.FinalDisbursementDate'),(33,NULL,0,'Product Type','','productType','sourceProperty.ProductType'),(34,NULL,0,'Legacy Simco Account','','legacySimcoAccount','sourceProperty.LegacySimcoAccount');
/*!40000 ALTER TABLE `deduct_column_template_source_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduct_filter_param`
--

LOCK TABLES `deduct_filter_param` WRITE;
/*!40000 ALTER TABLE `deduct_filter_param` DISABLE KEYS */;
INSERT INTO `deduct_filter_param` (`id`, `modified_by`, `version`, `filter_property`, `value`, `deduct_filter_id`) VALUES (999001,'TEST DATA',0,'RegionId','1',999001),(999002,'TEST DATA',0,'BankId','600001',999001),(999003,'TEST DATA',0,'Term','5',999001),(999004,'TEST DATA',0,'MinAmount','1000000',999001),(999005,'TEST DATA',0,'RegionId','2',999002),(999006,'TEST DATA',0,'BankId','600002',999002),(999007,'TEST DATA',0,'Term','10',999002),(999008,'TEST DATA',0,'MinAmount','2000000',999002);
/*!40000 ALTER TABLE `deduct_filter_param` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduct_filter_param_aud`
--

LOCK TABLES `deduct_filter_param_aud` WRITE;
/*!40000 ALTER TABLE `deduct_filter_param_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduct_filter_param_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_batch`
--

LOCK TABLES `deduction_batch` WRITE;
/*!40000 ALTER TABLE `deduction_batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_batch_line`
--

LOCK TABLES `deduction_batch_line` WRITE;
/*!40000 ALTER TABLE `deduction_batch_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction_batch_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_batch_line_custom_field`
--

LOCK TABLES `deduction_batch_line_custom_field` WRITE;
/*!40000 ALTER TABLE `deduction_batch_line_custom_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction_batch_line_custom_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_batch_result`
--

LOCK TABLES `deduction_batch_result` WRITE;
/*!40000 ALTER TABLE `deduction_batch_result` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction_batch_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_batch_result_line`
--

LOCK TABLES `deduction_batch_result_line` WRITE;
/*!40000 ALTER TABLE `deduction_batch_result_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction_batch_result_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_filter`
--

LOCK TABLES `deduction_filter` WRITE;
/*!40000 ALTER TABLE `deduction_filter` DISABLE KEYS */;
INSERT INTO `deduction_filter` (`id`, `modified_by`, `version`, `description`, `employer_id`, `global`, `name`, `source_id`, `source_version`) VALUES (999001,'TEST DATA',0,'The first static deduction filter',NULL,'','Static Test Filter 1',0,0),(999002,'TEST DATA',0,'The second static deduction filter',NULL,'','Static Test Filter 2',0,0);
/*!40000 ALTER TABLE `deduction_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_filter_aud`
--

LOCK TABLES `deduction_filter_aud` WRITE;
/*!40000 ALTER TABLE `deduction_filter_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction_filter_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_result_column`
--

LOCK TABLES `deduction_result_column` WRITE;
/*!40000 ALTER TABLE `deduction_result_column` DISABLE KEYS */;
/*!40000 ALTER TABLE `deduction_result_column` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deposit_slip_reference`
--

LOCK TABLES `deposit_slip_reference` WRITE;
/*!40000 ALTER TABLE `deposit_slip_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `deposit_slip_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement`
--

LOCK TABLES `disbursement` WRITE;
/*!40000 ALTER TABLE `disbursement` DISABLE KEYS */;
/*!40000 ALTER TABLE `disbursement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement_batch`
--

LOCK TABLES `disbursement_batch` WRITE;
/*!40000 ALTER TABLE `disbursement_batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `disbursement_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement_batch_line`
--

LOCK TABLES `disbursement_batch_line` WRITE;
/*!40000 ALTER TABLE `disbursement_batch_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `disbursement_batch_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement_reason_code`
--

LOCK TABLES `disbursement_reason_code` WRITE;
/*!40000 ALTER TABLE `disbursement_reason_code` DISABLE KEYS */;
INSERT INTO `disbursement_reason_code` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'import.sql',0,'No reason code set','','No reason code set'),(2,'import.sql',0,'Invalid Bank Account','','Invalid Bank Account');
/*!40000 ALTER TABLE `disbursement_reason_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `document_reference_aud`
--

LOCK TABLES `document_reference_aud` WRITE;
/*!40000 ALTER TABLE `document_reference_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_reference_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer_period`
--

LOCK TABLES `employer_period` WRITE;
/*!40000 ALTER TABLE `employer_period` DISABLE KEYS */;
/*!40000 ALTER TABLE `employer_period` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fee`
--

LOCK TABLES `fee` WRITE;
/*!40000 ALTER TABLE `fee` DISABLE KEYS */;
/*!40000 ALTER TABLE `fee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fee_value`
--

LOCK TABLES `fee_value` WRITE;
/*!40000 ALTER TABLE `fee_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `fee_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `hibernate_sequences`
--

LOCK TABLES `hibernate_sequences` WRITE;
/*!40000 ALTER TABLE `hibernate_sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `hibernate_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `interest_rate`
--

LOCK TABLES `interest_rate` WRITE;
/*!40000 ALTER TABLE `interest_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `interest_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_analysis_batch`
--

LOCK TABLES `loan_analysis_batch` WRITE;
/*!40000 ALTER TABLE `loan_analysis_batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_analysis_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_analysis_batch_line`
--

LOCK TABLES `loan_analysis_batch_line` WRITE;
/*!40000 ALTER TABLE `loan_analysis_batch_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_analysis_batch_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `lookup_index`
--

LOCK TABLES `lookup_index` WRITE;
/*!40000 ALTER TABLE `lookup_index` DISABLE KEYS */;
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`) VALUES (23,'sameer',0,'com.qualica.flexifin.accounting.domain.AccountReasonCodeCategory','AccountReasonCodeCategory',NULL,NULL),(24,'sameer',0,'com.qualica.flexifin.accounting.domain.AccountReasonCode','AccountReasonCode','accountReasonCodeCategory',23),(25,'sameer',0,'com.qualica.flexifin.accounting.domain.DisbursementReasonCode','DisbursementReasonCode',NULL,NULL),(26,'sameer',0,'com.qualica.flexifin.accounting.domain.ReceiptingBatchReasonCode','ReceiptingBatchReasonCode',NULL,NULL);
/*!40000 ALTER TABLE `lookup_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payment_priority`
--

LOCK TABLES `payment_priority` WRITE;
/*!40000 ALTER TABLE `payment_priority` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_priority` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_allocation`
--

LOCK TABLES `receipt_allocation` WRITE;
/*!40000 ALTER TABLE `receipt_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_allocation_aud`
--

LOCK TABLES `receipt_allocation_aud` WRITE;
/*!40000 ALTER TABLE `receipt_allocation_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_allocation_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch`
--

LOCK TABLES `receipt_batch` WRITE;
/*!40000 ALTER TABLE `receipt_batch` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch_aud`
--

LOCK TABLES `receipt_batch_aud` WRITE;
/*!40000 ALTER TABLE `receipt_batch_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch_column_descriptor`
--

LOCK TABLES `receipt_batch_column_descriptor` WRITE;
/*!40000 ALTER TABLE `receipt_batch_column_descriptor` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch_column_descriptor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch_column_descriptor_aud`
--

LOCK TABLES `receipt_batch_column_descriptor_aud` WRITE;
/*!40000 ALTER TABLE `receipt_batch_column_descriptor_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch_column_descriptor_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch_column_template`
--

LOCK TABLES `receipt_batch_column_template` WRITE;
/*!40000 ALTER TABLE `receipt_batch_column_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch_column_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch_column_template_aud`
--

LOCK TABLES `receipt_batch_column_template_aud` WRITE;
/*!40000 ALTER TABLE `receipt_batch_column_template_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch_column_template_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch_line`
--

LOCK TABLES `receipt_batch_line` WRITE;
/*!40000 ALTER TABLE `receipt_batch_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipt_batch_line_aud`
--

LOCK TABLES `receipt_batch_line_aud` WRITE;
/*!40000 ALTER TABLE `receipt_batch_line_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipt_batch_line_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipting_batch_column_descript`
--

LOCK TABLES `receipting_batch_column_descript` WRITE;
/*!40000 ALTER TABLE `receipting_batch_column_descript` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipting_batch_column_descript` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipting_batch_column_descript_aud`
--

LOCK TABLES `receipting_batch_column_descript_aud` WRITE;
/*!40000 ALTER TABLE `receipting_batch_column_descript_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipting_batch_column_descript_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipting_batch_reason_code`
--

LOCK TABLES `receipting_batch_reason_code` WRITE;
/*!40000 ALTER TABLE `receipting_batch_reason_code` DISABLE KEYS */;
INSERT INTO `receipting_batch_reason_code` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'import.sql',0,'No reason code set','','No reason code set'),(2,'import.sql',0,'Invalid Batch','','Invalid Batch');
/*!40000 ALTER TABLE `receipting_batch_reason_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipting_due`
--

LOCK TABLES `receipting_due` WRITE;
/*!40000 ALTER TABLE `receipting_due` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipting_due` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `refinance`
--

LOCK TABLES `refinance` WRITE;
/*!40000 ALTER TABLE `refinance` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `refinance_line`
--

LOCK TABLES `refinance_line` WRITE;
/*!40000 ALTER TABLE `refinance_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinance_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `refinance_refinance_line`
--

LOCK TABLES `refinance_refinance_line` WRITE;
/*!40000 ALTER TABLE `refinance_refinance_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `refinance_refinance_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `refund`
--

LOCK TABLES `refund` WRITE;
/*!40000 ALTER TABLE `refund` DISABLE KEYS */;
/*!40000 ALTER TABLE `refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `revinfo`
--

LOCK TABLES `revinfo` WRITE;
/*!40000 ALTER TABLE `revinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `revinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `settlement`
--

LOCK TABLES `settlement` WRITE;
/*!40000 ALTER TABLE `settlement` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `settlement_discharge_confirmation`
--

LOCK TABLES `settlement_discharge_confirmation` WRITE;
/*!40000 ALTER TABLE `settlement_discharge_confirmation` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlement_discharge_confirmation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `settlement_line`
--

LOCK TABLES `settlement_line` WRITE;
/*!40000 ALTER TABLE `settlement_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlement_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `settlement_quote_confirmation`
--

LOCK TABLES `settlement_quote_confirmation` WRITE;
/*!40000 ALTER TABLE `settlement_quote_confirmation` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlement_quote_confirmation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `settlement_settlement_line`
--

LOCK TABLES `settlement_settlement_line` WRITE;
/*!40000 ALTER TABLE `settlement_settlement_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `settlement_settlement_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `submission_due`
--

LOCK TABLES `submission_due` WRITE;
/*!40000 ALTER TABLE `submission_due` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_due` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `third_party_disbursement_authorisation`
--

LOCK TABLES `third_party_disbursement_authorisation` WRITE;
/*!40000 ALTER TABLE `third_party_disbursement_authorisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `third_party_disbursement_authorisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `timeline`
--

LOCK TABLES `timeline` WRITE;
/*!40000 ALTER TABLE `timeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `timeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_account`
--

LOCK TABLES `tx_account` WRITE;
/*!40000 ALTER TABLE `tx_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_balance`
--

LOCK TABLES `tx_balance` WRITE;
/*!40000 ALTER TABLE `tx_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_balance_link`
--

LOCK TABLES `tx_balance_link` WRITE;
/*!40000 ALTER TABLE `tx_balance_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_balance_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_change`
--

LOCK TABLES `tx_change` WRITE;
/*!40000 ALTER TABLE `tx_change` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_change` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_chart`
--

LOCK TABLES `tx_chart` WRITE;
/*!40000 ALTER TABLE `tx_chart` DISABLE KEYS */;
INSERT INTO `tx_chart` (`id`, `name`) VALUES (1016,'Arrears Interest'),(1018,'Arrears Penalty'),(1001,'Bank Disbursement'),(1009,'Bank Payment'),(1019,'Cheque Fee'),(1012,'Cool Off'),(1010,'Debtor Advance Provision'),(1002,'Debtor Control'),(1011,'Disbursement Suspense'),(1020,'Grace Period Fee'),(1021,'Recognised Aval Fee'),(1006,'Recognised Fee'),(1008,'Recognised Fee Interest'),(1022,'Recognised Insurance Fee'),(1026,'recognised Interes Anticipado Fee'),(1004,'Recognised Interest'),(1014,'Settlement Interest'),(1015,'Settlement Write Off'),(1017,'Suspense'),(1023,'Unrecognised Aval Fee'),(1005,'Unrecognised Fee'),(1007,'Unrecognised Fee Interest'),(1024,'Unrecognised Insurance Fee'),(1027,'unrecognised Interes Anticipado Fee'),(1003,'Unrecognised Interest'),(1025,'Unrecognised Principal'),(1013,'Write Off');
/*!40000 ALTER TABLE `tx_chart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_chart_aud`
--

LOCK TABLES `tx_chart_aud` WRITE;
/*!40000 ALTER TABLE `tx_chart_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_chart_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_header`
--

LOCK TABLES `tx_header` WRITE;
/*!40000 ALTER TABLE `tx_header` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_header` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_header_tx_line`
--

LOCK TABLES `tx_header_tx_line` WRITE;
/*!40000 ALTER TABLE `tx_header_tx_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_header_tx_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_instalment`
--

LOCK TABLES `tx_instalment` WRITE;
/*!40000 ALTER TABLE `tx_instalment` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_instalment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_instalment_line`
--

LOCK TABLES `tx_instalment_line` WRITE;
/*!40000 ALTER TABLE `tx_instalment_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_instalment_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_instalment_link`
--

LOCK TABLES `tx_instalment_link` WRITE;
/*!40000 ALTER TABLE `tx_instalment_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_instalment_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_line`
--

LOCK TABLES `tx_line` WRITE;
/*!40000 ALTER TABLE `tx_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_principal`
--

LOCK TABLES `tx_principal` WRITE;
/*!40000 ALTER TABLE `tx_principal` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_principal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_principal_link`
--

LOCK TABLES `tx_principal_link` WRITE;
/*!40000 ALTER TABLE `tx_principal_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_principal_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `tx_recognition`
--

LOCK TABLES `tx_recognition` WRITE;
/*!40000 ALTER TABLE `tx_recognition` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_recognition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 16:07:33
