USE flexifinproduct

ALTER TABLE loan_product CHANGE COLUMN cheque_fee_type cheque_fee_type VARCHAR(255) DEFAULT NULL;