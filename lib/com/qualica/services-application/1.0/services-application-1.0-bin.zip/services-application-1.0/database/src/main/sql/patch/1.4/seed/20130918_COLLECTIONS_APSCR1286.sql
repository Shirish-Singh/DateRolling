use collections;


UPDATE `collections`.`contact_script_template` SET `description`='CHECK_PROOF_OF_PAYMENT', `name`='CHECK_PROOF_OF_PAYMENT', `label`='Check Proof Of Payment', `template_content`='Please check if proof of payment received from client or not.' WHERE `id`='2401';

UPDATE `collections`.`contact_script_template` SET `description`='CHECK_PROOF_OF_PAYMENT', `name`='CHECK_PROOF_OF_PAYMENT', `label`='Check Proof Of Payment', `template_content`='Please check if proof of payment received from client or not.' WHERE `id`='3401';



UPDATE `collections`.`contact_script_template` SET `description`='UPLOAD_PROOF_OF_PAYMENT', `name`='PROOF_OF_PAYMENT_AVAILABLE', `label`='Proof of Payment Available', `template_content`='Please send clients proof of payment to Receipting team.', `workflow_outcome_name`='yes', `script_outcome_state`='INACTIVE' WHERE `id`='2404';

UPDATE `collections`.`contact_script_template` SET `description`='UPLOAD_PROOF_OF_PAYMENT', `name`='PROOF_OF_PAYMENT_AVAILABLE', `label`='Proof of Payment Available', `template_content`='Please send clients proof of payment to Receipting team.', `workflow_outcome_name`='yes', `script_outcome_state`='INACTIVE' WHERE `id`='3404';


UPDATE `collections`.`contact_script_template` SET `description`='UPLOAD_PROOF_OF_PAYMENT', `name`='EMAIL_SENT_TO_RECEIPTING_TEAM', `label`='Email Sent to ReceiptingTeam', `template_content`='--Thank you-- Please followup with Receipting Team after every 4 days', `workflow_outcome_name`='', `script_outcome_state`='INACTIVE' WHERE `id`='2403';

UPDATE `collections`.`contact_script_template` SET `description`='UPLOAD_PROOF_OF_PAYMENT', `name`='EMAIL_SENT_TO_RECEIPTING_TEAM', `label`='Email Sent to ReceiptingTeam', `template_content`='--Thank you-- Please followup with Receipting Team after every 4 days', `workflow_outcome_name`='', `script_outcome_state`='INACTIVE' WHERE `id`='3403';


UPDATE `collections`.`contact_script_template` SET `description`='CHECK_PROOF_OF_PAYMENT', `name`='PROOF_OF_PAYMENT_NOT_AVAILABLE', `label`='Proof of Payment Not Available', `template_content`='Continue collection process for the client', `workflow_outcome_name`='no', `script_outcome_state`='INACTIVE' WHERE `id`='2451';

UPDATE `collections`.`contact_script_template` SET `description`='CHECK_PROOF_OF_PAYMENT', `name`='PROOF_OF_PAYMENT_NOT_AVAILABLE', `label`='Proof of Payment Not Available', `template_content`='Continue collection process for the client', `workflow_outcome_name`='no', `script_outcome_state`='INACTIVE' WHERE `id`='3451';



