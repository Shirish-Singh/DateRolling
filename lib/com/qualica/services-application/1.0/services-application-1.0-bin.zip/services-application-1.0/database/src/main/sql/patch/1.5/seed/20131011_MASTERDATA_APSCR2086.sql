USE masterdata;


DELETE FROM `trading_entity` WHERE `id`='2002';
DELETE FROM `organisation_role` WHERE `id`='2002';
DELETE FROM `party_role` WHERE `id`='2002';
DELETE FROM `organisation` WHERE `id`='1002';
DELETE FROM `party` WHERE `id`='1002';
insert into party (id, version, modified_by) values(1002, 0, 'sharad');

insert into organisation(id,name, registration_number, sales_tax_number, tax_number) values(1002, 'LIBRAVAL', '10', '1000', '100');

insert into party_role(id, modified_by, version, from_date, to_date, party_id, role_type_id) values(2002, 'sharad', 0, TIMESTAMP '2012-01-01 00:00:00.0', NULL, 1002, 500);

insert into organisation_role(id) values(2002);

insert into trading_entity  (id, entity_identifier) values (2002,'');

DELETE FROM `trading_entity` WHERE `id`='2003';
DELETE FROM `organisation_role` WHERE `id`='2003';
DELETE FROM `party_role` WHERE `id`='2003';
DELETE FROM `organisation` WHERE `id`='1003';
DELETE FROM `party` WHERE `id`='1003';
insert into party (id, version, modified_by) values(1003, 0, 'sharad');

insert into organisation(id,name, registration_number, sales_tax_number, tax_number) values(1003, 'COLPATRIA', '10', '1000', '100');

insert into party_role(id, modified_by, version, from_date, to_date, party_id, role_type_id) values(2003, 'sharad', 0, TIMESTAMP '2012-01-01 00:00:00.0', NULL, 1003, 500);

insert into organisation_role(id) values(2003);

insert into trading_entity  (id, entity_identifier) values (2003,'');


DELETE FROM `trading_entity` WHERE `id`='2004';
DELETE FROM `organisation_role` WHERE `id`='2004';
DELETE FROM `party_role` WHERE `id`='2004';
DELETE FROM `organisation` WHERE `id`='1004';
DELETE FROM `party` WHERE `id`='1004';
insert into party (id, version, modified_by) values(1004, 0, 'sharad');

insert into organisation(id,name, registration_number, sales_tax_number, tax_number) values(1004, 'SUDAMERIS', '10', '1000', '100');

insert into party_role(id, modified_by, version, from_date, to_date, party_id, role_type_id) values(2004, 'sharad', 0, TIMESTAMP '2012-01-01 00:00:00.0', NULL, 1004, 500);

insert into organisation_role(id) values(2004);

insert into trading_entity  (id, entity_identifier) values (2004,'');



UPDATE `masterdata`.`trading_entity` SET `deducting_trading_entity`=1, `lending_trading_entity`=1 WHERE `id`='2000';
UPDATE `masterdata`.`trading_entity` SET `lending_trading_entity`=1 WHERE `id`='2001';



