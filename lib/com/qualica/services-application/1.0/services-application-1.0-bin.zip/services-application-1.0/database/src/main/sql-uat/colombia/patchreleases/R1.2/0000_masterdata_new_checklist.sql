use masterdata;

insert into check_list_definition (id, name, source_resource_id, source_resource_name, version) values
(30, 'employerApplicationSignature', null, null, 1);

insert into check_list_item_definition (id, name, description, item_order, required, check_list_definition_id, enabled, version) values
(120, 'Signature Document', 'Signature samples', 1, true,  30, true, 1);

insert into check_list_item_document_definition (id, approval_required, required_approval_role) values
(120, false, null);

