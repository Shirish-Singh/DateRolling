USE collections;

DROP PROCEDURE IF EXISTS collections.drop_fk ;

DELIMITER $$

CREATE PROCEDURE collections.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'collections'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL collections.drop_fk('collection_case', 'FK3F2DF8313F9DAE9') ;
CALL collections.drop_fk('collection_case', 'FK3F2DF8311F1F94EE') ;
CALL collections.drop_fk('collection_instance', 'FKAA1DA9162352B753') ;
CALL collections.drop_fk('collection_instance', 'FKAA1DA916EC3BED0E') ;
CALL collections.drop_fk('collection_case_status_reason', 'FKD4166BA3A319045B') ;
CALL collections.drop_fk('collection_instance_status_reason', 'FK2B1827C8C302AD25') ;


DROP PROCEDURE IF EXISTS collections.drop_fk ;


DROP PROCEDURE IF EXISTS collections.alter_column ;

DELIMITER $$

CREATE PROCEDURE collections.alter_column(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
  BEGIN
    IF EXISTS (
        SELECT * FROM information_schema.COLUMNS
        WHERE column_name = newColName
              AND table_name = tableName
              AND table_schema = 'collections'
    )
    THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

    END IF;
  END ;$$

DELIMITER ;

CALL collections.alter_column('collection_case', 'status_id', 'status_id', 'INT(4) NULL') ;
CALL collections.alter_column('collection_case_aud', 'status_id', 'status_id', 'INT(4) NULL') ;
CALL collections.alter_column('collection_instance', 'status_id', 'status_id', 'INT(4) NOT NULL') ;
CALL collections.alter_column('collection_instance_aud', 'status_id', 'status_id', 'INT(4) NULL DEFAULT NULL') ;

DROP PROCEDURE IF EXISTS collections.alter_column ;



DROP PROCEDURE IF EXISTS collections.drop_column ;

DELIMITER $$

CREATE PROCEDURE collections.drop_column(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100)
)
  BEGIN
    IF EXISTS (
        SELECT * FROM information_schema.COLUMNS
        WHERE column_name = colName
              AND table_name = tableName
              AND table_schema = 'collections'
    )
    THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` DROP COLUMN `', colName, '`');

      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

    END IF;
  END ;$$

DELIMITER ;


CALL collections.drop_column('collection_case', 'status_reason_id') ;
CALL collections.drop_column('collection_case_aud', 'status_reason_id');
CALL collections.drop_column('collection_instance', 'status_reason_id');
CALL collections.drop_column('collection_instance_aud', 'status_reason_id');


DROP PROCEDURE IF EXISTS collections.drop_column ;



DROP PROCEDURE IF EXISTS collections.add_column ;

DELIMITER $$

CREATE PROCEDURE collections.add_column(
  IN tableName VARCHAR(100),
  IN columnName VARCHAR(100),
  IN columnType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = columnName
      AND table_name = tableName
      AND table_schema = 'collections'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL collections.add_column('collection_case', 'legacy_account_number', 'VARCHAR(255)');
CALL collections.add_column('collection_case_aud', 'legacy_account_number', 'VARCHAR(255)');

DROP PROCEDURE IF EXISTS collections.add_column ;




DROP TABLE IF EXISTS collection_case_status;
DROP TABLE IF EXISTS collection_case_status_aud;

DROP TABLE IF EXISTS collection_case_status_reason;
DROP TABLE IF EXISTS collection_case_status_reason_aud;

DROP TABLE IF EXISTS collection_instance_status;
DROP TABLE IF EXISTS collection_instance_status_aud;

DROP TABLE IF EXISTS collection_instance_status_reason;
DROP TABLE IF EXISTS collection_instance_status_reason_aud;











