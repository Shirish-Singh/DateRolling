use masterdata;

DELETE from application_status_reason where id in(15);
INSERT INTO `application_status_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES ('15', 'static', '0', 'Application was rejected because refinance quote has expired', 1, 'rejection_due_to_refinance_quote_expired');
