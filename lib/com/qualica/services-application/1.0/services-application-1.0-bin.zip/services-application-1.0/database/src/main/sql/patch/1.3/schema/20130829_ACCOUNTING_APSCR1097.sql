use accounting;


--
-- Table structure for table `accounting_dto_to_class_binding`
--
DROP TABLE IF EXISTS `accounting_note`;
DROP TABLE IF EXISTS `accounting_dto_to_class_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_dto_to_class_binding` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `dto_name` varchar(255) DEFAULT NULL,
  `relevant_entity_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;



--
-- Table structure for table `accounting_note`
--
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_note` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_time_created` datetime DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `processname` varchar(255) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `task_definition_key` varchar(255) DEFAULT NULL,
  `taskid` varchar(255) DEFAULT NULL,
  `taskname` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `accounting_dto_to_class_binding` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK362B7B5C66AF32D5` (`accounting_dto_to_class_binding`),
  CONSTRAINT `FK362B7B5C66AF32D5` FOREIGN KEY (`accounting_dto_to_class_binding`) REFERENCES `accounting_dto_to_class_binding` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

