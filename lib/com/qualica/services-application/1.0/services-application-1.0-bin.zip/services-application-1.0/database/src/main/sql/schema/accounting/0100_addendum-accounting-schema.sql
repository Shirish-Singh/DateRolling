USE `accounting`;

DROP TABLE IF EXISTS `accounting_document_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_document_number` (
  `document_type` varchar(50) NOT NULL,
  `next_number` bigint(20) NOT NULL ,
  PRIMARY KEY (`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
