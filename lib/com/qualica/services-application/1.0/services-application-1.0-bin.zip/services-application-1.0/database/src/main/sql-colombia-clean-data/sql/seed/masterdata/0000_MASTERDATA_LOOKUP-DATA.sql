use masterdata;
SET character_set_client = utf8;
-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: masterdata
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `account_application`
--

LOCK TABLES `account_application` WRITE;
/*!40000 ALTER TABLE `account_application` DISABLE KEYS */;
INSERT INTO `account_application` (`id`, `modified_by`, `version`) VALUES (801000015,'112_documentpack.sql',0),(801000038,'112_documentpack.sql',0);
/*!40000 ALTER TABLE `account_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `account_application_aud`
--

LOCK TABLES `account_application_aud` WRITE;
/*!40000 ALTER TABLE `account_application_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_application_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `address_type`
--

LOCK TABLES `address_type` WRITE;
/*!40000 ALTER TABLE `address_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`address_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Casa','Casa',1);
INSERT INTO `masterdata`.`address_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Oficina','Oficina',1);
INSERT INTO `masterdata`.`address_type` (`id`, `version`, `description`, `name`, `enabled`) VALUES ('1003', '0', 'Apartamento', 'Apartamento',1);
/*!40000 ALTER TABLE `address_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agent`
--

LOCK TABLES `agent` WRITE;
/*!40000 ALTER TABLE `agent` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agent_aud`
--

LOCK TABLES `agent_aud` WRITE;
/*!40000 ALTER TABLE `agent_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `agent_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `agent_type`
--

LOCK TABLES `agent_type` WRITE;
/*!40000 ALTER TABLE `agent_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`agent_type`(`id`,`version`,`description`,`name`,`enabled`,`level`) VALUES ('1001','0','Asesor Junior','Asesor Junior',1,1);
INSERT INTO `masterdata`.`agent_type`(`id`,`version`,`description`,`name`,`enabled`,`level`) VALUES ('1002','0','Asesor Externo','Asesor Externo',1,1);
INSERT INTO `masterdata`.`agent_type`(`id`,`version`,`description`,`name`,`enabled`,`level`) VALUES ('1003','0','Asesor Lider','Asesor Lider',1,1);
/*!40000 ALTER TABLE `agent_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `applicable_product`
--

LOCK TABLES `applicable_product` WRITE;
/*!40000 ALTER TABLE `applicable_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `applicable_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_approval_status`
--

LOCK TABLES `application_approval_status` WRITE;
/*!40000 ALTER TABLE `application_approval_status` DISABLE KEYS */;
INSERT INTO `application_approval_status` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (0,'static',0,'Origination initial','','origination_new'),(1,'static',0,'Pending review','','review_pending'),(2,'static',0,'Pending Underwriting','','underwriting_pending'),(3,'static',0,'In Recovery','','recovery'),(4,'static',0,'Recovery Failed','','recovery_failed'),(5,'static',0,'Approved','','approved'),(6,'static',0,'Rejected','','rejected'),(7,'static',0,'Cancelled','','cancelled');
/*!40000 ALTER TABLE `application_approval_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_approval_status_aud`
--

LOCK TABLES `application_approval_status_aud` WRITE;
/*!40000 ALTER TABLE `application_approval_status_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_approval_status_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_decision`
--

LOCK TABLES `application_decision` WRITE;
/*!40000 ALTER TABLE `application_decision` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_decision` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_decision_aud`
--

LOCK TABLES `application_decision_aud` WRITE;
/*!40000 ALTER TABLE `application_decision_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_decision_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_decision_reason`
--

LOCK TABLES `application_decision_reason` WRITE;
/*!40000 ALTER TABLE `application_decision_reason` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_decision_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_decision_reason_aud`
--

LOCK TABLES `application_decision_reason_aud` WRITE;
/*!40000 ALTER TABLE `application_decision_reason_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_decision_reason_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_status_reason`
--

LOCK TABLES `application_status_reason` WRITE;
/*!40000 ALTER TABLE `application_status_reason` DISABLE KEYS */;
INSERT INTO `application_status_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (0,'static',0,'No reason code set','','unset'),(1,'static',0,'Loan not viable','','rejected_not_viable'),(2,'static',0,'Client blacklisted','','rejected_blacklisted'),(3,'static',0,'Denied by credit bureau','','rejected_credit_bureau'),(4,'static',0,'Invalid identity document/number','','rejected_invalid_id'),(5,'static',0,'Loan denied in origination','','rejected_origination'),(6,'static',0,'Agent rejected loan','','rejected_agent'),(7,'static',0,'Agent rejected loan','','rejected_employer_confirmation'),(8,'static',0,'Rejected due to recovery outcome','','rejected_recovery_outcome'),(9,'static',0,'Recovery requires loan review','','rejected_recovery_review_loan'),(10,'static',0,'Recovered application review rejection','','rejected_review_recovered_application'),(11,'static',0,'recovery outcome was successful','','accepted_review_recovered_application'),(12,'static',0,'Loan cancelled in underwriting','','cancelled_underwriting'),(13,'static',0,'Employer code validity has expired','','origination_employer_code_expired'),(14,'static',0,'Application was rejected because an application error occurred at a critical stage of approval','','rejection_due_to_error');
/*!40000 ALTER TABLE `application_status_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `application_status_reason_aud`
--

LOCK TABLES `application_status_reason_aud` WRITE;
/*!40000 ALTER TABLE `application_status_reason_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `application_status_reason_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `approval`
--

LOCK TABLES `approval` WRITE;
/*!40000 ALTER TABLE `approval` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank`
--

LOCK TABLES `bank` WRITE;
/*!40000 ALTER TABLE `bank` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank_account`
--

LOCK TABLES `bank_account` WRITE;
/*!40000 ALTER TABLE `bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank_account_number_configuration`
--

LOCK TABLES `bank_account_number_configuration` WRITE;
/*!40000 ALTER TABLE `bank_account_number_configuration` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_account_number_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank_account_status`
--

LOCK TABLES `bank_account_status` WRITE;
/*!40000 ALTER TABLE `bank_account_status` DISABLE KEYS */;
INSERT INTO `bank_account_status` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,NULL,0,'Open',NULL,'open'),(2,NULL,0,'Closed',NULL,'closed');
/*!40000 ALTER TABLE `bank_account_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank_account_type`
--

LOCK TABLES `bank_account_type` WRITE;
/*!40000 ALTER TABLE `bank_account_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`bank_account_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Ahorros','Ahorros',1);
INSERT INTO `masterdata`.`bank_account_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Corriente','Corriente',1);
/*!40000 ALTER TABLE `bank_account_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank_branch`
--

LOCK TABLES `bank_branch` WRITE;
/*!40000 ALTER TABLE `bank_branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `bank_branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bank_type`
--

LOCK TABLES `bank_type` WRITE;
/*!40000 ALTER TABLE `bank_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`bank_type` (`id`, `modified_by`, `version`, `description`, `name`,`enabled`) VALUES (1001,NULL,0,'Banco','Banco',1);
/*!40000 ALTER TABLE `bank_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `bayport_colombia_payroll_deduction_loan_application`
--

LOCK TABLES `bayport_colombia_payroll_deduction_loan_application` WRITE;
/*!40000 ALTER TABLE `bayport_colombia_payroll_deduction_loan_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `bayport_colombia_payroll_deduction_loan_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `blacklist`
--

LOCK TABLES `blacklist` WRITE;
/*!40000 ALTER TABLE `blacklist` DISABLE KEYS */;
/*!40000 ALTER TABLE `blacklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list`
--

LOCK TABLES `check_list` WRITE;
/*!40000 ALTER TABLE `check_list` DISABLE KEYS */;
INSERT INTO `check_list` (`id`, `created`, `definition_name`, `target_resource_id`, `target_resource_name`, `task_id`) VALUES (720101111,'2013-01-01 01:01:00','employerApplication',120715,'employer',NULL),(720101112,'2013-01-01 01:01:00','employerOrigination',801000015,'payrollLoanApplication',NULL),(720201112,'2013-01-01 01:01:00','employerOrigination',801000038,'payrollLoanApplication',NULL);
/*!40000 ALTER TABLE `check_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_definition`
--

LOCK TABLES `check_list_definition` WRITE;
/*!40000 ALTER TABLE `check_list_definition` DISABLE KEYS */;
INSERT INTO `check_list_definition` (`id`, `modified_by`, `version`, `name`, `source_resource_id`, `source_resource_name`) VALUES (1,NULL,1,'originationPreApproval',NULL,NULL),(2,NULL,1,'employerApplication',NULL,NULL),(3,NULL,1,'employerPolicies',NULL,NULL),(4,NULL,1,'employerOrigination',120705,'employer'),(5,NULL,1,'employerOrigination',120706,'employer'),(6,NULL,1,'employerOrigination',120707,'employer'),(7,NULL,1,'employerOrigination',120708,'employer'),(8,NULL,1,'employerOrigination',120709,'employer'),(9,NULL,1,'employerOrigination',120715,'employer'),(10,NULL,1,'employerOrigination',120716,'employer'),(11,NULL,1,'employerOrigination',120717,'employer'),(12,NULL,1,'employerOrigination',120718,'employer'),(13,NULL,1,'employerOrigination',120719,'employer'),(14,NULL,1,'originationClientID',NULL,NULL),(15,NULL,1,'originationClientCredit',NULL,NULL),(16,NULL,1,'underwritingEmployer',NULL,NULL),(17,NULL,1,'underwritingAudit',NULL,NULL),(18,NULL,1,'originationGuarantorCredit',NULL,NULL),(19,NULL,1,'originationGuarantorID',NULL,NULL),(20,NULL,1,'bayportEntityOrigination',NULL,NULL),(21,NULL,1,'microcreditoEntityOrigination',NULL,NULL),(30,NULL,1,'employerApplicationSignature',NULL,NULL);
/*!40000 ALTER TABLE `check_list_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item`
--

LOCK TABLES `check_list_item` WRITE;
/*!40000 ALTER TABLE `check_list_item` DISABLE KEYS */;
INSERT INTO `check_list_item` (`id`, `description`, `name`, `item_order`, `required`, `check_list_id`, `check_list_item_definition_id`, `process_variable_key`, `date_updated`, `username`) VALUES (10104444,'check list item description 10104444','check list item name 10104444',0,'',720101112,104444,NULL,NULL,NULL),(20101111,'check list item description 20101111','check list item name 20101111',0,'',720101111,2,NULL,NULL,NULL),(20104444,'check list item description 20104444','check list item name 20104444',0,'',720201112,104444,NULL,NULL,NULL);
/*!40000 ALTER TABLE `check_list_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_check_box`
--

LOCK TABLES `check_list_item_check_box` WRITE;
/*!40000 ALTER TABLE `check_list_item_check_box` DISABLE KEYS */;
/*!40000 ALTER TABLE `check_list_item_check_box` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_check_box_definition`
--

LOCK TABLES `check_list_item_check_box_definition` WRITE;
/*!40000 ALTER TABLE `check_list_item_check_box_definition` DISABLE KEYS */;
INSERT INTO `check_list_item_check_box_definition` (`id`) VALUES (17),(18),(19),(20),(21),(22),(25),(28),(31),(34),(37),(40),(46),(49),(52),(57),(58),(59),(95),(96),(97),(98),(99),(100);
/*!40000 ALTER TABLE `check_list_item_check_box_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_check_box_info`
--

LOCK TABLES `check_list_item_check_box_info` WRITE;
/*!40000 ALTER TABLE `check_list_item_check_box_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `check_list_item_check_box_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_check_box_info_definition`
--

LOCK TABLES `check_list_item_check_box_info_definition` WRITE;
/*!40000 ALTER TABLE `check_list_item_check_box_info_definition` DISABLE KEYS */;
INSERT INTO `check_list_item_check_box_info_definition` (`info_trigger_type`, `id`) VALUES (0,19),(1,57),(1,58),(1,59);
/*!40000 ALTER TABLE `check_list_item_check_box_info_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_definition`
--

LOCK TABLES `check_list_item_definition` WRITE;
/*!40000 ALTER TABLE `check_list_item_definition` DISABLE KEYS */;
INSERT INTO `check_list_item_definition` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `item_order`, `required`, `check_list_definition_id`) VALUES (1,NULL,1,'Proof of residence not more than 3 months old','\0','Proof of residence',1,'',1),(2,NULL,1,'Presentation letter','\0','Presentation letter',1,'',2),(3,NULL,1,'Chamber of Commerce certificate','\0','Chamber of Commerce certificate',1,'\0',2),(4,NULL,1,'Photocopy of the legal representative\'s legal history','\0','Legal history',1,'\0',2),(5,NULL,1,'Letter of the superintendent\'s inspection','\0','Inspection letter',1,'\0',2),(6,NULL,1,'Financial states to 31 December 2012','\0','Financial states',1,'\0',2),(7,NULL,1,'RUT photocopy','\0','RUT',1,'\0',2),(8,NULL,1,'Photocopy of the legal representative\'s id','\0','Legal representative ID',1,'\0',2),(9,NULL,1,'Portfolio of services and interest rates applied','\0','Services and interest rates',1,'\0',2),(10,NULL,1,'Statuses','\0','Statuses',1,'\0',2),(11,NULL,1,'Photocopy of the accountant\'s id','\0','Accountant ID',1,'\0',2),(12,NULL,1,'Photocopy of the accountant\'s professional card','\0','Accountant professional card',1,'\0',2),(13,NULL,1,'Certificate of the accountant\'s disciplinary history','\0','Accountant disciplinary history',1,'\0',2),(14,NULL,1,'Technical certificate of the software','\0','Software certificate',1,'\0',2),(15,NULL,1,'Bank certificate','\0','Bank certificate',1,'\0',2),(16,NULL,1,'Photocopy of codes granted to the employer','\0','Employer codes',1,'\0',2),(17,NULL,1,'Does the employer save instalments in a queue','\0','Queue instalments',1,'',3),(18,NULL,1,'Does the employer allow third party settlements','\0','Third party settlements',1,'\0',3),(19,NULL,1,'Does the employer make payslips available online','\0','Payslips online',1,'\0',3),(20,NULL,1,'Does the employer keep a payroll deduction contract in the affordability confirmation','\0','Payroll deduction contract',0,'',3),(21,NULL,1,'Does the employer confirm free investment loans','\0','Confirm free investment loans',1,'\0',3),(22,NULL,1,'Does the employer confirm third party settlements','\0','Confirm third party settlements',1,'\0',3),(23,NULL,1,'Certified copy of I.D Document','','ID Document',1,'\0',4),(24,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',4),(25,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',4),(26,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',5),(27,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',5),(28,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',5),(29,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',6),(30,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',6),(31,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',6),(32,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',7),(33,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',7),(34,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',7),(35,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',8),(36,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',8),(37,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',8),(38,NULL,1,'Certified copy of I.D Document','','ID Document',1,'\0',9),(39,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',9),(40,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',9),(41,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',10),(42,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',10),(43,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',10),(44,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',11),(45,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',11),(46,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',11),(47,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',12),(48,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',12),(49,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',12),(50,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',13),(51,NULL,1,'Photocopy of proof of residence','','Proof of residence',1,'\0',13),(52,NULL,1,'Is the phone number confirmed','','Confirm phone number',1,'',13),(53,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',14),(54,NULL,1,'Authorisation Document','','Authorisation Document',1,'\0',15),(55,NULL,1,'Credit Check Document','','Credit Check Document',1,'\0',15),(56,NULL,1,'Employer Response','','Employer Response',1,'\0',16),(57,NULL,1,'Validate client documents and information','','Validate client documents and information',1,'',17),(58,NULL,1,'Confirm referencing','','Confirm referencing',1,'',17),(59,NULL,1,'Loan analysis','','Loan analysis',1,'',17),(60,NULL,1,'Authorisation Document','','Authorisation Document',1,'',18),(61,NULL,1,'Credit Check Document','','Credit Check Document',1,'',18),(62,NULL,1,'Photocopy of I.D Document','','ID Document',1,'\0',19),(63,NULL,1,'Letters of Admission and Retirement from the coop','','Admission Letter',1,'',21),(70,NULL,1,'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella','','3 LIBRANZAS',1,'',1),(71,NULL,1,'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella','','3 PAGARÃ‰S y 1 CARTA DE INSTRUCCIONES AL RESPALDO',2,'',1),(72,NULL,1,'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella','','FORMATO DE SOLICITUD ',3,'',1),(73,NULL,1,'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella','','FORMATO DEBITO AUTOMÃTICO',4,'',1),(74,NULL,1,'Debidamente diligenciado sin tachones ni enmendaduras con firma','','FORMATO SEGURO DE VIDA',5,'',1),(75,NULL,1,'Debidamente diligenciado sin tachones ni enmendaduras con firma y huella','','FORMATO DE LIBRAVAL',6,'',1),(76,NULL,1,'Fotocopia al 150% Con firma y huella','','2 FOTOCOPIAS DE LA CÃ‰DULA',7,'',1),(77,NULL,1,'Con firma y huella','','3 ÃšLTIMOS DESPRENDIBLES DE PAGO',8,'',1),(78,NULL,1,'No mayor a 30 dÃ­as Con firma y huella','','CERTIFICADO LABORAL',9,'',1),(79,NULL,1,'Con firma y huella','','FORMATO DE ACTIVACIÃ“N DE CRÃ‰DITO (COOPMICROCRÃ‰DITO)',10,'\0',1),(81,NULL,1,'Debidamente firmada por el representante legal','','CARTA DE PRESENTACIÃ“N',1,'',2),(82,NULL,1,'Este documento debe estar actualizado','','CERTIFICADO DE CÃMARA DE COMERCIO.',2,'',2),(83,NULL,1,'Este documento debe estar actualizado','','FOTOCOPIA DEL CERTIFICADO DE ANTECEDENTES JUDICIALES DEL REPRESENTANTE LEGAL.',3,'',2),(84,NULL,1,'Este documento debe estar actualizado','','CARTA DE SOMETIMIENTO DE INSPECCIÃ“N DE LA SUPERSOCIEDADES.',4,'',2),(85,NULL,1,'Este documento debe estar actualizado','','ESTADOS FINANCIEROS A 31 DE DICIEMBRE DEL ÃšLTIMO AÃ‘O.',5,'',2),(86,NULL,1,'Este documento debe estar actualizado','','FOTOCOPIA DEL RUT.',6,'',2),(87,NULL,1,'Fotocopia legible al 150% ','','FOTOCOPIA CÃ‰DULA DE CIUDADANÃA REPRESENTANTE LEGAL.',7,'',2),(88,NULL,1,'Este documento debe estar actualizado','','PORTAFOLIO DE SERVICIOS Y TASAS DE INTERÃ‰S APLICADAS.',8,'',2),(89,NULL,1,'Este documento debe estar actualizado','','ESTATUTOS.',9,'',2),(90,NULL,1,'Debidamente firmada por el representante legal','','FOTOCOPIA DE LA CÃ‰DULA DE CIUDADANÃA DEL CONTADOR.',10,'',2),(91,NULL,1,'Fotocopia legible al 150% ','','FOTOCOPIA DE LA TARJETA PROFESIONAL DEL CONTADOR.',11,'',2),(92,NULL,1,'Este documento debe estar actualizado','','CERTIFICADO DE ANTECEDENTES DISCIPLINARIOS DEL CONTADOR.',12,'',2),(93,NULL,1,'Este documento debe estar actualizado no mayor a 30 dÃ­as','','CERTIFICACIÃ“N BANCARIA.',13,'',2),(94,NULL,1,'Fotocopia Legible tamaÃ±o normal','','FOTOCOPIA DE CÃ“DIGOS OTORGADOS A LA EMPRESA.',14,'\0',2),(95,NULL,1,'','','Â¿Al momento de la visacion la pagadurÃ­a se queda con alguna libranza?',1,'\0',3),(96,NULL,1,'','','Â¿La pagadurÃ­a guarda descuentos en cola?',2,'\0',3),(97,NULL,1,'','','Â¿Se visa compra de cartera?',3,'\0',3),(98,NULL,1,'','','Â¿Se consultan desprendibles de nÃ³mina por internet? ',4,'\0',3),(99,NULL,1,'','','Â¿Se visa libre inversiÃ³n?',5,'\0',3),(100,NULL,1,'','','Â¿Se visa compra de cartera?',6,'\0',3),(120,NULL,1,'Signature samples','','Signature Docyment',1,'',30),(104444,NULL,1,'Client details form','','client_details_form',1,'',9),(204444,NULL,1,'Copy of Client Id Document','','client_id_doc',1,'',9);
/*!40000 ALTER TABLE `check_list_item_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_document`
--

LOCK TABLES `check_list_item_document` WRITE;
/*!40000 ALTER TABLE `check_list_item_document` DISABLE KEYS */;
INSERT INTO `check_list_item_document` (`approval_required`, `approved`, `document_reference`, `required_approval_met`, `required_approval_role`, `uploaded`, `id`) VALUES ('\0','','/cms/client/0/document/testSourceClientDoc1-AUTOMATED_TEST_DO_NOT_DELETE.xlsx?action=download','',NULL,NULL,10104444),('\0','','/cms/employer/0/document/testSourceEmployerDoc1-AUTOMATED_TEST_DO_NOT_DELETE.jpg?action=download','',NULL,NULL,20101111),('\0','','/cms/client/0/document/testSourceClientDoc2-AUTOMATED_TEST_DO_NOT_DELETE.pdf?action=download','',NULL,NULL,20104444);
/*!40000 ALTER TABLE `check_list_item_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_document_definition`
--

LOCK TABLES `check_list_item_document_definition` WRITE;
/*!40000 ALTER TABLE `check_list_item_document_definition` DISABLE KEYS */;
INSERT INTO `check_list_item_document_definition` (`approval_required`, `required_approval_role`, `id`) VALUES ('','manager',1),('','accountant',2),('','managing director',3),('\0',NULL,4),('\0',NULL,5),('\0',NULL,6),('\0',NULL,7),('\0',NULL,8),('\0',NULL,9),('\0',NULL,10),('\0',NULL,11),('\0',NULL,12),('\0',NULL,13),('\0',NULL,14),('\0',NULL,15),('\0',NULL,16),('\0',NULL,23),('\0',NULL,24),('\0',NULL,26),('\0',NULL,27),('\0',NULL,29),('\0',NULL,30),('\0',NULL,32),('\0',NULL,33),('\0',NULL,35),('\0',NULL,36),('\0',NULL,38),('\0',NULL,39),('\0',NULL,41),('\0',NULL,42),('\0',NULL,44),('\0',NULL,45),('\0',NULL,47),('\0',NULL,48),('\0',NULL,50),('\0',NULL,51),('\0',NULL,53),('\0',NULL,54),('\0',NULL,55),('\0',NULL,56),('\0',NULL,60),('\0',NULL,61),('\0',NULL,62),('\0',NULL,63),('','manager',70),('','manager',71),('','manager',72),('','manager',73),('','manager',74),('','manager',75),('','manager',76),('','manager',77),('','manager',78),('','manager',79),('','manager',81),('','manager',82),('','manager',83),('','manager',84),('','manager',85),('','manager',86),('','manager',87),('','manager',88),('','manager',89),('','manager',90),('','manager',91),('','manager',92),('','manager',93),('\0',NULL,94),('\0',NULL,120);
/*!40000 ALTER TABLE `check_list_item_document_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_document_history`
--

LOCK TABLES `check_list_item_document_history` WRITE;
/*!40000 ALTER TABLE `check_list_item_document_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `check_list_item_document_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `check_list_item_reason_code`
--

LOCK TABLES `check_list_item_reason_code` WRITE;
/*!40000 ALTER TABLE `check_list_item_reason_code` DISABLE KEYS */;
INSERT INTO `check_list_item_reason_code` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,NULL,1,'Reason 1 description','','Reason 1'),(2,NULL,1,'Reason 2 description','','Reason 2');
/*!40000 ALTER TABLE `check_list_item_reason_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cheque_number_allocation`
--

LOCK TABLES `cheque_number_allocation` WRITE;
/*!40000 ALTER TABLE `cheque_number_allocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `cheque_number_allocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cheque_number_range`
--

LOCK TABLES `cheque_number_range` WRITE;
/*!40000 ALTER TABLE `cheque_number_range` DISABLE KEYS */;
INSERT INTO `cheque_number_range` (`id`, `modified_by`, `version`, `first_number`, `last_number`, `next_available`, `bank_account_id`) VALUES (1,NULL,0,100,199,100,101),(2,NULL,0,100,199,100,102);
/*!40000 ALTER TABLE `cheque_number_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `client_aud`
--

LOCK TABLES `client_aud` WRITE;
/*!40000 ALTER TABLE `client_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `client_credit_bureau_listing`
--

LOCK TABLES `client_credit_bureau_listing` WRITE;
/*!40000 ALTER TABLE `client_credit_bureau_listing` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_credit_bureau_listing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `client_reference`
--

LOCK TABLES `client_reference` WRITE;
/*!40000 ALTER TABLE `client_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `client_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `client_reference_type`
--

LOCK TABLES `client_reference_type` WRITE;
/*!40000 ALTER TABLE `client_reference_type` DISABLE KEYS */;
INSERT INTO `client_reference_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'static',0,'Parent','','parent'),(2,'static',0,'Mother','','mother'),(3,'static',0,'Father','','father');
/*!40000 ALTER TABLE `client_reference_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `commission`
--

LOCK TABLES `commission` WRITE;
/*!40000 ALTER TABLE `commission` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `commission_aud`
--

LOCK TABLES `commission_aud` WRITE;
/*!40000 ALTER TABLE `commission_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `commission_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `commission_payment_schedule_type`
--

LOCK TABLES `commission_payment_schedule_type` WRITE;
/*!40000 ALTER TABLE `commission_payment_schedule_type` DISABLE KEYS */;
INSERT INTO `commission_payment_schedule_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,NULL,0,'Monthly','','monthly'),(2,NULL,0,'Quarterly','','quarterly'),(3,NULL,0,'Biannual','','biannual'),(4,NULL,0,'Annual','','annual'),(5,NULL,0,'linked to deduction payments','','linked_deduction_payments');
/*!40000 ALTER TABLE `commission_payment_schedule_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `commission_structure`
--

LOCK TABLES `commission_structure` WRITE;
/*!40000 ALTER TABLE `commission_structure` DISABLE KEYS */;
INSERT INTO `commission_structure` (`id`, `modified_by`, `version`, `minimum_active_loans`, `per_loan_fixed`, `per_loan_percent_value`, `per_month_fixed`, `per_month_percent_value`, `commission_payment_schedule_type_id`, `deduction_arrangement_relationship_id`) VALUES (2001011,'Colombia',0,1,4000000.00,NULL,NULL,NULL,1,20019101),(2001012,'Colombia',0,1,5000000.00,NULL,NULL,NULL,1,20019102),(2001013,'Colombia',0,5,9648000.00,NULL,NULL,NULL,1,20019103),(2001014,'Colombia',0,5,9280000.00,NULL,NULL,NULL,1,20019104),(2001015,'Colombia',0,2,7500000.00,NULL,NULL,NULL,1,20019105),(2001016,'Colombia',0,2,7500000.00,NULL,NULL,NULL,1,20019106);
/*!40000 ALTER TABLE `commission_structure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `commission_type`
--

LOCK TABLES `commission_type` WRITE;
/*!40000 ALTER TABLE `commission_type` DISABLE KEYS */;
INSERT INTO `commission_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,NULL,0,'team commission','','team_commission'),(2,NULL,0,'individual commission','','individual_commission');
/*!40000 ALTER TABLE `commission_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `confirmation_detail_type`
--

LOCK TABLES `confirmation_detail_type` WRITE;
/*!40000 ALTER TABLE `confirmation_detail_type` DISABLE KEYS */;
INSERT INTO `confirmation_detail_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (0,'102_lookup.sql',0,'Default confirmation detail type','','default_confirmation_detail_type'),(1,'102_lookup.sql',0,'Confirmation detail type One','','confirmation_detail_type_1'),(2,'102_lookup.sql',0,'Confirmation detail type Two','','confirmation_detail_type_2');
/*!40000 ALTER TABLE `confirmation_detail_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `confirmation_detail_type_aud`
--

LOCK TABLES `confirmation_detail_type_aud` WRITE;
/*!40000 ALTER TABLE `confirmation_detail_type_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `confirmation_detail_type_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_number`
--

LOCK TABLES `contact_number` WRITE;
/*!40000 ALTER TABLE `contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_number_type`
--

LOCK TABLES `contact_number_type` WRITE;
/*!40000 ALTER TABLE `contact_number_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`contact_number_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Celular','Celular',1);
INSERT INTO `masterdata`.`contact_number_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Telefono Fijo','Telefono Fijo',1);
INSERT INTO `masterdata`.`contact_number_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'Oficina','Oficina',1);
INSERT INTO `masterdata`.`contact_number_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'Fax','Fax',1);
INSERT INTO `masterdata`.`contact_number_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005',0,'Extensión','Extensión',1);
/*!40000 ALTER TABLE `contact_number_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_role`
--

LOCK TABLES `contact_role` WRITE;
/*!40000 ALTER TABLE `contact_role` DISABLE KEYS */;
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001','0','NINGUNO','NINGUNO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002','0','ABOGADO','ABOGADO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003','0','ANALISTA COMPRA DE CARTERA','ANALISTA COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004','0','ANALISTA CONTABLE','ANALISTA CONTABLE',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005','0','ANALISTA DE CONTROL DE CALIDAD','ANALISTA DE CONTROL DE CALIDAD',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1006','0','ANALISTA DE CREDITO SENIOR','ANALISTA DE CREDITO SENIOR',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1007','0','ANALISTA DE CREDITO','ANALISTA DE CREDITO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1008','0','ANALISTA DE PROYECTOS','ANALISTA DE PROYECTOS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1009','0','ANALISTA JUNIOR DE PROYECTOS','ANALISTA JUNIOR DE PROYECTOS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1010','0','ANALISTA DE RECAUDOS','ANALISTA DE RECAUDOS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1011','0','ANALISTA RH','ANALISTA RH',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1012','0','ASESOR SERVICIO AL CLIENTE','ASESOR SERVICIO AL CLIENTE',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1013','0','ASESOR COMERCIAL','ASESOR COMERCIAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1014','0','AUXILIAR ADMINISTRATIVO','AUXILIAR ADMINISTRATIVO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1015','0','AUXILIAR ARCHIVO','AUXILIAR ARCHIVO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1016','0','AUXILIAR COMERCIAL','AUXILIAR COMERCIAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1017','0','AUXILIAR COMPRAS DE CARTERA','AUXILIAR COMPRAS DE CARTERA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1018','0','AUXILIAR CONTABLE','AUXILIAR CONTABLE',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1019','0','AUXILIAR DE ARCHIVO','AUXILIAR DE ARCHIVO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1020','0','AUXILIAR DE COBRANZAS','AUXILIAR DE COBRANZAS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1021','0','AUXILIAR DE CÓDIGOS','AUXILIAR DE CÓDIGOS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1022','0','AUXILIAR DE INCORPORACIONES','AUXILIAR DE INCORPORACIONES',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1023','0','AUXILIAR DE RECUPERACION','AUXILIAR DE RECUPERACION',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1024','0','AUXILIAR DE REFERENCIACION','AUXILIAR DE REFERENCIACION',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1025','0','AUXILIAR DE SALVAMENTO','AUXILIAR DE SALVAMENTO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1026','0','AUXILIAR DE SERVICIO GENERALES','AUXILIAR DE SERVICIO GENERALES',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1027','0','AUXILIAR DE TESORERIA','AUXILIAR DE TESORERIA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1028','0','AUXILIAR DE VISACION','AUXILIAR DE VISACION',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1029','0','AUXILIAR SERVICIOS GENERALES','AUXILIAR SERVICIOS GENERALES',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1030','0','COODINADORA REGIONAL','COODINADORA REGIONAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1031','0','COORDINADOR ADMINISTRATIVO Y DE COMPRAS','COORDINADOR ADMINISTRATIVO Y DE COMPRAS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1032','0','COORDINADOR COMERCIAL','COORDINADOR COMERCIAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1033','0','COORDINADOR COMERCIAL JUNIOR','COORDINADOR COMERCIAL JUNIOR',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1034','0','COORDINADOR COMERCIAL SENIOR','COORDINADOR COMERCIAL SENIOR',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1035','0','COORDINADOR COMPRA DE CARTERA','COORDINADOR COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1036','0','COORDINADOR DE COBRANZA','COORDINADOR DE COBRANZA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1037','0','COORDINADOR DE CÓDIGOS','COORDINADOR DE CÓDIGOS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1038','0','COORDINADOR DE CREDITO','COORDINADOR DE CREDITO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1039','0','COORDINADOR DE TESORERÍA','COORDINADOR DE TESORERÍA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1040','0','COORDINADOR INCORPORACIONES','COORDINADOR INCORPORACIONES',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1041','0','COORDINADOR INFRAESTRUCTURA','COORDINADOR INFRAESTRUCTURA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1042','0','COORDINADOR IT','COORDINADOR IT',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1043','0','COORDINADOR MERCADO Y PUBLICIDAD','COORDINADOR MERCADO Y PUBLICIDAD',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1044','0','COORDINADOR SENIOR DE PROYECTOS','COORDINADOR SENIOR DE PROYECTOS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1045','0','COORDINADOR SOPORTE A LA OPERACIÓN','COORDINADOR SOPORTE A LA OPERACIÓN',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1046','0','DESARROLLADOR DE NEGOCIOS','DESARROLLADOR DE NEGOCIOS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1047','0','DIRECTOR COMERCIAL REGIONAL','DIRECTOR COMERCIAL REGIONAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1048','0','DIRECTOR CREDITO Y CARTERA','DIRECTOR CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1049','0','DIRECTOR EJECUTIVO','DIRECTOR EJECUTIVO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1050','0','GERENTE CREDITO Y CARTERA','GERENTE CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1051','0','GERENTE DE INCORPORACIONES Y COBRANZAS','GERENTE DE INCORPORACIONES Y COBRANZAS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1052','0','GERENTE GENERAL','GERENTE GENERAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1053','0','GERENTE NACIONAL DE VENTAS','GERENTE NACIONAL DE VENTAS',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1054','0','INGENIERO JUNIOR','INGENIERO JUNIOR',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1055','0','LIDER DE CAPACITACION','LIDER DE CAPACITACION',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1056','0','MANAGEMENT TRAINEE','MANAGEMENT TRAINEE',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1057','0','MENSAJERO','MENSAJERO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1058','0','RECEPCIONISTA','RECEPCIONISTA',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1059','0','SECRETARIA GENERAL','SECRETARIA GENERAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1060','0','SUPERVISOR DE ARCHIVO','SUPERVISOR DE ARCHIVO',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1061','0','VERIFICADOR DOCUMENTAL','VERIFICADOR DOCUMENTAL',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1062','0','DIRECTOR DE OPERACIONES','DIRECTOR DE OPERACIONES',1);
INSERT INTO `masterdata`.`contact_role`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1063','0','DIRECTOR DE SOPORTE','DIRECTOR DE SOPORTE',1);
/*!40000 ALTER TABLE `contact_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `code`, `nationality`, `currency_id`) VALUES (1001,NULL,0,NULL,'','Zambia','ZM','Zambian',1101),(1002,NULL,0,NULL,'','South Africa','ZA','South African',1102),(1003,NULL,0,NULL,'','Uganda','UG','Ugandan',1103),(1004,NULL,0,NULL,'','Kenya','KE','Kenyan',1104),(1005,NULL,0,NULL,'','Ghana','GH','Ghanaian',1105),(1006,NULL,0,NULL,'','Tanzanian','TZ','Tanzanian',1106),(1008,NULL,0,NULL,'','Botswana','BW','Botswanian',1108),(1009,NULL,0,NULL,'','Colombia','CO','Colombian',1109);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `courier_company`
--

LOCK TABLES `courier_company` WRITE;
/*!40000 ALTER TABLE `courier_company` DISABLE KEYS */;
/*!40000 ALTER TABLE `courier_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `credit_bureau`
--

LOCK TABLES `credit_bureau` WRITE;
/*!40000 ALTER TABLE `credit_bureau` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_bureau` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `credit_bureau_status`
--

LOCK TABLES `credit_bureau_status` WRITE;
/*!40000 ALTER TABLE `credit_bureau_status` DISABLE KEYS */;
INSERT INTO `masterdata`.`credit_bureau_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1',0,'Aprobado','Aprobado',1);
INSERT INTO `masterdata`.`credit_bureau_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('2',0,'Rechazado','Rechazado',1);
INSERT INTO `masterdata`.`credit_bureau_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('3',0,'Zona Gris','Zona Gris',1);
INSERT INTO `masterdata`.`credit_bureau_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('4',0,'Verificacion Huellas de consulta','Verificacion Huellas de consulta',1);
/*!40000 ALTER TABLE `credit_bureau_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `credit_bureau_status_aud`
--

LOCK TABLES `credit_bureau_status_aud` WRITE;
/*!40000 ALTER TABLE `credit_bureau_status_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_bureau_status_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `credit_reference`
--

LOCK TABLES `credit_reference` WRITE;
/*!40000 ALTER TABLE `credit_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `credit_reference_aud`
--

LOCK TABLES `credit_reference_aud` WRITE;
/*!40000 ALTER TABLE `credit_reference_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `credit_reference_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `code`) VALUES (1101,NULL,0,NULL,NULL,'Zambian Kwacha','ZMK'),(1102,NULL,0,NULL,NULL,'South African Rand','ZAR'),(1103,NULL,0,NULL,NULL,'Ugandan Shilling','UGX'),(1104,NULL,0,NULL,NULL,'Kenyan Shilling','KES'),(1105,NULL,0,NULL,NULL,'Ghanaian Cedi','GHC'),(1106,NULL,0,NULL,NULL,'Tanzanian Shilling','TZS'),(1108,NULL,0,NULL,NULL,'Botswana Pula','BWP'),(1109,NULL,0,NULL,NULL,'Colombia Peso','COP');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `custom_field`
--

LOCK TABLES `custom_field` WRITE;
/*!40000 ALTER TABLE `custom_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `custom_field_definition`
--

LOCK TABLES `custom_field_definition` WRITE;
/*!40000 ALTER TABLE `custom_field_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_field_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_arrangement_relationship`
--

LOCK TABLES `deduction_arrangement_relationship` WRITE;
/*!40000 ALTER TABLE `deduction_arrangement_relationship` DISABLE KEYS */;
INSERT INTO `deduction_arrangement_relationship` (`id`) VALUES (20019101),(20019102),(20019103),(20019104),(20019105),(20019106);
/*!40000 ALTER TABLE `deduction_arrangement_relationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_authorisation`
--

LOCK TABLES `deduction_authorisation` WRITE;
/*!40000 ALTER TABLE `deduction_authorisation` DISABLE KEYS */;
INSERT INTO `deduction_authorisation` (`id`, `modified_by`, `version`, `auth_centralised`, `does_submission`, `employer_auth_required`, `gives_affordability`, `set_aside`, `signature_document`, `verifies_labour_information`, `deduction_arrangement_relationship_id`) VALUES (2001910101,'colombia',0,'','','\0','','','document 123','\0',20019101),(2001910102,'colombia',0,'','','','','','document 123','\0',20019102),(2001910103,'colombia',0,'','','','','','document 123','\0',20019103),(2001910104,'colombia',0,'','','','','','document 123','\0',20019104),(2001910105,'colombia',0,'','','','','','document 123','\0',20019105),(2001910106,'colombia',0,'','','','','','document 123','\0',20019106);
/*!40000 ALTER TABLE `deduction_authorisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_configuration`
--

LOCK TABLES `deduction_configuration` WRITE;
/*!40000 ALTER TABLE `deduction_configuration` DISABLE KEYS */;
INSERT INTO `deduction_configuration` (`id`, `modified_by`, `version`, `account`, `bank`, `day_in_period_payment_due`, `day_in_period_submissions_due`, `deduction_frequency`, `errors_delivered`, `errors_delivery_day`, `errors_delivery_method`, `errors_digital_format`, `errors_email_address`, `payment_means`, `receipting_delivery_method`, `submissions_delivery_method`, `submissions_digital_format`, `submissions_email_address`, `deduction_arrangement_relationship_id`, `minimum_takehome_amount`, `takehome_eligibility_amount`) VALUES (200151,'Colombia',0,'account-1111','bank-1',2,1,'Weekly','',3,'Digital','Email','errors@200151.com','EFT','Physical','Digital','Email','submissions@200151.com',20019101,3000000,3000000),(200152,'Colombia',0,'account-2222','bank-2',2,1,'Fortnightly','',3,'Digital','Email','errors@200152.com','CHEQUE','Physical','Digital','CD',NULL,20019102,3000000,3000000),(200153,'Colombia',0,'account-3333','bank-3',2,1,'Monthly','',3,'Digital','Email','errors@200153.com','EFT','Physical','Digital','USB',NULL,20019103,3000000,3000000),(200154,'Colombia',0,'account-4444','bank-4',2,1,'Weekly','\0',3,'Digital','Email','errors@200154.com','EFT','Physical','Digital','Email','submissions@200154.com',20019104,3000000,3000000),(200155,'Colombia',0,'account-5555','bank-5',2,1,'Fortnightly','',3,'Digital','Email','errors@200155.com','CHEQUE','Physical','Digital','Diskette',NULL,20019105,3000000,3000000),(200156,'Colombia',0,'account-5555','bank-5',2,1,'Fortnightly','',3,'Digital','Email','errors@200155.com','CHEQUE','Physical','Digital','Diskette',NULL,20019106,3000000,3000000);
/*!40000 ALTER TABLE `deduction_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_configuration_supporting_checklist`
--

LOCK TABLES `deduction_configuration_supporting_checklist` WRITE;
/*!40000 ALTER TABLE `deduction_configuration_supporting_checklist` DISABLE KEYS */;
INSERT INTO `deduction_configuration_supporting_checklist` (`id`, `modified_by`, `version`, `expected_target`, `name`, `deduction_configuration_id`) VALUES (1111,'112_documentpack.sql',0,'Employer','employerApplication',200151),(1112,'112_documentpack.sql',0,'LoanApplication','employerOrigination',200151);
/*!40000 ALTER TABLE `deduction_configuration_supporting_checklist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `deduction_configuration_supporting_document`
--

LOCK TABLES `deduction_configuration_supporting_document` WRITE;
/*!40000 ALTER TABLE `deduction_configuration_supporting_document` DISABLE KEYS */;
INSERT INTO `deduction_configuration_supporting_document` (`id`, `modified_by`, `version`, `enabled`, `line_item_definition_id`, `name`, `required`, `deduction_configuration_supporting_checklist_id`, `deduction_configuration_id`) VALUES (101111,'112_documentpack.sql',0,'',2,'supporting item name 101111','',1111,200151),(101112,'112_documentpack.sql',0,'',104444,'supporting item name 101112','',1112,200151),(201112,'112_documentpack.sql',0,'',204444,'supporting item name 101112','',1112,200151);
/*!40000 ALTER TABLE `deduction_configuration_supporting_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement_detail`
--

LOCK TABLES `disbursement_detail` WRITE;
/*!40000 ALTER TABLE `disbursement_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `disbursement_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement_detail_aud`
--

LOCK TABLES `disbursement_detail_aud` WRITE;
/*!40000 ALTER TABLE `disbursement_detail_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `disbursement_detail_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement_type`
--

LOCK TABLES `disbursement_type` WRITE;
/*!40000 ALTER TABLE `disbursement_type` DISABLE KEYS */;
INSERT INTO `disbursement_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'102_lookups.sql',0,'Cash',NULL,'Cash'),(2,'102_lookups.sql',0,'EFT',NULL,'EFT'),(4,'102_lookups.sql',0,'Refinance',NULL,'Refinance'),(5,'102_lookups.sql',0,'ThirdPartyManaged',NULL,'ThirdPartyManaged'),(6,'102_lookups.sql',0,'SpecialDisbursement',NULL,'SpecialDisbursement');
/*!40000 ALTER TABLE `disbursement_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `disbursement_type_aud`
--

LOCK TABLES `disbursement_type_aud` WRITE;
/*!40000 ALTER TABLE `disbursement_type_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `disbursement_type_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `division`
--

LOCK TABLES `division` WRITE;
/*!40000 ALTER TABLE `division` DISABLE KEYS */;
/*!40000 ALTER TABLE `division` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `document_type`
--

LOCK TABLES `document_type` WRITE;
/*!40000 ALTER TABLE `document_type` DISABLE KEYS */;
INSERT INTO `document_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'102_lookups.sql',0,NULL,NULL,'BankStatement'),(2,'102_lookups.sql',0,NULL,NULL,'DriversLicence'),(3,'102_lookups.sql',0,NULL,NULL,'IdDocument'),(4,'102_lookups.sql',0,NULL,NULL,'IdPhoto'),(5,'102_lookups.sql',0,NULL,NULL,'LoanContract'),(6,'102_lookups.sql',0,NULL,NULL,'MarriageCertificate'),(7,'102_lookups.sql',0,NULL,NULL,'Payslip'),(8,'102_lookups.sql',0,NULL,NULL,'SupportingLetter');
/*!40000 ALTER TABLE `document_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `dto_to_class_binding`
--

LOCK TABLES `dto_to_class_binding` WRITE;
/*!40000 ALTER TABLE `dto_to_class_binding` DISABLE KEYS */;
INSERT INTO `dto_to_class_binding` (`id`, `modified_by`, `version`, `class_name`, `dto_name`, `relevant_entity_name`) VALUES (1,NULL,0,'com.qualica.flexifin.masterdata.domain.application.AccountApplication','com.qualica.flexifin.masterdata.shared.dto.AccountApplicationDTO','com.qualica.flexifin.masterdata.domain.Note'),(2,NULL,0,'com.qualica.flexifin.masterdata.domain.role.PayrollDeductionClient','com.qualica.flexifin.masterdata.shared.dto.PayrollDeductionClientDTO','com.qualica.flexifin.masterdata.domain.Note'),(3,NULL,0,'com.qualica.flexifin.masterdata.domain.application.EmployerApplication','com.qualica.flexifin.masterdata.shared.dto.EmployerApplicationDTO','com.qualica.flexifin.masterdata.domain.Note'),(4,NULL,0,'com.qualica.flexifin.masterdata.domain.application.Recovery','com.qualica.flexifin.masterdata.shared.dto.RecoveryDTO','com.qualica.flexifin.masterdata.domain.Note');
/*!40000 ALTER TABLE `dto_to_class_binding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `education_level`
--

LOCK TABLES `education_level` WRITE;
/*!40000 ALTER TABLE `education_level` DISABLE KEYS */;
INSERT INTO `masterdata`.`education_level`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Ninguno','Ninguno',1);
INSERT INTO `masterdata`.`education_level`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Primaria','Primaria',1);
INSERT INTO `masterdata`.`education_level`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'Secundaria','Secundaria',1);
INSERT INTO `masterdata`.`education_level`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'Tecnica','Tecnica',1);
INSERT INTO `masterdata`.`education_level`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005',0,'Tecnologica','Tecnologica',1);
INSERT INTO `masterdata`.`education_level`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1006',0,'Profesional','Profesional',1);
/*!40000 ALTER TABLE `education_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `email_address`
--

LOCK TABLES `email_address` WRITE;
/*!40000 ALTER TABLE `email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer`
--

LOCK TABLES `employer` WRITE;
/*!40000 ALTER TABLE `employer` DISABLE KEYS */;
/*!40000 ALTER TABLE `employer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer_application`
--

LOCK TABLES `employer_application` WRITE;
/*!40000 ALTER TABLE `employer_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `employer_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer_application_aud`
--

LOCK TABLES `employer_application_aud` WRITE;
/*!40000 ALTER TABLE `employer_application_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `employer_application_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer_application_status_reason`
--

LOCK TABLES `employer_application_status_reason` WRITE;
/*!40000 ALTER TABLE `employer_application_status_reason` DISABLE KEYS */;
INSERT INTO `employer_application_status_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (0,'static',0,'No reason code set','','unset'),(1,'static',0,'default rejection reason','','rejected_default');
/*!40000 ALTER TABLE `employer_application_status_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer_application_status_reason_aud`
--

LOCK TABLES `employer_application_status_reason_aud` WRITE;
/*!40000 ALTER TABLE `employer_application_status_reason_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `employer_application_status_reason_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer_deduction_code`
--

LOCK TABLES `employer_deduction_code` WRITE;
/*!40000 ALTER TABLE `employer_deduction_code` DISABLE KEYS */;
INSERT INTO `employer_deduction_code` (`id`, `modified_by`, `version`, `end_date`, `issue_date`, `start_date`, `validity_status`, `validity_type`, `deduction_arrangement_relationship_id`) VALUES (2001910151,'colombia',0,'2015-09-24 00:00:00','2012-09-24 00:00:00','2012-09-24 00:00:00','ACTIVE','LIMITED',20019101),(2001910152,'colombia',0,'2015-09-24 00:00:00','2012-09-24 00:00:00','2012-09-24 00:00:00','ACTIVE','LIMITED',20019102),(2001910153,'colombia',0,'2015-09-24 00:00:00','2012-09-24 00:00:00','2012-09-24 00:00:00','ACTIVE','LIMITED',20019103),(2001910154,'colombia',0,'2015-09-24 00:00:00','2012-09-24 00:00:00','2012-09-24 00:00:00','ACTIVE','LIMITED',20019104),(2001910155,'colombia',0,'2015-09-24 00:00:00','2012-09-24 00:00:00','2012-09-24 00:00:00','ACTIVE','LIMITED',20019105),(2001910156,'colombia',0,'2015-09-24 00:00:00','2012-09-24 00:00:00','2012-09-24 00:00:00','ACTIVE','LIMITED',20019106);
/*!40000 ALTER TABLE `employer_deduction_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employer_type`
--

LOCK TABLES `employer_type` WRITE;
/*!40000 ALTER TABLE `employer_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`employer_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Privada','Privada',1);
INSERT INTO `masterdata`.`employer_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Publica','Publica',1);
/*!40000 ALTER TABLE `employer_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `employment`
--

LOCK TABLES `employment` WRITE;
/*!40000 ALTER TABLE `employment` DISABLE KEYS */;
/*!40000 ALTER TABLE `employment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `financial_institution`
--

LOCK TABLES `financial_institution` WRITE;
/*!40000 ALTER TABLE `financial_institution` DISABLE KEYS */;
/*!40000 ALTER TABLE `financial_institution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `first_instalment_schedule`
--

LOCK TABLES `first_instalment_schedule` WRITE;
/*!40000 ALTER TABLE `first_instalment_schedule` DISABLE KEYS */;
/*!40000 ALTER TABLE `first_instalment_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fixed_term_loan_application`
--

LOCK TABLES `fixed_term_loan_application` WRITE;
/*!40000 ALTER TABLE `fixed_term_loan_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_term_loan_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `fixed_term_loan_application_aud`
--

LOCK TABLES `fixed_term_loan_application_aud` WRITE;
/*!40000 ALTER TABLE `fixed_term_loan_application_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `fixed_term_loan_application_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `gender`
--

LOCK TABLES `gender` WRITE;
/*!40000 ALTER TABLE `gender` DISABLE KEYS */;
INSERT INTO `masterdata`.`gender`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Masculino','Masculino',1);
INSERT INTO `masterdata`.`gender`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Femenino','Femenino',1);
/*!40000 ALTER TABLE `gender` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `guarantor`
--

LOCK TABLES `guarantor` WRITE;
/*!40000 ALTER TABLE `guarantor` DISABLE KEYS */;
/*!40000 ALTER TABLE `guarantor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `guarantor_aud`
--

LOCK TABLES `guarantor_aud` WRITE;
/*!40000 ALTER TABLE `guarantor_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `guarantor_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `hibernate_sequences`
--

LOCK TABLES `hibernate_sequences` WRITE;
/*!40000 ALTER TABLE `hibernate_sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `hibernate_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `id_type`
--

LOCK TABLES `id_type` WRITE;
/*!40000 ALTER TABLE `id_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`id_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Cedula de Ciudadania','Cedula de Ciudadania',1);
INSERT INTO `masterdata`.`id_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Cedula de Extranjeria','Cedula de Extranjeria',1);
/*!40000 ALTER TABLE `id_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `industry`
--

LOCK TABLES `industry` WRITE;
/*!40000 ALTER TABLE `industry` DISABLE KEYS */;
INSERT INTO `masterdata`.`industry`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Comercialización','Comercialización',1);
INSERT INTO `masterdata`.`industry`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Militar','Militar',1);
INSERT INTO `masterdata`.`industry`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'Pensión','Pensión',1);
INSERT INTO `masterdata`.`industry`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'Producción','Producción',1);
INSERT INTO `masterdata`.`industry`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005',0,'Servicios','Servicios',1);
/*!40000 ALTER TABLE `industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `instrumentation`
--

LOCK TABLES `instrumentation` WRITE;
/*!40000 ALTER TABLE `instrumentation` DISABLE KEYS */;
/*!40000 ALTER TABLE `instrumentation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `job_position`
--

LOCK TABLES `job_position` WRITE;
/*!40000 ALTER TABLE `job_position` DISABLE KEYS */;
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001','0','NINGUNO','NINGUNO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002','0','ABOGADO','ABOGADO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003','0','ANALISTA COMPRA DE CARTERA','ANALISTA COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004','0','ANALISTA CONTABLE','ANALISTA CONTABLE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005','0','ANALISTA DE CONTROL DE CALIDAD','ANALISTA DE CONTROL DE CALIDAD',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1006','0','ANALISTA DE CREDITO SENIOR','ANALISTA DE CREDITO SENIOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1007','0','ANALISTA DE CREDITO','ANALISTA DE CREDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1008','0','ANALISTA DE PROYECTOS','ANALISTA DE PROYECTOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1009','0','ANALISTA JUNIOR DE PROYECTOS','ANALISTA JUNIOR DE PROYECTOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1010','0','ANALISTA DE RECAUDOS','ANALISTA DE RECAUDOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1011','0','ANALISTA RH','ANALISTA RH',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1012','0','ASESOR SERVICIO AL CLIENTE','ASESOR SERVICIO AL CLIENTE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1013','0','ASESOR COMERCIAL','ASESOR COMERCIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1014','0','AUXILIAR ADMINISTRATIVO','AUXILIAR ADMINISTRATIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1015','0','AUXILIAR ARCHIVO','AUXILIAR ARCHIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1016','0','AUXILIAR COMERCIAL','AUXILIAR COMERCIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1017','0','AUXILIAR COMPRAS DE CARTERA','AUXILIAR COMPRAS DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1018','0','AUXILIAR CONTABLE','AUXILIAR CONTABLE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1019','0','AUXILIAR DE ARCHIVO','AUXILIAR DE ARCHIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1020','0','AUXILIAR DE COBRANZAS','AUXILIAR DE COBRANZAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1021','0','AUXILIAR DE CÓDIGOS','AUXILIAR DE CÓDIGOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1022','0','AUXILIAR DE INCORPORACIONES','AUXILIAR DE INCORPORACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1023','0','AUXILIAR DE RECUPERACION','AUXILIAR DE RECUPERACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1024','0','AUXILIAR DE REFERENCIACION','AUXILIAR DE REFERENCIACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1025','0','AUXILIAR DE SALVAMENTO','AUXILIAR DE SALVAMENTO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1026','0','AUXILIAR DE SERVICIO GENERALES','AUXILIAR DE SERVICIO GENERALES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1027','0','AUXILIAR DE TESORERIA','AUXILIAR DE TESORERIA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1028','0','AUXILIAR DE VISACION','AUXILIAR DE VISACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1029','0','AUXILIAR SERVICIOS GENERALES','AUXILIAR SERVICIOS GENERALES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1030','0','COODINADORA REGIONAL','COODINADORA REGIONAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1031','0','COORDINADOR ADMINISTRATIVO Y DE COMPRAS','COORDINADOR ADMINISTRATIVO Y DE COMPRAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1032','0','COORDINADOR COMERCIAL','COORDINADOR COMERCIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1033','0','COORDINADOR COMERCIAL JUNIOR','COORDINADOR COMERCIAL JUNIOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1034','0','COORDINADOR COMERCIAL SENIOR','COORDINADOR COMERCIAL SENIOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1035','0','COORDINADOR COMPRA DE CARTERA','COORDINADOR COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1036','0','COORDINADOR DE COBRANZA','COORDINADOR DE COBRANZA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1037','0','COORDINADOR DE CÓDIGOS','COORDINADOR DE CÓDIGOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1038','0','COORDINADOR DE CREDITO','COORDINADOR DE CREDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1039','0','COORDINADOR DE TESORERÍA','COORDINADOR DE TESORERÍA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1040','0','COORDINADOR INCORPORACIONES','COORDINADOR INCORPORACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1041','0','COORDINADOR INFRAESTRUCTURA','COORDINADOR INFRAESTRUCTURA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1042','0','COORDINADOR IT','COORDINADOR IT',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1043','0','COORDINADOR MERCADO Y PUBLICIDAD','COORDINADOR MERCADO Y PUBLICIDAD',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1044','0','COORDINADOR SENIOR DE PROYECTOS','COORDINADOR SENIOR DE PROYECTOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1045','0','COORDINADOR SOPORTE A LA OPERACIÓN','COORDINADOR SOPORTE A LA OPERACIÓN',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1046','0','DESARROLLADOR DE NEGOCIOS','DESARROLLADOR DE NEGOCIOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1047','0','DIRECTOR COMERCIAL REGIONAL','DIRECTOR COMERCIAL REGIONAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1048','0','DIRECTOR CREDITO Y CARTERA','DIRECTOR CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1049','0','DIRECTOR EJECUTIVO','DIRECTOR EJECUTIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1050','0','GERENTE CREDITO Y CARTERA','GERENTE CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1051','0','GERENTE DE INCORPORACIONES Y COBRANZAS','GERENTE DE INCORPORACIONES Y COBRANZAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1052','0','GERENTE GENERAL','GERENTE GENERAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1053','0','GERENTE NACIONAL DE VENTAS','GERENTE NACIONAL DE VENTAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1054','0','INGENIERO JUNIOR','INGENIERO JUNIOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1055','0','LIDER DE CAPACITACION','LIDER DE CAPACITACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1056','0','MANAGEMENT TRAINEE','MANAGEMENT TRAINEE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1057','0','MENSAJERO','MENSAJERO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1058','0','RECEPCIONISTA','RECEPCIONISTA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1059','0','SECRETARIA GENERAL','SECRETARIA GENERAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1060','0','SUPERVISOR DE ARCHIVO','SUPERVISOR DE ARCHIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1061','0','VERIFICADOR DOCUMENTAL','VERIFICADOR DOCUMENTAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1062','0','DIRECTOR DE OPERACIONES','DIRECTOR DE OPERACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1063','0','DIRECTOR DE SOPORTE','DIRECTOR DE SOPORTE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1064','0','ANALISTA SENIOR DE REPORTES','ANALISTA SENIOR DE REPORTES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1065','0','DIRECTOR FINANCIERO','DIRECTOR FINANCIERO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1066','0','AUXILIAR DE CRÉDITO','AUXILIAR DE CRÉDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1067','0','SERVICE DESK OPERATOR','SERVICE DESK OPERATOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1068','0','COORDINADOR DE CARTERA','COORDINADOR DE CARTERA',1);
/*!40000 ALTER TABLE `job_position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `labour_environment`
--

LOCK TABLES `labour_environment` WRITE;
/*!40000 ALTER TABLE `labour_environment` DISABLE KEYS */;
/*!40000 ALTER TABLE `labour_environment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `lawyer`
--

LOCK TABLES `lawyer` WRITE;
/*!40000 ALTER TABLE `lawyer` DISABLE KEYS */;
/*!40000 ALTER TABLE `lawyer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `lending_arrangement_relationship`
--

LOCK TABLES `lending_arrangement_relationship` WRITE;
/*!40000 ALTER TABLE `lending_arrangement_relationship` DISABLE KEYS */;
/*!40000 ALTER TABLE `lending_arrangement_relationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_application`
--

LOCK TABLES `loan_application` WRITE;
/*!40000 ALTER TABLE `loan_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_application_aud`
--

LOCK TABLES `loan_application_aud` WRITE;
/*!40000 ALTER TABLE `loan_application_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_application_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_duration`
--

LOCK TABLES `loan_duration` WRITE;
/*!40000 ALTER TABLE `loan_duration` DISABLE KEYS */;
INSERT INTO `loan_duration` (`id`, `modified_by`, `version`, `duration`, `loan_duration_type_id`) VALUES (5515,'import_test_documentPack',0,12,2),(5538,'import_test_documentPack',0,12,2);
/*!40000 ALTER TABLE `loan_duration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_duration_aud`
--

LOCK TABLES `loan_duration_aud` WRITE;
/*!40000 ALTER TABLE `loan_duration_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_duration_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_duration_type`
--

LOCK TABLES `loan_duration_type` WRITE;
/*!40000 ALTER TABLE `loan_duration_type` DISABLE KEYS */;
INSERT INTO `loan_duration_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'102_lookups.sql',0,'Days',NULL,'Days'),(2,'102_lookups.sql',0,'Months',NULL,'Months');
/*!40000 ALTER TABLE `loan_duration_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_duration_type_aud`
--

LOCK TABLES `loan_duration_type_aud` WRITE;
/*!40000 ALTER TABLE `loan_duration_type_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_duration_type_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `loan_guarantee_relationship`
--

LOCK TABLES `loan_guarantee_relationship` WRITE;
/*!40000 ALTER TABLE `loan_guarantee_relationship` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan_guarantee_relationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `lookup_index`
--

LOCK TABLES `lookup_index` WRITE;
/*!40000 ALTER TABLE `lookup_index` DISABLE KEYS */;
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`) VALUES (1,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.Country','Country',NULL,NULL),(2,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.Region','Region','country',1),(3,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.AddressType','AddressType',NULL,NULL),(4,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.Title','Title',NULL,NULL),(5,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.Occupation','Occupation',NULL,NULL),(6,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.ResidentStatus','ResidentStatus',NULL,NULL),(7,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.ResidenceType','ResidenceType',NULL,NULL),(8,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.City','City','region',2),(9,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.ContactNumberType','ContactNumberType',NULL,NULL),(10,'sameer',0,'com.qualica.flexifin.masterdata.domain.ContactRole','ContactRole',NULL,NULL),(11,'sameer',0,'com.qualica.flexifin.masterdata.domain.CreditBureauStatus','CreditBureauStatus',NULL,NULL),(12,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.EducationLevel','EducationLevel',NULL,NULL),(13,'sameer',0,'com.qualica.flexifin.masterdata.domain.application.EmployerApplicationStatusReason','EmployerApplicationStatusReason',NULL,NULL),(14,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.EmployerType','EmployerType',NULL,NULL),(15,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.Gender','Gender',NULL,NULL),(16,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.IdType','IdType',NULL,NULL),(17,'sameer',0,'com.qualica.flexifin.masterdata.domain.Industry','Industry',NULL,NULL),(18,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.MaritalStatus','MaritalStatus',NULL,NULL),(19,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.OccupationStatus','OccupationStatus',NULL,NULL),(20,'sameer',0,'com.qualica.flexifin.masterdata.domain.PayslipLineItemType','PayslipLineItemType',NULL,NULL),(21,'sameer',0,'com.qualica.flexifin.masterdata.domain.application.RecoveryResults','RecoveryResults',NULL,NULL),(22,'sameer',0,'com.qualica.flexifin.masterdata.domain.JobPosition','JobPosition',NULL,NULL),(27,'sameer',0,'com.qualica.flexifin.masterdata.domain.role.ClientReferenceType','ClientReferenceType',NULL,NULL),(29,'sameer',0,'com.qualica.flexifin.masterdata.domain.CheckListItemReasonCode','CheckListItemReasonCode',NULL,NULL),(30,'sameer',0,'com.qualica.flexifin.masterdata.domain.CommissionPaymentScheduleType','CommissionPaymentScheduleType',NULL,NULL),(31,'sameer',0,'com.qualica.flexifin.masterdata.domain.CommissionType','CommissionType',NULL,NULL),(32,'sameer',0,'com.qualica.flexifin.masterdata.domain.application.ConfirmationDetailType','ConfirmationDetailType',NULL,NULL),(33,'sameer',0,'com.qualica.flexifin.masterdata.domain.application.ApplicationApprovalStatus','ApplicationApprovalStatus',NULL,NULL),(34,'sameer',0,'com.qualica.flexifin.masterdata.domain.application.ApplicationStatusReason','ApplicationStatusReason',NULL,NULL),(35,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.BankAccountType','BankAccountType',NULL,NULL),(36,'sameer',0,'com.qualica.flexifin.masterdata.domain.core.BankType','BankType',NULL,NULL),(37,'102_lookups.sql',0,'com.qualica.flexifin.masterdata.domain.DocumentType','DocumentType',NULL,NULL),(38,'sharad',0,'com.qualica.flexifin.masterdata.domain.role.CreditBureau','CreditBureau',NULL,NULL),(39,'sharad',0,'com.qualica.flexifin.masterdata.domain.role.CourierCompany','CourierCompany',NULL,NULL),(40,'sharad',0,'com.qualica.flexifin.masterdata.domain.role.VisitingAgent','VisitingAgent',NULL,NULL),(41,'sharad',0,'com.qualica.flexifin.masterdata.domain.role.Lawyer','Lawyer',NULL,NULL);
/*!40000 ALTER TABLE `lookup_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `marital_status`
--

LOCK TABLES `marital_status` WRITE;
/*!40000 ALTER TABLE `marital_status` DISABLE KEYS */;
INSERT INTO `masterdata`.`marital_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'soltero','soltero',1);
INSERT INTO `masterdata`.`marital_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'casado','casado',1);
INSERT INTO `masterdata`.`marital_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'viudo','viudo',1);
INSERT INTO `masterdata`.`marital_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'divorciado','divorciado',1);
INSERT INTO `masterdata`.`marital_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005',0,'union libre','union libre',1);
/*!40000 ALTER TABLE `marital_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `occupation`
--

LOCK TABLES `occupation` WRITE;
/*!40000 ALTER TABLE `occupation` DISABLE KEYS */;
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Empleado','Empleado',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Independiente','Independiente',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'No Aplica','No Aplica',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'Pensionado','Pensionado',1);
/*!40000 ALTER TABLE `occupation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `occupation_status`
--

LOCK TABLES `occupation_status` WRITE;
/*!40000 ALTER TABLE `occupation_status` DISABLE KEYS */;
INSERT INTO `masterdata`.`occupation_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Empleado','Empleado',1);
INSERT INTO `masterdata`.`occupation_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Pensionado','Pensionado',1);
/*!40000 ALTER TABLE `occupation_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `organisation`
--

LOCK TABLES `organisation` WRITE;
/*!40000 ALTER TABLE `organisation` DISABLE KEYS */;
INSERT INTO `organisation` (`name`, `registration_number`, `sales_tax_number`, `tax_number`, `id`) VALUES ('Bayport','10','1000','100',1000),('CoopMicrocredito','10','1000','100',1001);
/*!40000 ALTER TABLE `organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `organisation_role`
--

LOCK TABLES `organisation_role` WRITE;
/*!40000 ALTER TABLE `organisation_role` DISABLE KEYS */;
INSERT INTO `organisation_role` (`id`) VALUES (2000),(2001);
/*!40000 ALTER TABLE `organisation_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `organisation_role_aud`
--

LOCK TABLES `organisation_role_aud` WRITE;
/*!40000 ALTER TABLE `organisation_role_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `organisation_role_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `organisation_unit`
--

LOCK TABLES `organisation_unit` WRITE;
/*!40000 ALTER TABLE `organisation_unit` DISABLE KEYS */;
/*!40000 ALTER TABLE `organisation_unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `organisation_unit_aud`
--

LOCK TABLES `organisation_unit_aud` WRITE;
/*!40000 ALTER TABLE `organisation_unit_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `organisation_unit_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `outlet`
--

LOCK TABLES `outlet` WRITE;
/*!40000 ALTER TABLE `outlet` DISABLE KEYS */;
/*!40000 ALTER TABLE `outlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `outlet_aud`
--

LOCK TABLES `outlet_aud` WRITE;
/*!40000 ALTER TABLE `outlet_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `outlet_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `packed_document`
--

LOCK TABLES `packed_document` WRITE;
/*!40000 ALTER TABLE `packed_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `packed_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `parent_organisation`
--

LOCK TABLES `parent_organisation` WRITE;
/*!40000 ALTER TABLE `parent_organisation` DISABLE KEYS */;
/*!40000 ALTER TABLE `parent_organisation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party`
--

LOCK TABLES `party` WRITE;
/*!40000 ALTER TABLE `party` DISABLE KEYS */;
INSERT INTO `party` (`id`, `modified_by`, `version`) VALUES (1000,NULL,0),(1001,'102_static_update_0070_multientity.sql',0);
/*!40000 ALTER TABLE `party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_address`
--

LOCK TABLES `party_address` WRITE;
/*!40000 ALTER TABLE `party_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_contact_number`
--

LOCK TABLES `party_contact_number` WRITE;
/*!40000 ALTER TABLE `party_contact_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_contact_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_email_address`
--

LOCK TABLES `party_email_address` WRITE;
/*!40000 ALTER TABLE `party_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_relationship`
--

LOCK TABLES `party_relationship` WRITE;
/*!40000 ALTER TABLE `party_relationship` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_relationship` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_relationship_type`
--

LOCK TABLES `party_relationship_type` WRITE;
/*!40000 ALTER TABLE `party_relationship_type` DISABLE KEYS */;
INSERT INTO `party_relationship_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `role_type_id_from`, `role_type_id_to`) VALUES (901,'Colombia',0,'Agent of Employer',NULL,'agent',501,10001),(902,'Colombia',0,'Key Contact',NULL,'contact',501,921),(903,'Colombia',0,'Union Rep',NULL,'unionRep',501,931),(904,'Colombia',0,'client_reference',NULL,'client_reference',10006,10007),(905,'Colombia',0,'employment',NULL,'employment',501,10009),(906,'Colombia',0,'Branch agent belong to',NULL,'belongs_to_outlet',10005,10001),(907,'Colombia',0,'Agent team members',NULL,'team_member',10001,10001),(908,'Colombia',0,'Agent report to',NULL,'reports_to',10001,10001),(910,'Colombia',0,'TradingEntity to Employer',NULL,'deductionArrangementWithEmployer',500,501),(911,'Colombia',0,'Guarantee the loan',NULL,'guarantee',10012,10006),(912,'Colombia',0,'LendingEntity to Employer',NULL,'LendingArrangement',500,501);
/*!40000 ALTER TABLE `party_relationship_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_role`
--

LOCK TABLES `party_role` WRITE;
/*!40000 ALTER TABLE `party_role` DISABLE KEYS */;
INSERT INTO `party_role` (`id`, `modified_by`, `version`, `from_date`, `to_date`, `party_id`, `role_type_id`)  VALUES (2000,'employer_testdata.xml',0,'2012-01-01 00:00:00',NULL,1000,500),  (2001,'102_static_update_0070_multientity.sql',0,'2012-01-01 00:00:00',NULL,1001,500);
/*!40000 ALTER TABLE `party_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_role_aud`
--

LOCK TABLES `party_role_aud` WRITE;
/*!40000 ALTER TABLE `party_role_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `party_role_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `party_role_type`
--

LOCK TABLES `party_role_type` WRITE;
/*!40000 ALTER TABLE `party_role_type` DISABLE KEYS */;
INSERT INTO `party_role_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (500,NULL,0,'Trading Entity','','Trading Entity'),(501,NULL,0,'employer','','employer'),(502,NULL,0,'division','','division'),(503,NULL,0,'parent_organisation','','parent_organisation'),(921,NULL,0,'key_contact','','key_contact'),(931,NULL,0,'union_rep','','union_rep'),(10001,NULL,0,'agent','','agent'),(10003,NULL,0,'user','','user'),(10004,NULL,0,'bank','','bank'),(10005,NULL,0,'outlet','','outlet'),(10006,NULL,0,'pdclient','','pdclient'),(10007,NULL,0,'client_reference','','client_reference'),(10009,NULL,0,'employee','','employee'),(10010,NULL,0,'bank_branch','','bank_branch'),(10011,NULL,0,'third_party','','third_party'),(10012,NULL,0,'guarantor','','guarantor');
/*!40000 ALTER TABLE `party_role_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payable_bank_account`
--

LOCK TABLES `payable_bank_account` WRITE;
/*!40000 ALTER TABLE `payable_bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `payable_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payable_type`
--

LOCK TABLES `payable_type` WRITE;
/*!40000 ALTER TABLE `payable_type` DISABLE KEYS */;
INSERT INTO `payable_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,NULL,0,'Disbursement',NULL,'Disbursement'),(2,NULL,0,'Refund',NULL,'Refund');
/*!40000 ALTER TABLE `payable_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payroll_deduction_client`
--

LOCK TABLES `payroll_deduction_client` WRITE;
/*!40000 ALTER TABLE `payroll_deduction_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_deduction_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payroll_deduction_client_aud`
--

LOCK TABLES `payroll_deduction_client_aud` WRITE;
/*!40000 ALTER TABLE `payroll_deduction_client_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_deduction_client_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payroll_deduction_loan_application`
--

LOCK TABLES `payroll_deduction_loan_application` WRITE;
/*!40000 ALTER TABLE `payroll_deduction_loan_application` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_deduction_loan_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payroll_deduction_loan_application_aud`
--

LOCK TABLES `payroll_deduction_loan_application_aud` WRITE;
/*!40000 ALTER TABLE `payroll_deduction_loan_application_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `payroll_deduction_loan_application_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payslip`
--

LOCK TABLES `payslip` WRITE;
/*!40000 ALTER TABLE `payslip` DISABLE KEYS */;
/*!40000 ALTER TABLE `payslip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payslip_line_item`
--

LOCK TABLES `payslip_line_item` WRITE;
/*!40000 ALTER TABLE `payslip_line_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `payslip_line_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payslip_line_item_definition`
--

LOCK TABLES `payslip_line_item_definition` WRITE;
/*!40000 ALTER TABLE `payslip_line_item_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `payslip_line_item_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `payslip_line_item_type`
--

LOCK TABLES `payslip_line_item_type` WRITE;
/*!40000 ALTER TABLE `payslip_line_item_type` DISABLE KEYS */;
INSERT INTO `payslip_line_item_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,NULL,0,'add','','add'),(2,NULL,0,'subtract','','subtract');
/*!40000 ALTER TABLE `payslip_line_item_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` (`id`, `modified_by`, `version`, `name`) VALUES (1,'',0,'ROLE_BRANCHMANAGER'),(2,'',0,'ROLE_CREDITMANAGEMENT'),(3,'',0,'ROLE_HR'),(4,'',0,'ROLE_LOANCONSULTANT'),(5,'',0,'ROLE_MANAGER'),(6,'',0,'ROLE_QC_SUPERVISOR'),(7,'',0,'ROLE_SUPERUSER'),(8,'',0,'ROLE_USER'),(9,'',0,'UW_CONTACT_CHECK'),(10,'',0,'UW_CREDIT_CHECK'),(11,'',0,'UW_GROUP'),(12,'',0,'UW_LOAN_APPROVAL'),(13,'',0,'UW_QUALITY_CHECK'),(14,'',0,'UW_REFERENCE_CHECK'),(15,'',0,'CORE-AC-GROUP'),(16,'',0,'CORE-EC-GROUP'),(17,'',0,'CORE-LPC-GROUP'),(18,'',0,'CORE-IM-SIMPLE-GROUP'),(19,'',0,'CORE-IM-SIMPLE-GROUP-ADMIN'),(20,'',0,'CORE-RM-SIMPLE-GROUP'),(21,'',0,'CORE-RM-SIMPLE-GROUP-ADMIN'),(22,'',0,'CORE-LS-SIMPLE-GROUP'),(23,'',0,'CORE-LI-SIMPLE-GROUP'),(24,'',0,'CORE-IM-DEDUCT-BATCH-GROUP'),(25,'',0,'CORE-IM-SUBMIT-BATCH-GROUP'),(26,'',0,'CORE-IM-RECEIPT-ALLOCATE-GROUP'),(27,'',0,'CORE-IM-RECEIPT-REVERSE-GROUP'),(28,'',0,'CORE-IM-RECEIPT-UPLOAD-GROUP'),(29,'',0,'CORE-CS-REPLACE-DISBURSEMENTS-GROUP'),(30,'',0,'CORE-CS-DISBURSE-CASH-GROUP'),(31,'',0,'CORE-CS-DISBURSE-CASH-ADMIN-GROUP'),(32,'',0,'CORE-CS-DISBURSE-CASH-CASHIER-GROUP'),(33,'',0,'CORE-DM-BATCH-EFT-DISBURSEMENT-GROUP'),(34,'',0,'CORE-DM-BATCH-EFT-DISBURSEMENT-ADMIN-GROUP'),(35,'',0,'CORE-DM-BATCH-EFT-RECONCILIATION-GROUP'),(36,'',0,'CORE-CA-GROUP'),(37,'',0,'CORE-CE-GROUP'),(38,'',0,'CORE-MA-GROUP'),(39,'',0,'CORE-CO-GROUP'),(40,'',0,'CORE-ST-GROUP'),(41,'',0,'COLLECT-CALL-GROUP'),(42,'',0,'CORE-AC-ADMIN-GROUP'),(43,'',0,'CORE-CM-GROUP'),(44,'',0,'CORE-EC-ADMIN-GROUP'),(45,'',0,'CORE-LS-GROUP'),(46,'',0,'CORE-UM-ADMIN-GROUP'),(47,'',0,'CORE-UM-GROUP'),(48,'',0,'CORE-RC-GROUP'),(49,'',0,'CORE-TP-GROUP'),(50,'',0,'OriginationTeamLeader'),(51,'',0,'OriginationClerk'),(52,'',0,'OriginationCreditAnalyst'),(53,'',0,'UnderwritingConfirmationClerk'),(54,'',0,'UnderwritingCreditClerk'),(55,'',0,'UnderwritingBranchRep'),(56,'',0,'UnderwritingCreditAnalyst'),(57,'',0,'UnderwritingCreditCoordinator'),(58,'',0,'UnderwritingCreditDirector'),(59,'',0,'UnderwritingCEO'),(60,'',0,'UnderwritingRecoveryAnalyst'),(61,'',0,'UnderwritingReferenceClerk'),(62,'',0,'UnderwritingCoordinator'),(63,'',0,'UnderwritingTeamLeader'),(64,'',0,'EmployerBranchRepresentative'),(65,'',0,'EmployerOfficer'),(66,'',0,'EmployerClerk'),(67,'',0,'EmployerUnderwriting'),(68,'',0,'EmployerSubmissionsOfficer'),(69,'',0,'EmployerDirector'),(70,'',0,'EmployerCEO'),(71,'',0,'ManagedDisbursementsTeamLeader'),(72,'',0,'ManagedDisbursementsClerk'),(73,'',0,'TreasuryClerk'),(74,'',0,'SubmissionsClerk'),(75,'',0,'UnderwritingHead'),(76,'',0,'ReceiptingClerk'),(80,'',0,'OriginationQualityControl'),(81,'',0,'OriginationOutsourcingUser'),(90,'103_user_update_0040.sql',0,'AgentRestricted'),(100,'',0,'OriginationTeamLeader'),(101,'',0,'OriginationClerk'),(102,'',0,'OriginationCreditAnalyst'),(103,'',0,'OriginationQualityControl'),(104,'',0,'OriginationOutsourcingUser'),(105,'',0,'UnderwritingConfirmationClerk'),(106,'',0,'UnderwritingCreditClerk'),(107,'',0,'UnderwritingBranchRep'),(108,'',0,'UnderwritingCreditAnalyst'),(109,'',0,'UnderwritingCreditCoordinator'),(110,'',0,'UnderwritingHead'),(111,'',0,'UnderwritingCreditDirector'),(112,'',0,'UnderwritingCEO'),(113,'',0,'UnderwritingRecoveryAnalyst'),(114,'',0,'UnderwritingReferenceClerk'),(115,'',0,'UnderwritingCoordinator'),(116,'',0,'UnderwritingTeamLeader'),(117,'',0,'ManagedDisbursementsTeamLeader'),(118,'',0,'ManagedDisbursementsClerk'),(119,'',0,'TreasuryClerk'),(120,'',0,'EmployerBranchRepresentative'),(121,'',0,'EmployerOfficer'),(122,'',0,'EmployerClerk'),(123,'',0,'EmployerUnderwriting'),(124,'',0,'EmployerSubmissionsOfficer'),(125,'',0,'EmployerDirector'),(126,'',0,'EmployerCEO'),(127,'',0,'SubmissionsClerk'),(128,'',0,'ReceiptingClerk'),(1000,'',0,'Administrator'),(2001,'',0,'CollectionCoordinator'),(2002,'',0,'CollectionAgent');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;

/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `person_role`
--

LOCK TABLES `person_role` WRITE;
/*!40000 ALTER TABLE `person_role` DISABLE KEYS */;

/*!40000 ALTER TABLE `person_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `person_role_aud`
--

LOCK TABLES `person_role_aud` WRITE;
/*!40000 ALTER TABLE `person_role_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `person_role_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `policy_code`
--

LOCK TABLES `policy_code` WRITE;
/*!40000 ALTER TABLE `policy_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `policy_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `policy_code_definition`
--

LOCK TABLES `policy_code_definition` WRITE;
/*!40000 ALTER TABLE `policy_code_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `policy_code_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `receipting_date`
--

LOCK TABLES `receipting_date` WRITE;
/*!40000 ALTER TABLE `receipting_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `receipting_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery`
--

LOCK TABLES `recovery` WRITE;
/*!40000 ALTER TABLE `recovery` DISABLE KEYS */;
/*!40000 ALTER TABLE `recovery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery_aud`
--

LOCK TABLES `recovery_aud` WRITE;
/*!40000 ALTER TABLE `recovery_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `recovery_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery_reason`
--

LOCK TABLES `recovery_reason` WRITE;
/*!40000 ALTER TABLE `recovery_reason` DISABLE KEYS */;
INSERT INTO `recovery_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `recovery_reason_category_id`) VALUES (1,'102_lookups.sql',0,'Invalid Id',NULL,'Invalid Id',1),(2,'102_lookups.sql',0,'Wrong Document',NULL,'Wrong Document',1),(3,'102_lookups.sql',0,'Documents are missing',NULL,'Documents are missing',1),(4,'102_lookups.sql',0,'Invalid reference',NULL,'Invalid reference',2),(5,'102_lookups.sql',0,'Bad credit history',NULL,'Bad credit history',3);
/*!40000 ALTER TABLE `recovery_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery_reason_aud`
--

LOCK TABLES `recovery_reason_aud` WRITE;
/*!40000 ALTER TABLE `recovery_reason_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `recovery_reason_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery_reason_category`
--

LOCK TABLES `recovery_reason_category` WRITE;
/*!40000 ALTER TABLE `recovery_reason_category` DISABLE KEYS */;
INSERT INTO `recovery_reason_category` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'102_lookups.sql',0,'Documents',NULL,'Documents'),(2,'102_lookups.sql',0,'Reference',NULL,'Reference'),(3,'102_lookups.sql',0,'Credit History',NULL,'Credit History');
/*!40000 ALTER TABLE `recovery_reason_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery_reason_category_aud`
--

LOCK TABLES `recovery_reason_category_aud` WRITE;
/*!40000 ALTER TABLE `recovery_reason_category_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `recovery_reason_category_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery_results`
--

LOCK TABLES `recovery_results` WRITE;
/*!40000 ALTER TABLE `recovery_results` DISABLE KEYS */;
INSERT INTO `recovery_results` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,'102_lookups.sql',0,'succeeded','','succeeded'),(2,'102_lookups.sql',0,'failed','','failed');
/*!40000 ALTER TABLE `recovery_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `recovery_results_aud`
--

LOCK TABLES `recovery_results_aud` WRITE;
/*!40000 ALTER TABLE `recovery_results_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `recovery_results_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `residence_type`
--

LOCK TABLES `residence_type` WRITE;
/*!40000 ALTER TABLE `residence_type` DISABLE KEYS */;
INSERT INTO `masterdata`.`residence_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Casa','Casa',1);
INSERT INTO `masterdata`.`residence_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Apartamento','Apartamento',1);
/*!40000 ALTER TABLE `residence_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `resident_status`
--

LOCK TABLES `resident_status` WRITE;
/*!40000 ALTER TABLE `resident_status` DISABLE KEYS */;
INSERT INTO `masterdata`.`resident_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Propia','Propia',1);
INSERT INTO `masterdata`.`resident_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Arrendada','Arrendada',1);
INSERT INTO `masterdata`.`resident_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'Familiar','Familiar',1);
/*!40000 ALTER TABLE `resident_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `revinfo`
--

LOCK TABLES `revinfo` WRITE;
/*!40000 ALTER TABLE `revinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `revinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`id`, `modified_by`, `version`, `name`) VALUES (1,'',0,'general role'),(2,'',0,'User'),(3,'103_user_update_0040.sql',0,'Agent (restricted)'),(100,'',0,'OriginationTeamLeader'),(101,'',0,'OriginationClerk'),(102,'',0,'OriginationCreditAnalyst'),(103,'',0,'OriginationQualityControl'),(104,'',0,'OriginationOutsourcingUser'),(105,'',0,'UnderwritingConfirmationClerk'),(106,'',0,'UnderwritingCreditClerk'),(107,'',0,'UnderwritingBranchRep'),(108,'',0,'UnderwritingCreditAnalyst'),(109,'',0,'UnderwritingCreditCoordinator'),(110,'',0,'UnderwritingHead'),(111,'',0,'UnderwritingCreditDirector'),(112,'',0,'UnderwritingCEO'),(113,'',0,'UnderwritingRecoveryAnalyst'),(114,'',0,'UnderwritingReferenceClerk'),(115,'',0,'UnderwritingCoordinator'),(116,'',0,'UnderwritingTeamLeader'),(117,'',0,'ManagedDisbursementsTeamLeader'),(118,'',0,'ManagedDisbursementsClerk'),(119,'',0,'TreasuryClerk'),(120,'',0,'EmployerBranchRepresentative'),(121,'',0,'EmployerOfficer'),(122,'',0,'EmployerClerk'),(123,'',0,'EmployerUnderwriting'),(124,'',0,'EmployerSubmissionsOfficer'),(125,'',0,'EmployerDirector'),(126,'',0,'EmployerCEO'),(127,'',0,'SubmissionsClerk'),(128,'',0,'ReceiptingClerk'),(129,'',0,'CollectionCoordinator'),(130,NULL,0,'CollectionAgent');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` (`role_id`, `permission_id`) VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(1,18),(1,19),(1,20),(1,21),(1,22),(1,23),(1,24),(1,25),(1,26),(1,27),(1,28),(1,29),(1,30),(1,31),(1,32),(1,33),(1,34),(1,35),(1,36),(1,37),(1,38),(1,39),(1,40),(1,41),(1,42),(1,43),(1,44),(1,45),(1,46),(1,47),(1,48),(1,49),(1,50),(1,51),(1,52),(1,53),(1,54),(1,55),(1,56),(1,57),(1,58),(1,59),(1,60),(1,61),(1,62),(1,63),(1,64),(1,65),(1,66),(1,67),(1,68),(1,69),(1,70),(1,71),(1,72),(1,73),(1,74),(1,75),(1,76),(1,80),(1,81),(1,1000),(2,8),(3,8),(3,90),(100,8),(100,100),(101,8),(101,101),(102,8),(102,102),(103,8),(103,103),(104,8),(104,104),(105,8),(105,105),(106,8),(106,106),(107,8),(107,107),(108,8),(108,108),(109,8),(109,109),(110,8),(110,110),(111,8),(111,111),(112,8),(112,112),(113,8),(113,113),(114,8),(114,114),(115,8),(115,115),(116,8),(116,116),(117,8),(117,117),(118,8),(118,118),(119,8),(119,119),(120,8),(120,120),(121,8),(121,121),(122,8),(122,122),(123,8),(123,123),(124,8),(124,124),(125,8),(125,125),(126,8),(126,126),(127,8),(127,127),(128,8),(128,128),(129,2001),(130,2002);
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `salary_scale`
--

LOCK TABLES `salary_scale` WRITE;
/*!40000 ALTER TABLE `salary_scale` DISABLE KEYS */;
/*!40000 ALTER TABLE `salary_scale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `status_type`
--

LOCK TABLES `status_type` WRITE;
/*!40000 ALTER TABLE `status_type` DISABLE KEYS */;
INSERT INTO `status_type` (`id`, `modified_by`, `version`, `description`) VALUES (1,NULL,0,'active'),(2,NULL,0,'inactive');
/*!40000 ALTER TABLE `status_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `submission_date`
--

LOCK TABLES `submission_date` WRITE;
/*!40000 ALTER TABLE `submission_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `submission_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `suburb`
--

LOCK TABLES `suburb` WRITE;
/*!40000 ALTER TABLE `suburb` DISABLE KEYS */;
/*!40000 ALTER TABLE `suburb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `system_bank_account`
--

LOCK TABLES `system_bank_account` WRITE;
/*!40000 ALTER TABLE `system_bank_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_bank_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` (`id`, `modified_by`, `version`, `currency_locale`, `timezone_offset`, `country_id`) VALUES (0,'system',0,'es_CO','+02:00',1009);
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `termination_reason`
--

LOCK TABLES `termination_reason` WRITE;
/*!40000 ALTER TABLE `termination_reason` DISABLE KEYS */;
INSERT INTO `termination_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES (1,NULL,0,'changed employers',NULL,'changed_employers'),(2,NULL,0,'won the lotto',NULL,'won_lotto'),(3,NULL,0,'employment deleted',NULL,'delete_employment');
/*!40000 ALTER TABLE `termination_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `third_party`
--

LOCK TABLES `third_party` WRITE;
/*!40000 ALTER TABLE `third_party` DISABLE KEYS */;
/*!40000 ALTER TABLE `third_party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `title`
--

LOCK TABLES `title` WRITE;
/*!40000 ALTER TABLE `title` DISABLE KEYS */;
INSERT INTO `masterdata`.`title`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Señor','Señor',1);
INSERT INTO `masterdata`.`title`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Señora','Señora',1);
INSERT INTO `masterdata`.`title`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'Señorita','Señorita',1);
INSERT INTO `masterdata`.`title`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'Doctor','Doctor',1);
/*!40000 ALTER TABLE `title` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `trading_entity`
--

LOCK TABLES `trading_entity` WRITE;
/*!40000 ALTER TABLE `trading_entity` DISABLE KEYS */;
INSERT INTO `trading_entity` (`id`, `entity_identifier`) VALUES (2000,'bayport'),(2001,'microcredito');
/*!40000 ALTER TABLE `trading_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `union_rep`
--

LOCK TABLES `union_rep` WRITE;
/*!40000 ALTER TABLE `union_rep` DISABLE KEYS */;
/*!40000 ALTER TABLE `union_rep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `user_role`
--

LOCK TABLES `user_role` WRITE;
/*!40000 ALTER TABLE `user_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `visiting_agent`
--

LOCK TABLES `visiting_agent` WRITE;
/*!40000 ALTER TABLE `visiting_agent` DISABLE KEYS */;
/*!40000 ALTER TABLE `visiting_agent` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 16:08:32
