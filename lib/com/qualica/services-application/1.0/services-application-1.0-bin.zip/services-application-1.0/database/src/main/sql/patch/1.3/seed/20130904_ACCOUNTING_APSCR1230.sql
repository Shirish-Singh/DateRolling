INSERT INTO `accounting`.`configuration` (`id`, `version`, `name`, `value`) VALUES ('10010', '0', 'max.loan.binary.search.iterations', '100');
