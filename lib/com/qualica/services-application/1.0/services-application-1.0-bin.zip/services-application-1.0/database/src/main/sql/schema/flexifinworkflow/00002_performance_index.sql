USE `flexifinworkflow`;
create index EXECUTION_ID_IDX on ACT_HI_ACTINST(EXECUTION_ID_);
