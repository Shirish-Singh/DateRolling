SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';


USE accounting;



DROP PROCEDURE IF EXISTS accounting.drop_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;


;

DROP PROCEDURE IF EXISTS accounting.drop_fk ;
SET SQL_MODE=@OLD_SQL_MODE;



CREATE TABLE IF NOT EXISTS `quote_disbursement` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `amount_editable` bit(1) DEFAULT NULL,
  `bank_id` bigint(20) DEFAULT NULL,
  `cashiers_cheque_city_id` bigint(20) DEFAULT NULL,
  `cashiers_cheque_holder` varchar(255) DEFAULT NULL,
  `created_by` bit(1) DEFAULT NULL,
  `current` bit(1) DEFAULT NULL,
  `disbursement_actioner_id` bigint(20) DEFAULT NULL,
  `disbursement_recipient_id` bigint(20) DEFAULT NULL,
  `document_reference` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `payment_mechanism` varchar(255) DEFAULT NULL,
  `payment_resource_id` bigint(20) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `recipient_type` varchar(255) DEFAULT NULL,
  `account_quote_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2BA45E0493923260` (`account_quote_id`),
  CONSTRAINT `FK2BA45E0493923260` FOREIGN KEY (`account_quote_id`) REFERENCES `account_quote` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




CREATE TABLE IF NOT EXISTS `quote_cost` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `cost_type` varchar(255) DEFAULT NULL,
  `disbursement_actioner` bigint(20) DEFAULT NULL,
  `inclusive` bit(1) DEFAULT NULL,
  `waivable` bit(1) DEFAULT NULL,
  `waived` bit(1) DEFAULT NULL,
  `quote_disbursement_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4C69D7B01DB71112` (`quote_disbursement_id`),
  CONSTRAINT `FK4C69D7B01DB71112` FOREIGN KEY (`quote_disbursement_id`) REFERENCES `quote_disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



CREATE TABLE IF NOT EXISTS `breakdown` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `breakdown_resource` bigint(20) DEFAULT NULL,
  `portion_type` varchar(255) DEFAULT NULL,
  `is_waivable` bit(1) DEFAULT NULL,
  `is_waived` bit(1) DEFAULT NULL,
  `quote_cost_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8EE6E62170DDF992` (`quote_cost_id`),
  CONSTRAINT `FK8EE6E62170DDF992` FOREIGN KEY (`quote_cost_id`) REFERENCES `quote_cost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

