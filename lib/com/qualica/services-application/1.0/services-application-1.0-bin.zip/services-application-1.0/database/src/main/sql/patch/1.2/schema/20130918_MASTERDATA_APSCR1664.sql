USE masterdata;

ALTER TABLE first_instalment_schedule CHANGE COLUMN cut_off_date cut_off_date date not null;
ALTER TABLE first_instalment_schedule CHANGE COLUMN feid_date feid_date date not null;