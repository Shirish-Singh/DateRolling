USE masterdata;

ALTER TABLE `masterdata`.`third_party` ADD COLUMN `third_party_identifier` VARCHAR(255) NULL DEFAULT NULL  AFTER `id` ;

