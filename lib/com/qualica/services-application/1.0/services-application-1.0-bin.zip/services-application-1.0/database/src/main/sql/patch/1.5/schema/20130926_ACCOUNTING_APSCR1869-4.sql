USE accounting;

ALTER TABLE disbursement_batch_line CHANGE COLUMN account_approval_date account_approval_date DATE DEFAULT NULL;

ALTER TABLE receipt_allocation CHANGE COLUMN loan_start_date loan_start_date DATE DEFAULT NULL;
ALTER TABLE receipt_allocation_aud CHANGE COLUMN loan_start_date loan_start_date DATE DEFAULT NULL;
