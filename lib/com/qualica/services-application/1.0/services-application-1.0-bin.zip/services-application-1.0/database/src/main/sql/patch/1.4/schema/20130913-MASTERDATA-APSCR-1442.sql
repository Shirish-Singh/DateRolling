USE masterdata;

ALTER TABLE `packed_document` ADD COLUMN `document_name` VARCHAR(255) NULL DEFAULT NULL AFTER `document_description`;