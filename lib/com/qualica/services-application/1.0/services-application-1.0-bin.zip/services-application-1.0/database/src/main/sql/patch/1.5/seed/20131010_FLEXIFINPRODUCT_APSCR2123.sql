USE flexifinproduct;

UPDATE loan_product SET cheque_fee_type = null where cheque_fee_type = '0';