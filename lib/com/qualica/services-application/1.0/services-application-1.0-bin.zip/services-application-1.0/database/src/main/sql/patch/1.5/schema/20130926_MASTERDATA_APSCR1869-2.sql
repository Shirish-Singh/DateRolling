
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE masterdata;

DROP PROCEDURE IF EXISTS masterdata.alter_column ;

DELIMITER $$

CREATE PROCEDURE masterdata.alter_column(
  IN tableName VARCHAR(100) character set utf8,
  IN oldColName VARCHAR(100) character set utf8,
  IN newColName VARCHAR(100) character set utf8,
  IN newColType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'masterdata'
      )
  THEN
      IF EXISTS (
          SELECT * FROM information_schema.COLUMNS
          WHERE column_name = oldColName
          AND table_name = tableName
          AND table_schema = 'masterdata'
          )
      THEN
          SET @Statement = CONCAT('ALTER TABLE `masterdata`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
          prepare DynamicStatement from @Statement ;
          execute DynamicStatement ;
          deallocate prepare DynamicStatement ;
      END IF;
  END IF;
END ;$$

DELIMITER ;

CALL masterdata.alter_column('receipting_date', 'date_due', 'due_date', 'DATE DEFAULT NULL');
CALL masterdata.alter_column('submission_date', 'date_due', 'due_date', 'DATE DEFAULT NULL');

DROP PROCEDURE IF EXISTS masterdata.alter_column ;

SET SQL_MODE=@OLD_SQL_MODE ;

