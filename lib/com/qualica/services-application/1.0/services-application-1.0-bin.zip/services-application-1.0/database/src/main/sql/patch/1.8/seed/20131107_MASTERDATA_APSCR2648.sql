use masterdata;
UPDATE trading_entity SET ENTITY_IDENTIFIER ='bayport' where id=2000 ;
UPDATE trading_entity SET ENTITY_IDENTIFIER ='microcredito' where id=2001;