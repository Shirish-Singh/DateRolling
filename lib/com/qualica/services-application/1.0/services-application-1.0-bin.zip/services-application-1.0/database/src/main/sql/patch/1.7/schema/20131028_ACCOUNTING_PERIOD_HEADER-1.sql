SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_fk('tx_line', 'FKCA85CCCFD90855E6') ;

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_column ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_column(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP COLUMN `', colName, '`');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_column('tx_line', 'accounting_period_id') ;

DROP PROCEDURE IF EXISTS accounting.drop_column ;

SET SQL_MODE=@OLD_SQL_MODE;



