use collections;

-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: collections
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `collection_case`
--

LOCK TABLES `collection_case` WRITE;
/*!40000 ALTER TABLE `collection_case` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_case_aud`
--

LOCK TABLES `collection_case_aud` WRITE;
/*!40000 ALTER TABLE `collection_case_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_case_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_case_discount`
--

LOCK TABLES `collection_case_discount` WRITE;
/*!40000 ALTER TABLE `collection_case_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_case_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_case_discount_aud`
--

LOCK TABLES `collection_case_discount_aud` WRITE;
/*!40000 ALTER TABLE `collection_case_discount_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_case_discount_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_case_status`
--

LOCK TABLES `collection_case_status` WRITE;
/*!40000 ALTER TABLE `collection_case_status` DISABLE KEYS */;
INSERT INTO `collection_case_status` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `is_active`) VALUES (1,'',0,'IN PROGRESS','','IN PROGRESS',''),(2,'',0,'HOLD','','HOLD',''),(3,'',0,'SUCCESSFUL','','SUCCESSFUL',''),(4,'',0,'FAILURE','','FAILURE','');
/*!40000 ALTER TABLE `collection_case_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_case_status_aud`
--

LOCK TABLES `collection_case_status_aud` WRITE;
/*!40000 ALTER TABLE `collection_case_status_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_case_status_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_case_status_reason`
--

LOCK TABLES `collection_case_status_reason` WRITE;
/*!40000 ALTER TABLE `collection_case_status_reason` DISABLE KEYS */;
INSERT INTO `collection_case_status_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `is_active`, `collection_case_status_id`) VALUES (1,'',0,'IN ARREARS','','IN ARREARS','',1),(2,'',0,'in progress reason1','','in progress reason1','',1),(3,'',0,'in progress reason2','','in progress reason2','',1),(4,'',0,'hold reason 1','','hold reason 1','',2),(5,'',0,'hold reason 2','','hold reason 2','',2),(6,'',0,'hold reason 3','','hold reason 3','',2),(7,'',0,'success reason 1','','success reason 1','',3),(8,'',0,'success reason 2','','success reason 2','',3),(9,'',0,'success reason 3','','success reason 3','',3),(10,'',0,'failure reason 1','','failure reason 1','',4),(11,'',0,'failure reason 2','','failure reason 2','',4),(12,'',0,'failure reason 3','','failure reason 3','',4);
/*!40000 ALTER TABLE `collection_case_status_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_case_status_reason_aud`
--

LOCK TABLES `collection_case_status_reason_aud` WRITE;
/*!40000 ALTER TABLE `collection_case_status_reason_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_case_status_reason_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_global_variable`
--

LOCK TABLES `collection_global_variable` WRITE;
/*!40000 ALTER TABLE `collection_global_variable` DISABLE KEYS */;
INSERT INTO `collection_global_variable` (`id`, `modified_by`, `version`, `variable_name`, `display_name`, `variable_value`, `editable_from_ui`) VALUES (1,'',0,'days_in_arrears_lower_limit','Minium Days In Arrears','30','\0'),(2,'',0,'last_arrears_in_days','Max Last Day in Arrears','180',''),(3,'',0,'days_in_arrears_higher_limit','Max Days In Arrears','60','\0'),(4,'',0,'outstanding_loan_amount_limit','Outstanding Loan Amount Limit for Visit Customer','8000000',''),(5,'',0,'promise_to_pay_wait_time','Promise To Pay wait Time','PT620S','\0'),(6,'',0,'letter_sent_wait_time','Letter Sent Wait Time','PT620S','\0'),(7,'',0,'phone_wait_time','Phone Wait Time','PT620S','\0'),(8,'',0,'visit_wait_time','Visit Wait Time','PT620S','\0'),(9,'',0,'max_contact_attempt_per_phone_number','Maximum Contact Attempts Per Phone Number','3',''),(10,'',0,'collection_discount_1','Defalut Collection Discount 1 percentage','50',''),(11,'',0,'collection_discount_2','Defalut Collection Discount 2 percentage','20',''),(12,'',0,'collection_fee','Defalut Collection Fee','10000','');
/*!40000 ALTER TABLE `collection_global_variable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_global_variable_aud`
--

LOCK TABLES `collection_global_variable_aud` WRITE;
/*!40000 ALTER TABLE `collection_global_variable_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_global_variable_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance`
--

LOCK TABLES `collection_instance` WRITE;
/*!40000 ALTER TABLE `collection_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance_aud`
--

LOCK TABLES `collection_instance_aud` WRITE;
/*!40000 ALTER TABLE `collection_instance_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_instance_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance_severity`
--

LOCK TABLES `collection_instance_severity` WRITE;
/*!40000 ALTER TABLE `collection_instance_severity` DISABLE KEYS */;
INSERT INTO `collection_instance_severity` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `is_active`) VALUES (1,'',0,'EXEMPT','','EXEMPT',''),(2,'',0,'PREVENTATIVE','','PREVENTATIVE',''),(3,'',0,'COERSIVE','','COERSIVE',''),(4,'',0,'LEGAL','','LEGAL','');
/*!40000 ALTER TABLE `collection_instance_severity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance_severity_aud`
--

LOCK TABLES `collection_instance_severity_aud` WRITE;
/*!40000 ALTER TABLE `collection_instance_severity_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_instance_severity_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance_status`
--

LOCK TABLES `collection_instance_status` WRITE;
/*!40000 ALTER TABLE `collection_instance_status` DISABLE KEYS */;
INSERT INTO `collection_instance_status` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `is_active`) VALUES (1,'',0,'IN PROGRESS','','IN PROGRESS',''),(2,'',0,'HOLD','','HOLD',''),(3,'',0,'SUCCESSFUL','','SUCCESSFUL',''),(4,'',0,'FAILURE','','FAILURE','');
/*!40000 ALTER TABLE `collection_instance_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance_status_aud`
--

LOCK TABLES `collection_instance_status_aud` WRITE;
/*!40000 ALTER TABLE `collection_instance_status_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_instance_status_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance_status_reason`
--

LOCK TABLES `collection_instance_status_reason` WRITE;
/*!40000 ALTER TABLE `collection_instance_status_reason` DISABLE KEYS */;
INSERT INTO `collection_instance_status_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `is_active`, `collection_instance_status_id`) VALUES (1,'',0,'IN ARREARS','','IN ARREARS','',1),(2,'',0,'in progress reason1','','in progress reason1','',1),(3,'',0,'in progress reason2','','in progress reason2','',1),(4,'',0,'hold reason 1','','hold reason 1','',2),(5,'',0,'hold reason 2','','hold reason 2','',2),(6,'',0,'hold reason 3','','hold reason 3','',2),(7,'',0,'success reason 1','','success reason 1','',3),(8,'',0,'success reason 2','','success reason 2','',3),(9,'',0,'success reason 3','','success reason 3','',3),(10,'',0,'failure reason 1','','failure reason 1','',4),(11,'',0,'failure reason 2','','failure reason 2','',4),(12,'',0,'failure reason 3','','failure reason 3','',4);
/*!40000 ALTER TABLE `collection_instance_status_reason` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collection_instance_status_reason_aud`
--

LOCK TABLES `collection_instance_status_reason_aud` WRITE;
/*!40000 ALTER TABLE `collection_instance_status_reason_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `collection_instance_status_reason_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collections_dto_to_class_binding`
--

LOCK TABLES `collections_dto_to_class_binding` WRITE;
/*!40000 ALTER TABLE `collections_dto_to_class_binding` DISABLE KEYS */;
INSERT INTO `collections_dto_to_class_binding` (`id`, `modified_by`, `version`, `class_name`, `dto_name`, `relevant_entity_name`) VALUES (1,NULL,0,'com.qualica.flexifin.collections.domain.CollectionsNote','com.qualica.flexifin.collections.shared.dto.CollectionsNoteDTO','com.qualica.flexifin.collections.domain.CollectionsNote');
/*!40000 ALTER TABLE `collections_dto_to_class_binding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `collections_note`
--

LOCK TABLES `collections_note` WRITE;
/*!40000 ALTER TABLE `collections_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `collections_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cont_attmpt_line_item_out_hist`
--

LOCK TABLES `cont_attmpt_line_item_out_hist` WRITE;
/*!40000 ALTER TABLE `cont_attmpt_line_item_out_hist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cont_attmpt_line_item_out_hist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `cont_attmpt_line_item_out_hist_aud`
--

LOCK TABLES `cont_attmpt_line_item_out_hist_aud` WRITE;
/*!40000 ALTER TABLE `cont_attmpt_line_item_out_hist_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `cont_attmpt_line_item_out_hist_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt`
--

LOCK TABLES `contact_attempt` WRITE;
/*!40000 ALTER TABLE `contact_attempt` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_aud`
--

LOCK TABLES `contact_attempt_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item`
--

LOCK TABLES `contact_attempt_line_item` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_aud`
--

LOCK TABLES `contact_attempt_line_item_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_email`
--

LOCK TABLES `contact_attempt_line_item_email` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_email_aud`
--

LOCK TABLES `contact_attempt_line_item_email_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_email_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_email_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_legal`
--

LOCK TABLES `contact_attempt_line_item_legal` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_legal` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_legal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_legal_aud`
--

LOCK TABLES `contact_attempt_line_item_legal_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_legal_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_legal_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_letter`
--

LOCK TABLES `contact_attempt_line_item_letter` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_letter` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_letter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_letter_aud`
--

LOCK TABLES `contact_attempt_line_item_letter_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_letter_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_letter_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_phone`
--

LOCK TABLES `contact_attempt_line_item_phone` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_phone` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_phone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_phone_aud`
--

LOCK TABLES `contact_attempt_line_item_phone_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_phone_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_phone_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_sms`
--

LOCK TABLES `contact_attempt_line_item_sms` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_sms_aud`
--

LOCK TABLES `contact_attempt_line_item_sms_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_sms_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_sms_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_visit`
--

LOCK TABLES `contact_attempt_line_item_visit` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_visit` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_visit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_line_item_visit_aud`
--

LOCK TABLES `contact_attempt_line_item_visit_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_line_item_visit_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_line_item_visit_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_script_history`
--

LOCK TABLES `contact_attempt_script_history` WRITE;
/*!40000 ALTER TABLE `contact_attempt_script_history` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_script_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_script_history_aud`
--

LOCK TABLES `contact_attempt_script_history_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_script_history_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_script_history_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_type`
--

LOCK TABLES `contact_attempt_type` WRITE;
/*!40000 ALTER TABLE `contact_attempt_type` DISABLE KEYS */;
INSERT INTO `contact_attempt_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `is_active`) VALUES (1,'',0,'PHONE','','PHONE',''),(2,'',0,'EMAIL','','EMAIL',''),(3,'',0,'LETTER','','LETTER',''),(4,'',0,'VISIT','','VISIT',''),(5,'',0,'LEGAL','','LEGAL','');
/*!40000 ALTER TABLE `contact_attempt_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_attempt_type_aud`
--

LOCK TABLES `contact_attempt_type_aud` WRITE;
/*!40000 ALTER TABLE `contact_attempt_type_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_attempt_type_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_script_template`
--

LOCK TABLES `contact_script_template` WRITE;
/*!40000 ALTER TABLE `contact_script_template` DISABLE KEYS */;
INSERT INTO `contact_script_template` (`id`, `modified_by`, `version`, `description`, `enabled`, `is_active`, `name`, `label`, `template_content`, `contact_attempt_type_id`, `severity_id`, `debtor_type`, `workflow_outcome_name`, `script_outcome_state`, `entity_id`) VALUES (101,NULL,0,'PHONE','','','CALL_CLIENT','Call client','Please carry out the collections phone call to  ______ ID______ issued _______ to the next numbers ____________.',1,NULL,NULL,NULL,'ACTIVE',2000),(102,NULL,0,'PHONE','','','ENGAGED','Engaged','Please call again in two hours.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2000),(103,NULL,0,'PHONE','','','NOT_ANSWERED','Not Answered','Please call again in two hours.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2000),(104,NULL,0,'PHONE','','','NOT_REACHABLE','Not Reachable','Please call again in two hours.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2000),(105,NULL,0,'PHONE','','','NUMBER_OUT_OF_SERVICE','Number out of Service','Please classify the client and carryout location according to the case.',1,NULL,NULL,'FAILED','ACTIVE',2000),(106,NULL,0,'PHONE','','','CALL_ANSWERED','Call answered','Good morning/afternoon/evening can i speak with Mr./Mrs. __________Hi, how are you? My name is _________  we are calling you from BAYPORT FIMSA.',1,NULL,NULL,NULL,'ACTIVE',2000),(107,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to you by ______________, the payment list sent by the employer does not register the instalment deduction on the payroll.',1,NULL,NULL,NULL,'ACTIVE',2000),(108,NULL,0,'PHONE','','','CLIENT_UNAVAILABLE','Client unavailable','Good morning/afternoon/evening can you please communicate me directly with Mr. __________ .<br>Can you please confirm me a number in which I can find directly Mr. ___? Can you please leave a message for him? Can you confirm me your kinship with the account holder? <br>Please be kind to communicate him that we called from BAYPORT FIMSA because he presents arrears with us. That he must communicate himself with us as soon as possible to the phone number _____.',1,NULL,NULL,NULL,'ACTIVE',2000),(109,NULL,0,'PHONE','','','CLIENT_DECEASED','Client deceased','Mr./Mrs. ______, as a relative of _______ who was holder of the loan No. ______ for the amount of $_____.<br>The holder signed an insurance policy in the case of disability or decease, in order to use this policy it is necessary to give us the required documents in order to carry out the process on the insurance company.<ul> <li>Death certificate</li><li>Patient record</li><li>Medical history</li><li>ID copy enlarged to 150</li><li>Debt certificate to the date</li><li>Letter claiming the insurance.</li></ul>',1,NULL,NULL,NULL,'ACTIVE',2000),(110,NULL,0,'PHONE','','','INCORRECT_NUMBER','Incorrect number','Please classify the client and carryout location according to the case.',1,NULL,NULL,'FAILED','ACTIVE',2000),(111,NULL,0,'PHONE','','','PROMISE_TO_PAY','Promise to pay','We will conduct then the payment commitment for the day  _______ for an amount  _________ .',1,NULL,NULL,NULL,'ACTIVE',2000),(112,NULL,0,'PHONE','','','PAYMENT_ALLREADY_MADE','Payment already made','Mr./Mrs. ______,<br>our system doesn\'t register the payment of the month ____, for an amount of $_____, if your payment was done or deducted please send us the corresponding payslips in order to apply them on our system.<br> This information can be sent to the mail ______ or via fax: 8050052 specifying the account holder name and ID.',1,NULL,NULL,NULL,'ACTIVE',2000),(113,NULL,0,'PHONE','','','REFUSES_TO_PAY','Refuses to pay','We understand your situation at this moment but I remind you that the loan with BAYPORT FIMSA is a financial obligation which you signed and accepted.<br> Likewise this loan is generating arrears charges, negative reports on credit bureau and taking in to account the arrears days and balance a pre legal collection process will initiate.',1,NULL,NULL,NULL,'ACTIVE',2000),(114,NULL,0,'PHONE','','','PAYMENTS_NOT_CLEARED','Payments not cleared','Thank you very much for you attention remember you spoke with ______ from BAYPORT FIMSA have a great day.',1,NULL,NULL,NULL,'ACTIVE',2000),(115,NULL,0,'PHONE','','','CLIENT_INSOLVENT','Client insolvent','We will keep aware of the delivery of the documents that support your economical situation in order to initiate the process of validation.',1,NULL,NULL,NULL,'ACTIVE',2000),(116,NULL,0,'PHONE','','','INITIATE_LEGAL_ACTION_INSTRUCTION','Initiate legal action instruction','Please start legal proceedings.',1,NULL,NULL,NULL,'ACTIVE',2000),(117,NULL,0,'PHONE','','','PAYMENTS_FOUND','Payments found','Mr./Mrs.________<br>We are sorry we found your payment in our system. Apologies.',1,NULL,NULL,NULL,'ACTIVE',2000),(118,NULL,0,'PHONE','','','CLIENT_SOLVENT','Client solvent','Remember you have an obligation with BAYPORT FIMSA and to the date the loan is still in arrears.<br>I notify you that if a payment agreement is not done on this month it will generate an arrears charge, negative reports to credit bureau and taking in to account the arrears days and balance a pre legal process will initiate.<br> It is very important for you to pay as soon as possible.',1,NULL,NULL,NULL,'ACTIVE',2000),(119,NULL,0,'PHONE','','','CLIENT_UP_TO_DATE','Client up to date','Mr./Mrs._______ <br>We are sorry we found your payment in our system. Apologies.',1,NULL,NULL,NULL,'ACTIVE',2000),(120,NULL,0,'PHONE','','','CLIENT_RELENTS','Client relents','Remember that the loan is already presenting arrears, which generates arrears interests and the payment must be done before the next installment is due.<br>On this case it is necessary to carry out the payment of the installment over the counter on Banco Colpatria account 161-002-224 the amount to be paid is $____ which must be done before ______.<br>I remind you that the receipt of bank deposit receipt must be sent to the mail _____ or fax No. 8050052 with name and ID in order to update the payment information.',1,NULL,NULL,NULL,'ACTIVE',2000),(121,NULL,0,'PHONE','','','CLIENT_STILL_IN_ARREARS','Client still in arrears','On this case it is necessary to carry out the remaining payment of the arrears over the counter on Banco Colpatria account 161-002-224 the amount to be paid $____ which must be done before ______.<br>I remind you that the receipt of bank deposit receipt must be sent to the mail _____ or fax No. 8050052 with name and ID in order to update the payment information.',1,NULL,NULL,NULL,'ACTIVE',2000),(122,NULL,0,'PHONE','','','PAYMENTS_CLEARED','Payments cleared','Mr./Mrs. ____ can you please confirm me the date in which the payment was done, the bank and amount in order to carry out the validation.',1,NULL,NULL,NULL,'ACTIVE',2000),(123,NULL,0,'PHONE','','','PAYMENTS_NOT_FOUND','Payments not found','Mr./Mrs. ______, our system doesn\'t register your payment of the month ____, if your payment was done or deducted please send us the corresponding payslips in order to apply them on our system.<br>This information can be sent to the mail ______ or via fax: 8050052 specifying the account holder name and ID.',1,NULL,NULL,NULL,'ACTIVE',2000),(124,NULL,0,'PHONE','','','CLIENT_STILL_REFUSES','Client still refuses','Remember you have an obligation with BAYPORT FIMSA and to the date the loan is still in arrears.<br>I notify you that if a payment agreement is not done on this month it will generate an arrear charge, negative reports to credit bureau and taking in to acount the arrears days and balance a pre legal proces will initiate.<br>It is very important for you to pay as soon as possible.',1,NULL,NULL,NULL,'ACTIVE',2000),(125,NULL,0,'PHONE','','','VOICE_MAIL','Voice mail','Good morning/afternoon/evening you\'re speaking to ---- from BAYPORT FIMSA this message is for Mr. ----- in order to notify that your obligation is in arrears.<br>Please immediately contact us on 6170711 ext. --- thank you.',1,NULL,NULL,NULL,'ACTIVE',2000),(126,NULL,0,'PHONE','','','CALL_ON_SUGGESTED_TIME','Call on suggested time','Please note down the suggested time and try again at suggested time.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2000),(127,NULL,0,'PHONE','','','NO_SUGGESTED_TIME','No suggested time','Time Not suggested.<br>Please end the call.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2000),(128,NULL,0,'PHONE','','','LEAVE_MESSAGE','Leave message','This is  ___ from BayPort FIMSA, Please contact BAYPORT FIMSA immediately. <br>Thank You.',1,NULL,NULL,NULL,'ACTIVE',2000),(129,NULL,0,'PHONE','','','END_SCRIPT','End call','Thank you very much for you attention remember you spoke with ______ from BAYPORT FIMSA have a great day.',1,NULL,NULL,NULL,'ACTIVE',2000),(130,NULL,0,'PHONE','','','END_STATE','End','--End--',1,NULL,NULL,'FINISH','INACTIVE',2000),(201,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to you by ______________, the payment list sent by the employer does not register the instalment deduction on the payroll.',1,'1','PRIMARY',NULL,'ACTIVE',2000),(202,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','Your payments must be done on the checking account No. ___________ of the ____________ on behalf of FIMSA S.A.S indicating on the Ref. 1, ________ID number.<br> Once the payment is done please send a copy of the bank deposit to the fax No. 8-050052 in Bogota, or to the email cobranza@bayport.com.co',1,'2','PRIMARY',NULL,'ACTIVE',2000),(203,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','I remind you that your arrear is currently reflected on the credit bureau, as a negative indicator to your credit life, for which its important to improve the qualification through the payment and avoid the initiation of a legal process which will make you engage on additional expenses!',1,'3','PRIMARY',NULL,'ACTIVE',2000),(301,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to __________ by ______________, of which you are the co debtor.<br> The payment list sent by the employer does not register the installment deduction on the payroll of the account holder, by which we are calling you in order to report that the pay roll deduction loan No. ___ has an arrear of ____. On this case a payment of $____ must be done.',1,'1','GUARANTOR',NULL,'ACTIVE',2000),(302,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to __________ by ______________, of which you are the co debtor.<br> The payment list sent by the employer does not register the installment deduction on the payroll of the account holder, by which we are calling you in order to report that the pay roll deduction loan No. ___ has an arrear of ____. On this case a payment of $____ must be done.',1,'2','GUARANTOR',NULL,'ACTIVE',2000),(303,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to __________ by ______________, of which you are the co debtor.<br> The payment list sent by the employer does not register the installment deduction on the payroll of the account holder, by which we are calling you in order to report that the pay roll deduction loan No. ___ has an arrear of ____. On this case a payment of $____ must be done.',1,'3','GUARANTOR',NULL,'ACTIVE',2000),(1001,NULL,0,'PHONE','','','CALL_CLIENT','Call client','Please carry out the collections phone call to  ______ ID______ issued _______ to the next numbers ____________.',1,NULL,NULL,NULL,'ACTIVE',2001),(1002,NULL,0,'PHONE','','','ENGAGED','Engaged','Please call again in two hours.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2001),(1003,NULL,0,'PHONE','','','NOT_ANSWERED','Not Answered','Please call again in two hours.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2001),(1004,NULL,0,'PHONE','','','NOT_REACHABLE','Not Reachable','Please call again in two hours.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2001),(1005,NULL,0,'PHONE','','','NUMBER_OUT_OF_SERVICE','Number out of Service','Please classify the client and carryout location according to the case.',1,NULL,NULL,'FAILED','ACTIVE',2001),(1006,NULL,0,'PHONE','','','CALL_ANSWERED','Call answered','Good morning/afternoon/evening can i speak with Mr./Mrs. __________Hi, how are you? My name is _________  we are calling you from COOP MICROCREDITO.',1,NULL,NULL,NULL,'ACTIVE',2001),(1007,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to you by ______________, the payment list sent by the employer does not register the instalment deduction on the payroll.',1,NULL,NULL,NULL,'ACTIVE',2001),(1008,NULL,0,'PHONE','','','CLIENT_UNAVAILABLE','Client unavailable','Good morning/afternoon/evening can you please communicate me directly with Mr. __________ .<br>Can you please confirm me a number in which I can find directly Mr. ___? Can you please leave a message for him? Can you confirm me your kinship with the account holder? <br>Please be kind to communicate him that we called from COOP MICROCREDITO because he presents arrears with us. That he must communicate himself with us as soon as possible to the phone number _____.',1,NULL,NULL,NULL,'ACTIVE',2001),(1009,NULL,0,'PHONE','','','CLIENT_DECEASED','Client deceased','Mr./Mrs. ______, as a relative of _______ who was holder of the loan No. ______ for the amount of $_____.<br>The holder signed an insurance policy in the case of disability or decease, in order to use this policy it is necessary to give us the required documents in order to carry out the process on the insurance company.<ul> <li>Death certificate</li><li>Patient record</li><li>Medical history</li><li>ID copy enlarged to 150</li><li>Debt certificate to the date</li><li>Letter claiming the insurance.</li></ul>',1,NULL,NULL,NULL,'ACTIVE',2001),(1010,NULL,0,'PHONE','','','INCORRECT_NUMBER','Incorrect number','Please classify the client and carryout location according to the case.',1,NULL,NULL,'FAILED','ACTIVE',2001),(1011,NULL,0,'PHONE','','','PROMISE_TO_PAY','Promise to pay','We will conduct then the payment commitment for the day  _______ for an amount  _________ .',1,NULL,NULL,NULL,'ACTIVE',2001),(1012,NULL,0,'PHONE','','','PAYMENT_ALLREADY_MADE','Payment already made','Mr./Mrs. ______,<br>our system doesn\'t register the payment of the month ____, for an amount of $_____, if your payment was done or deducted please send us the corresponding payslips in order to apply them on our system.<br> This information can be sent to the mail ______ or via fax: 8050052 specifying the account holder name and ID.',1,NULL,NULL,NULL,'ACTIVE',2001),(1013,NULL,0,'PHONE','','','REFUSES_TO_PAY','Refuses to pay','We understand your situation at this moment but I remind you that the loan with COOP MICROCREDITO is a financial obligation which you signed and accepted.<br> Likewise this loan is generating arrears charges, negative reports on credit bureau and taking in to account the arrears days and balance a pre legal collection process will initiate.',1,NULL,NULL,NULL,'ACTIVE',2001),(1014,NULL,0,'PHONE','','','PAYMENTS_NOT_CLEARED','Payments not cleared','Thank you very much for you attention remember you spoke with ______ from COOP MICROCREDITO have a great day.',1,NULL,NULL,NULL,'ACTIVE',2001),(1015,NULL,0,'PHONE','','','CLIENT_INSOLVENT','Client insolvent','We will keep aware of the delivery of the documents that support your economical situation in order to initiate the process of validation.',1,NULL,NULL,NULL,'ACTIVE',2001),(1016,NULL,0,'PHONE','','','INITIATE_LEGAL_ACTION_INSTRUCTION','Initiate legal action instruction','Please start legal proceedings.',1,NULL,NULL,NULL,'ACTIVE',2001),(1017,NULL,0,'PHONE','','','PAYMENTS_FOUND','Payments found','Mr./Mrs.________<br>We are sorry we found your payment in our system. Apologies.',1,NULL,NULL,NULL,'ACTIVE',2001),(1018,NULL,0,'PHONE','','','CLIENT_SOLVENT','Client solvent','Remember you have an obligation with COOP MICROCREDITO and to the date the loan is still in arrears.<br>I notify you that if a payment agreement is not done on this month it will generate an arrears charge, negative reports to credit bureau and taking in to account the arrears days and balance a pre legal process will initiate.<br> It is very important for you to pay as soon as possible.',1,NULL,NULL,NULL,'ACTIVE',2001),(1019,NULL,0,'PHONE','','','CLIENT_UP_TO_DATE','Client up to date','Mr./Mrs._______ <br>We are sorry we found your payment in our system. Apologies.',1,NULL,NULL,NULL,'ACTIVE',2001),(1020,NULL,0,'PHONE','','','CLIENT_RELENTS','Client relents','Remember that the loan is already presenting arrears, which generates arrears interests and the payment must be done before the next installment is due.<br>On this case it is necessary to carry out the payment of the installment over the counter on Banco Colpatria account 161-002-224 the amount to be paid is $____ which must be done before ______.<br>I remind you that the receipt of bank deposit receipt must be sent to the mail _____ or fax No. 8050052 with name and ID in order to update the payment information.',1,NULL,NULL,NULL,'ACTIVE',2001),(1021,NULL,0,'PHONE','','','CLIENT_STILL_IN_ARREARS','Client still in arrears','On this case it is necessary to carry out the remaining payment of the arrears over the counter on Banco Colpatria account 161-002-224 the amount to be paid $____ which must be done before ______.<br>I remind you that the receipt of bank deposit receipt must be sent to the mail _____ or fax No. 8050052 with name and ID in order to update the payment information.',1,NULL,NULL,NULL,'ACTIVE',2001),(1022,NULL,0,'PHONE','','','PAYMENTS_CLEARED','Payments cleared','Mr./Mrs. ____ can you please confirm me the date in which the payment was done, the bank and amount in order to carry out the validation.',1,NULL,NULL,NULL,'ACTIVE',2001),(1023,NULL,0,'PHONE','','','PAYMENTS_NOT_FOUND','Payments not found','Mr./Mrs. ______, our system doesn\'t register your payment of the month ____, if your payment was done or deducted please send us the corresponding payslips in order to apply them on our system.<br>This information can be sent to the mail ______ or via fax: 8050052 specifying the account holder name and ID.',1,NULL,NULL,NULL,'ACTIVE',2001),(1024,NULL,0,'PHONE','','','CLIENT_STILL_REFUSES','Client still refuses','Remember you have an obligation with COOP MICROCREDITO and to the date the loan is still in arrears.<br>I notify you that if a payment agreement is not done on this month it will generate an arrear charge, negative reports to credit bureau and taking in to acount the arrears days and balance a pre legal proces will initiate.<br>It is very important for you to pay as soon as possible.',1,NULL,NULL,NULL,'ACTIVE',2001),(1025,NULL,0,'PHONE','','','VOICE_MAIL','Voice mail','Good morning/afternoon/evening you\'re speaking to ---- from COOP MICROCREDITO this message is for Mr. ----- in order to notify that your obligation is in arrears.<br>Please immediately contact us on 6170711 ext. --- thank you.',1,NULL,NULL,NULL,'ACTIVE',2001),(1026,NULL,0,'PHONE','','','CALL_ON_SUGGESTED_TIME','Call on suggested time','Please note down the suggested time and try again at suggested time.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2001),(1027,NULL,0,'PHONE','','','NO_SUGGESTED_TIME','No suggested time','Time Not suggested.<br>Please end the call.',1,NULL,NULL,'IN_PROGRESS','ACTIVE',2001),(1028,NULL,0,'PHONE','','','LEAVE_MESSAGE','Leave message','This is  ___ from COOP MICROCREDITO, Please contact COOP MICROCREDITO immediately. <br>Thank You.',1,NULL,NULL,NULL,'ACTIVE',2001),(1029,NULL,0,'PHONE','','','END_SCRIPT','End call','Thank you very much for you attention remember you spoke with ______ from COOP MICROCREDITO have a great day.',1,NULL,NULL,NULL,'ACTIVE',2001),(1030,NULL,0,'PHONE','','','END_STATE','End','--End--',1,NULL,NULL,'FINISH','INACTIVE',2001),(1201,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to you by ______________, the payment list sent by the employer does not register the instalment deduction on the payroll.',1,'1','PRIMARY',NULL,'ACTIVE',2001),(1202,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','Your payments must be done on the checking account No. ___________ of the ____________ on behalf of FIMSA S.A.S indicating on the Ref. 1, ________ID number.<br> Once the payment is done please send a copy of the bank deposit to the fax No. 8-050052 in Bogota, or to the email cobranza@bayport.com.co',1,'2','PRIMARY',NULL,'ACTIVE',2001),(1203,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','I remind you that your arrear is currently reflected on the credit bureau, as a negative indicator to your credit life, for which its important to improve the qualification through the payment and avoid the initiation of a legal process which will make you engage on additional expenses!',1,'3','PRIMARY',NULL,'ACTIVE',2001),(1301,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to __________ by ______________, of which you are the co debtor.<br> The payment list sent by the employer does not register the installment deduction on the payroll of the account holder, by which we are calling you in order to report that the pay roll deduction loan No. ___ has an arrear of ____. On this case a payment of $____ must be done.',1,'1','GUARANTOR',NULL,'ACTIVE',2001),(1302,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to __________ by ______________, of which you are the co debtor.<br> The payment list sent by the employer does not register the installment deduction on the payroll of the account holder, by which we are calling you in order to report that the pay roll deduction loan No. ___ has an arrear of ____. On this case a payment of $____ must be done.',1,'2','GUARANTOR',NULL,'ACTIVE',2001),(1303,NULL,0,'PHONE','','','CLIENT_AVAILABLE','Client available','My phone call is regarding the pay roll deduction loan granted to __________ by ______________, of which you are the co debtor.<br> The payment list sent by the employer does not register the installment deduction on the payroll of the account holder, by which we are calling you in order to report that the pay roll deduction loan No. ___ has an arrear of ____. On this case a payment of $____ must be done.',1,'3','GUARANTOR',NULL,'ACTIVE',2001),(2001,NULL,0,'EMAIL','','','EMAIL','Email','Please Copy Below Email Template and mail it to Client:<br><br>Dear Customer,<br><br>Good Day,<p>Supporting you with negotiation options, is our best opportunity to show you our commitment. It is of our interest to offer you the necessary alternatives in order to normalize your loan.<br>We notify that your pay roll deduction loan originated with BAYPORT-FIMSA S.A is in arrears.<br>We have tried several times to contact you on the contact numbers supplied in order to have a payment solution and to the date this has not been possible.<br>We will appreciate you to communicate yourself immediately to our care line 7458920, extensions 114-115, 301-651-48-46, where one of our agents will give you the loan information.<br>Your commercial image is very important, remember that all arrear has a report to the Credit Bureau!<br></p>Best Regards,<br>BAYPORT FIMSA.',2,NULL,NULL,NULL,'ACTIVE',2000),(2002,NULL,0,'EMAIL','','','EMAIL_SENT','Email sent','--Thank you--',2,NULL,NULL,'FINISH','INACTIVE',2000),(2101,NULL,0,'SEND_LETTER','','','SEND_LETTER','Send letter','Please Print Letter and deliver it to the debtor\'s/guarantor\'s address.',3,NULL,NULL,NULL,'ACTIVE',2000),(2102,NULL,0,'SEND_LETTER','','','LETTER_SENT','Letter sent','--Thank you--',3,NULL,NULL,'IN_PROGRESS','INACTIVE',2000),(2103,NULL,0,'SEND_LETTER','','','LETTER_DELIVERED','Letter delivered','--Thank you--',3,NULL,NULL,'FINISH','INACTIVE',2000),(2104,NULL,0,'SEND_LETTER','','','LETTER_NOT_DELIVERED','Letter not delivered','--Thank you--',3,NULL,NULL,'FINISH','INACTIVE',2000),(2201,NULL,0,'VISIT_DEBTOR','','','VISIT_DEBTOR','Visit debtor','Please send this client to personal visit.',4,NULL,NULL,'FINISH','INACTIVE',2000),(2202,NULL,0,'VISIT_DEBTOR','','','VISIT_SUCCESSFUL','Visit successful','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2000),(2203,NULL,0,'VISIT_DEBTOR','','','INVALID_ADDRESS','Invalid address','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2000),(2204,NULL,0,'VISIT_DEBTOR','','','CLIENT_NOT_AT_ADDRESS','Client not at address','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2000),(2205,NULL,0,'VISIT_DEBTOR','','','CLIENT_NOT_AT_HOME','Client not at home','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2000),(2206,NULL,0,'VISIT_DEBTOR','','','VISIT_CLIENT_DECEASED','Client deceased','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2000),(2207,NULL,0,'VISIT_DEBTOR','','','VISITING_AGENT_DISPATCHED','Visiting agent dispatched','--Thank you--',4,NULL,NULL,'IN_PROGRESS','INACTIVE',2000),(2208,NULL,0,'VISIT_DEBTOR','','','OTHER','Unsuccessful/other','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2000),(2301,NULL,0,'LIST_DEBTOR_WITH_CB','','','LIST_DEBTOR_WITH_CB','List with Credit Bureau','Please add the Credit Bureau with which Client has been registered.',5,NULL,NULL,NULL,'ACTIVE',2000),(2302,NULL,0,'REGISTRATION_FAILED_DUMMY_OUTCOME','','','REGISTRATION_FAILED','Registered with Credit bureau','Credit bureau registration completed',5,NULL,NULL,'FINISH','INACTIVE',2000),(2303,NULL,0,'REGISTRATION_SUCCESSFUL_DUMMY_OUTCOME','','','REGISTRATION_SUCCESSFUL','Registered with Credit bureau','Credit bureau registration completed',5,NULL,NULL,'FINISH','INACTIVE',2000),(2351,NULL,0,'SETTLE_DEBTOR','','','SETTLE_DEBTOR','Settle debtor','Ask debtor/guarantor to settle the loan and capture the response.',5,NULL,NULL,NULL,'ACTIVE',2000),(2352,NULL,0,'SETTLE_DEBTOR','','','DEBT_SETTLED','Debt settled','--Thank you--',5,NULL,NULL,'DEBT_SETTLED','INACTIVE',2000),(2353,NULL,0,'SETTLE_DEBTOR','','','DEBT_NOT_SETTLED','Debt not settled','--Thank you--',5,NULL,NULL,'DEBT_NOT_SETTLED','INACTIVE',2000),(2401,NULL,0,'PRE_LEGAL','','','PRE_LEGAL','Pre legal','Please print letter, documents depending on debtor type (debtor/guarantor) and hand it over to pre-legal dept.',5,NULL,NULL,NULL,'ACTIVE',2000),(2402,NULL,0,'PRE_LEGAL','','','AWAITING_DECISION','Awaiting decision','--Thank you--',5,NULL,NULL,'IN_PROGRESS','INACTIVE',2000),(2403,NULL,0,'PRE_LEGAL','','','PRE_LEGAL_SUE_DEBTOR','Sue Debtor','Please initiate Sue Debtor process.',5,NULL,NULL,'SUE_DEBTOR','INACTIVE',2000),(2404,NULL,0,'PRE_LEGAL','','','DO_NOT_SUE_DEBTOR','Do not Sue Debtor','--Thank you--',5,NULL,NULL,'DO_NOT_SUE_DEBTOR','INACTIVE',2000),(2451,NULL,0,'SUE_DEBTOR','','','SUE_DEBTOR','Sue debtor','Please start with Sue Debtor process and capture the outcome.',5,NULL,NULL,NULL,'ACTIVE',2000),(2452,NULL,0,'SUE_DEBTOR','','','SUE_IN_PROGRESS','In progress','--Thank you--',5,NULL,NULL,'IN_PROGRESS','INACTIVE',2000),(2453,NULL,0,'SUE_DEBTOR','','','SUE_SUCCESSFUL','Sue successful','--Thank you--',5,NULL,NULL,'SUE_SUCCESSFUL','INACTIVE',2000),(2454,NULL,0,'SUE_DEBTOR','','','SUE_FAILED','Sue failed','--Thank you--',5,NULL,NULL,'SUE_FAILED','INACTIVE',2000),(2501,NULL,0,'SELL_WRITE_OFF','','','SELL_WRITE_OFF','Sell Write OFF','Please print letter, documents and hand it over to pre-legal dept. (Debtor/Guarantor)',5,NULL,NULL,NULL,'ACTIVE',2000),(2502,NULL,0,'SELL_WRITE_OFF','','','SELL_WRITE_IN_PROGRESS','In progress','--Thank you--',5,NULL,NULL,'IN_PROGRESS','INACTIVE',2000),(2503,NULL,0,'SELL_WRITE_OFF','','','SOLD','Sold','--Thank you--',5,NULL,NULL,'FINISH','INACTIVE',2000),(2504,NULL,0,'SELL_WRITE_OFF','','','WRITE_OFF','Written Off','--Thank you--',5,NULL,NULL,NULL,'INACTIVE',2000),(3001,NULL,0,'EMAIL','','','EMAIL','Email','Please Copy Below Email Template and mail it to Client:<br><br>Dear Customer,<br><br>Good Day,<p>Supporting you with negotiation options, is our best opportunity to show you our commitment. It is of our interest to offer you the necessary alternatives in order to normalize your loan.<br>We notify that your pay roll deduction loan originated with COOP MICROCREDITO is in arrears.<br>We have tried several times to contact you on the contact numbers supplied in order to have a payment solution and to the date this has not been possible.<br>We will appreciate you to communicate yourself immediately to our care line 7458920, extensions 114-115, 301-651-48-46, where one of our agents will give you the loan information.<br>Your commercial image is very important, remember that all arrear has a report to the Credit Bureau!<br></p>Best Regards,<br>COOP MICROCREDITO.',2,NULL,NULL,NULL,'ACTIVE',2001),(3002,NULL,0,'EMAIL','','','EMAIL_SENT','Email sent','--Thank you--',2,NULL,NULL,'FINISH','INACTIVE',2001),(3101,NULL,0,'SEND_LETTER','','','SEND_LETTER','Send letter','Please Print Letter and deliver it to the debtor\'s/guarantor\'s address.',3,NULL,NULL,NULL,'ACTIVE',2001),(3102,NULL,0,'SEND_LETTER','','','LETTER_SENT','Letter sent','--Thank you--',3,NULL,NULL,'IN_PROGRESS','INACTIVE',2001),(3103,NULL,0,'SEND_LETTER','','','LETTER_DELIVERED','Letter delivered','--Thank you--',3,NULL,NULL,'FINISH','INACTIVE',2001),(3104,NULL,0,'SEND_LETTER','','','LETTER_NOT_DELIVERED','Letter not delivered','--Thank you--',3,NULL,NULL,'FINISH','INACTIVE',2001),(3201,NULL,0,'VISIT_DEBTOR','','','VISIT_DEBTOR','Visit debtor','Please send this client to personal visit.',4,NULL,NULL,'FINISH','INACTIVE',2001),(3202,NULL,0,'VISIT_DEBTOR','','','VISIT_SUCCESSFUL','Visit successful','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2001),(3203,NULL,0,'VISIT_DEBTOR','','','INVALID_ADDRESS','Invalid address','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2001),(3204,NULL,0,'VISIT_DEBTOR','','','CLIENT_NOT_AT_ADDRESS','Client not at address','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2001),(3205,NULL,0,'VISIT_DEBTOR','','','CLIENT_NOT_AT_HOME','Client not at home','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2001),(3206,NULL,0,'VISIT_DEBTOR','','','VISIT_CLIENT_DECEASED','Client deceased','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2001),(3207,NULL,0,'VISIT_DEBTOR','','','VISITING_AGENT_DISPATCHED','Visiting agent dispatched','--Thank you--',4,NULL,NULL,'IN_PROGRESS','INACTIVE',2001),(3208,NULL,0,'VISIT_DEBTOR','','','OTHER','Unsuccessful/other','--Thank you--',4,NULL,NULL,'FINISH','INACTIVE',2001),(3301,NULL,0,'LIST_DEBTOR_WITH_CB','','','LIST_DEBTOR_WITH_CB','List with Credit Bureau','Please add the Credit Bureau with which Client has been registered.',5,NULL,NULL,NULL,'ACTIVE',2001),(3302,NULL,0,'REGISTRATION_FAILED_DUMMY_OUTCOME','','','REGISTRATION_FAILED','Registered with Credit bureau','Credit bureau registration completed',5,NULL,NULL,'FINISH','INACTIVE',2001),(3303,NULL,0,'REGISTRATION_SUCCESSFUL_DUMMY_OUTCOME','','','REGISTRATION_SUCCESSFUL','Registered with Credit bureau','Credit bureau registration completed',5,NULL,NULL,'FINISH','INACTIVE',2001),(3351,NULL,0,'SETTLE_DEBTOR','','','SETTLE_DEBTOR','Settle debtor','Ask debtor/guarantor to settle the loan and capture the response.',5,NULL,NULL,NULL,'ACTIVE',2001),(3352,NULL,0,'SETTLE_DEBTOR','','','DEBT_SETTLED','Debt settled','--Thank you--',5,NULL,NULL,'DEBT_SETTLED','INACTIVE',2001),(3353,NULL,0,'SETTLE_DEBTOR','','','DEBT_NOT_SETTLED','Debt not settled','--Thank you--',5,NULL,NULL,'DEBT_NOT_SETTLED','INACTIVE',2001),(3401,NULL,0,'PRE_LEGAL','','','PRE_LEGAL','Pre legal','Please print letter, documents depending on debtor type (debtor/guarantor) and hand it over to pre-legal dept.',5,NULL,NULL,NULL,'ACTIVE',2001),(3402,NULL,0,'PRE_LEGAL','','','AWAITING_DECISION','Awaiting decision','--Thank you--',5,NULL,NULL,'IN_PROGRESS','INACTIVE',2001),(3403,NULL,0,'PRE_LEGAL','','','PRE_LEGAL_SUE_DEBTOR','Sue Debtor','Please initiate Sue Debtor process.',5,NULL,NULL,'SUE_DEBTOR','INACTIVE',2001),(3404,NULL,0,'PRE_LEGAL','','','DO_NOT_SUE_DEBTOR','Do not Sue Debtor','--Thank you--',5,NULL,NULL,'DO_NOT_SUE_DEBTOR','INACTIVE',2001),(3451,NULL,0,'SUE_DEBTOR','','','SUE_DEBTOR','Sue debtor','Please start with Sue Debtor process and capture the outcome.',5,NULL,NULL,NULL,'ACTIVE',2001),(3452,NULL,0,'SUE_DEBTOR','','','SUE_IN_PROGRESS','In progress','--Thank you--',5,NULL,NULL,'IN_PROGRESS','INACTIVE',2001),(3453,NULL,0,'SUE_DEBTOR','','','SUE_SUCCESSFUL','Sue successful','--Thank you--',5,NULL,NULL,'SUE_SUCCESSFUL','INACTIVE',2001),(3454,NULL,0,'SUE_DEBTOR','','','SUE_FAILED','Sue failed','--Thank you--',5,NULL,NULL,'SUE_FAILED','INACTIVE',2001),(3501,NULL,0,'SELL_WRITE_OFF','','','SELL_WRITE_OFF','Sell Write OFF','Please print letter, documents and hand it over to pre-legal dept. (Debtor/Guarantor)',5,NULL,NULL,NULL,'ACTIVE',2001),(3502,NULL,0,'SELL_WRITE_OFF','','','SELL_WRITE_IN_PROGRESS','In progress','--Thank you--',5,NULL,NULL,'IN_PROGRESS','INACTIVE',2001),(3503,NULL,0,'SELL_WRITE_OFF','','','SOLD','Sold','--Thank you--',5,NULL,NULL,'FINISH','INACTIVE',2001),(3504,NULL,0,'SELL_WRITE_OFF','','','WRITE_OFF','Written Off','--Thank you--',5,NULL,NULL,NULL,'INACTIVE',2001);
/*!40000 ALTER TABLE `contact_script_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `contact_script_template_aud`
--

LOCK TABLES `contact_script_template_aud` WRITE;
/*!40000 ALTER TABLE `contact_script_template_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_script_template_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `hibernate_sequences`
--

LOCK TABLES `hibernate_sequences` WRITE;
/*!40000 ALTER TABLE `hibernate_sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `hibernate_sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `lookup_index`
--

LOCK TABLES `lookup_index` WRITE;
/*!40000 ALTER TABLE `lookup_index` DISABLE KEYS */;
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`) VALUES (50,'sharad',0,'com.qualica.flexifin.collections.domain.CollectionInstanceSeverity','CollectionInstanceSeverity',NULL,NULL),(51,'sharad',0,'com.qualica.flexifin.collections.domain.CollectionCaseStatus','CollectionCaseStatus',NULL,NULL),(52,'sharad',0,'com.qualica.flexifin.collections.domain.CollectionCaseStatusReason','CollectionCaseStatusReason','collectionCaseStatus',51),(53,'sharad',0,'com.qualica.flexifin.collections.domain.CollectionInstanceStatus','CollectionInstanceStatus',NULL,NULL),(54,'sharad',0,'com.qualica.flexifin.collections.domain.CollectionInstanceStatusReason','CollectionInstanceStatusReason','collectionInstanceStatus',53),(55,'sharad',0,'com.qualica.flexifin.collections.domain.ContactAttemptType','ContactAttemptType',NULL,NULL);
/*!40000 ALTER TABLE `lookup_index` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product_collection_discount`
--

LOCK TABLES `product_collection_discount` WRITE;
/*!40000 ALTER TABLE `product_collection_discount` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_collection_discount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `product_collection_discount_aud`
--

LOCK TABLES `product_collection_discount_aud` WRITE;
/*!40000 ALTER TABLE `product_collection_discount_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_collection_discount_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `revinfo`
--

LOCK TABLES `revinfo` WRITE;
/*!40000 ALTER TABLE `revinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `revinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `workflow_exception`
--

LOCK TABLES `workflow_exception` WRITE;
/*!40000 ALTER TABLE `workflow_exception` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_exception` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `workflow_exception_aud`
--

LOCK TABLES `workflow_exception_aud` WRITE;
/*!40000 ALTER TABLE `workflow_exception_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_exception_aud` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `workflow_exception_log`
--

LOCK TABLES `workflow_exception_log` WRITE;
/*!40000 ALTER TABLE `workflow_exception_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_exception_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `workflow_exception_log_aud`
--

LOCK TABLES `workflow_exception_log_aud` WRITE;
/*!40000 ALTER TABLE `workflow_exception_log_aud` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_exception_log_aud` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 16:08:44
