use masterdata;
UPDATE `masterdata`.`payslip_line_item_type` SET `name`='Ingreso' WHERE `id`='1';
UPDATE `masterdata`.`payslip_line_item_type` SET `name`='Egreso' WHERE `id`='2';
UPDATE `masterdata`.`payslip_line_item_type` SET `description`='Ingreso' WHERE `id`='1';
UPDATE `masterdata`.`payslip_line_item_type` SET `description`='Egreso' WHERE `id`='2';