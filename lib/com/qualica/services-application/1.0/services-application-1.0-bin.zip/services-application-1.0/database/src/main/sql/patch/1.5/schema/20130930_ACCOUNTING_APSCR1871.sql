USE accounting;

ALTER TABLE receipt_allocation CHANGE COLUMN post_date post_date DATE DEFAULT NULL;
ALTER TABLE receipt_allocation_aud CHANGE COLUMN post_date post_date DATE DEFAULT NULL;
