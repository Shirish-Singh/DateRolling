use masterdata;
SET character_set_client = utf8;
-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: masterdata
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


LOCK TABLES `title` WRITE;
/*!40000 ALTER TABLE `title` DISABLE KEYS */;
UPDATE title SET enabled = false WHERE id = 1003;
UPDATE title SET enabled = false WHERE id = 1004;
/*!40000 ALTER TABLE `title` ENABLE KEYS */;
UNLOCK TABLES;



LOCK TABLES `application_approval_status` WRITE;
/*!40000 ALTER TABLE `application_approval_status` DISABLE KEYS */;
UPDATE application_approval_status SET id = 0, modified_by = 'static', version = 0, description = 'Nueva Originacion', enabled = true, name = 'origination_new' WHERE id = 0;
UPDATE application_approval_status SET id = 1, modified_by = 'static', version = 0, description = 'Revision Pendiente', enabled = true, name = 'review_pending' WHERE id = 1;
UPDATE application_approval_status SET id = 2, modified_by = 'static', version = 0, description = 'Credito Pendiente', enabled = true, name = 'underwriting_pending' WHERE id = 2;
UPDATE application_approval_status SET id = 3, modified_by = 'static', version = 0, description = 'En Recuperacion', enabled = true, name = 'recovery' WHERE id = 3;
UPDATE application_approval_status SET id = 4, modified_by = 'static', version = 0, description = 'Recuperacion Fallida', enabled = true, name = 'recovery_failed' WHERE id = 4;
UPDATE application_approval_status SET id = 5, modified_by = 'static', version = 0, description = 'Aprobado', enabled = true, name = 'approved' WHERE id = 5;
UPDATE application_approval_status SET id = 6, modified_by = 'static', version = 0, description = 'Negado', enabled = true, name = 'rejected' WHERE id = 6;
UPDATE application_approval_status SET id = 7, modified_by = 'static', version = 0, description = 'Cancelado', enabled = true, name = 'cancelled' WHERE id = 7;
/*!40000 ALTER TABLE `application_approval_status` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `bank_type` WRITE;
/*!40000 ALTER TABLE `bank_type` DISABLE KEYS */;
UPDATE bank_type SET id = 1001, modified_by = null, version = 0, description = 'Banco', enabled = true, name = 'Banco' WHERE id = 1001;
Delete from bank_type where id =1002;
INSERT INTO `masterdata`.`bank_type` (`id`, `modified_by`, `version`, `description`, `name`,`enabled`) VALUES (1002, NULL, 0, 'Entidad compras de cartera', 'Entidad compras de cartera',1);
/*!40000 ALTER TABLE `bank_type` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `agent_type` WRITE;
/*!40000 ALTER TABLE `agent_type` DISABLE KEYS */;
UPDATE agent_type SET id = 1001, modified_by = null, version = 0, description = 'Asesor Externo', enabled = true, name = 'Asesor Externo', level = 1 WHERE id = 1001;
UPDATE agent_type SET id = 1002, modified_by = null, version = 0, description = 'Asesor Interno', enabled = true, name = 'Asesor Interno', level = 1 WHERE id = 1002;
UPDATE agent_type SET id = 1003, modified_by = null, version = 0, description = 'Coordinador Comercial', enabled = true, name = 'Coordinador Comercial', level = 1 WHERE id = 1003;
UPDATE agent_type SET id = 1004, modified_by = null, version = 0, description = 'Coordinador Regional', enabled = true, name = 'Coordinador Regional', level = 1 WHERE id = 1004;
UPDATE agent_type SET id = 1005, modified_by = null, version = 0, description = 'Director Regional', enabled = true, name = 'Director Regional', level = 1 WHERE id = 1005;

DELETE from agent_type where id = 1006;

INSERT INTO agent_type (id, modified_by, version, description, enabled, name, level) VALUES (1006, null, 0, 'Asesor Junior', true, 'Asesor Junior', 1);

/*!40000 ALTER TABLE `agent_type` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `document_type` WRITE;
/*!40000 ALTER TABLE `document_type` DISABLE KEYS */;

UPDATE document_type SET id = 1, modified_by = '102_lookups.sql', version = 0, description = 'Cédula de ciudadanía', enabled = true, name = 'Cédula de ciudadanía' WHERE id = 1;
UPDATE document_type SET id = 2, modified_by = '102_lookups.sql', version = 0, description = 'Cédula de extranjeria' , enabled = true, name = 'Cédula de extranjeria' WHERE id = 2;
UPDATE document_type SET id = 3, modified_by = '102_lookups.sql', version = 0, description = null, enabled = false, name = 'IdDocument' WHERE id = 3;
UPDATE document_type SET id = 4, modified_by = '102_lookups.sql', version = 0, description = null, enabled = false, name = 'IdPhoto' WHERE id = 4;
UPDATE document_type SET id = 5, modified_by = '102_lookups.sql', version = 0, description = null, enabled = false, name = 'LoanContract' WHERE id = 5;
UPDATE document_type SET id = 6, modified_by = '102_lookups.sql', version = 0, description = null, enabled = false, name = 'MarriageCertificate' WHERE id = 6;
UPDATE document_type SET id = 7, modified_by = '102_lookups.sql', version = 0, description = null, enabled = false, name = 'Payslip' WHERE id = 7;
UPDATE document_type SET id = 8, modified_by = '102_lookups.sql', version = 0, description = null, enabled = false, name = 'SupportingLetter' WHERE id = 8;
/*!40000 ALTER TABLE `document_type` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `employer_application_status_reason` WRITE;
/*!40000 ALTER TABLE `employer_application_status_reason` DISABLE KEYS */;


UPDATE employer_application_status_reason SET enabled = false WHERE id = 0;
UPDATE employer_application_status_reason SET enabled = false WHERE id = 1;

delete from   employer_application_status_reason where id in (2,3,4,5,6,7,8,9,10,11,12,13,14);

INSERT INTO `employer_application_status_reason` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES
(2,'static',0,'Numero de empleados insuficiente',1,'Numero de empleados insuficiente'),
(3,'static',0,'UbicaciÃ³n inaccesible',1,'UbicaciÃ³n inaccesible'),
(4,'static',0,'InformaciÃ³n especÃ­fica de las libranzas limitadas',1,'InformaciÃ³n especÃ­fica de las libranzas limitadas'),
(5,'static',0,'Sin ley 550',1,'Sin ley 550'),
(6,'static',0,'Sin investigaciÃ³n en lavado de activos',1,'Sin investigaciÃ³n en lavado de activos'),
(7,'static',0,'Sin investigaciÃ³n en lavado de activos',1,'Sin investigaciÃ³n en lavado de activos'),
(8,'static',0,'Fecha de fundaciÃ³n menor a 3 aÃ±os de antigÃ¼edad',1,'Fecha de fundaciÃ³n menor a 3 aÃ±os de antigÃ¼edad'),
(9,'static',0,'PagadurÃ­a en liquidaciÃ³n',1,'PagadurÃ­a en liquidaciÃ³n'),
(10,'static',0,'PagadurÃ­a fondo de empleados',1,'PagadurÃ­a fondo de empleados'),
(11,'static',0,'Hospital',1,'Hospital'),
(12,'static',0,'Cooperativa de trabajo asociado',1,'Cooperativa de trabajo asociado'),
(13,'static',0,'Sindicales',1,'Sindicales'),
(14,'static',0,'CÃ³digo cerrado',1,'CÃ³digo cerrado');

/*!40000 ALTER TABLE `employer_application_status_reason` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `lawyer` WRITE;
/*!40000 ALTER TABLE `lawyer` DISABLE KEYS */;
Delete from lawyer where id in (1,2);

INSERT INTO masterdata.lawyer (id, modified_by, version, description, enabled, name) VALUES
(1, 'sameer', 0, 'Alfredo Rojas ', true, 'Alfredo Rojas '),
(2, 'sameer', 0, 'Karen Echeverria', true, 'Karen Echeverria');
/*!40000 ALTER TABLE `lawyer` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `trading_entity` WRITE;
/*!40000 ALTER TABLE `trading_entity` DISABLE KEYS */;
UPDATE trading_entity SET id = 2000, entity_identifier = 'Bayport' WHERE id = 2000;
UPDATE trading_entity SET id = 2001, entity_identifier = 'CoopmicrocrÃ©dito' WHERE id = 2001;
/*!40000 ALTER TABLE `trading_entity` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `education_level` WRITE;
/*!40000 ALTER TABLE `education_level` DISABLE KEYS */;
Delete from education_level where id =1007;
INSERT INTO `masterdata`.`education_level`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1007',0,'Doctorado','Doctorado',1);
/*!40000 ALTER TABLE `education_level` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `contact_number_type` WRITE;
/*!40000 ALTER TABLE `contact_number_type` DISABLE KEYS */;
UPDATE masterdata.contact_number_type SET enabled = false WHERE id = 1005;

Delete from masterdata.contact_number_type where id =1006;
INSERT INTO masterdata.contact_number_type (id, modified_by, version, description, enabled, name) VALUES (1006, null, 0, 'fijo', true, 'fijo');

/*!40000 ALTER TABLE `contact_number_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping data for table `residence_type`
--

LOCK TABLES `residence_type` WRITE;
/*!40000 ALTER TABLE `residence_type` DISABLE KEYS */;
Delete from residence_type where id = 1003;
INSERT INTO `masterdata`.`residence_type`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'Finca','Finca',1);
/*!40000 ALTER TABLE `residence_type` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `resident_status` WRITE;
/*!40000 ALTER TABLE `resident_status` DISABLE KEYS */;
Delete from resident_status where id = 1004;

INSERT INTO `masterdata`.`resident_status`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'No aplica','No aplica',1);
/*!40000 ALTER TABLE `resident_status` ENABLE KEYS */;
UNLOCK TABLES;



LOCK TABLES `address_type` WRITE;
/*!40000 ALTER TABLE `address_type` DISABLE KEYS */;
Delete from address_type where id =1003;
UPDATE masterdata.address_type SET id = 1001, modified_by = null, version = 0, description = 'Residencia', enabled = true, name = 'Residencia' WHERE id = 1001;
UPDATE masterdata.address_type SET id = 1002, modified_by = null, version = 0, description = 'Oficina', enabled = true, name = 'Oficina' WHERE id = 1002;
/*!40000 ALTER TABLE `address_type` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `job_position` WRITE;
/*!40000 ALTER TABLE `job_position` DISABLE KEYS */;
UPDATE job_position SET enabled = false WHERE id BETWEEN  1001 And 1068;
DELETE from job_position where id BETWEEN 1069 And 1178;
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1069,'0','ADMINISTRADOR DE NOMINA','ADMINISTRADOR DE NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1070,'0','ANALISTA DE NOMINA','ANALISTA DE NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1071,'0','ANALISTA EJECUTOR NOMINA','ANALISTA EJECUTOR NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1072,'0','AREA DE CERTIFICACIONES','AREA DE CERTIFICACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1073,'0','ASISTENTE DE GESTION HUMANA','ASISTENTE DE GESTION HUMANA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1074,'0','ASISTENTE FORENSE','ASISTENTE FORENSE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1075,'0','AUXILIAR ADMINISTRATIVO','AUXILIAR ADMINISTRATIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1076,'0','AUXILIAR ADMINISTRATIVO - NOMINA','AUXILIAR ADMINISTRATIVO - NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1077,'0','COORDINADOR NOMINA','COORDINADOR NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1078,'0','COORDINADOR AREA DE TALENTO HUMANO','COORDINADOR AREA DE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1079,'0','COORDINADOR AREA FINANCIERA','COORDINADOR AREA FINANCIERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1080,'0','DEPARTAMENTO NOMINA','DEPARTAMENTO NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1081,'0','DIRECTOR','DIRECTOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1082,'0','DIRECTOR FONDO PENSIONES','DIRECTOR FONDO PENSIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1083,'0','DIRECTOR REGIONAL','DIRECTOR REGIONAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1084,'0','DIRECTOR SECCIONAL','DIRECTOR SECCIONAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1085,'0','DIRECTOR TECNICO','DIRECTOR TECNICO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1086,'0','DIRECTOR DE TALENTO HUMANO','DIRECTOR DE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1087,'0','GERENTE','GERENTE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1088,'0','GESTOR I','GESTOR I',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1089,'0','INTEGRADOR DE NOMINA','INTEGRADOR DE NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1090,'0','JEFE DE AREA TALENTO HUMANO','JEFE DE AREA TALENTO HUMANO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1091,'0','JEFE DE GESTION ADMINISTRATIVA','JEFE DE GESTION ADMINISTRATIVA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1092,'0','JEFE DE GESTION RECURSOS FISICOS Y FINANCIEROS','JEFE DE GESTION RECURSOS FISICOS Y FINANCIEROS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1093,'0','JEFE DE OFICINA ADMINISTRACIÃ“N','JEFE DE OFICINA ADMINISTRACIÃ“N',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1094,'0','JEFE DE PERSONAL','JEFE DE PERSONAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1095,'0','JEFE DE RECURSOS HUMANOS','JEFE DE RECURSOS HUMANOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1096,'0','JEFE GESTION ADMINISTRATIVA Y FINANCIERA','JEFE GESTION ADMINISTRATIVA Y FINANCIERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1097,'0','JEFE NOMINA','JEFE NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1098,'0','JEFE SECCION NOVEDADES','JEFE SECCION NOVEDADES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1099,'0','LIDER DE PROYECTO','LIDER DE PROYECTO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1100,'0','NOMINA','NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1101,'0','PAGADOR','PAGADOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1102,'0','PAGADOR GENERAL','PAGADOR GENERAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1103,'0','PROFESIONAL ESPECIALIZADO','PROFESIONAL ESPECIALIZADO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1104,'0','PROFESIONAL DE NOMINA','PROFESIONAL DE NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1105,'0','PROFESIONAL DE RECURSOS HUMANOS','PROFESIONAL DE RECURSOS HUMANOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1106,'0','PROFESIONAL TALENTO HUMANO','PROFESIONAL TALENTO HUMANO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1107,'0','PROFESIONAL U. RECURSOS HH','PROFESIONAL U. RECURSOS HH',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1108,'0','PROFESIONAL U.GESTION H.','PROFESIONAL U.GESTION H.',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1109,'0','PROFESIONAL UNIVERSITARIO','PROFESIONAL UNIVERSITARIO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1110,'0','RESPONSABLE TALENTO HUMANO','RESPONSABLE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1111,'0','SECRETARIO DE TALENTO HUMANO','SECRETARIO DE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1112,'0','SUBDIRECTOR DE PRESTACIONES SOCIALES','SUBDIRECTOR DE PRESTACIONES SOCIALES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1113,'0','SUBDIRECTOR','SUBDIRECTOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1114,'0','SUBDIRECTOR DE NOMINA','SUBDIRECTOR DE NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1115,'0','TALENTO HUMANO','TALENTO HUMANO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1116,'0','TECNICO ','TECNICO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1117,'0','TECNICO ADMINISTRATIVO','TECNICO ADMINISTRATIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1118,'0','TECNICO DE NOMINA','TECNICO DE NOMINA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1119,'0','TECNICO FACILITADOR','TECNICO FACILITADOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1120,'0','TECNICO OFICIAL DE RECURSOS HUMANOS','TECNICO OFICIAL DE RECURSOS HUMANOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1121,'0','TECNICO OPERARIO','TECNICO OPERARIO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1122,'0','TECNICO OPERATIVO','TECNICO OPERATIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1123,'0','TESORERO','TESORERO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1124,'0','TESORERO GENERAL','TESORERO GENERAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1125,'0','TESORERO-PAGADOR','TESORERO-PAGADOR',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1126,'0','ABOGADO','ABOGADO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1127,'0','ANALISTA COMPRA DE CARTERA','ANALISTA COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1128,'0','ANALISTA DE CONTROL DE CALIDAD','ANALISTA DE CONTROL DE CALIDAD',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1129,'0','ANALISTA DE CREDITO','ANALISTA DE CREDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1130,'0','ANALISTA DE RECAUDOS','ANALISTA DE RECAUDOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1131,'0','ANALISTA DE REPORTES','ANALISTA DE REPORTES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1132,'0','ANALISTA JUNIOR DE PROYECTOS','ANALISTA JUNIOR DE PROYECTOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1133,'0','ANALISTA SENIOR DE REPORTES','ANALISTA SENIOR DE REPORTES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1134,'0','ASISTENTE CONTABILIDAD','ASISTENTE CONTABILIDAD',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1135,'0','ASISTENTE JUDICIAL','ASISTENTE JUDICIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1136,'0','AUXILIAR ADMINISTRATIVO Y DE COMPRAS','AUXILIAR ADMINISTRATIVO Y DE COMPRAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1137,'0','AUXILIAR COMERCIAL','AUXILIAR COMERCIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1138,'0','AUXILIAR COMPRAS DE CARTERA','AUXILIAR COMPRAS DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1139,'0','AUXILIAR DE ARCHIVO','AUXILIAR DE ARCHIVO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1140,'0','AUXILIAR DE COBRANZAS','AUXILIAR DE COBRANZAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1141,'0','AUXILIAR DE CÓDIGOS','AUXILIAR DE CÓDIGOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1142,'0','AUXILIAR DE CONTABILIDAD','AUXILIAR DE CONTABILIDAD',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1143,'0','AUXILIAR DE CRÉDITO','AUXILIAR DE CRÉDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1144,'0','AUXILIAR DE INCORPORACIONES','AUXILIAR DE INCORPORACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1145,'0','AUXILIAR DE NOVEDADES','AUXILIAR DE NOVEDADES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1146,'0','AUXILIAR DE RECUPERACION','AUXILIAR DE RECUPERACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1147,'0','AUXILIAR DE REFERENCIACION','AUXILIAR DE REFERENCIACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1148,'0','AUXILIAR DE TESORERIA','AUXILIAR DE TESORERIA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1149,'0','AUXILIAR DE TESORERIA','AUXILIAR DE TESORERIA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1150,'0','AUXILIAR DE TESORERIA','AUXILIAR DE TESORERIA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1151,'0','AUXILIAR DE TESORERIA','AUXILIAR DE TESORERIA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1152,'0','AUXILIAR DE VISACION','AUXILIAR DE VISACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1153,'0','CAPACITACION','CAPACITACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1154,'0','COORDINADOR COMERCIAL','COORDINADOR COMERCIAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1155,'0','COORDINADOR COMPRA DE CARTERA','COORDINADOR COMPRA DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1156,'0','COORDINADOR DE CARTERA','COORDINADOR DE CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1157,'0','COORDINADOR DE COBRANZA','COORDINADOR DE COBRANZA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1158,'0','COORDINADOR DE CÓDIGOS','COORDINADOR DE CÓDIGOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1159,'0','COORDINADOR DE CREDITO','COORDINADOR DE CREDITO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1160,'0','COORDINADOR DE TESORERÃA','COORDINADOR DE TESORERÃA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1161,'0','COORDINADOR INCORPORACIONES','COORDINADOR INCORPORACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1162,'0','COORDINADOR SERVICIO AL CLIENTE','COORDINADOR SERVICIO AL CLIENTE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1163,'0','DIRECTOR COMERCIAL REGIONAL','DIRECTOR COMERCIAL REGIONAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1164,'0','DIRECTOR CREDITO Y CARTERA','DIRECTOR CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1165,'0','DIRECTOR DE OPERACIONES','DIRECTOR DE OPERACIONES',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1166,'0','DIRECTOR FINANCIERO','DIRECTOR FINANCIERO',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1167,'0','GERENTE CREDITO Y CARTERA','GERENTE CREDITO Y CARTERA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1168,'0','GERENTE DE INCORPORACIONES Y COBRANZAS','GERENTE DE INCORPORACIONES Y COBRANZAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1169,'0','GERENTE GENERAL','GERENTE GENERAL',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1170,'0','GERENTE NACIONAL DE VENTAS','GERENTE NACIONAL DE VENTAS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1171,'0','JEFE DE CONTABILIDAD','JEFE DE CONTABILIDAD',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1172,'0','LIDER DE CAPACITACION','LIDER DE CAPACITACION',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1173,'0','MANAGEMENT TRAINEE','MANAGEMENT TRAINEE',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1174,'0','MESA DE AYUDA','MESA DE AYUDA',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1175,'0','RECURSOS HUMANOS','RECURSOS HUMANOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1176,'0','SUPERVISOR DE PROCESOS ARCHIVISTICOS','SUPERVISOR DE PROCESOS ARCHIVISTICOS',1);
INSERT INTO `masterdata`.`job_position`(`id`,`version`,`description`,`name`,`enabled`) VALUES (1177,'0','VERIFICADOR DOCUMENTAL','VERIFICADOR DOCUMENTAL',1);
/*!40000 ALTER TABLE `job_position` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `credit_bureau_status` WRITE;
/*!40000 ALTER TABLE `credit_bureau_status` DISABLE KEYS */;

UPDATE masterdata.credit_bureau_status SET enabled = false WHERE id = 4;

/*!40000 ALTER TABLE `credit_bureau_status` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `visiting_agent` WRITE;
/*!40000 ALTER TABLE `visiting_agent` DISABLE KEYS */;

DELETE from visiting_agent where id BETWEEN 1 AND 8;

INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (1, '', 0, 'Julian Alberto Callejas ', true, 'Julian Alberto Callejas ');
INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (2, '', 0, 'Oscar Javier Leguizamon Rey', true, 'Oscar Javier Leguizamon Rey');
INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (3, '', 0, 'Jonathan Ferraro ', true, 'Jonathan Ferraro');
INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (4, '', 0, 'Jeniffer Quintero Fuerte', true, 'Jeniffer Quintero Fuerte');
INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (5, '', 0, 'Jhon Guerrero', true, 'Jhon Guerrero');
INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (6, '', 0, 'Kennys Villalba', true, 'Kennys Villalba');
INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (7, '', 0, 'Paula Carvajal', true, 'Paula Carvajal');
INSERT INTO masterdata.visiting_agent (id, modified_by, version, description, enabled, name) VALUES (8, '', 0, 'Erika AlarcÃ³n', true, 'Erika AlarcÃ³n');

/*!40000 ALTER TABLE `visiting_agent` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `commission_payment_schedule_type` WRITE;
/*!40000 ALTER TABLE `commission_payment_schedule_type` DISABLE KEYS */;
UPDATE masterdata.commission_payment_schedule_type SET id = 1, modified_by = null, version = 0, description = 'Quincenal', enabled = true, name = 'Quincenal' WHERE id = 1;
UPDATE masterdata.commission_payment_schedule_type SET id = 2, modified_by = null, version = 0, description = 'semanal', enabled = true, name = 'semanal' WHERE id = 2;
UPDATE masterdata.commission_payment_schedule_type SET id = 3, modified_by = null, version = 0, description = 'Biannual', enabled = false, name = 'biannual' WHERE id = 3;
UPDATE masterdata.commission_payment_schedule_type SET id = 4, modified_by = null, version = 0, description = 'Annual', enabled = false, name = 'annual' WHERE id = 4;
UPDATE masterdata.commission_payment_schedule_type SET id = 5, modified_by = null, version = 0, description = 'linked to deduction payments', enabled = false, name = 'linked_deduction_payments' WHERE id = 5;
/*!40000 ALTER TABLE `commission_payment_schedule_type` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `commission_type` WRITE;
/*!40000 ALTER TABLE `commission_type` DISABLE KEYS */;
UPDATE masterdata.commission_type SET id = 1, modified_by = null, version = 0, description = 'team commission', enabled = false, name = 'team_commission' WHERE id = 1;
UPDATE masterdata.commission_type SET id = 2, modified_by = null, version = 0, description = 'ComisiÃ³n individual', enabled = true, name = 'ComisiÃ³n individual' WHERE id = 2;
/*!40000 ALTER TABLE `commission_type` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `client_reference_type` WRITE;
/*!40000 ALTER TABLE `client_reference_type` DISABLE KEYS */;
UPDATE masterdata.client_reference_type SET id = 1, modified_by = 'static', version = 0, description = 'Familiar', enabled = true, name = 'Familiar' WHERE id = 1;
UPDATE masterdata.client_reference_type SET id = 2, modified_by = 'static', version = 0, description = 'Personal', enabled = true, name = 'Personal' WHERE id = 2;
UPDATE masterdata.client_reference_type SET id = 3, modified_by = 'static', version = 0, description = 'Father', enabled = false, name = 'father' WHERE id = 3;
/*!40000 ALTER TABLE `client_reference_type` ENABLE KEYS */;
UNLOCK TABLES;





LOCK TABLES `payslip_line_item_type` WRITE;
/*!40000 ALTER TABLE `payslip_line_item_type` DISABLE KEYS */;

UPDATE masterdata.payslip_line_item_type SET id = 1, modified_by = null, version = 0, description = 'Ingreso', enabled = true, name = 'Ingreso' WHERE id = 1;
UPDATE masterdata.payslip_line_item_type SET id = 2, modified_by = null, version = 0, description = 'Egreso', enabled = true, name = 'Egreso' WHERE id = 2;
/*!40000 ALTER TABLE `payslip_line_item_type` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `recovery_reason_category` WRITE;
/*!40000 ALTER TABLE `recovery_reason_category` DISABLE KEYS */;

UPDATE masterdata.recovery_reason_category SET id = 1, modified_by = '102_lookups.sql', version = 1, description = 'Documentación', enabled = true, name = 'Documentación' WHERE id = 1;
UPDATE masterdata.recovery_reason_category SET id = 2, modified_by = '102_lookups.sql', version = 1, description = 'Referenciación', enabled = true, name = 'Referenciación' WHERE id = 2;
UPDATE masterdata.recovery_reason_category SET id = 3, modified_by = '102_lookups.sql', version = 1, description = 'Análisis de Crédito', enabled = true, name = 'Análisis de Crédito' WHERE id = 3;
/*!40000 ALTER TABLE `recovery_reason_category` ENABLE KEYS */;
UNLOCK TABLES;


LOCK TABLES `recovery_results` WRITE;
/*!40000 ALTER TABLE `recovery_results` DISABLE KEYS */;

UPDATE masterdata.recovery_results SET id = 1, modified_by = '102_lookups.sql', version = 0, description = 'Recuperación Exitosa', enabled = true, name = 'Recuperación Exitosa' WHERE id = 1;
UPDATE masterdata.recovery_results SET id = 2, modified_by = '102_lookups.sql', version = 0, description = 'Recuperación No Exitosa', enabled = true, name = 'Recuperación No Exitosa' WHERE id = 2;
/*!40000 ALTER TABLE `recovery_results` ENABLE KEYS */;
UNLOCK TABLES;



LOCK TABLES `occupation` WRITE;
/*!40000 ALTER TABLE `occupation` DISABLE KEYS */;

DELETE from  occupation where id BETWEEN 1001 AND  1061;

INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1001',0,'Empleado','Empleado',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1002',0,'Independiente','Independiente',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1003',0,'No Aplica','No Aplica',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1004',0,'Pensionado','Pensionado',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1005','0','ADMINISTRADOR DE NOMINA','ADMINISTRADOR DE NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1006','0','ANALISTA DE NOMINA','ANALISTA DE NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1007','0','ANALISTA EJECUTOR NOMINA','ANALISTA EJECUTOR NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1008','0','AREA DE CERTIFICACIONES','AREA DE CERTIFICACIONES',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1009','0','ASISTENTE DE GESTION HUMANA','ASISTENTE DE GESTION HUMANA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1010','0','ASISTENTE FORENSE','ASISTENTE FORENSE',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1011','0','AUXILIAR ADMINISTRATIVO','AUXILIAR ADMINISTRATIVO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1012','0','AUXILIAR ADMINISTRATIVO - NOMINA','AUXILIAR ADMINISTRATIVO - NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1013','0','COORDINADOR NOMINA','COORDINADOR NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1014','0','COORDINADOR AREA DE TALENTO HUMANO','COORDINADOR AREA DE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1015','0','COORDINADOR AREA FINANCIERA','COORDINADOR AREA FINANCIERA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1016','0','DEPARTAMENTO NOMINA','DEPARTAMENTO NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1017','0','DIRECTOR','DIRECTOR',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1018','0','DIRECTOR FONDO PENSIONES','DIRECTOR FONDO PENSIONES',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1019','0','DIRECTOR REGIONAL','DIRECTOR REGIONAL',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1020','0','DIRECTOR SECCIONAL','DIRECTOR SECCIONAL',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1021','0','DIRECTOR TECNICO','DIRECTOR TECNICO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1022','0','DIRECTOR DE TALENTO HUMANO','DIRECTOR DE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1023','0','GERENTE','GERENTE',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1024','0','GESTOR I','GESTOR I',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1025','0','INTEGRADOR DE NOMINA','INTEGRADOR DE NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1026','0','JEFE DE AREA TALENTO HUMANO','JEFE DE AREA TALENTO HUMANO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1027','0','JEFE DE GESTION ADMINISTRATIVA','JEFE DE GESTION ADMINISTRATIVA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1028','0','JEFE DE GESTION RECURSOS FISICOS Y FINANCIEROS','JEFE DE GESTION RECURSOS FISICOS Y FINANCIEROS',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1029','0','JEFE DE OFICINA ADMINISTRACIÃ“N','JEFE DE OFICINA ADMINISTRACIÃ“N',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1030','0','JEFE DE PERSONAL','JEFE DE PERSONAL',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1031','0','JEFE DE RECURSOS HUMANOS','JEFE DE RECURSOS HUMANOS',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1032','0','JEFE GESTION ADMINISTRATIVA Y FINANCIERA','JEFE GESTION ADMINISTRATIVA Y FINANCIERA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1033','0','JEFE NOMINA','JEFE NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1034','0','JEFE SECCION NOVEDADES','JEFE SECCION NOVEDADES',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1035','0','LIDER DE PROYECTO','LIDER DE PROYECTO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1036','0','NOMINA','NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1037','0','PAGADOR','PAGADOR',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1038','0','PAGADOR GENERAL','PAGADOR GENERAL',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1039','0','PROFESIONAL ESPECIALIZADO','PROFESIONAL ESPECIALIZADO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1040','0','PROFESIONAL DE NOMINA','PROFESIONAL DE NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1041','0','PROFESIONAL DE RECURSOS HUMANOS','PROFESIONAL DE RECURSOS HUMANOS',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1042','0','PROFESIONAL TALENTO HUMANO','PROFESIONAL TALENTO HUMANO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1043','0','PROFESIONAL U. RECURSOS HH','PROFESIONAL U. RECURSOS HH',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1044','0','PROFESIONAL U.GESTION H.','PROFESIONAL U.GESTION H.',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1045','0','PROFESIONAL UNIVERSITARIO ','PROFESIONAL UNIVERSITARIO ',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1046','0','RESPONSABLE TALENTO HUMANO','RESPONSABLE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1047','0','SECRETARIO DE TALENTO HUMANO','SECRETARIO DE TALENTO HUMANO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1048','0','SUBDIRECTOR DE PRESTACIONES SOCIALES','SUBDIRECTOR DE PRESTACIONES SOCIALES',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1049','0','SUBDIRECTOR','SUBDIRECTOR',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1050','0','SUBDIRECTOR DE NOMINA','SUBDIRECTOR DE NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1051','0','TALENTO HUMANO','TALENTO HUMANO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1052','0','TECNICO ','TECNICO ',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1053','0','TECNICO ADMINISTRATIVO','TECNICO ADMINISTRATIVO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1054','0','TECNICO DE NOMINA','TECNICO DE NOMINA',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1055','0','TECNICO FACILITADOR','TECNICO FACILITADOR',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1056','0','TECNICO OFICIAL DE RECURSOS HUMANOS','TECNICO OFICIAL DE RECURSOS HUMANOS',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1057','0','TECNICO OPERARIO','TECNICO OPERARIO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1058','0','TECNICO OPERATIVO','TECNICO OPERATIVO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1059','0','TESORERO','TESORERO',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1060','0','TESORERO GENERAL','TESORERO GENERAL',1);
INSERT INTO `masterdata`.`occupation`(`id`,`version`,`description`,`name`,`enabled`) VALUES ('1061','0','TESORERO-PAGADOR','TESORERO-PAGADOR',1);

/*!40000 ALTER TABLE `occupation` ENABLE KEYS */;
UNLOCK TABLES;


UPDATE check_list_item_reason_code SET enabled = false WHERE id = 1;
UPDATE check_list_item_reason_code SET enabled = false WHERE id = 2;

delete from check_list_item_reason_code where id in (3,4,5,6,7,8,9,10,11);

INSERT INTO `check_list_item_reason_code` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES
(3,NULL,0,'Documento mal cargado',true,'Documento mal cargado'),
(4,NULL,0,'Datos no corresponden al cliente',true,'Datos no corresponden al cliente'),
(5,NULL,0,'Documento vencido',true,'Documento vencido'),
(6,NULL,0,'Documento mal diligenciado',true,'Documento mal diligenciado'),
(7,NULL,0,'Documento sin huellas',true,'Documento sin huellas'),
(8,NULL,0,'Documento con huellas ilegibles',true,'Documento con huellas ilegibles'),
(9,NULL,0,'Documento sin firmas',true,'Documento sin firmas'),
(10,NULL,0,'Documentos con tachones',true,'Documentos con tachones'),
(11,NULL,0,'Otro',true,'Otro');