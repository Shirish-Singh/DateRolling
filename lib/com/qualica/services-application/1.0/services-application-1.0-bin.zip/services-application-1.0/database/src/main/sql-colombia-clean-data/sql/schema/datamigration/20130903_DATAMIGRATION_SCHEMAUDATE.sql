USE `datamigration`;

ALTER TABLE `datamigration`.`staging_client` CHANGE COLUMN `prevoius_employer_name` `current_employee_number` VARCHAR(255) CHARACTER SET 'utf8' COLLATE 'utf8_unicode_ci' NULL DEFAULT NULL  ;

ALTER TABLE `datamigration`.`staging_client` ADD COLUMN `occupation_position` VARCHAR(255) NULL DEFAULT NULL  AFTER `uploaded_client_sheet_line_number` ,
 ADD COLUMN `agent_id_number` VARCHAR(255) NULL DEFAULT NULL  AFTER `occupation_position` ,
  ADD COLUMN `outlet_name` VARCHAR(255) NULL DEFAULT NULL  AFTER `agent_id_number` ,
   ADD COLUMN `lending_entity` VARCHAR(255) NULL DEFAULT NULL  AFTER `outlet_name` ;

ALTER TABLE `datamigration`.`staging_employer` ADD COLUMN `employer_code` VARCHAR(255) NULL DEFAULT NULL  AFTER `uploaded_employer_sheet_line_number` ,
 ADD COLUMN `region_lookup_value` VARCHAR(255) NULL DEFAULT NULL  AFTER `employer_code`,
  ADD COLUMN `suburb_lookup_value` VARCHAR(255) NULL DEFAULT NULL  AFTER `region_lookup_value`,
   ADD COLUMN `tittle` VARCHAR(255) NULL DEFAULT NULL  AFTER `suburb_lookup_value`,
    ADD COLUMN `first_name` VARCHAR(255) NULL DEFAULT NULL  AFTER `tittle`,
     ADD COLUMN `last_name` VARCHAR(255) NULL DEFAULT NULL  AFTER `first_name`,
      ADD COLUMN `role` VARCHAR(255) NULL DEFAULT NULL  AFTER `last_name`;



