use flexifinproduct;
alter table loan_product modify cheque_fee decimal(19,9);