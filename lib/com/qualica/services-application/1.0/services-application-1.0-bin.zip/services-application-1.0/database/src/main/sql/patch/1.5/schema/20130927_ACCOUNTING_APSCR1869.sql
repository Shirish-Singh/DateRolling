USE accounting;

ALTER TABLE timeline CHANGE COLUMN datestamp datestamp DATE DEFAULT NULL;
ALTER TABLE tx_instalment CHANGE COLUMN effective_date effective_date DATE NOT NULL;
