use masterdata;
SET FOREIGN_KEY_CHECKS=0;
update disbursement_type set id=0 where id=1;
update disbursement_type set id=1 where id=2;
update disbursement_type set id=2 where id=3;
update disbursement_type set id=3 where id=4;
update disbursement_type set id=4 where id=5;
update disbursement_type set id=5 where id=6;

/*
update disbursement_detail set disbursement_type_id=0 where disbursement_type_id=1;
update disbursement_detail set disbursement_type_id=1 where disbursement_type_id=2;
update disbursement_detail set disbursement_type_id=2 where disbursement_type_id=3;
update disbursement_detail set disbursement_type_id=3 where disbursement_type_id=4;
update disbursement_detail set disbursement_type_id=4 where disbursement_type_id=5;
update disbursement_detail set disbursement_type_id=5 where disbursement_type_id=6;
*/
SET FOREIGN_KEY_CHECKS=1;
