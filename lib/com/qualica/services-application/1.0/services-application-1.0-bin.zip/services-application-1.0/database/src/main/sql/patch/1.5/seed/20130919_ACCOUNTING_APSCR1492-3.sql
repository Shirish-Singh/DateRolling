use masterdata;

DELETE FROM `role_permission` WHERE role_id=300 and permission_id=3031;
DELETE FROM `permission` WHERE id in (3031);

INSERT INTO `permission` (`id`, `modified_by`, `version`, `name`) VALUES ('3031', 'Sharad', '0', 'ui.capture_employer_response');

INSERT INTO `role_permission` (`role_id`, `permission_id`) VALUES ('300', '3031');

DELETE FROM `role_permission` WHERE role_id=300 and permission_id=3032;
DELETE FROM `permission` WHERE id in (3032);

INSERT INTO `permission` (`id`, `modified_by`, `version`, `name`) VALUES ('3032', 'Sharad', '0', 'ui.collections_download_csv');

INSERT INTO `role_permission` (`role_id`, `permission_id`) VALUES ('300', '3032');