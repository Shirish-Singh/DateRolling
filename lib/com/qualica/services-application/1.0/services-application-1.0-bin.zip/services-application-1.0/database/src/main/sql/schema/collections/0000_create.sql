-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: collections
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `collections`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `collections` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `collections`;

--
-- Table structure for table `collection_case`
--

DROP TABLE IF EXISTS `collection_case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `arrears_amount` bigint(20) DEFAULT NULL,
  `arrears_from_date` datetime DEFAULT NULL,
  `colection_start_date` datetime DEFAULT NULL,
  `review_pending` bit(1) DEFAULT NULL,
  `status_id` bigint(20) NOT NULL,
  `status_reason_id` bigint(20) NOT NULL,
  `id_passport_number` varchar(255) DEFAULT NULL,
  `primary_debtor_first_name` varchar(255) DEFAULT NULL,
  `primary_debtor_last_name` varchar(255) DEFAULT NULL,
  `guarantor_party_role_id` bigint(20) DEFAULT NULL,
  `primary_debtor_party_role_id` bigint(20) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3F2DF8313F9DAE9` (`status_id`),
  KEY `FK3F2DF8311F1F94EE` (`status_reason_id`),
  CONSTRAINT `FK3F2DF8311F1F94EE` FOREIGN KEY (`status_reason_id`) REFERENCES `collection_case_status_reason` (`id`),
  CONSTRAINT `FK3F2DF8313F9DAE9` FOREIGN KEY (`status_id`) REFERENCES `collection_case_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_case_aud`
--

DROP TABLE IF EXISTS `collection_case_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `arrears_amount` bigint(20) DEFAULT NULL,
  `arrears_from_date` datetime DEFAULT NULL,
  `colection_start_date` datetime DEFAULT NULL,
  `review_pending` bit(1) DEFAULT NULL,
  `status_id` bigint(20) DEFAULT NULL,
  `status_reason_id` bigint(20) DEFAULT NULL,
  `id_passport_number` varchar(255) DEFAULT NULL,
  `primary_debtor_first_name` varchar(255) DEFAULT NULL,
  `primary_debtor_last_name` varchar(255) DEFAULT NULL,
  `guarantor_party_role_id` bigint(20) DEFAULT NULL,
  `primary_debtor_party_role_id` bigint(20) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK8A5121A2DF74E053` (`REV`),
  CONSTRAINT `FK8A5121A2DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_case_discount`
--

DROP TABLE IF EXISTS `collection_case_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case_discount` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `collection_fee` bigint(20) DEFAULT NULL,
  `percentage_discount1` decimal(19,2) DEFAULT NULL,
  `percentage_discount2` decimal(19,2) DEFAULT NULL,
  `discount_amount_1` bigint(20) DEFAULT NULL,
  `discount_amount_2` bigint(20) DEFAULT NULL,
  `discount_date_1` datetime DEFAULT NULL,
  `discount_date_2` datetime DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `collection_case_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK80C5558FCFC4178` (`collection_case_id`),
  CONSTRAINT `FK80C5558FCFC4178` FOREIGN KEY (`collection_case_id`) REFERENCES `collection_case` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_case_discount_aud`
--

DROP TABLE IF EXISTS `collection_case_discount_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case_discount_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `collection_fee` bigint(20) DEFAULT NULL,
  `percentage_discount1` decimal(19,2) DEFAULT NULL,
  `percentage_discount2` decimal(19,2) DEFAULT NULL,
  `discount_amount_1` bigint(20) DEFAULT NULL,
  `discount_amount_2` bigint(20) DEFAULT NULL,
  `discount_date_1` datetime DEFAULT NULL,
  `discount_date_2` datetime DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  `collection_case_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK4C1EA000DF74E053` (`REV`),
  CONSTRAINT `FK4C1EA000DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_case_status`
--

DROP TABLE IF EXISTS `collection_case_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_case_status_aud`
--

DROP TABLE IF EXISTS `collection_case_status_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case_status_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK539335B1DF74E053` (`REV`),
  CONSTRAINT `FK539335B1DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_case_status_reason`
--

DROP TABLE IF EXISTS `collection_case_status_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case_status_reason` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `collection_case_status_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD4166BA3A319045B` (`collection_case_status_id`),
  CONSTRAINT `FKD4166BA3A319045B` FOREIGN KEY (`collection_case_status_id`) REFERENCES `collection_case_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_case_status_reason_aud`
--

DROP TABLE IF EXISTS `collection_case_status_reason_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_case_status_reason_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `collection_case_status_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKC60E8C14DF74E053` (`REV`),
  CONSTRAINT `FKC60E8C14DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_global_variable`
--

DROP TABLE IF EXISTS `collection_global_variable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_global_variable` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `variable_name` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `variable_value` varchar(255) DEFAULT NULL,
  `editable_from_ui` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_global_variable_aud`
--

DROP TABLE IF EXISTS `collection_global_variable_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_global_variable_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `variable_name` varchar(255) DEFAULT NULL,
  `display_name` varchar(255) DEFAULT NULL,
  `variable_value` varchar(255) DEFAULT NULL,
  `editable_from_ui` bit(1) DEFAULT b'0',
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE0BF4668DF74E053` (`REV`),
  CONSTRAINT `FKE0BF4668DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance`
--

DROP TABLE IF EXISTS `collection_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `debtor_liability_percentage` double DEFAULT NULL,
  `debtor_id` bigint(20) DEFAULT NULL,
  `debtor_type` varchar(255) DEFAULT NULL,
  `workflow_process_id` varchar(255) DEFAULT NULL,
  `collection_case_id` bigint(20) NOT NULL,
  `severity_id` bigint(20) NOT NULL,
  `status_id` bigint(20) NOT NULL,
  `status_reason_id` bigint(20) NOT NULL,
  `debtor_first_name` varchar(255) DEFAULT NULL,
  `debtor_last_name` varchar(255) DEFAULT NULL,
  `debtor_liability_amount` double DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKAA1DA916CFC4178` (`collection_case_id`),
  KEY `FKAA1DA916EC3BED0E` (`status_id`),
  KEY `FKAA1DA9162352B753` (`status_reason_id`),
  KEY `FKAA1DA916EB02382E` (`severity_id`),
  CONSTRAINT `FKAA1DA916EB02382E` FOREIGN KEY (`severity_id`) REFERENCES `collection_instance_severity` (`id`),
  CONSTRAINT `FKAA1DA9162352B753` FOREIGN KEY (`status_reason_id`) REFERENCES `collection_instance_status_reason` (`id`),
  CONSTRAINT `FKAA1DA916CFC4178` FOREIGN KEY (`collection_case_id`) REFERENCES `collection_case` (`id`),
  CONSTRAINT `FKAA1DA916EC3BED0E` FOREIGN KEY (`status_id`) REFERENCES `collection_instance_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance_aud`
--

DROP TABLE IF EXISTS `collection_instance_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `debtor_liability_percentage` double DEFAULT NULL,
  `debtor_id` bigint(20) DEFAULT NULL,
  `debtor_type` varchar(255) DEFAULT NULL,
  `workflow_process_id` varchar(255) DEFAULT NULL,
  `collection_case_id` bigint(20) DEFAULT NULL,
  `severity_id` bigint(20) DEFAULT NULL,
  `status_id` bigint(20) DEFAULT NULL,
  `status_reason_id` bigint(20) DEFAULT NULL,
  `debtor_first_name` varchar(255) DEFAULT NULL,
  `debtor_last_name` varchar(255) DEFAULT NULL,
  `debtor_liability_amount` double DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKA283D807DF74E053` (`REV`),
  CONSTRAINT `FKA283D807DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance_severity`
--

DROP TABLE IF EXISTS `collection_instance_severity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance_severity` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance_severity_aud`
--

DROP TABLE IF EXISTS `collection_instance_severity_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance_severity_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKCA21AF17DF74E053` (`REV`),
  CONSTRAINT `FKCA21AF17DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance_status`
--

DROP TABLE IF EXISTS `collection_instance_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance_status` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance_status_aud`
--

DROP TABLE IF EXISTS `collection_instance_status_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance_status_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK10DE73ACDF74E053` (`REV`),
  CONSTRAINT `FK10DE73ACDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance_status_reason`
--

DROP TABLE IF EXISTS `collection_instance_status_reason`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance_status_reason` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `collection_instance_status_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK2B1827C8C302AD25` (`collection_instance_status_id`),
  CONSTRAINT `FK2B1827C8C302AD25` FOREIGN KEY (`collection_instance_status_id`) REFERENCES `collection_instance_status` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collection_instance_status_reason_aud`
--

DROP TABLE IF EXISTS `collection_instance_status_reason_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_instance_status_reason_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `collection_instance_status_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKFDBADB9DF74E053` (`REV`),
  CONSTRAINT `FKFDBADB9DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collections_dto_to_class_binding`
--

DROP TABLE IF EXISTS `collections_dto_to_class_binding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collections_dto_to_class_binding` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `class_name` varchar(255) DEFAULT NULL,
  `dto_name` varchar(255) DEFAULT NULL,
  `relevant_entity_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `collections_note`
--

DROP TABLE IF EXISTS `collections_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collections_note` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_time_created` datetime DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `processname` varchar(255) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `taskid` varchar(255) DEFAULT NULL,
  `taskname` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `dto_to_class_binding_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC87F785CE5CB64B3` (`dto_to_class_binding_id`),
  CONSTRAINT `FKC87F785CE5CB64B3` FOREIGN KEY (`dto_to_class_binding_id`) REFERENCES `collections_dto_to_class_binding` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cont_attmpt_line_item_out_hist`
--

DROP TABLE IF EXISTS `cont_attmpt_line_item_out_hist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cont_attmpt_line_item_out_hist` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cont_attmpt_line_item_out_hist_aud`
--

DROP TABLE IF EXISTS `cont_attmpt_line_item_out_hist_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cont_attmpt_line_item_out_hist_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `is_enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK48FB3BE7DF74E053` (`REV`),
  CONSTRAINT `FK48FB3BE7DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt`
--

DROP TABLE IF EXISTS `contact_attempt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `promise_to_pay_amount` bigint(20) DEFAULT NULL,
  `promise_to_pay_date` datetime DEFAULT NULL,
  `collection_instance_id` bigint(20) NOT NULL,
  `contact_attempt_type_id` bigint(20) NOT NULL,
  `suggested_date_time` datetime DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1E317DAED5AFF837` (`contact_attempt_type_id`),
  KEY `FK1E317DAE57467C58` (`collection_instance_id`),
  CONSTRAINT `FK1E317DAE57467C58` FOREIGN KEY (`collection_instance_id`) REFERENCES `collection_instance` (`id`),
  CONSTRAINT `FK1E317DAED5AFF837` FOREIGN KEY (`contact_attempt_type_id`) REFERENCES `contact_attempt_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_aud`
--

DROP TABLE IF EXISTS `contact_attempt_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `promise_to_pay_amount` bigint(20) DEFAULT NULL,
  `promise_to_pay_date` datetime DEFAULT NULL,
  `collection_instance_id` bigint(20) DEFAULT NULL,
  `contact_attempt_type_id` bigint(20) DEFAULT NULL,
  `suggested_date_time` datetime DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK88EBA09FDF74E053` (`REV`),
  CONSTRAINT `FK88EBA09FDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item`
--

DROP TABLE IF EXISTS `contact_attempt_line_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `customer_initiated` bit(1) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `contact_attempt_id` bigint(20) NOT NULL,
  `contact_script_id` bigint(20) DEFAULT NULL,
  `outcome_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKEFD9132D7B7841DF` (`outcome_id`),
  KEY `FKEFD9132D8784666B` (`contact_script_id`),
  KEY `FKEFD9132D121DB27A` (`contact_attempt_id`),
  CONSTRAINT `FKEFD9132D121DB27A` FOREIGN KEY (`contact_attempt_id`) REFERENCES `contact_attempt` (`id`),
  CONSTRAINT `FKEFD9132D7B7841DF` FOREIGN KEY (`outcome_id`) REFERENCES `cont_attmpt_line_item_out_hist` (`id`),
  CONSTRAINT `FKEFD9132D8784666B` FOREIGN KEY (`contact_script_id`) REFERENCES `contact_attempt_script_history` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_aud`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `customer_initiated` bit(1) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `contact_attempt_id` bigint(20) DEFAULT NULL,
  `contact_script_id` bigint(20) DEFAULT NULL,
  `outcome_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK69BE5E9EDF74E053` (`REV`),
  CONSTRAINT `FK69BE5E9EDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_email`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_email` (
  `email_address` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF3D5EC0AE31AD90` (`id`),
  CONSTRAINT `FKF3D5EC0AE31AD90` FOREIGN KEY (`id`) REFERENCES `contact_attempt_line_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_email_aud`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_email_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_email_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `email_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKFFB980FB6300CDA4` (`id`,`REV`),
  CONSTRAINT `FKFFB980FB6300CDA4` FOREIGN KEY (`id`, `REV`) REFERENCES `contact_attempt_line_item_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_legal`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_legal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_legal` (
  `lawyer_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF4350327E31AD90` (`id`),
  CONSTRAINT `FKF4350327E31AD90` FOREIGN KEY (`id`) REFERENCES `contact_attempt_line_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_legal_aud`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_legal_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_legal_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `lawyer_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKFE4DC1986300CDA4` (`id`,`REV`),
  CONSTRAINT `FKFE4DC1986300CDA4` FOREIGN KEY (`id`, `REV`) REFERENCES `contact_attempt_line_item_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_letter`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_letter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_letter` (
  `address_id` bigint(20) DEFAULT NULL,
  `courier_company_id` bigint(20) DEFAULT NULL,
  `delivery_address` varchar(255) DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `received_by` varchar(255) DEFAULT NULL,
  `sent_date` datetime DEFAULT NULL,
  `tracking_number` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK92719178E31AD90` (`id`),
  CONSTRAINT `FK92719178E31AD90` FOREIGN KEY (`id`) REFERENCES `contact_attempt_line_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_letter_aud`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_letter_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_letter_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `address_id` bigint(20) DEFAULT NULL,
  `courier_company_id` bigint(20) DEFAULT NULL,
  `delivery_address` varchar(255) DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `received_by` varchar(255) DEFAULT NULL,
  `sent_date` datetime DEFAULT NULL,
  `tracking_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKF408BF696300CDA4` (`id`,`REV`),
  CONSTRAINT `FKF408BF696300CDA4` FOREIGN KEY (`id`, `REV`) REFERENCES `contact_attempt_line_item_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_phone`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_phone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_phone` (
  `phone_number` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF46EDDDCE31AD90` (`id`),
  CONSTRAINT `FKF46EDDDCE31AD90` FOREIGN KEY (`id`) REFERENCES `contact_attempt_line_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_phone_aud`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_phone_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_phone_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK440139CD6300CDA4` (`id`,`REV`),
  CONSTRAINT `FK440139CD6300CDA4` FOREIGN KEY (`id`, `REV`) REFERENCES `contact_attempt_line_item_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_sms`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_sms` (
  `sms_number` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK69BEA147E31AD90` (`id`),
  CONSTRAINT `FK69BEA147E31AD90` FOREIGN KEY (`id`) REFERENCES `contact_attempt_line_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_sms_aud`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_sms_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_sms_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `sms_number` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK3B9B4FB86300CDA4` (`id`,`REV`),
  CONSTRAINT `FK3B9B4FB86300CDA4` FOREIGN KEY (`id`, `REV`) REFERENCES `contact_attempt_line_item_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_visit`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_visit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_visit` (
  `address_id` bigint(20) DEFAULT NULL,
  `contacted_person` varchar(255) DEFAULT NULL,
  `visit_address` varchar(255) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `visting_agent_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF4C3EDB9E31AD90` (`id`),
  CONSTRAINT `FKF4C3EDB9E31AD90` FOREIGN KEY (`id`) REFERENCES `contact_attempt_line_item` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_line_item_visit_aud`
--

DROP TABLE IF EXISTS `contact_attempt_line_item_visit_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_line_item_visit_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `address_id` bigint(20) DEFAULT NULL,
  `contacted_person` varchar(255) DEFAULT NULL,
  `visit_address` varchar(255) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `visting_agent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKF161132A6300CDA4` (`id`,`REV`),
  CONSTRAINT `FKF161132A6300CDA4` FOREIGN KEY (`id`, `REV`) REFERENCES `contact_attempt_line_item_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_script_history`
--

DROP TABLE IF EXISTS `contact_attempt_script_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_script_history` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `template_content` varchar(2500) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_script_history_aud`
--

DROP TABLE IF EXISTS `contact_attempt_script_history_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_script_history_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `template_content` varchar(2500) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK9395D942DF74E053` (`REV`),
  CONSTRAINT `FK9395D942DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_type`
--

DROP TABLE IF EXISTS `contact_attempt_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_type` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_attempt_type_aud`
--

DROP TABLE IF EXISTS `contact_attempt_type_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_attempt_type_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK8BFE67BCDF74E053` (`REV`),
  CONSTRAINT `FK8BFE67BCDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_script_template`
--

DROP TABLE IF EXISTS `contact_script_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_script_template` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `template_content` varchar(2500) DEFAULT NULL,
  `contact_attempt_type_id` bigint(20) NOT NULL,
  `severity_id` varchar(100) DEFAULT NULL,
  `debtor_type` varchar(255) DEFAULT NULL,
  `workflow_outcome_name` varchar(255) DEFAULT NULL,
  `script_outcome_state` varchar(255) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK38CD1B4FD5AFF837` (`contact_attempt_type_id`),
  CONSTRAINT `FK38CD1B4FD5AFF837` FOREIGN KEY (`contact_attempt_type_id`) REFERENCES `contact_attempt_type` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contact_script_template_aud`
--

DROP TABLE IF EXISTS `contact_script_template_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact_script_template_aud` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `is_active` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `template_content` varchar(2500) DEFAULT NULL,
  `contact_attempt_type_id` bigint(20) NOT NULL,
  `severity_id` varchar(100) DEFAULT NULL,
  `debtor_type` varchar(255) DEFAULT NULL,
  `workflow_outcome_name` varchar(255) DEFAULT NULL,
  `script_outcome_state` varchar(255) DEFAULT NULL,
  `entity_id` bigint(20) DEFAULT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK8B4D85C0DF74E053` (`REV`),
  CONSTRAINT `FK8B4D85C0DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hibernate_sequences`
--

DROP TABLE IF EXISTS `hibernate_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequences` (
  `sequence_name` varchar(255) NOT NULL,
  `next_val` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`sequence_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lookup_index`
--

DROP TABLE IF EXISTS `lookup_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookup_index` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `lookup_entity` varchar(200) DEFAULT NULL,
  `lookup_name` varchar(100) DEFAULT NULL,
  `parent_property_name` varchar(100) DEFAULT NULL,
  `parent_lookup_index` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF785C1ADB10B9019` (`parent_lookup_index`),
  CONSTRAINT `FKF785C1ADB10B9019` FOREIGN KEY (`parent_lookup_index`) REFERENCES `lookup_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_collection_discount`
--

DROP TABLE IF EXISTS `product_collection_discount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_collection_discount` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `collection_fee` bigint(20) DEFAULT NULL,
  `collection_discount1` decimal(19,2) DEFAULT NULL,
  `collection_discount2` decimal(19,2) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`),
  KEY `IX_ProdCollDis_ProductId` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `product_collection_discount_aud`
--

DROP TABLE IF EXISTS `product_collection_discount_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_collection_discount_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `collection_fee` bigint(20) DEFAULT NULL,
  `collection_discount1` decimal(19,2) DEFAULT NULL,
  `collection_discount2` decimal(19,2) DEFAULT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKB0D33763DF74E053` (`REV`),
  CONSTRAINT `FKB0D33763DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revinfo`
--

DROP TABLE IF EXISTS `revinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revinfo` (
  `REV` int(11) NOT NULL AUTO_INCREMENT,
  `REVTSTMP` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`REV`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_exception`
--

DROP TABLE IF EXISTS `workflow_exception`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_exception` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `collection_case_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_exception_aud`
--

DROP TABLE IF EXISTS `workflow_exception_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_exception_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `collection_case_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE9876A40DF74E053` (`REV`),
  CONSTRAINT `FKE9876A40DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_exception_log`
--

DROP TABLE IF EXISTS `workflow_exception_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_exception_log` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `workflow_exception_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE98792D42E6AD89A` (`workflow_exception_id`),
  CONSTRAINT `FKE98792D42E6AD89A` FOREIGN KEY (`workflow_exception_id`) REFERENCES `workflow_exception` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `workflow_exception_log_aud`
--

DROP TABLE IF EXISTS `workflow_exception_log_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_exception_log_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `time_stamp` datetime DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `workflow_exception_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE346B2C5DF74E053` (`REV`),
  CONSTRAINT `FKE346B2C5DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 15:51:29
