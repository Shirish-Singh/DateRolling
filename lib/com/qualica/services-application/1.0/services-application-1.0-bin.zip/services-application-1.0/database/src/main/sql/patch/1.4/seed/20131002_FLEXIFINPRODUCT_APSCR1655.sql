USE flexifinproduct;
LOCK TABLES `lookup_index` WRITE;
/*!40000 ALTER TABLE `lookup_index` DISABLE KEYS */;
DELETE FROM `lookup_index` WHERE id in (102,103);
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`)
VALUES
(102,'rahult',0,'com.qualica.flexifin.product.domain.core.ProductApplicability','ProductApplicability',NULL,NULL),
(103,'rahult',0,'com.qualica.flexifin.product.domain.core.ProductCategory','ProductCategory',NULL,NULL);
/*!40000 ALTER TABLE `lookup_index` ENABLE KEYS */;
UNLOCK TABLES;