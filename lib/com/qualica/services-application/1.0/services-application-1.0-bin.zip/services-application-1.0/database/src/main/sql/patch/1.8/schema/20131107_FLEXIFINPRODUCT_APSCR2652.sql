SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS flexifinproduct.alter_column;

DELIMITER $$

CREATE PROCEDURE flexifinproduct.alter_column(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'flexifinproduct'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `flexifinproduct`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL flexifinproduct.alter_column('product_fee', 'from_date', 'from_date', 'datetime default null');
CALL flexifinproduct.alter_column('product_fee', 'to_date', 'to_date', 'datetime default null');

DROP PROCEDURE IF EXISTS flexifinproduct.alter_column ;

SET SQL_MODE=@OLD_SQL_MODE ;

