USE accounting;

DELETE FROM `deduct_column_template_source_property` WHERE `id`='35';

INSERT INTO `deduct_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`)
VALUES ('35', '0', 'Loan Activation Date', 1, 'loanActivationDate', 'sourceProperty.LoanActivationDate');