use flexifinproduct;

SET FOREIGN_KEY_CHECKS= 0;
DELETE FROM `product` where id = 1;
DELETE FROM `loan_product` where id = 1;

INSERT INTO `product` 
(`id`, `modified_by`, `version`, `account_processing_day`, `account_processing_day_of_month`, `currency`, `description`, `name`, `archived`) 
VALUES (1,'Naveen Kumar',0,'PeriodEnd',NULL,'COP','18 Month Loan','Data Migration Product',1);

INSERT INTO flexifinproduct.`loan_product` (`max_amount_cents`, `max_term_months`, `min_amount_cents`, `min_term_months`, `rate_delta`, `step_amount_cents`, `step_term_months`,
`target_rate`, `id`, `product_applicability_id`, `interest_rate_id`, `arrears_rate`, `arrears_trigger_cycle`, `arrears_type`, `cheque_fee`, `enabled`, `grace_period_fee_days`, `recognition_mode`, `arrears_interest_type`, `product_type`)
VALUES (10000000000,60,200000000,6,NULL,NULL,NULL,2.138100000,1,2,1,NULL,NULL,NULL,NULL,NULL,0,'OnActivation',NULL,'FreeInvestmentLoan');

SET FOREIGN_KEY_CHECKS= 1;