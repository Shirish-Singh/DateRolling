use masterdata;

INSERT INTO role (id, modified_by, version, name) VALUES (131, '', 0, 'EmployerCodesCoordinator');
INSERT INTO role (id, modified_by, version, name) VALUES (132, '', 0, 'EmployerCodesClerk');
INSERT INTO role (id, modified_by, version, name) VALUES (133, '', 0, 'EmployerNationalSalesManager');
INSERT INTO role (id, modified_by, version, name) VALUES (134, '', 0, 'EmployerTeamLeader');

INSERT INTO permission (id, modified_by, version, name) VALUES (129, 'sameer', 0, 'EmployerCodesCoordinator');
INSERT INTO permission (id, modified_by, version, name) VALUES (130, 'sameer', 0, 'EmployerCodesClerk');
INSERT INTO permission (id, modified_by, version, name) VALUES (131, 'sameer', 0, 'EmployerNationalSalesManager');
INSERT INTO permission (id, modified_by, version, name) VALUES (132, 'sameer', 0, 'EmployerTeamLeader');

INSERT INTO role_permission (role_id, permission_id) VALUES (131, 129);
INSERT INTO role_permission (role_id, permission_id) VALUES (132, 130);
INSERT INTO role_permission (role_id, permission_id) VALUES (133, 131);
INSERT INTO role_permission (role_id, permission_id) VALUES (134, 132);
INSERT INTO role_permission (role_id, permission_id) VALUES (1, 129);
INSERT INTO role_permission (role_id, permission_id) VALUES (1, 130);
INSERT INTO role_permission (role_id, permission_id) VALUES (1, 131);
INSERT INTO role_permission (role_id, permission_id) VALUES (1, 132);
