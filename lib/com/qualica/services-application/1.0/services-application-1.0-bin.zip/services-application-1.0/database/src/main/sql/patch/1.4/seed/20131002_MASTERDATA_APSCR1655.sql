USE masterdata;
LOCK TABLES `lookup_index` WRITE;
/*!40000 ALTER TABLE `lookup_index` DISABLE KEYS */;
DELETE FROM `lookup_index` WHERE id = 52;
DELETE FROM `lookup_index` WHERE id in (42,43,44,45,46,47,48,49,50,51,53,54);
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`)
VALUES
(42,'rahult',0,'com.qualica.flexifin.masterdata.domain.role.AgentType','AgentType',NULL,NULL),
(43,'rahult',0,'com.qualica.flexifin.masterdata.domain.core.BankAccountStatus','BankAccountStatus',NULL,NULL),
(44,'rahult',0,'com.qualica.flexifin.masterdata.domain.ClientCreditBureauListing','ClientCreditBureauListing',NULL,NULL),
(45,'rahult',0,'com.qualica.flexifin.masterdata.domain.core.Currency','Currency',NULL,NULL),
(46,'rahult',0,'com.qualica.flexifin.masterdata.domain.application.DisbursementType','DisbursementType',NULL,NULL),
(47,'rahult',0,'com.qualica.flexifin.masterdata.domain.application.LoanDurationType','LoanDurationType',NULL,NULL),
(48,'rahult',0,'com.qualica.flexifin.masterdata.domain.core.PartyRelationshipType','PartyRelationshipType',NULL,NULL),
(49,'rahult',0,'com.qualica.flexifin.masterdata.domain.core.PartyRoleType','PartyRoleType',NULL,NULL),
(50,'rahult',0,'com.qualica.flexifin.masterdata.domain.PayableType','PayableType',NULL,NULL),
(51,'rahult',0,'com.qualica.flexifin.masterdata.domain.application.RecoveryReasonCategory','RecoveryReasonCategory',NULL,NULL),
(52,'rahult',0,'com.qualica.flexifin.masterdata.domain.application.RecoveryReason','RecoveryReason','recoveryReasonCategory',51),
(53,'rahult',0,'com.qualica.flexifin.masterdata.domain.core.Suburb','Suburb','city',8),
(54,'rahult',0,'com.qualica.flexifin.masterdata.domain.TerminationReason','TerminationReason',NULL,NULL);
/*!40000 ALTER TABLE `lookup_index` ENABLE KEYS */;
UNLOCK TABLES;