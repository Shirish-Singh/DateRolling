SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_column_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_column_fk(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100),
  IN fkSymbol VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY `', fkSymbol, '`');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP COLUMN `', colName, '`');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_column_fk('agreement_term_admin_fee_gpf', 'principal_term_id', 'FK7C8E01364BB96336') ;



DROP PROCEDURE IF EXISTS accounting.drop_column_fk ;

SET SQL_MODE=@OLD_SQL_MODE;

