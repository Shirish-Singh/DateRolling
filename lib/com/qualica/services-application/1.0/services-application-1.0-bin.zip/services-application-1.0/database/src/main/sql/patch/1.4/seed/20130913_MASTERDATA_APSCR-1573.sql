use masterdata;

UPDATE `masterdata`.`check_list_item_definition` SET `required`=1 WHERE `id`='53';
UPDATE `masterdata`.`check_list_item_definition` SET `required`=1 WHERE `id`='54';
UPDATE `masterdata`.`check_list_item_definition` SET `required`=1 WHERE `id`='55';
UPDATE `masterdata`.`check_list_item_definition` SET `required`=1 WHERE `id`='62';
