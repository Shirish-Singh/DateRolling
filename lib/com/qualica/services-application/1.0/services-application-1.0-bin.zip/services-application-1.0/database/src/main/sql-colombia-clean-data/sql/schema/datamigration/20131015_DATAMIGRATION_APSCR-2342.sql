USE datamigration;

SET FOREIGN_KEY_CHECKS=0;

--
-- Table structure for table `user_role_mapping`
--

DROP TABLE IF EXISTS `user_role_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role_mapping` (
  `user_role_id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  PRIMARY KEY (`user_role_id`,`role_id`),
  UNIQUE KEY `role_id` (`role_id`),
  KEY `FK5D9A9F91DF90F11` (`user_role_id`),
  KEY `FK5D9A9F94D04584B` (`role_id`),
  CONSTRAINT `FK5D9A9F94D04584B` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `FK5D9A9F91DF90F11` FOREIGN KEY (`user_role_id`) REFERENCES `user_role` (`user_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `role_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `modified_by` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `manage_lookup_error`
--

DROP TABLE IF EXISTS `manage_lookup_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `manage_lookup_error` (
  `manage_look_up_id` bigint(20) NOT NULL,
  `file_uploader_error_id` bigint(20) NOT NULL,
  UNIQUE KEY `file_uploader_error_id` (`file_uploader_error_id`),
  KEY `FKED8ED39DA8EA5962` (`manage_look_up_id`),
  KEY `FKED8ED39D1CABAD11` (`file_uploader_error_id`),
  CONSTRAINT `FKED8ED39D1CABAD11` FOREIGN KEY (`file_uploader_error_id`) REFERENCES `master_data_file_uploader_error` (`file_uploader_error_id`),
  CONSTRAINT `FKED8ED39DA8EA5962` FOREIGN KEY (`manage_look_up_id`) REFERENCES `manage_look_up` (`manage_look_up_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

SET FOREIGN_KEY_CHECKS=1;