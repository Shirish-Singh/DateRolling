use masterdata;
SET character_set_client = utf8;

UPDATE `masterdata`.`contact_number_type` SET `enabled`=1 WHERE `id`='1005';
INSERT INTO `masterdata`.`address_type` (`id`, `version`, `description`, `enabled`, `name`) VALUES ('1003', '0', 'Casa', 1, 'Casa');
INSERT INTO `masterdata`.`address_type` (`id`, `version`, `description`, `enabled`, `name`) VALUES ('1004', '0', 'Apartamento', 1, 'Apartamento');
UPDATE `masterdata`.`job_position` SET `enabled`=1 WHERE `id`='1067';
UPDATE `masterdata`.`job_position` SET `enabled`=1 WHERE `id`='1021';
UPDATE `masterdata`.`job_position` SET `enabled`=1 WHERE `id`='1066';
UPDATE `masterdata`.`job_position` SET `enabled`=1 WHERE `id`='1037';
UPDATE `masterdata`.`job_position` SET `enabled`=1 WHERE `id`='1039';
INSERT INTO `masterdata`.`agent_type` (`id`, `version`, `description`, `enabled`, `name`, `level`) VALUES ('1007', '0', 'Director Regional', 1, 'Director Regional', '1');
INSERT INTO `masterdata`.`agent_type` (`id`, `version`, `description`, `enabled`, `name`, `level`) VALUES ('1008', '0', 'Coordinador Regional', 1, 'Coordinador Regional', '1');


