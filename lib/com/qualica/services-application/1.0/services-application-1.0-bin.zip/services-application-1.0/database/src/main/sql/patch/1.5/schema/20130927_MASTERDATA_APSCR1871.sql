USE masterdata;

ALTER TABLE employer_deduction_code CHANGE COLUMN start_date start_date DATE DEFAULT NULL;
ALTER TABLE employer_deduction_code CHANGE COLUMN end_date end_date DATE DEFAULT NULL;
ALTER TABLE employer_deduction_code CHANGE COLUMN issue_date issue_date DATE DEFAULT NULL;

ALTER TABLE person CHANGE COLUMN birth_date birth_date DATE DEFAULT NULL;
ALTER TABLE person CHANGE COLUMN passport_expire_date passport_expire_date DATE DEFAULT NULL;
ALTER TABLE person CHANGE COLUMN id_issue_date id_issue_date DATE DEFAULT NULL;

ALTER TABLE agent CHANGE COLUMN appointment_date appointment_date DATE DEFAULT NULL;
ALTER TABLE agent_aud CHANGE COLUMN appointment_date appointment_date DATE DEFAULT NULL;

ALTER TABLE employer CHANGE COLUMN founding_date founding_date DATE DEFAULT NULL;



