USE collections;


DROP PROCEDURE IF EXISTS collections.alter_column ;

DELIMITER $$

CREATE PROCEDURE collections.alter_column(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
  BEGIN
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS
        WHERE column_name = newColName
              AND table_name = tableName
              AND table_schema = 'collections'
    )
    THEN
      SET @Statement = CONCAT('ALTER TABLE `collections`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

    END IF;
  END ;$$

DELIMITER ;

CALL collections.alter_column('collection_case', 'colection_start_date', 'collection_start_date', 'date default null') ;
CALL collections.alter_column('collection_case_aud', 'colection_start_date', 'collection_start_date', 'date default null') ;

ALTER TABLE collection_case CHANGE COLUMN loan_issue_year loan_issue_year DATETIME default null;
ALTER TABLE collection_case_aud CHANGE COLUMN loan_issue_year loan_issue_year DATETIME default null;

DROP PROCEDURE IF EXISTS collections.alter_column ;

