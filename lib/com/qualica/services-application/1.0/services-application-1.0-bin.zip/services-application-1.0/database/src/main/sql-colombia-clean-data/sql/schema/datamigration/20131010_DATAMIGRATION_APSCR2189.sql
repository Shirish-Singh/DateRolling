SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE datamigration;

DROP PROCEDURE IF EXISTS datamigration.drop_column ;

DELIMITER $$

CREATE PROCEDURE datamigration.drop_column(
  IN tableName VARCHAR(100) character set utf8,
  IN colName VARCHAR(100) character set utf8
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'datamigration'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `datamigration`.`', tableName ,'` DROP COLUMN `', colName, '`');

      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL datamigration.drop_column('manage_look_up', 'country') ;


DROP PROCEDURE IF EXISTS datamigration.drop_column ;

SET SQL_MODE=@OLD_SQL_MODE;

