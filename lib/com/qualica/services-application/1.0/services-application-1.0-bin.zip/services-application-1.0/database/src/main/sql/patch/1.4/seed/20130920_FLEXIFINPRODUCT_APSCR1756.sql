use flexifinproduct;

UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useAval' WHERE `id`='100007';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useAval' WHERE `id`='100015';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useAval' WHERE `id`='100023';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useAval' WHERE `id`='100031';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useAval' WHERE `id`='100039';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInsurance' WHERE `id`='100008';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInsurance' WHERE `id`='100016';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInsurance' WHERE `id`='100024';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInsurance' WHERE `id`='100032';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInsurance' WHERE `id`='100040';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInterest' WHERE `id`='100006';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInterest' WHERE `id`='100014';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInterest' WHERE `id`='100022';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInterest' WHERE `id`='100030';
UPDATE `flexifinproduct`.`fee_mapping` SET `domain_property`='useInterest' WHERE `id`='100038';