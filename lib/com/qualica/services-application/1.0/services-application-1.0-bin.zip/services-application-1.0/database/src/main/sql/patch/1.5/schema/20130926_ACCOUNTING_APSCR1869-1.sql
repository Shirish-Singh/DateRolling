SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_column ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_column(
  IN tableName VARCHAR(100),
  IN colName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP COLUMN `', colName, '`');

      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_column('agreement_action', 'start_date') ;
CALL accounting.drop_column('agreement_action_aud', 'start_date') ;

DROP PROCEDURE IF EXISTS accounting.drop_column ;

SET SQL_MODE=@OLD_SQL_MODE;

