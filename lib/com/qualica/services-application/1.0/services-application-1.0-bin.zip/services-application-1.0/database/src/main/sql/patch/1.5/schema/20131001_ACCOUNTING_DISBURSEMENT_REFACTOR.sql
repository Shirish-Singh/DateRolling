SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_fk('deposit_slip_reference', 'FKD659EE7934A9509Bcbed1acd') ;
CALL accounting.drop_fk('settlement_quote_confirmation', 'FKD659EE7934A9509Ba30fa01e30a993ee') ;
CALL accounting.drop_fk('settlement_discharge_confirmation', 'FKD659EE7934A9509Ba30fa01e92a3d468') ;

DROP PROCEDURE IF EXISTS accounting.drop_fk ;
SET SQL_MODE=@OLD_SQL_MODE;
