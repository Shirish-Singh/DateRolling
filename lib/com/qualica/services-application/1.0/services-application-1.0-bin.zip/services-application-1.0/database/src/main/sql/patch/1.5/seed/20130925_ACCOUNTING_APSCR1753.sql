USE accounting;

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
DELETE FROM `configuration` WHERE id in (10011);
INSERT INTO `configuration` (`id`, `version`, `name`, `value`) VALUES
(10011, 0, 'targetEnvironment', 'colombia');
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;