SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.alter_column_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.alter_column_fk(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100),
  IN fkSymbol VARCHAR(100),
  IN refTable VARCHAR(100),
  IN refColName VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY ', fkSymbol);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` ADD CONSTRAINT `', fkSymbol, '` FOREIGN KEY `', fkSymbol ,'` (`', newColName, '`) REFERENCES `', refTable, '` (`', refColName, '`)');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;


  END IF;
END ;$$

DELIMITER ;

CALL accounting.alter_column_fk('agreement_term_admin_fee_gpf', 'gpf_account_id', 'gpf_interest_account_id', 'bigint(20) not null', 'FK7C8E013666868C5B', 'account', 'id');
CALL accounting.alter_column_fk('agreement_term_admin_fee_gpf', 'gpf_chart_id', 'gpf_interest_chart_id', 'bigint(20) not null', 'FK7C8E01367282717', 'tx_chart', 'id');

DROP PROCEDURE IF EXISTS accounting.alter_column_fk ;

SET SQL_MODE=@OLD_SQL_MODE ;

