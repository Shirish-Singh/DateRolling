USE accounting;

alter table agreement change column first_instalment_due_date first_instalment_due_date date default null;
update agreement set first_instalment_due_date = null where first_instalment_due_date = '0000-00-00';