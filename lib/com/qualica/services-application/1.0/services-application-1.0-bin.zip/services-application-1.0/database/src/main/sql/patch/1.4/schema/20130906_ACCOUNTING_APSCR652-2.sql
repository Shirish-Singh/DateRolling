SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.alter_column_zero ;

DELIMITER $$

CREATE PROCEDURE accounting.alter_column_zero(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      IF EXISTS (
          SELECT * FROM information_schema.COLUMNS
          WHERE column_name = oldColName
          AND table_name = tableName
          AND table_schema = 'accounting'
      )
      THEN
          SET @Statement = CONCAT('UPDATE `accounting`.`', tableName, '` SET ', oldColName, ' = 0');
          prepare DynamicStatement from @Statement ;
          execute DynamicStatement ;
          deallocate prepare DynamicStatement ;

          SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
          prepare DynamicStatement from @Statement ;
          execute DynamicStatement ;
          deallocate prepare DynamicStatement ;
    END IF;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.alter_column_zero('agreement_term_admin_fee_gpf', 'aval_allowed', 'aval_rate', 'double not null');
CALL accounting.alter_column_zero('agreement_term_admin_fee_gpf', 'insurance_allowed', 'insurance_rate', 'double not null');
CALL accounting.alter_column_zero('agreement_term_admin_fee_gpf', 'gpf_rate', 'interest_rate', 'double not null');
CALL accounting.alter_column_zero('agreement_term_admin_fee_iaf', 'iaf_days', 'iaf_periods', 'BIGINT(20) not null');
CALL accounting.alter_column_zero('agreement_term_admin_fee_iaf', 'aval_allowed', 'aval_rate', 'double not null');
CALL accounting.alter_column_zero('agreement_term_admin_fee_iaf', 'insurance_allowed', 'insurance_rate', 'double not null');

DROP PROCEDURE IF EXISTS accounting.alter_column_zero ;

SET SQL_MODE=@OLD_SQL_MODE ;

