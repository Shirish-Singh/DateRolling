use masterdata;

update check_list_item_definition set name = 'Signature Document' where id = 120;