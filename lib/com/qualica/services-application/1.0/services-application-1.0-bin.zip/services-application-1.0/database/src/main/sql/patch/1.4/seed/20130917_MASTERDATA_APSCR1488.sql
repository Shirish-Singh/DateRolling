use masterdata;
DELETE FROM `lookup_index` WHERE id IN (42);
INSERT INTO `lookup_index` (`id`, `modified_by`, `version`, `lookup_entity`, `lookup_name`, `parent_property_name`, `parent_lookup_index`) VALUES ('42', 'sharad', '0', 'com.qualica.flexifin.masterdata.domain.core.Suburb', 'Suburb', 'city', '8');
