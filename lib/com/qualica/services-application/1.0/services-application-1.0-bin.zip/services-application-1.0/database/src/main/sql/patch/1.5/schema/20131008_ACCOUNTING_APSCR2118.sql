
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.drop_index ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_index(
  IN tableName VARCHAR(100),
  IN indexName VARCHAR(100)
)
BEGIN
  IF EXISTS (
  SELECT * FROM information_schema.statistics
      WHERE index_name = indexName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP INDEX `', indexName, '`');

      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_index('submission_due', 'date_file_due_UNIQUE') ;
CALL accounting.drop_index('receipting_due', 'employer_id_UNIQUE') ;

DROP PROCEDURE IF EXISTS accounting.drop_index ;

SET SQL_MODE=@OLD_SQL_MODE;