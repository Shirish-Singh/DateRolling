USE accounting;

ALTER TABLE `accounting`.`fee` CHANGE COLUMN `use_interest` `use_interest` bit(1) default null;
ALTER TABLE `accounting`.`fee` CHANGE COLUMN `use_aval` `use_aval` bit(1) default null;
ALTER TABLE `accounting`.`fee` CHANGE COLUMN `use_insurance` `use_insurance` bit(1) default null;
