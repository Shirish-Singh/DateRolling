-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: accounting
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `accounting`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `accounting` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `accounting`;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_type` varchar(255) DEFAULT NULL,
  `activated_date` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `currency_code` varchar(3) NOT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `in_arrears` bit(1) NOT NULL,
  `initialised_date` datetime DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `submission_attempt` int(11) DEFAULT NULL,
  `submission_status` varchar(255) NOT NULL,
  `system` bit(1) NOT NULL,
  `account_reason_code_history_id` bigint(20) DEFAULT NULL,
  `lending_trading_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB9D38A2DC258FFE6` (`account_reason_code_history_id`),
  KEY `IX_Account_EmployerId` (`employer_id`),
  KEY `IX_Account_ActivatedDate` (`activated_date`),
  KEY `IX_Account_Status` (`status`),
  CONSTRAINT `FKB9D38A2DC258FFE6` FOREIGN KEY (`account_reason_code_history_id`) REFERENCES `account_reason_code_history` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_aud`
--

DROP TABLE IF EXISTS `account_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `account_type` varchar(255) DEFAULT NULL,
  `activated_date` datetime DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `currency_code` varchar(3) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `in_arrears` bit(1) DEFAULT NULL,
  `initialised_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `submission_attempt` int(11) DEFAULT NULL,
  `submission_status` varchar(255) DEFAULT NULL,
  `system` bit(1) DEFAULT NULL,
  `account_reason_code_history_id` bigint(20) DEFAULT NULL,
  `lending_trading_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK33A5559EDF74E053` (`REV`),
  CONSTRAINT `FK33A5559EDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_configuration`
--

DROP TABLE IF EXISTS `account_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_configuration` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `chart_id` bigint(20) DEFAULT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_AccountConfiguration_Name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_configuration_aud`
--

DROP TABLE IF EXISTS `account_configuration_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_configuration_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `chart_id` bigint(20) DEFAULT NULL,
  `descr` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKEEBD655DF74E053` (`REV`),
  CONSTRAINT `FKEEBD655DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_quote`
--

DROP TABLE IF EXISTS `account_quote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_quote` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_application_id` bigint(20) NOT NULL,
  `arrears_type` varchar(255) DEFAULT NULL,
  `cheque_fee` bigint(20) DEFAULT NULL,
  `instalment` bigint(20) DEFAULT NULL,
  `principal_amount` bigint(20) NOT NULL,
  `principal_type` varchar(255) NOT NULL,
  `term_in_months` int(11) NOT NULL,
  `total_owed` bigint(20) NOT NULL,
  `arrears_rate` bigint(20) DEFAULT NULL,
  `interest_rate_id` bigint(20) NOT NULL,
  `recognition_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKE08815EA6F53E70` (`interest_rate_id`),
  KEY `FKE08815EAC985686C` (`arrears_rate`),
  KEY `IX_AccountQuote_AccountApplicationId` (`account_application_id`),
  CONSTRAINT `FKE08815EA6F53E70` FOREIGN KEY (`interest_rate_id`) REFERENCES `interest_rate` (`id`),
  CONSTRAINT `FKE08815EAC985686C` FOREIGN KEY (`arrears_rate`) REFERENCES `interest_rate` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_quote_fee`
--

DROP TABLE IF EXISTS `account_quote_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_quote_fee` (
  `account_quote_id` bigint(20) NOT NULL,
  `fees_id` bigint(20) NOT NULL,
  UNIQUE KEY `fees_id` (`fees_id`),
  KEY `FK9183CBB193923260` (`account_quote_id`),
  KEY `FK9183CBB13DE98D2` (`fees_id`),
  CONSTRAINT `FK9183CBB13DE98D2` FOREIGN KEY (`fees_id`) REFERENCES `fee` (`id`),
  CONSTRAINT `FK9183CBB193923260` FOREIGN KEY (`account_quote_id`) REFERENCES `account_quote` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_reason_code`
--

DROP TABLE IF EXISTS `account_reason_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_reason_code` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `client_may_replace` bit(1) DEFAULT NULL,
  `new_loan_default` bit(1) DEFAULT NULL,
  `suspend_earnings` bit(1) DEFAULT NULL,
  `suspend_submissions` bit(1) DEFAULT NULL,
  `trigger_insurance_claim` bit(1) DEFAULT NULL,
  `reason_code_category_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK36A1ABF6264E5FE0` (`reason_code_category_id`),
  CONSTRAINT `FK36A1ABF6264E5FE0` FOREIGN KEY (`reason_code_category_id`) REFERENCES `account_reason_code_category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_reason_code_category`
--

DROP TABLE IF EXISTS `account_reason_code_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_reason_code_category` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `account_reason_code_history`
--

DROP TABLE IF EXISTS `account_reason_code_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_reason_code_history` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `reason_code_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF958E14BAD79C42F` (`reason_code_id`),
  KEY `FKF958E14BDB515B79` (`account_id`),
  CONSTRAINT `FKF958E14BDB515B79` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKF958E14BAD79C42F` FOREIGN KEY (`reason_code_id`) REFERENCES `account_reason_code` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accounting_document`
--

DROP TABLE IF EXISTS `accounting_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_document` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `allocation_time` datetime DEFAULT NULL,
  `document_number` bigint(20) DEFAULT NULL,
  `document_type` varchar(255) DEFAULT NULL,
  `tx_header_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `document_type` (`document_type`,`document_number`),
  KEY `FKC84CD7851B61ED44` (`tx_header_id`),
  CONSTRAINT `FKC84CD7851B61ED44` FOREIGN KEY (`tx_header_id`) REFERENCES `tx_header` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accounting_document_number`
--

DROP TABLE IF EXISTS `accounting_document_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_document_number` (
  `document_type` varchar(50) NOT NULL,
  `next_number` bigint(20) NOT NULL,
  PRIMARY KEY (`document_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accounting_job`
--

DROP TABLE IF EXISTS `accounting_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_job` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `complete_date` datetime DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `job_detail` varchar(255) DEFAULT NULL,
  `job_status` varchar(255) DEFAULT NULL,
  `job_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_AccountingJob_JobStatus` (`job_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accounting_period`
--

DROP TABLE IF EXISTS `accounting_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_period` (
  `id` bigint(20) NOT NULL,
  `active` bit(1) NOT NULL,
  `date_from` datetime NOT NULL,
  `date_to` datetime NOT NULL,
  `financial_year` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `IX_AccountingPeriod_Name` (`name`),
  KEY `IX_AccountingPeriod_DateTo` (`date_to`),
  KEY `IX_AccountingPeriod_DateFrom` (`date_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `accounting_period_aud`
--

DROP TABLE IF EXISTS `accounting_period_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_period_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `date_from` datetime DEFAULT NULL,
  `date_to` datetime DEFAULT NULL,
  `financial_year` varchar(50) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK2FF56B1CDF74E053` (`REV`),
  CONSTRAINT `FK2FF56B1CDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement`
--

DROP TABLE IF EXISTS `agreement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `activation_strategy` varchar(255) DEFAULT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `first_instalment_due_date` datetime DEFAULT NULL,
  `instalment_strategy` int(11) DEFAULT NULL,
  `open_date` datetime NOT NULL,
  `outlet_id` bigint(20) DEFAULT NULL,
  `party_role_id` bigint(20) NOT NULL,
  `simulation` bit(1) NOT NULL,
  `term` int(11) NOT NULL,
  `term_type` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `arrears_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3A29520ADB515B79` (`account_id`),
  KEY `IX_Agreement_Account` (`account_id`),
  KEY `IX_Agreement_PartyRoleId` (`party_role_id`),
  CONSTRAINT `FK3A29520ADB515B79` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action`
--

DROP TABLE IF EXISTS `agreement_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `enabled` bit(1) NOT NULL,
  `start_date` datetime NOT NULL,
  `agreement_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3181AA0BF2B699` (`agreement_id`),
  KEY `IX_AgreementAction_Agreement` (`agreement_id`),
  CONSTRAINT `FK3181AA0BF2B699` FOREIGN KEY (`agreement_id`) REFERENCES `agreement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_aud`
--

DROP TABLE IF EXISTS `agreement_action_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `agreement_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE564567CDF74E053` (`REV`),
  CONSTRAINT `FKE564567CDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_cool_off`
--

DROP TABLE IF EXISTS `agreement_action_cool_off`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_cool_off` (
  `cool_off_descr` varchar(255) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `source_descr` varchar(255) DEFAULT NULL,
  `time_period_applicable` bit(1) DEFAULT NULL,
  `time_period_in_days` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `cool_off_account_id` bigint(20) DEFAULT NULL,
  `cool_off_chart_id` bigint(20) DEFAULT NULL,
  `debtorAccount_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `source_account_id` bigint(20) DEFAULT NULL,
  `source_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK18BB632DCE18B21E` (`debtor_chart_id`),
  KEY `FK18BB632D43FEFFDA` (`id`),
  KEY `FK18BB632D3609EFBB` (`cool_off_chart_id`),
  KEY `FK18BB632D2680DD59` (`source_chart_id`),
  KEY `FK18BB632D6418BBFF` (`cool_off_account_id`),
  KEY `FK18BB632D128ABA1D` (`source_account_id`),
  KEY `FK18BB632D9A0161AF` (`debtorAccount_id`),
  CONSTRAINT `FK18BB632D9A0161AF` FOREIGN KEY (`debtorAccount_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK18BB632D128ABA1D` FOREIGN KEY (`source_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK18BB632D2680DD59` FOREIGN KEY (`source_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK18BB632D3609EFBB` FOREIGN KEY (`cool_off_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK18BB632D43FEFFDA` FOREIGN KEY (`id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FK18BB632D6418BBFF` FOREIGN KEY (`cool_off_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK18BB632DCE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement`
--

DROP TABLE IF EXISTS `agreement_action_disbursement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement` (
  `amount` bigint(20) NOT NULL,
  `bank_descr` varchar(255) DEFAULT NULL,
  `beneficiary_party_role_id` bigint(20) NOT NULL,
  `debtor_advance_provision_descr` varchar(255) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `disbursement_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_descr` varchar(255) DEFAULT NULL,
  `user_reference` varchar(255) NOT NULL,
  `id` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `bank_chart_id` bigint(20) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_chart_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_account_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_descr` varchar(255) DEFAULT NULL,
  `unrecognised_principal_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKEBFB72D5712EF340` (`disbursement_suspense_account_id`),
  KEY `FKEBFB72D51217033C` (`disbursement_suspense_chart_id`),
  KEY `FKEBFB72D5CE18B21E` (`debtor_chart_id`),
  KEY `FKEBFB72D543FEFFDA` (`id`),
  KEY `FKEBFB72D5AD81FCE5` (`debtor_advance_provision_chart_id`),
  KEY `FKEBFB72D5338071A2` (`debtor_account_id`),
  KEY `FKEBFB72D5DDC226A9` (`debtor_advance_provision_account_id`),
  KEY `FKEBFB72D5C2CC9458` (`bank_chart_id`),
  KEY `FKEBFB72D5CAC4AD5C` (`bank_account_id`),
  KEY `FKEBFB72D5D8549D9D` (`unrecognised_principal_chart_id`),
  KEY `FKEBFB72D5C62725D0` (`unrecognised_principal_account_id`),
  CONSTRAINT `FKEBFB72D5C62725D0` FOREIGN KEY (`unrecognised_principal_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKEBFB72D51217033C` FOREIGN KEY (`disbursement_suspense_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEBFB72D5338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKEBFB72D543FEFFDA` FOREIGN KEY (`id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FKEBFB72D5712EF340` FOREIGN KEY (`disbursement_suspense_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKEBFB72D5AD81FCE5` FOREIGN KEY (`debtor_advance_provision_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEBFB72D5C2CC9458` FOREIGN KEY (`bank_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEBFB72D5CAC4AD5C` FOREIGN KEY (`bank_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKEBFB72D5CE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEBFB72D5D8549D9D` FOREIGN KEY (`unrecognised_principal_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEBFB72D5DDC226A9` FOREIGN KEY (`debtor_advance_provision_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_3_party`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_3_party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_3_party` (
  `target_bank_account_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK563BC0707582F69B` (`id`),
  CONSTRAINT `FK563BC0707582F69B` FOREIGN KEY (`id`) REFERENCES `agreement_action_disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_3_party_aud`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_3_party_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_3_party_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `target_bank_account_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK58B2B261BF20992F` (`id`,`REV`),
  CONSTRAINT `FK58B2B261BF20992F` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_action_disbursement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_3_party_m`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_3_party_m`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_3_party_m` (
  `cheque_fee` bigint(20) DEFAULT NULL,
  `cheque_fee_desc` varchar(255) DEFAULT NULL,
  `document_reference` varchar(255) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `cheque_fee_account` bigint(20) DEFAULT NULL,
  `cheque_fee_chart` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB64D705E7582F69B` (`id`),
  KEY `FKB64D705E257D3C62` (`cheque_fee_account`),
  KEY `FKB64D705EBA9801E0` (`cheque_fee_chart`),
  CONSTRAINT `FKB64D705EBA9801E0` FOREIGN KEY (`cheque_fee_chart`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKB64D705E257D3C62` FOREIGN KEY (`cheque_fee_account`) REFERENCES `account` (`id`),
  CONSTRAINT `FKB64D705E7582F69B` FOREIGN KEY (`id`) REFERENCES `agreement_action_disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_3_party_m_aud`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_3_party_m_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_3_party_m_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `cheque_fee` bigint(20) DEFAULT NULL,
  `cheque_fee_desc` varchar(255) DEFAULT NULL,
  `document_reference` varchar(255) DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `cheque_fee_account` bigint(20) DEFAULT NULL,
  `cheque_fee_chart` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKF76EBB4FBF20992F` (`id`,`REV`),
  CONSTRAINT `FKF76EBB4FBF20992F` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_action_disbursement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_aud`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `bank_descr` varchar(255) DEFAULT NULL,
  `beneficiary_party_role_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_descr` varchar(255) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `disbursement_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_descr` varchar(255) DEFAULT NULL,
  `user_reference` varchar(255) DEFAULT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `bank_chart_id` bigint(20) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_chart_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_account_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_descr` varchar(255) DEFAULT NULL,
  `unrecognised_principal_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKC8D8AA4671E7EAEE` (`id`,`REV`),
  CONSTRAINT `FKC8D8AA4671E7EAEE` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_action_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_cash`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_cash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_cash` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK523D3E5D7582F69B` (`id`),
  CONSTRAINT `FK523D3E5D7582F69B` FOREIGN KEY (`id`) REFERENCES `agreement_action_disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_cash_aud`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_cash_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_cash_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK5AB971CEBF20992F` (`id`,`REV`),
  CONSTRAINT `FK5AB971CEBF20992F` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_action_disbursement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_eft`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_eft`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_eft` (
  `target_bank_account_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `target_bank_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC8D8B7897582F69B` (`id`),
  CONSTRAINT `FKC8D8B7897582F69B` FOREIGN KEY (`id`) REFERENCES `agreement_action_disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_eft_aud`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_eft_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_eft_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `target_bank_account_id` bigint(20) DEFAULT NULL,
  `target_bank_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKB75C74FABF20992F` (`id`,`REV`),
  CONSTRAINT `FKB75C74FABF20992F` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_action_disbursement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_special`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_special`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_special` (
  `disbursement_special_type` varchar(255) DEFAULT NULL,
  `target_bank_account_id` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKAC32B54F7582F69B` (`id`),
  CONSTRAINT `FKAC32B54F7582F69B` FOREIGN KEY (`id`) REFERENCES `agreement_action_disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_disbursement_special_aud`
--

DROP TABLE IF EXISTS `agreement_action_disbursement_special_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_disbursement_special_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `disbursement_special_type` varchar(255) DEFAULT NULL,
  `target_bank_account_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK3E561FC0BF20992F` (`id`,`REV`),
  CONSTRAINT `FK3E561FC0BF20992F` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_action_disbursement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_payment`
--

DROP TABLE IF EXISTS `agreement_action_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_payment` (
  `debtor_descr` varchar(255) DEFAULT NULL,
  `high_priority_chart_list` varchar(255) DEFAULT NULL,
  `low_priority_chart_list` varchar(255) DEFAULT NULL,
  `oldest_first` bit(1) DEFAULT NULL,
  `source_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `source_account_id` bigint(20) DEFAULT NULL,
  `source_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4ED447D2CE18B21E` (`debtor_chart_id`),
  KEY `FK4ED447D243FEFFDA` (`id`),
  KEY `FK4ED447D22680DD59` (`source_chart_id`),
  KEY `FK4ED447D2338071A2` (`debtor_account_id`),
  KEY `FK4ED447D2128ABA1D` (`source_account_id`),
  CONSTRAINT `FK4ED447D2128ABA1D` FOREIGN KEY (`source_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK4ED447D22680DD59` FOREIGN KEY (`source_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK4ED447D2338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK4ED447D243FEFFDA` FOREIGN KEY (`id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FK4ED447D2CE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_refinance`
--

DROP TABLE IF EXISTS `agreement_action_refinance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_refinance` (
  `refinance_quote_id` bigint(20) DEFAULT NULL,
  `source_desc` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `source_account` bigint(20) DEFAULT NULL,
  `source_chart` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBF7E45137582F69B` (`id`),
  KEY `FKBF7E4513FC768D15` (`source_account`),
  KEY `FKBF7E45137D03E353` (`source_chart`),
  CONSTRAINT `FKBF7E45137D03E353` FOREIGN KEY (`source_chart`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKBF7E45137582F69B` FOREIGN KEY (`id`) REFERENCES `agreement_action_disbursement` (`id`),
  CONSTRAINT `FKBF7E4513FC768D15` FOREIGN KEY (`source_account`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_refinance_aud`
--

DROP TABLE IF EXISTS `agreement_action_refinance_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_refinance_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `refinance_quote_id` bigint(20) DEFAULT NULL,
  `source_desc` varchar(255) DEFAULT NULL,
  `source_account` bigint(20) DEFAULT NULL,
  `source_chart` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK9E0C2D84BF20992F` (`id`,`REV`),
  CONSTRAINT `FK9E0C2D84BF20992F` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_action_disbursement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_refund`
--

DROP TABLE IF EXISTS `agreement_action_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_refund` (
  `bank_descr` varchar(255) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `bankChart_id` bigint(20) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB38FE02CCE18B21E` (`debtor_chart_id`),
  KEY `FKB38FE02C43FEFFDA` (`id`),
  KEY `FKB38FE02C338071A2` (`debtor_account_id`),
  KEY `FKB38FE02CBCCA2FF1` (`bankChart_id`),
  KEY `FKB38FE02CCAC4AD5C` (`bank_account_id`),
  CONSTRAINT `FKB38FE02CCAC4AD5C` FOREIGN KEY (`bank_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKB38FE02C338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKB38FE02C43FEFFDA` FOREIGN KEY (`id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FKB38FE02CBCCA2FF1` FOREIGN KEY (`bankChart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKB38FE02CCE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_action_settle`
--

DROP TABLE IF EXISTS `agreement_action_settle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_action_settle` (
  `debtor_descr` varchar(255) DEFAULT NULL,
  `excludePendingInstalments` bit(1) DEFAULT NULL,
  `source_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `source_account_id` bigint(20) DEFAULT NULL,
  `source_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB54B11FFCE18B21E` (`debtor_chart_id`),
  KEY `FKB54B11FF43FEFFDA` (`id`),
  KEY `FKB54B11FF2680DD59` (`source_chart_id`),
  KEY `FKB54B11FF338071A2` (`debtor_account_id`),
  KEY `FKB54B11FF128ABA1D` (`source_account_id`),
  CONSTRAINT `FKB54B11FF128ABA1D` FOREIGN KEY (`source_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKB54B11FF2680DD59` FOREIGN KEY (`source_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKB54B11FF338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKB54B11FF43FEFFDA` FOREIGN KEY (`id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FKB54B11FFCE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_agreement_term`
--

DROP TABLE IF EXISTS `agreement_agreement_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_agreement_term` (
  `agreement_id` bigint(20) NOT NULL,
  `agreementTerms_id` bigint(20) NOT NULL,
  PRIMARY KEY (`agreement_id`,`agreementTerms_id`),
  UNIQUE KEY `agreementTerms_id` (`agreementTerms_id`),
  KEY `FKAB42E856F2B699` (`agreement_id`),
  KEY `FKAB42E856773AD612` (`agreementTerms_id`),
  CONSTRAINT `FKAB42E856773AD612` FOREIGN KEY (`agreementTerms_id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FKAB42E856F2B699` FOREIGN KEY (`agreement_id`) REFERENCES `agreement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_agreement_term_aud`
--

DROP TABLE IF EXISTS `agreement_agreement_term_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_agreement_term_aud` (
  `REV` int(11) NOT NULL,
  `agreement_id` bigint(20) NOT NULL,
  `agreementTerms_id` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`REV`,`agreement_id`,`agreementTerms_id`),
  KEY `FK4777747DF74E053` (`REV`),
  CONSTRAINT `FK4777747DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_aud`
--

DROP TABLE IF EXISTS `agreement_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `activation_strategy` varchar(255) DEFAULT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `first_instalment_due_date` datetime DEFAULT NULL,
  `instalment_strategy` int(11) DEFAULT NULL,
  `open_date` datetime DEFAULT NULL,
  `outlet_id` bigint(20) DEFAULT NULL,
  `party_role_id` bigint(20) DEFAULT NULL,
  `simulation` bit(1) DEFAULT NULL,
  `term` int(11) DEFAULT NULL,
  `term_type` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `arrears_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK81E9E6FBDF74E053` (`REV`),
  CONSTRAINT `FK81E9E6FBDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_bayport_legacy`
--

DROP TABLE IF EXISTS `agreement_bayport_legacy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_bayport_legacy` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF14E4BC2B26F5844` (`id`),
  CONSTRAINT `FKF14E4BC2B26F5844` FOREIGN KEY (`id`) REFERENCES `agreement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_bayport_legacy_aud`
--

DROP TABLE IF EXISTS `agreement_bayport_legacy_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_bayport_legacy_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKC60B44B3641FE58` (`id`,`REV`),
  CONSTRAINT `FKC60B44B3641FE58` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query`
--

DROP TABLE IF EXISTS `agreement_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `start_date` datetime NOT NULL,
  `agreement_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKAFED9E53F2B699` (`agreement_id`),
  KEY `IX_AgreementQuery_Agreement` (`agreement_id`),
  CONSTRAINT `FKAFED9E53F2B699` FOREIGN KEY (`agreement_id`) REFERENCES `agreement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_aud`
--

DROP TABLE IF EXISTS `agreement_query_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `agreement_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKA8ACE6C4DF74E053` (`REV`),
  CONSTRAINT `FKA8ACE6C4DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_collectible`
--

DROP TABLE IF EXISTS `agreement_query_collectible`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_collectible` (
  `maximum` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB0580C90C10A7C3A` (`id`),
  CONSTRAINT `FKB0580C90C10A7C3A` FOREIGN KEY (`id`) REFERENCES `agreement_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_collectible_aud`
--

DROP TABLE IF EXISTS `agreement_query_collectible_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_collectible_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `maximum` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK758BEE814A1E374E` (`id`,`REV`),
  CONSTRAINT `FK758BEE814A1E374E` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_query_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_instalment`
--

DROP TABLE IF EXISTS `agreement_query_instalment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_instalment` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA326C33BC10A7C3A` (`id`),
  CONSTRAINT `FKA326C33BC10A7C3A` FOREIGN KEY (`id`) REFERENCES `agreement_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_instalment_aud`
--

DROP TABLE IF EXISTS `agreement_query_instalment_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_instalment_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK5F7957AC4A1E374E` (`id`,`REV`),
  CONSTRAINT `FK5F7957AC4A1E374E` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_query_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_refinance`
--

DROP TABLE IF EXISTS `agreement_query_refinance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_refinance` (
  `exclude_pending_instalments` bit(1) DEFAULT NULL,
  `penalty_capped` bit(1) DEFAULT NULL,
  `penalty_days` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4EDB7F5BC10A7C3A` (`id`),
  CONSTRAINT `FK4EDB7F5BC10A7C3A` FOREIGN KEY (`id`) REFERENCES `agreement_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_refinance_aud`
--

DROP TABLE IF EXISTS `agreement_query_refinance_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_refinance_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `exclude_pending_instalments` bit(1) DEFAULT NULL,
  `penalty_capped` bit(1) DEFAULT NULL,
  `penalty_days` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK6C3303CC4A1E374E` (`id`,`REV`),
  CONSTRAINT `FK6C3303CC4A1E374E` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_query_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_settlement`
--

DROP TABLE IF EXISTS `agreement_query_settlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_settlement` (
  `excluded_pending_instalments` bit(1) DEFAULT NULL,
  `expiry_days` int(11) DEFAULT NULL,
  `penalty_capped` bit(1) DEFAULT NULL,
  `penalty_days` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK71E11E95C10A7C3A` (`id`),
  CONSTRAINT `FK71E11E95C10A7C3A` FOREIGN KEY (`id`) REFERENCES `agreement_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_query_settlement_aud`
--

DROP TABLE IF EXISTS `agreement_query_settlement_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_settlement_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `excluded_pending_instalments` bit(1) DEFAULT NULL,
  `expiry_days` int(11) DEFAULT NULL,
  `penalty_capped` bit(1) DEFAULT NULL,
  `penalty_days` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK488276064A1E374E` (`id`,`REV`),
  CONSTRAINT `FK488276064A1E374E` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_query_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term`
--

DROP TABLE IF EXISTS `agreement_term`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `active` bit(1) NOT NULL,
  `attracts_arrears` bit(1) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `start_date` datetime NOT NULL,
  `term` int(11) NOT NULL,
  `term_type` varchar(255) NOT NULL,
  `agreement_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBB5B6181F2B699` (`agreement_id`),
  KEY `IX_AgreementTerm_Agreement` (`agreement_id`),
  CONSTRAINT `FKBB5B6181F2B699` FOREIGN KEY (`agreement_id`) REFERENCES `agreement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_adhoc_fee`
--

DROP TABLE IF EXISTS `agreement_term_adhoc_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_adhoc_fee` (
  `debtor_descr` varchar(255) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDE4A9642CE18B21E` (`debtor_chart_id`),
  KEY `FKDE4A964263B5450` (`id`),
  KEY `FKDE4A9642338071A2` (`debtor_account_id`),
  KEY `FKDE4A9642D1C19C85` (`recognised_fee_interest_account_id`),
  KEY `FKDE4A9642168AECC2` (`recognised_fee_account_id`),
  KEY `FKDE4A9642AB5D39C1` (`recognised_fee_interest_chart_id`),
  KEY `FKDE4A9642E1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FKDE4A9642E1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKDE4A9642168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKDE4A9642338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKDE4A964263B5450` FOREIGN KEY (`id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FKDE4A9642AB5D39C1` FOREIGN KEY (`recognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKDE4A9642CE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKDE4A9642D1C19C85` FOREIGN KEY (`recognised_fee_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_adhoc_fee_aud`
--

DROP TABLE IF EXISTS `agreement_term_adhoc_fee_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_adhoc_fee_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKEEDE4F335C591464` (`id`,`REV`),
  CONSTRAINT `FKEEDE4F335C591464` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_adhoc_fee_fixed_i`
--

DROP TABLE IF EXISTS `agreement_term_adhoc_fee_fixed_i`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_adhoc_fee_fixed_i` (
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA13BC161A0D1EFD` (`id`),
  CONSTRAINT `FKA13BC161A0D1EFD` FOREIGN KEY (`id`) REFERENCES `agreement_term_adhoc_fee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_adhoc_fee_fixed_i_aud`
--

DROP TABLE IF EXISTS `agreement_term_adhoc_fee_fixed_i_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_adhoc_fee_fixed_i_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK30F6D2D237BBC091` (`id`,`REV`),
  CONSTRAINT `FK30F6D2D237BBC091` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_adhoc_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_adhoc_fee_floating_i`
--

DROP TABLE IF EXISTS `agreement_term_adhoc_fee_floating_i`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_adhoc_fee_floating_i` (
  `base_rate_enum` int(11) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK46F4CC8DA0D1EFD` (`id`),
  CONSTRAINT `FK46F4CC8DA0D1EFD` FOREIGN KEY (`id`) REFERENCES `agreement_term_adhoc_fee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_adhoc_fee_floating_i_aud`
--

DROP TABLE IF EXISTS `agreement_term_adhoc_fee_floating_i_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_adhoc_fee_floating_i_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `base_rate_enum` int(11) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKEF9E67FE37BBC091` (`id`,`REV`),
  CONSTRAINT `FKEF9E67FE37BBC091` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_adhoc_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee` (
  `debtor_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `recognition_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDD27AD58CE18B21E` (`debtor_chart_id`),
  KEY `FKDD27AD5863B5450` (`id`),
  KEY `FKDD27AD58338071A2` (`debtor_account_id`),
  CONSTRAINT `FKDD27AD58338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKDD27AD5863B5450` FOREIGN KEY (`id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FKDD27AD58CE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `recognition_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK7C8DEB495C591464` (`id`,`REV`),
  CONSTRAINT `FK7C8DEB495C591464` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_aval`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_aval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_aval` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK152F81A7A584DC69` (`id`),
  CONSTRAINT `FK152F81A7A584DC69` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee_fixed_t_partial_i_payroll` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_aval_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_aval_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_aval_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK8E50018ACFEE7FD` (`id`,`REV`),
  CONSTRAINT `FK8E50018ACFEE7FD` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_i`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_i`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_i` (
  `allocation_method` int(11) DEFAULT NULL,
  `ias39_applicable` bit(1) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `interest_rate` double DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK56F362771245CD27` (`id`),
  KEY `FK56F3627794860A85` (`unrecognised_fee_chart_id`),
  KEY `FK56F36277168AECC2` (`recognised_fee_account_id`),
  KEY `FK56F3627713F94C49` (`unrecognised_fee_account_id`),
  KEY `FK56F36277A5E903AD` (`recognised_fee_interest_account_id`),
  KEY `FK56F36277E1C7753E` (`recognised_fee_chart_id`),
  KEY `FK56F36277FD531FEB` (`recognised_fee_interest_chart_id`),
  CONSTRAINT `FK56F36277FD531FEB` FOREIGN KEY (`recognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK56F362771245CD27` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee` (`id`),
  CONSTRAINT `FK56F3627713F94C49` FOREIGN KEY (`unrecognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK56F36277168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK56F3627794860A85` FOREIGN KEY (`unrecognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK56F36277A5E903AD` FOREIGN KEY (`recognised_fee_interest_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK56F36277E1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_i_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_i_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_i_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `allocation_method` int(11) DEFAULT NULL,
  `ias39_applicable` bit(1) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `interest_rate` double DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK112BF8E8FA3D49BB` (`id`,`REV`),
  CONSTRAINT `FK112BF8E8FA3D49BB` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_i_immediate_r`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_i_immediate_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_i_immediate_r` (
  `interest_applicable` bit(1) DEFAULT NULL,
  `interest_rate` double DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8468773A1245CD27` (`id`),
  KEY `FK8468773AD1C19C85` (`recognised_fee_interest_account_id`),
  KEY `FK8468773A168AECC2` (`recognised_fee_account_id`),
  KEY `FK8468773AAB5D39C1` (`recognised_fee_interest_chart_id`),
  KEY `FK8468773AE1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FK8468773AE1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK8468773A1245CD27` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee` (`id`),
  CONSTRAINT `FK8468773A168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK8468773AAB5D39C1` FOREIGN KEY (`recognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK8468773AD1C19C85` FOREIGN KEY (`recognised_fee_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_i_immediate_r_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_i_immediate_r_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_i_immediate_r_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `interest_rate` double DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKA0B2F42BFA3D49BB` (`id`,`REV`),
  CONSTRAINT `FKA0B2F42BFA3D49BB` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_amortised_r_payroll`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_amortised_r_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_amortised_r_payroll` (
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) NOT NULL,
  `recognised_fee_chart_id` bigint(20) NOT NULL,
  `unrecognised_fee_account_id` bigint(20) NOT NULL,
  `unrecognised_fee_chart_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK12867E2ABAA79C94` (`id`),
  KEY `FK12867E2A94860A85` (`unrecognised_fee_chart_id`),
  KEY `FK12867E2A168AECC2` (`recognised_fee_account_id`),
  KEY `FK12867E2A13F94C49` (`unrecognised_fee_account_id`),
  KEY `FK12867E2AE1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FK12867E2AE1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK12867E2A13F94C49` FOREIGN KEY (`unrecognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK12867E2A168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK12867E2A94860A85` FOREIGN KEY (`unrecognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK12867E2ABAA79C94` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee_payroll` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_amortised_r_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK5194031BF51F9AA8` (`id`,`REV`),
  CONSTRAINT `FK5194031BF51F9AA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_payroll_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_fixed_i_payroll`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_fixed_i_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_fixed_i_payroll` (
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) NOT NULL,
  `recognised_fee_chart_id` bigint(20) NOT NULL,
  `unrecognised_fee_account_id` bigint(20) NOT NULL,
  `unrecognised_fee_chart_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK98F6087BAA79C94` (`id`),
  KEY `FK98F608794860A85` (`unrecognised_fee_chart_id`),
  KEY `FK98F6087168AECC2` (`recognised_fee_account_id`),
  KEY `FK98F608713F94C49` (`unrecognised_fee_account_id`),
  KEY `FK98F6087E1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FK98F6087E1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK98F608713F94C49` FOREIGN KEY (`unrecognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK98F6087168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK98F608794860A85` FOREIGN KEY (`unrecognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK98F6087BAA79C94` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee_payroll` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_fixed_i_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKFA7A6EF8F51F9AA8` (`id`,`REV`),
  CONSTRAINT `FKFA7A6EF8F51F9AA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_payroll_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_flat_r`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_flat_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_flat_r` (
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCAD135891245CD27` (`id`),
  KEY `FKCAD1358994860A85` (`unrecognised_fee_chart_id`),
  KEY `FKCAD13589168AECC2` (`recognised_fee_account_id`),
  KEY `FKCAD1358913F94C49` (`unrecognised_fee_account_id`),
  KEY `FKCAD13589E1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FKCAD13589E1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKCAD135891245CD27` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee` (`id`),
  CONSTRAINT `FKCAD1358913F94C49` FOREIGN KEY (`unrecognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKCAD13589168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKCAD1358994860A85` FOREIGN KEY (`unrecognised_fee_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_flat_r_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_flat_r_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_flat_r_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKECE5F2FAFA3D49BB` (`id`,`REV`),
  CONSTRAINT `FKECE5F2FAFA3D49BB` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_immediate_r_payroll`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_immediate_r_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_immediate_r_payroll` (
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF7DD60D1245CD27` (`id`),
  KEY `FKF7DD60D94860A85` (`unrecognised_fee_chart_id`),
  KEY `FKF7DD60D168AECC2` (`recognised_fee_account_id`),
  KEY `FKF7DD60D13F94C49` (`unrecognised_fee_account_id`),
  KEY `FKF7DD60DE1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FKF7DD60DBAA79C94` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee_payroll` (`id`),
  CONSTRAINT `FKF7DD60D1245CD27` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee` (`id`),
  CONSTRAINT `FKF7DD60D13F94C49` FOREIGN KEY (`unrecognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKF7DD60D168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKF7DD60D94860A85` FOREIGN KEY (`unrecognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKF7DD60DE1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_immediate_r_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKD186B17EFA3D49BB` (`id`,`REV`),
  CONSTRAINT `FKD186B17EF51F9AA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_payroll_aud` (`id`, `REV`),
  CONSTRAINT `FKD186B17EFA3D49BB` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_partial_i_payroll`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_partial_i_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_partial_i_payroll` (
  `total_interest_rate` double NOT NULL,
  `id` bigint(20) NOT NULL,
  `principal_term_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKBE9BD194BAA79C94` (`id`),
  KEY `FKBE9BD1944BB96336` (`principal_term_id`),
  CONSTRAINT `FKBE9BD1944BB96336` FOREIGN KEY (`principal_term_id`) REFERENCES `agreement_term_principal` (`id`),
  CONSTRAINT `FKBE9BD194BAA79C94` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee_payroll` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `total_interest_rate` double DEFAULT NULL,
  `principal_term_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK829D9185F51F9AA8` (`id`,`REV`),
  CONSTRAINT `FK829D9185F51F9AA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_payroll_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_floating_i`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_floating_i`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_floating_i` (
  `allocation_method` int(11) DEFAULT NULL,
  `base_rate` int(11) DEFAULT NULL,
  `ias_39_applicable` bit(1) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKEB178BB71245CD27` (`id`),
  KEY `FKEB178BB794860A85` (`unrecognised_fee_chart_id`),
  KEY `FKEB178BB7D1C19C85` (`recognised_fee_interest_account_id`),
  KEY `FKEB178BB7168AECC2` (`recognised_fee_account_id`),
  KEY `FKEB178BB713F94C49` (`unrecognised_fee_account_id`),
  KEY `FKEB178BB7AB5D39C1` (`recognised_fee_interest_chart_id`),
  KEY `FKEB178BB7E1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FKEB178BB7E1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEB178BB71245CD27` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee` (`id`),
  CONSTRAINT `FKEB178BB713F94C49` FOREIGN KEY (`unrecognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKEB178BB7168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKEB178BB794860A85` FOREIGN KEY (`unrecognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEB178BB7AB5D39C1` FOREIGN KEY (`recognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKEB178BB7D1C19C85` FOREIGN KEY (`recognised_fee_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_floating_i_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_floating_i_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_floating_i_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `allocation_method` int(11) DEFAULT NULL,
  `base_rate` int(11) DEFAULT NULL,
  `ias_39_applicable` bit(1) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK38998228FA3D49BB` (`id`,`REV`),
  CONSTRAINT `FK38998228FA3D49BB` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_floating_i_immediate_r`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_floating_i_immediate_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_floating_i_immediate_r` (
  `base_rate` int(11) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKA46B707A1245CD27` (`id`),
  KEY `FKA46B707AD1C19C85` (`recognised_fee_interest_account_id`),
  KEY `FKA46B707A168AECC2` (`recognised_fee_account_id`),
  KEY `FKA46B707AAB5D39C1` (`recognised_fee_interest_chart_id`),
  KEY `FKA46B707AE1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FKA46B707AE1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKA46B707A1245CD27` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee` (`id`),
  CONSTRAINT `FKA46B707A168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKA46B707AAB5D39C1` FOREIGN KEY (`recognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKA46B707AD1C19C85` FOREIGN KEY (`recognised_fee_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_floating_i_immediate_r_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_floating_i_immediate_r_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_floating_i_immediate_r_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `base_rate` int(11) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKA8174D6BFA3D49BB` (`id`,`REV`),
  CONSTRAINT `FKA8174D6BFA3D49BB` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_gpf`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_gpf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_gpf` (
  `activated_date` datetime DEFAULT NULL,
  `balance_allocation_allowed` bit(1) DEFAULT NULL,
  `aval_allowed` bit(1) DEFAULT NULL,
  `first_installment_date` datetime DEFAULT NULL,
  `first_month_only` bit(1) DEFAULT NULL,
  `gpf_interest_descr` varchar(255) DEFAULT NULL,
  `gpf_rate` double NOT NULL,
  `insurance_allowed` bit(1) DEFAULT NULL,
  `partial_allowed` bit(1) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `gpf_account_id` bigint(20) DEFAULT NULL,
  `gpf_chart_id` bigint(20) DEFAULT NULL,
  `principal_term_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7C8E013663B5450` (`id`),
  KEY `FK7C8E01367282717` (`gpf_chart_id`),
  KEY `FK7C8E01364BB96336` (`principal_term_id`),
  KEY `FK7C8E013666868C5B` (`gpf_account_id`),
  CONSTRAINT `FK7C8E01364BB96336` FOREIGN KEY (`principal_term_id`) REFERENCES `agreement_term_principal` (`id`),
  CONSTRAINT `FK7C8E013663B5450` FOREIGN KEY (`id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FK7C8E013666868C5B` FOREIGN KEY (`gpf_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK7C8E01367282717` FOREIGN KEY (`gpf_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_iaf`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_iaf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_iaf` (
  `balance_allocation_allowed` bit(1) DEFAULT NULL,
  `aval_allowed` bit(1) DEFAULT NULL,
  `iaf_days` bigint(20) DEFAULT NULL,
  `insurance_allowed` bit(1) DEFAULT NULL,
  `partial_allowed` bit(1) DEFAULT NULL,
  `principal_amount` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_account_id` bigint(20) NOT NULL,
  `recognised_fee_chart_id` bigint(20) NOT NULL,
  `unrecognised_fee_account_id` bigint(20) NOT NULL,
  `unrecognised_fee_chart_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7C8E06E7BAA79C94` (`id`),
  KEY `FK7C8E06E794860A85` (`unrecognised_fee_chart_id`),
  KEY `FK7C8E06E7168AECC2` (`recognised_fee_account_id`),
  KEY `FK7C8E06E713F94C49` (`unrecognised_fee_account_id`),
  KEY `FK7C8E06E7E1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FK7C8E06E7E1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK7C8E06E713F94C49` FOREIGN KEY (`unrecognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK7C8E06E7168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK7C8E06E794860A85` FOREIGN KEY (`unrecognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK7C8E06E7BAA79C94` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee_payroll` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_insurance`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_insurance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_insurance` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3F6C80B3A584DC69` (`id`),
  CONSTRAINT `FK3F6C80B3A584DC69` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee_fixed_t_partial_i_payroll` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_insurance_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_insurance_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_insurance_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKBF339924ACFEE7FD` (`id`,`REV`),
  CONSTRAINT `FKBF339924ACFEE7FD` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_fixed_t_partial_i_payroll_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_payroll`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_payroll` (
  `interest_rate` double NOT NULL,
  `rate_term_in_months` int(11) NOT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_write_off_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_interest_account_id` bigint(20) DEFAULT NULL,
  `settlement_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_account_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5A5F193E1245CD27` (`id`),
  KEY `FK5A5F193EE52CB398` (`settlement_interest_account_id`),
  KEY `FK5A5F193ED1C19C85` (`recognised_fee_interest_account_id`),
  KEY `FK5A5F193E8753DDBB` (`settlement_write_off_chart_id`),
  KEY `FK5A5F193E8A9F29FF` (`settlement_write_off_account_id`),
  KEY `FK5A5F193EAB5D39C1` (`recognised_fee_interest_chart_id`),
  KEY `FK5A5F193E23C8C4DE` (`unrecognised_fee_interest_account_id`),
  KEY `FK5A5F193E26B8F994` (`settlement_interest_chart_id`),
  KEY `FK5A5F193EAD94A45A` (`unrecognised_fee_interest_chart_id`),
  CONSTRAINT `FK5A5F193EAD94A45A` FOREIGN KEY (`unrecognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK5A5F193E1245CD27` FOREIGN KEY (`id`) REFERENCES `agreement_term_admin_fee` (`id`),
  CONSTRAINT `FK5A5F193E23C8C4DE` FOREIGN KEY (`unrecognised_fee_interest_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK5A5F193E26B8F994` FOREIGN KEY (`settlement_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK5A5F193E8753DDBB` FOREIGN KEY (`settlement_write_off_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK5A5F193E8A9F29FF` FOREIGN KEY (`settlement_write_off_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK5A5F193EAB5D39C1` FOREIGN KEY (`recognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK5A5F193ED1C19C85` FOREIGN KEY (`recognised_fee_interest_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK5A5F193EE52CB398` FOREIGN KEY (`settlement_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_admin_fee_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_admin_fee_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_admin_fee_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_write_off_descr` varchar(255) DEFAULT NULL,
  `unrecognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_interest_account_id` bigint(20) DEFAULT NULL,
  `settlement_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_account_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK76C0F42FFA3D49BB` (`id`,`REV`),
  CONSTRAINT `FK76C0F42FFA3D49BB` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_admin_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_arrears`
--

DROP TABLE IF EXISTS `agreement_term_arrears`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_arrears` (
  `arrears_interest_descr` varchar(255) DEFAULT NULL,
  `arrears_penalty_descr` varchar(255) DEFAULT NULL,
  `calculated_on_type` int(11) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `interest_rate` double DEFAULT NULL,
  `penaltyFeePercent` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `recenty_type` int(11) DEFAULT NULL,
  `recency_value` int(11) DEFAULT NULL,
  `settlement_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_write_off_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `arrears_interest_account_id` bigint(20) DEFAULT NULL,
  `arrears_interest_chart_id` bigint(20) DEFAULT NULL,
  `arrears_penalty_account_id` bigint(20) DEFAULT NULL,
  `arrears_penalty_chart_id` bigint(20) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `settlement_interest_account_id` bigint(20) DEFAULT NULL,
  `settlement_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_account_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK35B0BD00CE18B21E` (`debtor_chart_id`),
  KEY `FK35B0BD0063B5450` (`id`),
  KEY `FK35B0BD00E52CB398` (`settlement_interest_account_id`),
  KEY `FK35B0BD00CCA11AE9` (`arrears_interest_chart_id`),
  KEY `FK35B0BD00338071A2` (`debtor_account_id`),
  KEY `FK35B0BD008753DDBB` (`settlement_write_off_chart_id`),
  KEY `FK35B0BD008A9F29FF` (`settlement_write_off_account_id`),
  KEY `FK35B0BD0026B8F994` (`settlement_interest_chart_id`),
  KEY `FK35B0BD008FF8DC80` (`arrears_penalty_chart_id`),
  KEY `FK35B0BD002611EF02` (`arrears_penalty_account_id`),
  KEY `FK35B0BD00B191D3AD` (`arrears_interest_account_id`),
  CONSTRAINT `FK35B0BD008FF8DC80` FOREIGN KEY (`arrears_penalty_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK35B0BD002611EF02` FOREIGN KEY (`arrears_penalty_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK35B0BD0026B8F994` FOREIGN KEY (`settlement_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK35B0BD00338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK35B0BD0063B5450` FOREIGN KEY (`id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FK35B0BD008753DDBB` FOREIGN KEY (`settlement_write_off_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK35B0BD008A9F29FF` FOREIGN KEY (`settlement_write_off_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK35B0BD00B191D3AD` FOREIGN KEY (`arrears_interest_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK35B0BD00CCA11AE9` FOREIGN KEY (`arrears_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK35B0BD00CE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK35B0BD00E52CB398` FOREIGN KEY (`settlement_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_arrears_aud`
--

DROP TABLE IF EXISTS `agreement_term_arrears_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_arrears_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `arrears_interest_descr` varchar(255) DEFAULT NULL,
  `arrears_penalty_descr` varchar(255) DEFAULT NULL,
  `calculated_on_type` int(11) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `interest_rate` double DEFAULT NULL,
  `penaltyFeePercent` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `recenty_type` int(11) DEFAULT NULL,
  `recency_value` int(11) DEFAULT NULL,
  `settlement_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_write_off_descr` varchar(255) DEFAULT NULL,
  `arrears_interest_account_id` bigint(20) DEFAULT NULL,
  `arrears_interest_chart_id` bigint(20) DEFAULT NULL,
  `arrears_penalty_account_id` bigint(20) DEFAULT NULL,
  `arrears_penalty_chart_id` bigint(20) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `settlement_interest_account_id` bigint(20) DEFAULT NULL,
  `settlement_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_account_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK4536E6F15C591464` (`id`,`REV`),
  CONSTRAINT `FK4536E6F15C591464` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_arrears_fixed_r`
--

DROP TABLE IF EXISTS `agreement_term_arrears_fixed_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_arrears_fixed_r` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_arrears_linked_r`
--

DROP TABLE IF EXISTS `agreement_term_arrears_linked_r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_arrears_linked_r` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_aud`
--

DROP TABLE IF EXISTS `agreement_term_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `active` bit(1) DEFAULT NULL,
  `attracts_arrears` bit(1) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `term` int(11) DEFAULT NULL,
  `term_type` varchar(255) DEFAULT NULL,
  `agreement_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKF40962F2DF74E053` (`REV`),
  CONSTRAINT `FKF40962F2DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment`
--

DROP TABLE IF EXISTS `agreement_term_instalment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment` (
  `effective_day` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD47CD74D63B5450` (`id`),
  CONSTRAINT `FKD47CD74D63B5450` FOREIGN KEY (`id`) REFERENCES `agreement_term` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment_aud`
--

DROP TABLE IF EXISTS `agreement_term_instalment_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `effective_day` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK10A312BE5C591464` (`id`,`REV`),
  CONSTRAINT `FK10A312BE5C591464` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment_ideal_repayment`
--

DROP TABLE IF EXISTS `agreement_term_instalment_ideal_repayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment_ideal_repayment` (
  `max_instalment` bigint(20) DEFAULT NULL,
  `recurrence_day` int(11) DEFAULT NULL,
  `recurrence_type` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK62F33C17A5E59FFF` (`id`),
  CONSTRAINT `FK62F33C17A5E59FFF` FOREIGN KEY (`id`) REFERENCES `agreement_term_instalment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment_ideal_repayment_aud`
--

DROP TABLE IF EXISTS `agreement_term_instalment_ideal_repayment_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment_ideal_repayment_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `max_instalment` bigint(20) DEFAULT NULL,
  `recurrence_day` int(11) DEFAULT NULL,
  `recurrence_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK6602884187F093` (`id`,`REV`),
  CONSTRAINT `FK6602884187F093` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_instalment_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment_minimum_payment_due`
--

DROP TABLE IF EXISTS `agreement_term_instalment_minimum_payment_due`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment_minimum_payment_due` (
  `max_instalment` bigint(20) DEFAULT NULL,
  `recurrence_day` int(11) DEFAULT NULL,
  `recurrence_type` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDCA27998A5E59FFF` (`id`),
  CONSTRAINT `FKDCA27998A5E59FFF` FOREIGN KEY (`id`) REFERENCES `agreement_term_instalment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment_minimum_payment_due_aud`
--

DROP TABLE IF EXISTS `agreement_term_instalment_minimum_payment_due_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment_minimum_payment_due_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `max_instalment` bigint(20) DEFAULT NULL,
  `recurrence_day` int(11) DEFAULT NULL,
  `recurrence_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK6D4897894187F093` (`id`,`REV`),
  CONSTRAINT `FK6D4897894187F093` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_instalment_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment_payroll`
--

DROP TABLE IF EXISTS `agreement_term_instalment_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment_payroll` (
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7F97E33A5E59FFF` (`id`),
  CONSTRAINT `FK7F97E33A5E59FFF` FOREIGN KEY (`id`) REFERENCES `agreement_term_instalment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_instalment_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_instalment_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_instalment_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK5605D6A44187F093` (`id`,`REV`),
  CONSTRAINT `FK5605D6A44187F093` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_instalment_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal`
--

DROP TABLE IF EXISTS `agreement_term_principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal` (
  `debtor_advance_provision_descr` varchar(255) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `disbursement_suspense_descr` varchar(255) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_write_off_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_chart_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_account_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_chart_id` bigint(20) DEFAULT NULL,
  `recognised_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_interest_account_id` bigint(20) DEFAULT NULL,
  `settlement_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_account_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_chart_id` bigint(20) DEFAULT NULL,
  `recognition_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6FD39EF0C82E623A` (`recognised_interest_chart_id`),
  KEY `FK6FD39EF0AD81FCE5` (`debtor_advance_provision_chart_id`),
  KEY `FK6FD39EF0444E48B9` (`settlement_interest_account_id`),
  KEY `FK6FD39EF0338071A2` (`debtor_account_id`),
  KEY `FK6FD39EF08A9F29FF` (`settlement_write_off_account_id`),
  KEY `FK6FD39EF08753DDBB` (`settlement_write_off_chart_id`),
  KEY `FK6FD39EF0712EF340` (`disbursement_suspense_account_id`),
  KEY `FK6FD39EF0CE18B21E` (`debtor_chart_id`),
  KEY `FK6FD39EF01217033C` (`disbursement_suspense_chart_id`),
  KEY `FK6FD39EF063B5450` (`id`),
  KEY `FK6FD39EF0DDC226A9` (`debtor_advance_provision_account_id`),
  KEY `FK6FD39EF0FEEA8ABE` (`recognised_interest_account_id`),
  KEY `FK6FD39EF026B8F994` (`settlement_interest_chart_id`),
  CONSTRAINT `FK6FD39EF01217033C` FOREIGN KEY (`disbursement_suspense_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK6FD39EF026B8F994` FOREIGN KEY (`settlement_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK6FD39EF0338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK6FD39EF0444E48B9` FOREIGN KEY (`settlement_interest_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK6FD39EF063B5450` FOREIGN KEY (`id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FK6FD39EF0712EF340` FOREIGN KEY (`disbursement_suspense_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK6FD39EF08753DDBB` FOREIGN KEY (`settlement_write_off_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK6FD39EF08A9F29FF` FOREIGN KEY (`settlement_write_off_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK6FD39EF0AD81FCE5` FOREIGN KEY (`debtor_advance_provision_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK6FD39EF0C82E623A` FOREIGN KEY (`recognised_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK6FD39EF0CE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK6FD39EF0DDC226A9` FOREIGN KEY (`debtor_advance_provision_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK6FD39EF0FEEA8ABE` FOREIGN KEY (`recognised_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_aud`
--

DROP TABLE IF EXISTS `agreement_term_principal_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `debtor_advance_provision_descr` varchar(255) DEFAULT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `disbursement_suspense_descr` varchar(255) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_interest_descr` varchar(255) DEFAULT NULL,
  `settlement_write_off_descr` varchar(255) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_account_id` bigint(20) DEFAULT NULL,
  `debtor_advance_provision_chart_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_account_id` bigint(20) DEFAULT NULL,
  `disbursement_suspense_chart_id` bigint(20) DEFAULT NULL,
  `recognised_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_interest_account_id` bigint(20) DEFAULT NULL,
  `settlement_interest_chart_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_account_id` bigint(20) DEFAULT NULL,
  `settlement_write_off_chart_id` bigint(20) DEFAULT NULL,
  `recognition_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE3750E15C591464` (`id`,`REV`),
  CONSTRAINT `FKE3750E15C591464` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_fixed_i_open_b`
--

DROP TABLE IF EXISTS `agreement_term_principal_fixed_i_open_b`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_fixed_i_open_b` (
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK629A9DDC929A194` (`id`),
  CONSTRAINT `FK629A9DDC929A194` FOREIGN KEY (`id`) REFERENCES `agreement_term_principal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_fixed_i_open_b_aud`
--

DROP TABLE IF EXISTS `agreement_term_principal_fixed_i_open_b_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_fixed_i_open_b_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK23841D4E39171FA8` (`id`,`REV`),
  CONSTRAINT `FK23841D4E39171FA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_principal_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_fixed_t_fixed_i_payroll`
--

DROP TABLE IF EXISTS `agreement_term_principal_fixed_t_fixed_i_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_fixed_t_fixed_i_payroll` (
  `interest_rate` double DEFAULT NULL,
  `penalty_capped` bit(1) DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_interest_descr` varchar(255) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `unrecognised_interest_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_interest_chart_id` bigint(20) DEFAULT NULL,
  `bank_descr` varchar(255) DEFAULT NULL,
  `unrecognised_principal_descr` varchar(255) NOT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  `bank_chart_id` bigint(20) NOT NULL,
  `unrecognised_principal_account_id` bigint(20) NOT NULL,
  `unrecognised_principal_chart_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK660A1FC929A194` (`id`),
  KEY `FK660A1FD76D0153` (`unrecognised_interest_chart_id`),
  KEY `FK660A1F38FDC797` (`unrecognised_interest_account_id`),
  KEY `FK660A1FD8549D9D` (`unrecognised_principal_chart_id`),
  KEY `FK660A1FC2CC9458` (`bank_chart_id`),
  KEY `FK660A1F9E6F7961` (`unrecognised_principal_account_id`),
  KEY `FK660A1FCAC4AD5C` (`bank_account_id`),
  CONSTRAINT `FK660A1FCAC4AD5C` FOREIGN KEY (`bank_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK660A1F38FDC797` FOREIGN KEY (`unrecognised_interest_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK660A1F9E6F7961` FOREIGN KEY (`unrecognised_principal_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK660A1FC2CC9458` FOREIGN KEY (`bank_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK660A1FC929A194` FOREIGN KEY (`id`) REFERENCES `agreement_term_principal` (`id`),
  CONSTRAINT `FK660A1FD76D0153` FOREIGN KEY (`unrecognised_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK660A1FD8549D9D` FOREIGN KEY (`unrecognised_principal_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_fixed_t_fixed_i_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_principal_fixed_t_fixed_i_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_fixed_t_fixed_i_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `penalty_capped` bit(1) DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `unrecognised_interest_descr` varchar(255) DEFAULT NULL,
  `unrecognised_interest_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_interest_chart_id` bigint(20) DEFAULT NULL,
  `bank_descr` varchar(255) DEFAULT NULL,
  `unrecognised_principal_descr` varchar(255) DEFAULT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `bank_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKEC328C9039171FA8` (`id`,`REV`),
  CONSTRAINT `FKEC328C9039171FA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_principal_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_fixed_t_partial_i_payroll`
--

DROP TABLE IF EXISTS `agreement_term_principal_fixed_t_partial_i_payroll`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_fixed_t_partial_i_payroll` (
  `interest_rate` double NOT NULL,
  `rate_term_in_months` int(11) NOT NULL,
  `total_interest_rate` double DEFAULT NULL,
  `unrecognised_interest_descr` varchar(255) NOT NULL,
  `id` bigint(20) NOT NULL,
  `unrecognised_interest_account_id` bigint(20) NOT NULL,
  `unrecognised_interest_chart_id` bigint(20) NOT NULL,
  `bank_descr` varchar(255) DEFAULT NULL,
  `unrecognised_principal_descr` varchar(255) NOT NULL,
  `bank_account_id` bigint(20) NOT NULL,
  `bank_chart_id` bigint(20) NOT NULL,
  `unrecognised_principal_account_id` bigint(20) NOT NULL,
  `unrecognised_principal_chart_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5A6E752CC929A194` (`id`),
  KEY `FK5A6E752CD76D0153` (`unrecognised_interest_chart_id`),
  KEY `FK5A6E752C38FDC797` (`unrecognised_interest_account_id`),
  KEY `FK5A6E752CD8549D9D` (`unrecognised_principal_chart_id`),
  KEY `FK5A6E752CC2CC9458` (`bank_chart_id`),
  KEY `FK5A6E752C9E6F7961` (`unrecognised_principal_account_id`),
  KEY `FK5A6E752CCAC4AD5C` (`bank_account_id`),
  CONSTRAINT `FK5A6E752CCAC4AD5C` FOREIGN KEY (`bank_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK5A6E752C38FDC797` FOREIGN KEY (`unrecognised_interest_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK5A6E752C9E6F7961` FOREIGN KEY (`unrecognised_principal_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK5A6E752CC2CC9458` FOREIGN KEY (`bank_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK5A6E752CC929A194` FOREIGN KEY (`id`) REFERENCES `agreement_term_principal` (`id`),
  CONSTRAINT `FK5A6E752CD76D0153` FOREIGN KEY (`unrecognised_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK5A6E752CD8549D9D` FOREIGN KEY (`unrecognised_principal_chart_id`) REFERENCES `tx_chart` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_fixed_t_partial_i_payroll_aud`
--

DROP TABLE IF EXISTS `agreement_term_principal_fixed_t_partial_i_payroll_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_fixed_t_partial_i_payroll_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `total_interest_rate` double DEFAULT NULL,
  `unrecognised_interest_descr` varchar(255) DEFAULT NULL,
  `unrecognised_interest_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_interest_chart_id` bigint(20) DEFAULT NULL,
  `bank_descr` varchar(255) DEFAULT NULL,
  `unrecognised_principal_descr` varchar(255) DEFAULT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `bank_chart_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_account_id` bigint(20) DEFAULT NULL,
  `unrecognised_principal_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKE6C4A91D39171FA8` (`id`,`REV`),
  CONSTRAINT `FKE6C4A91D39171FA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_principal_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_floating_i_open_b`
--

DROP TABLE IF EXISTS `agreement_term_principal_floating_i_open_b`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_floating_i_open_b` (
  `base_rate` int(11) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK88ACA8CDC929A194` (`id`),
  CONSTRAINT `FK88ACA8CDC929A194` FOREIGN KEY (`id`) REFERENCES `agreement_term_principal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_principal_floating_i_open_b_aud`
--

DROP TABLE IF EXISTS `agreement_term_principal_floating_i_open_b_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_principal_floating_i_open_b_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `base_rate` int(11) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK9D8E243E39171FA8` (`id`,`REV`),
  CONSTRAINT `FK9D8E243E39171FA8` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_principal_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_service_fee`
--

DROP TABLE IF EXISTS `agreement_term_service_fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_service_fee` (
  `debtor_descr` varchar(255) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `recurrence_day` int(11) DEFAULT NULL,
  `recurrence_type` int(11) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC858A53ECE18B21E` (`debtor_chart_id`),
  KEY `FKC858A53E63B5450` (`id`),
  KEY `FKC858A53E338071A2` (`debtor_account_id`),
  KEY `FKC858A53ED1C19C85` (`recognised_fee_interest_account_id`),
  KEY `FKC858A53E168AECC2` (`recognised_fee_account_id`),
  KEY `FKC858A53EAB5D39C1` (`recognised_fee_interest_chart_id`),
  KEY `FKC858A53EE1C7753E` (`recognised_fee_chart_id`),
  CONSTRAINT `FKC858A53EE1C7753E` FOREIGN KEY (`recognised_fee_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKC858A53E168AECC2` FOREIGN KEY (`recognised_fee_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKC858A53E338071A2` FOREIGN KEY (`debtor_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKC858A53E63B5450` FOREIGN KEY (`id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FKC858A53EAB5D39C1` FOREIGN KEY (`recognised_fee_interest_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKC858A53ECE18B21E` FOREIGN KEY (`debtor_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKC858A53ED1C19C85` FOREIGN KEY (`recognised_fee_interest_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_service_fee_aud`
--

DROP TABLE IF EXISTS `agreement_term_service_fee_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_service_fee_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `debtor_descr` varchar(255) DEFAULT NULL,
  `interest_applicable` bit(1) DEFAULT NULL,
  `principal` bigint(20) DEFAULT NULL,
  `recognised_fee_descr` varchar(255) DEFAULT NULL,
  `recognised_fee_interest_descr` varchar(255) DEFAULT NULL,
  `recurrence_day` int(11) DEFAULT NULL,
  `recurrence_type` int(11) DEFAULT NULL,
  `refinance_penalty_days` int(11) DEFAULT NULL,
  `settlement_penalty_days` int(11) DEFAULT NULL,
  `debtor_account_id` bigint(20) DEFAULT NULL,
  `debtor_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_chart_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_account_id` bigint(20) DEFAULT NULL,
  `recognised_fee_interest_chart_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKF514802F5C591464` (`id`,`REV`),
  CONSTRAINT `FKF514802F5C591464` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_service_fee_fixed_i`
--

DROP TABLE IF EXISTS `agreement_term_service_fee_fixed_i`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_service_fee_fixed_i` (
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4EB9145D96B46C1` (`id`),
  CONSTRAINT `FK4EB9145D96B46C1` FOREIGN KEY (`id`) REFERENCES `agreement_term_service_fee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_service_fee_fixed_i_aud`
--

DROP TABLE IF EXISTS `agreement_term_service_fee_fixed_i_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_service_fee_fixed_i_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `rate_term_in_months` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK695A47CE88786655` (`id`,`REV`),
  CONSTRAINT `FK695A47CE88786655` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_service_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_service_fee_floating_i`
--

DROP TABLE IF EXISTS `agreement_term_service_fee_floating_i`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_service_fee_floating_i` (
  `base_rate_enum` int(11) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7210C81196B46C1` (`id`),
  CONSTRAINT `FK7210C81196B46C1` FOREIGN KEY (`id`) REFERENCES `agreement_term_service_fee` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agreement_term_service_fee_floating_i_aud`
--

DROP TABLE IF EXISTS `agreement_term_service_fee_floating_i_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_term_service_fee_floating_i_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `base_rate_enum` int(11) DEFAULT NULL,
  `rate_delta` double DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKED89018288786655` (`id`,`REV`),
  CONSTRAINT `FKED89018288786655` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_term_service_fee_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bank_account`
--

DROP TABLE IF EXISTS `bank_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bank_account` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_holder_name` varchar(255) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `bank_account_type` varchar(255) DEFAULT NULL,
  `bank_branch` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `base_rate`
--

DROP TABLE IF EXISTS `base_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_rate` (
  `id` bigint(20) NOT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `effective_date` datetime DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `termInMonths` int(11) NOT NULL,
  `version` int(11) DEFAULT NULL,
  `modified_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `base_rate_aud`
--

DROP TABLE IF EXISTS `base_rate_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_rate_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `effective_date` datetime DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `termInMonths` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `modified_by` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK9AC3CC7FDF74E053` (`REV`),
  CONSTRAINT `FK9AC3CC7FDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `column_template_column_descript`
--

DROP TABLE IF EXISTS `column_template_column_descript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `column_template_column_descript` (
  `column_template_id` bigint(20) NOT NULL,
  `column_descriptor_id` bigint(20) NOT NULL,
  PRIMARY KEY (`column_template_id`,`column_descriptor_id`),
  UNIQUE KEY `column_descriptor_id` (`column_descriptor_id`),
  KEY `FK10AB72594EB2FBF6` (`column_template_id`),
  KEY `FK10AB725920896CD6` (`column_descriptor_id`),
  CONSTRAINT `FK10AB725920896CD6` FOREIGN KEY (`column_descriptor_id`) REFERENCES `receipt_batch_column_descriptor` (`id`),
  CONSTRAINT `FK10AB72594EB2FBF6` FOREIGN KEY (`column_template_id`) REFERENCES `receipt_batch_column_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `column_template_column_descript_aud`
--

DROP TABLE IF EXISTS `column_template_column_descript_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `column_template_column_descript_aud` (
  `REV` int(11) NOT NULL,
  `column_template_id` bigint(20) NOT NULL,
  `column_descriptor_id` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`REV`,`column_template_id`,`column_descriptor_id`),
  KEY `FKEB547CADF74E053` (`REV`),
  CONSTRAINT `FKEB547CADF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_Configuration_Name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduct_column_desc`
--

DROP TABLE IF EXISTS `deduct_column_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduct_column_desc` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `default_value` varchar(255) DEFAULT NULL,
  `file_column_name` varchar(255) DEFAULT NULL,
  `ignored` bit(1) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `deduct_column_id` bigint(20) DEFAULT NULL,
  `deduct_column_source_property_desc_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDF8AF85E49D2BC` (`deduct_column_id`),
  KEY `FKDF8AF85E49D2BC_idx` (`id`),
  CONSTRAINT `FKDF8AF85E49D2BC` FOREIGN KEY (`deduct_column_id`) REFERENCES `deduct_column_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduct_column_source_property_desc`
--

DROP TABLE IF EXISTS `deduct_column_source_property_desc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduct_column_source_property_desc` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `property_id` bigint(20) DEFAULT NULL,
  `source_property_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduct_column_template`
--

DROP TABLE IF EXISTS `deduct_column_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduct_column_template` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `custom_delimiter` varchar(5) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `global` bit(1) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_DeductionColumnTemplate_Global` (`global`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduct_column_template_source_property`
--

DROP TABLE IF EXISTS `deduct_column_template_source_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduct_column_template_source_property` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `i18n_key` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduct_filter_param`
--

DROP TABLE IF EXISTS `deduct_filter_param`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduct_filter_param` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `filter_property` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `deduct_filter_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKAC7F2F027415057C` (`deduct_filter_id`),
  CONSTRAINT `FKAC7F2F027415057C` FOREIGN KEY (`deduct_filter_id`) REFERENCES `deduction_filter` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduct_filter_param_aud`
--

DROP TABLE IF EXISTS `deduct_filter_param_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduct_filter_param_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `filter_property` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `deduct_filter_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKEB9887F3DF74E053` (`REV`),
  CONSTRAINT `FKEB9887F3DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_batch`
--

DROP TABLE IF EXISTS `deduction_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_batch` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `accounting_period` varchar(255) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `employer_submission_format` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `reason_code` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `deductionColumnTemplate_id` bigint(20) DEFAULT NULL,
  `trading_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK689E3AE09C37C8B9` (`deductionColumnTemplate_id`),
  KEY `IX_DeductionBatch_DateCreate` (`created_date`),
  CONSTRAINT `FK689E3AE09C37C8B9` FOREIGN KEY (`deductionColumnTemplate_id`) REFERENCES `deduct_column_template` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_batch_line`
--

DROP TABLE IF EXISTS `deduction_batch_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_batch_line` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `arrears` bigint(20) DEFAULT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `bank_id` bigint(20) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `branch_code` varchar(255) DEFAULT NULL,
  `client_employee_number` varchar(255) DEFAULT NULL,
  `client_first_names` varchar(255) DEFAULT NULL,
  `client_fullname` varchar(255) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `client_idnumber` varchar(255) DEFAULT NULL,
  `client_surname` varchar(255) DEFAULT NULL,
  `division_id` bigint(20) DEFAULT NULL,
  `division_name` varchar(255) DEFAULT NULL,
  `employer_deduction_code` varchar(255) DEFAULT NULL,
  `generated_instalments` bigint(20) DEFAULT NULL,
  `instalment_amount` bigint(20) DEFAULT NULL,
  `loan_account_id` bigint(20) DEFAULT NULL,
  `loan_application_id` bigint(20) DEFAULT NULL,
  `loan_cycle` bigint(20) DEFAULT NULL,
  `loan_term` int(11) DEFAULT NULL,
  `loan_total` bigint(20) DEFAULT NULL,
  `missed_instalments` bigint(20) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `submission_attempt_number` int(11) DEFAULT NULL,
  `deduction_batch_id` bigint(20) DEFAULT NULL,
  `result_line_id` bigint(20) DEFAULT NULL,
  `payroll_deduction_contract_number` varchar(255) DEFAULT NULL,
  `first_expected_instalment_date` datetime DEFAULT NULL,
  `loan_end_term_date` datetime DEFAULT NULL,
  `third_party_managed_entity_name` varchar(255) DEFAULT NULL,
  `occupation_name` varchar(255) DEFAULT NULL,
  `employed_date` datetime DEFAULT NULL,
  `repayable_amount` bigint(20) DEFAULT NULL,
  `third_party_disbursements_dates` varchar(255) DEFAULT NULL,
  `final_disbursement_date` datetime DEFAULT NULL,
  `product_type` varchar(255) DEFAULT NULL,
  `legacy_simco_account` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC6E0F9F3E0366AF0` (`deduction_batch_id`),
  KEY `FKC6E0F9F37908BD8B` (`result_line_id`),
  KEY `IX_DeductionBatchLine_DeductionBatch` (`deduction_batch_id`),
  CONSTRAINT `FKC6E0F9F37908BD8B` FOREIGN KEY (`result_line_id`) REFERENCES `deduction_batch_result_line` (`id`),
  CONSTRAINT `FKC6E0F9F3E0366AF0` FOREIGN KEY (`deduction_batch_id`) REFERENCES `deduction_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_batch_line_custom_field`
--

DROP TABLE IF EXISTS `deduction_batch_line_custom_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_batch_line_custom_field` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `custom_field_definition_description` varchar(255) DEFAULT NULL,
  `custom_field_definition_id` bigint(20) DEFAULT NULL,
  `custom_field_definition_name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `deduction_batch_line_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK312EE978EA1A1811` (`deduction_batch_line_id`),
  CONSTRAINT `FK312EE978EA1A1811` FOREIGN KEY (`deduction_batch_line_id`) REFERENCES `deduction_batch_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_batch_result`
--

DROP TABLE IF EXISTS `deduction_batch_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_batch_result` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `parse_error` bit(1) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `deduction_batch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9C918E5CE0366AF0` (`deduction_batch_id`),
  KEY `IX_DeductionBatchREsult_DeductionBatch` (`deduction_batch_id`),
  CONSTRAINT `FK9C918E5CE0366AF0` FOREIGN KEY (`deduction_batch_id`) REFERENCES `deduction_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_batch_result_line`
--

DROP TABLE IF EXISTS `deduction_batch_result_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_batch_result_line` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `employee_number` varchar(255) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `employer_response` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `identity_number` varchar(255) DEFAULT NULL,
  `installment_amount` varchar(255) DEFAULT NULL,
  `line_number` int(11) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `deduction_batch_result_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK88A273F7D49A61B1` (`deduction_batch_result_id`),
  KEY `IX_DeductionBatchResultLine_DeductionBatchResult` (`deduction_batch_result_id`),
  CONSTRAINT `FK88A273F7D49A61B1` FOREIGN KEY (`deduction_batch_result_id`) REFERENCES `deduction_batch_result` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_filter`
--

DROP TABLE IF EXISTS `deduction_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_filter` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `global` bit(1) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `source_version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_DeductionFilterTemplate_EmployerId` (`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_filter_aud`
--

DROP TABLE IF EXISTS `deduction_filter_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_filter_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `global` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `source_version` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK7A51ED83DF74E053` (`REV`),
  CONSTRAINT `FK7A51ED83DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deduction_result_column`
--

DROP TABLE IF EXISTS `deduction_result_column`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deduction_result_column` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `data_position` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `system_property` varchar(255) DEFAULT NULL,
  `deduction_batch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7AAA7B5EE0366AF0` (`deduction_batch_id`),
  CONSTRAINT `FK7AAA7B5EE0366AF0` FOREIGN KEY (`deduction_batch_id`) REFERENCES `deduction_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deposit_slip_reference`
--

DROP TABLE IF EXISTS `deposit_slip_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deposit_slip_reference` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `document_reference` varchar(255) NOT NULL,
  `disbursement_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD659EE7934A9509Bcbed1acd` (`disbursement_id`),
  CONSTRAINT `FKD659EE7934A9509Bcbed1acd` FOREIGN KEY (`disbursement_id`) REFERENCES `disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement`
--

DROP TABLE IF EXISTS `disbursement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `beneficiary_party_role_id` bigint(20) NOT NULL,
  `created_date` datetime NOT NULL,
  `disbursement_status` varchar(255) NOT NULL,
  `disbursement_type` varchar(255) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `accounting_document` bigint(20) DEFAULT NULL,
  `agreement_action_id` bigint(20) NOT NULL,
  `disbursement_reason_code_id` bigint(20) DEFAULT NULL,
  `source_account_id` bigint(20) NOT NULL,
  `source_chart_id` bigint(20) NOT NULL,
  `bank_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK6E9D1D41BE05A823` (`disbursement_reason_code_id`),
  KEY `FK6E9D1D412680DD59` (`source_chart_id`),
  KEY `FK6E9D1D4195AF714F` (`agreement_action_id`),
  KEY `FK6E9D1D41128ABA1D` (`source_account_id`),
  KEY `FK6E9D1D41CB5BC416` (`accounting_document`),
  KEY `IX_Disbursement_DisbursementStatus` (`disbursement_status`),
  KEY `IX_Disbursement_AgreementAction` (`agreement_action_id`),
  KEY `IX_Disbursement_DisbursementType` (`disbursement_type`),
  CONSTRAINT `FK6E9D1D41128ABA1D` FOREIGN KEY (`source_account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK6E9D1D412680DD59` FOREIGN KEY (`source_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK6E9D1D4195AF714F` FOREIGN KEY (`agreement_action_id`) REFERENCES `agreement_action_disbursement` (`id`),
  CONSTRAINT `FK6E9D1D41BE05A823` FOREIGN KEY (`disbursement_reason_code_id`) REFERENCES `disbursement_reason_code` (`id`),
  CONSTRAINT `FK6E9D1D41CB5BC416` FOREIGN KEY (`accounting_document`) REFERENCES `accounting_document` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement_batch`
--

DROP TABLE IF EXISTS `disbursement_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement_batch` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `batch_name` varchar(255) DEFAULT NULL,
  `batch_status` varchar(255) NOT NULL,
  `batch_type` varchar(255) NOT NULL,
  `create_username` varchar(255) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `payee_name` varchar(255) DEFAULT NULL,
  `payment_method_type` varchar(255) NOT NULL,
  `system_bank_account_id` bigint(20) DEFAULT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1F3E69CB2F7C00` (`bank_account_id`),
  CONSTRAINT `FK1F3E69CB2F7C00` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement_batch_line`
--

DROP TABLE IF EXISTS `disbursement_batch_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement_batch_line` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_approval_date` datetime DEFAULT NULL,
  `account_number` bigint(20) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `disbursement_id` bigint(20) DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `transaction_status` varchar(255) NOT NULL,
  `bank_account_id` bigint(20) DEFAULT NULL,
  `batch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKC82D43B7B28FACF8` (`batch_id`),
  KEY `FKC82D43B7B2F7C00` (`bank_account_id`),
  KEY `IX_DisbursementBatchLine_DisbursementId` (`disbursement_id`),
  CONSTRAINT `FKC82D43B7B2F7C00` FOREIGN KEY (`bank_account_id`) REFERENCES `bank_account` (`id`),
  CONSTRAINT `FKC82D43B7B28FACF8` FOREIGN KEY (`batch_id`) REFERENCES `disbursement_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `disbursement_reason_code`
--

DROP TABLE IF EXISTS `disbursement_reason_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disbursement_reason_code` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `document_reference_aud`
--

DROP TABLE IF EXISTS `document_reference_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_reference_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `document_reference` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKEEFE6398DF74E053` (`REV`),
  CONSTRAINT `FKEEFE6398DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `employer_period`
--

DROP TABLE IF EXISTS `employer_period`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employer_period` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `closing_date` datetime DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `status_date` datetime DEFAULT NULL,
  `opening_date` datetime DEFAULT NULL,
  `party_role_id` bigint(20) DEFAULT NULL,
  `accounting_period_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK64BD93C5D90855E6` (`accounting_period_id`),
  KEY `IX_EmployerPeriod_PartyRoleId` (`party_role_id`),
  KEY `IX_EmployerPeriod_AccountingPeriod` (`accounting_period_id`),
  CONSTRAINT `FK64BD93C5D90855E6` FOREIGN KEY (`accounting_period_id`) REFERENCES `accounting_period` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fee`
--

DROP TABLE IF EXISTS `fee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `balance_allocation_allowed` bit(1) DEFAULT NULL,
  `attracts_arrears` bit(1) NOT NULL,
  `aval_allowed` bit(1) DEFAULT NULL,
  `collection_frequency` varchar(255) DEFAULT NULL,
  `fee_type` varchar(255) NOT NULL,
  `included_in_disbursed` bit(1) NOT NULL,
  `insurance_allowed` bit(1) DEFAULT NULL,
  `number_of_collection` int(11) DEFAULT NULL,
  `partial_allowed` bit(1) DEFAULT NULL,
  `account_quote_id` bigint(20) NOT NULL,
  `feeValue_id` bigint(20) DEFAULT NULL,
  `interest_rate_id` bigint(20) DEFAULT NULL,
  `recognition_mode` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK18B8693923260` (`account_quote_id`),
  KEY `FK18B866F53E70` (`interest_rate_id`),
  KEY `FK18B86AD7284BB` (`feeValue_id`),
  CONSTRAINT `FK18B866F53E70` FOREIGN KEY (`interest_rate_id`) REFERENCES `interest_rate` (`id`),
  CONSTRAINT `FK18B8693923260` FOREIGN KEY (`account_quote_id`) REFERENCES `account_quote` (`id`),
  CONSTRAINT `FK18B86AD7284BB` FOREIGN KEY (`feeValue_id`) REFERENCES `fee_value` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fee_value`
--

DROP TABLE IF EXISTS `fee_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee_value` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `fee_value_type` varchar(255) NOT NULL,
  `value_amount` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hibernate_sequences`
--

DROP TABLE IF EXISTS `hibernate_sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequences` (
  `sequence_name` varchar(255) NOT NULL,
  `next_val` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`sequence_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `interest_rate`
--

DROP TABLE IF EXISTS `interest_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `interest_rate` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `interest_rate_type` varchar(255) NOT NULL,
  `rate_per_month` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_analysis_batch`
--

DROP TABLE IF EXISTS `loan_analysis_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_analysis_batch` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `employer_id` bigint(20) NOT NULL,
  `employer_name` varchar(100) DEFAULT NULL,
  `loan_analysis_batch_status` varchar(31) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `loan_analysis_batch_line`
--

DROP TABLE IF EXISTS `loan_analysis_batch_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_analysis_batch_line` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_reason_code_id` bigint(20) DEFAULT NULL,
  `arrears_amount` bigint(20) DEFAULT NULL,
  `client_first_name` varchar(100) DEFAULT NULL,
  `client_id` bigint(20) NOT NULL,
  `client_id_number` varchar(20) NOT NULL,
  `client_last_name` varchar(100) DEFAULT NULL,
  `instalments` bigint(20) DEFAULT NULL,
  `last_payment` datetime DEFAULT NULL,
  `loan_account_balance` bigint(20) DEFAULT NULL,
  `loan_account_id` bigint(20) NOT NULL,
  `action` varchar(31) DEFAULT NULL,
  `loan_term` bigint(20) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `paid_to_date` bigint(20) DEFAULT NULL,
  `total_borrowed` bigint(20) DEFAULT NULL,
  `loan_analysis_batch_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK5A84814D262FD981` (`loan_analysis_batch_id`),
  CONSTRAINT `FK5A84814D262FD981` FOREIGN KEY (`loan_analysis_batch_id`) REFERENCES `loan_analysis_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lookup_index`
--

DROP TABLE IF EXISTS `lookup_index`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lookup_index` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `lookup_entity` varchar(200) DEFAULT NULL,
  `lookup_name` varchar(100) DEFAULT NULL,
  `parent_property_name` varchar(100) DEFAULT NULL,
  `parent_lookup_index` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKF785C1ADB10B9019` (`parent_lookup_index`),
  CONSTRAINT `FKF785C1ADB10B9019` FOREIGN KEY (`parent_lookup_index`) REFERENCES `lookup_index` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_priority`
--

DROP TABLE IF EXISTS `payment_priority`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_priority` (
  `id` bigint(20) NOT NULL,
  `priority_list` varchar(255) DEFAULT NULL,
  `tx_change_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tx_change_id` (`tx_change_id`),
  KEY `FK80225FBD76783664` (`tx_change_id`),
  KEY `IX_PaymentPriority_TxChange` (`tx_change_id`),
  CONSTRAINT `FK80225FBD76783664` FOREIGN KEY (`tx_change_id`) REFERENCES `tx_change` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_allocation`
--

DROP TABLE IF EXISTS `receipt_allocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_allocation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `allocation_amount` bigint(20) DEFAULT NULL,
  `client_first_name` varchar(255) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `client_identity_number` varchar(255) DEFAULT NULL,
  `client_last_name` varchar(255) DEFAULT NULL,
  `client_passport_number` varchar(255) DEFAULT NULL,
  `instalment_amount` bigint(20) DEFAULT NULL,
  `is_suspense_account` bit(1) DEFAULT NULL,
  `loan_account_balance` bigint(20) DEFAULT NULL,
  `loan_start_date` datetime DEFAULT NULL,
  `receipting_batch_line_id` bigint(20) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `post_date` datetime DEFAULT NULL,
  `posting_status` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK539F21475C1A7D8F` (`receipting_batch_line_id`),
  CONSTRAINT `FK539F21475C1A7D8F` FOREIGN KEY (`receipting_batch_line_id`) REFERENCES `receipt_batch_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_allocation_aud`
--

DROP TABLE IF EXISTS `receipt_allocation_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_allocation_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `allocation_amount` bigint(20) DEFAULT NULL,
  `client_first_name` varchar(255) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `client_identity_number` varchar(255) DEFAULT NULL,
  `client_last_name` varchar(255) DEFAULT NULL,
  `client_passport_number` varchar(255) DEFAULT NULL,
  `instalment_amount` bigint(20) DEFAULT NULL,
  `is_suspense_account` bit(1) DEFAULT NULL,
  `loan_account_balance` bigint(20) DEFAULT NULL,
  `loan_start_date` datetime DEFAULT NULL,
  `receipting_batch_line_id` bigint(20) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `post_date` datetime DEFAULT NULL,
  `posting_status` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK413BCFB8DF74E053` (`REV`),
  CONSTRAINT `FK413BCFB8DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch`
--

DROP TABLE IF EXISTS `receipt_batch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `adhoc_batch` bit(1) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `import_date` datetime DEFAULT NULL,
  `post_date` datetime DEFAULT NULL,
  `rejection_note` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `total_amount` bigint(20) DEFAULT NULL,
  `total_imported_lines` int(11) DEFAULT NULL,
  `total_matched` int(11) DEFAULT NULL,
  `total_unmatched` int(11) DEFAULT NULL,
  `total_uploaded_lines` int(11) DEFAULT NULL,
  `receipting_batch_reason_code_id` bigint(20) DEFAULT NULL,
  `trading_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK177122738EDDB40C` (`receipting_batch_reason_code_id`),
  CONSTRAINT `FK177122738EDDB40C` FOREIGN KEY (`receipting_batch_reason_code_id`) REFERENCES `receipting_batch_reason_code` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch_aud`
--

DROP TABLE IF EXISTS `receipt_batch_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `adhoc_batch` bit(1) DEFAULT NULL,
  `creator` varchar(255) DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `import_date` datetime DEFAULT NULL,
  `post_date` datetime DEFAULT NULL,
  `rejection_note` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `total_amount` bigint(20) DEFAULT NULL,
  `total_imported_lines` int(11) DEFAULT NULL,
  `total_matched` int(11) DEFAULT NULL,
  `total_unmatched` int(11) DEFAULT NULL,
  `total_uploaded_lines` int(11) DEFAULT NULL,
  `receipting_batch_reason_code_id` bigint(20) DEFAULT NULL,
  `trading_entity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKDC915AE4DF74E053` (`REV`),
  CONSTRAINT `FKDC915AE4DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch_column_descriptor`
--

DROP TABLE IF EXISTS `receipt_batch_column_descriptor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch_column_descriptor` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `system_field` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch_column_descriptor_aud`
--

DROP TABLE IF EXISTS `receipt_batch_column_descriptor_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch_column_descriptor_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `system_field` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FKFE4DAD1DDF74E053` (`REV`),
  CONSTRAINT `FKFE4DAD1DDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch_column_template`
--

DROP TABLE IF EXISTS `receipt_batch_column_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch_column_template` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch_column_template_aud`
--

DROP TABLE IF EXISTS `receipt_batch_column_template_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch_column_template_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK5EFAD3E8DF74E053` (`REV`),
  CONSTRAINT `FK5EFAD3E8DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch_line`
--

DROP TABLE IF EXISTS `receipt_batch_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch_line` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `allocated_status` varchar(255) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `identity_number` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `passport_number` varchar(255) DEFAULT NULL,
  `division_name` varchar(255) DEFAULT NULL,
  `employee_number` varchar(255) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `line_number` int(11) DEFAULT NULL,
  `matched_status` varchar(255) DEFAULT NULL,
  `remainder_amount` bigint(20) DEFAULT NULL,
  `receipt_batch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB59ED6404F6662F6` (`receipt_batch_id`),
  KEY `IX_ReceiptingBatchLine_ReceiptingBatch` (`receipt_batch_id`),
  CONSTRAINT `FKB59ED6404F6662F6` FOREIGN KEY (`receipt_batch_id`) REFERENCES `receipt_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipt_batch_line_aud`
--

DROP TABLE IF EXISTS `receipt_batch_line_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipt_batch_line_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `account_id` varchar(255) DEFAULT NULL,
  `allocated_status` varchar(255) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `identity_number` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `passport_number` varchar(255) DEFAULT NULL,
  `division_name` varchar(255) DEFAULT NULL,
  `employee_number` varchar(255) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `line_number` int(11) DEFAULT NULL,
  `matched_status` varchar(255) DEFAULT NULL,
  `remainder_amount` bigint(20) DEFAULT NULL,
  `receipt_batch_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK81F66031DF74E053` (`REV`),
  CONSTRAINT `FK81F66031DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipting_batch_column_descript`
--

DROP TABLE IF EXISTS `receipting_batch_column_descript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipting_batch_column_descript` (
  `receipting_batch_id` bigint(20) NOT NULL,
  `column_descriptor_id` bigint(20) NOT NULL,
  PRIMARY KEY (`receipting_batch_id`,`column_descriptor_id`),
  UNIQUE KEY `column_descriptor_id` (`column_descriptor_id`),
  KEY `FK227ED07B77F6DAC4` (`receipting_batch_id`),
  KEY `FK227ED07B20896CD6` (`column_descriptor_id`),
  CONSTRAINT `FK227ED07B20896CD6` FOREIGN KEY (`column_descriptor_id`) REFERENCES `receipt_batch_column_descriptor` (`id`),
  CONSTRAINT `FK227ED07B77F6DAC4` FOREIGN KEY (`receipting_batch_id`) REFERENCES `receipt_batch` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipting_batch_column_descript_aud`
--

DROP TABLE IF EXISTS `receipting_batch_column_descript_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipting_batch_column_descript_aud` (
  `REV` int(11) NOT NULL,
  `receipting_batch_id` bigint(20) NOT NULL,
  `column_descriptor_id` bigint(20) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`REV`,`receipting_batch_id`,`column_descriptor_id`),
  KEY `FK2D88C4ECDF74E053` (`REV`),
  CONSTRAINT `FK2D88C4ECDF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipting_batch_reason_code`
--

DROP TABLE IF EXISTS `receipting_batch_reason_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipting_batch_reason_code` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `receipting_due`
--

DROP TABLE IF EXISTS `receipting_due`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receipting_due` (
  `id` bigint(20) NOT NULL,
  `cycle` varchar(255) DEFAULT NULL,
  `date_file_due` datetime DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employer_id_UNIQUE` (`employer_id`,`date_file_due`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `refinance`
--

DROP TABLE IF EXISTS `refinance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinance` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `created_date` datetime NOT NULL,
  `status` varchar(255) NOT NULL,
  `agreement_query_id` bigint(20) NOT NULL,
  `source_account_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCF747247B5F73DA6` (`agreement_query_id`),
  CONSTRAINT `FKCF747247B5F73DA6` FOREIGN KEY (`agreement_query_id`) REFERENCES `agreement_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `refinance_line`
--

DROP TABLE IF EXISTS `refinance_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinance_line` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `unallocated` bigint(20) NOT NULL,
  `agreement_term_id` bigint(20) DEFAULT NULL,
  `can_waive` tinyint(1) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `refinance_id` bigint(20) DEFAULT NULL,
  `waived` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FKC0184AECF5545BCE` (`agreement_term_id`),
  KEY `FKC0184AEC7BA7179` (`refinance_id`),
  CONSTRAINT `FKC0184AEC7BA7179` FOREIGN KEY (`refinance_id`) REFERENCES `refinance` (`id`),
  CONSTRAINT `FKC0184AECF5545BCE` FOREIGN KEY (`agreement_term_id`) REFERENCES `agreement_term` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `refinance_refinance_line`
--

DROP TABLE IF EXISTS `refinance_refinance_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refinance_refinance_line` (
  `refinance_id` bigint(20) NOT NULL,
  `lines_id` bigint(20) NOT NULL,
  UNIQUE KEY `lines_id` (`lines_id`),
  KEY `FK76D28FE47BA7179` (`refinance_id`),
  KEY `FK76D28FE4B35BAD5` (`lines_id`),
  CONSTRAINT `FK76D28FE4B35BAD5` FOREIGN KEY (`lines_id`) REFERENCES `refinance_line` (`id`),
  CONSTRAINT `FK76D28FE47BA7179` FOREIGN KEY (`refinance_id`) REFERENCES `refinance` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `refund`
--

DROP TABLE IF EXISTS `refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refund` (
  `id` bigint(20) NOT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `client_id` bigint(20) DEFAULT NULL,
  `refund_amount` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revinfo`
--

DROP TABLE IF EXISTS `revinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revinfo` (
  `REV` int(11) NOT NULL AUTO_INCREMENT,
  `REVTSTMP` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settlement`
--

DROP TABLE IF EXISTS `settlement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settlement` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `created_date` datetime NOT NULL,
  `expiry_date` datetime NOT NULL,
  `status` varchar(255) NOT NULL,
  `agreement_query_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4668929B5F73DA6` (`agreement_query_id`),
  CONSTRAINT `FK4668929B5F73DA6` FOREIGN KEY (`agreement_query_id`) REFERENCES `agreement_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settlement_discharge_confirmation`
--

DROP TABLE IF EXISTS `settlement_discharge_confirmation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settlement_discharge_confirmation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `document_reference` varchar(255) NOT NULL,
  `disbursement_id` bigint(20) NOT NULL,
  `confirmation_date_time` datetime DEFAULT NULL,
  `confirmed_valid_invalid` bit(1) DEFAULT NULL,
  `confirmer_full_name` varchar(64) DEFAULT NULL,
  `confirmer_role` varchar(64) DEFAULT NULL,
  `settlement_amount` bigint(20) DEFAULT NULL,
  `valid` bit(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD659EE7934A9509Ba30fa01e92a3d468` (`disbursement_id`),
  CONSTRAINT `FKD659EE7934A9509Ba30fa01e92a3d468` FOREIGN KEY (`disbursement_id`) REFERENCES `disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settlement_line`
--

DROP TABLE IF EXISTS `settlement_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settlement_line` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `unallocated` bigint(20) NOT NULL,
  `agreement_action_id` bigint(20) DEFAULT NULL,
  `agreement_term_id` bigint(20) DEFAULT NULL,
  `settlement_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKDEAB314AF5545BCE` (`agreement_term_id`),
  KEY `FKDEAB314A642B7A8E` (`agreement_action_id`),
  KEY `FKDEAB314AAD149FDB` (`settlement_id`),
  CONSTRAINT `FKDEAB314AAD149FDB` FOREIGN KEY (`settlement_id`) REFERENCES `settlement` (`id`),
  CONSTRAINT `FKDEAB314A642B7A8E` FOREIGN KEY (`agreement_action_id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FKDEAB314AF5545BCE` FOREIGN KEY (`agreement_term_id`) REFERENCES `agreement_term` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settlement_quote_confirmation`
--

DROP TABLE IF EXISTS `settlement_quote_confirmation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settlement_quote_confirmation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `document_reference` varchar(255) NOT NULL,
  `disbursement_id` bigint(20) NOT NULL,
  `confirmation_date_time` datetime DEFAULT NULL,
  `confirmed_valid_invalid` bit(1) DEFAULT NULL,
  `confirmer_full_name` varchar(64) DEFAULT NULL,
  `confirmer_role` varchar(64) DEFAULT NULL,
  `settlement_amount` bigint(20) DEFAULT NULL,
  `valid` bit(1) DEFAULT NULL,
  `expiry_date` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD659EE7934A9509Ba30fa01e30a993ee` (`disbursement_id`),
  CONSTRAINT `FKD659EE7934A9509Ba30fa01e30a993ee` FOREIGN KEY (`disbursement_id`) REFERENCES `disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `settlement_settlement_line`
--

DROP TABLE IF EXISTS `settlement_settlement_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settlement_settlement_line` (
  `settlement_id` bigint(20) NOT NULL,
  `lines_id` bigint(20) NOT NULL,
  UNIQUE KEY `lines_id` (`lines_id`),
  KEY `FKDF359E34AD149FDB` (`settlement_id`),
  KEY `FKDF359E343BBB2159` (`lines_id`),
  CONSTRAINT `FKDF359E343BBB2159` FOREIGN KEY (`lines_id`) REFERENCES `settlement_line` (`id`),
  CONSTRAINT `FKDF359E34AD149FDB` FOREIGN KEY (`settlement_id`) REFERENCES `settlement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `submission_due`
--

DROP TABLE IF EXISTS `submission_due`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submission_due` (
  `id` bigint(20) NOT NULL,
  `cycle` varchar(255) DEFAULT NULL,
  `date_file_due` datetime DEFAULT NULL,
  `employer_id` bigint(20) DEFAULT NULL,
  `employer_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date_file_due_UNIQUE` (`date_file_due`,`employer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_party_disbursement_authorisation`
--

DROP TABLE IF EXISTS `third_party_disbursement_authorisation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_party_disbursement_authorisation` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `disbursement_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK335DC65334A9509B` (`disbursement_id`),
  CONSTRAINT `FK335DC65334A9509B` FOREIGN KEY (`disbursement_id`) REFERENCES `disbursement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `timeline`
--

DROP TABLE IF EXISTS `timeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timeline` (
  `id` bigint(20) NOT NULL,
  `accrued_fee` double DEFAULT NULL,
  `accrued_fee_interest` double DEFAULT NULL,
  `accrued_interest` double DEFAULT NULL,
  `arrears_interest` double DEFAULT NULL,
  `datestamp` datetime NOT NULL,
  `day_end_balance` bigint(20) DEFAULT NULL,
  `agreement_id` bigint(20) NOT NULL,
  `agreement_term_id` bigint(20) DEFAULT NULL,
  `grace_period_fee` double DEFAULT NULL,
  `accrued_principal_list` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `agreement_term_id` (`agreement_term_id`,`datestamp`),
  KEY `FK8438D441F5545BCE` (`agreement_term_id`),
  KEY `FK8438D441F2B699` (`agreement_id`),
  KEY `IX_Timeline_AgreementTerm` (`agreement_term_id`),
  KEY `IX_Timeline_Datestamp` (`datestamp`),
  KEY `IX_Timeline_Agreement` (`agreement_id`),
  CONSTRAINT `FK8438D441F2B699` FOREIGN KEY (`agreement_id`) REFERENCES `agreement` (`id`),
  CONSTRAINT `FK8438D441F5545BCE` FOREIGN KEY (`agreement_term_id`) REFERENCES `agreement_term` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_account`
--

DROP TABLE IF EXISTS `tx_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_account` (
  `id` bigint(20) NOT NULL,
  `balance` bigint(20) NOT NULL,
  `credit` bigint(20) NOT NULL,
  `debit` bigint(20) NOT NULL,
  `narrative` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `reference_type` varchar(255) NOT NULL,
  `reversed` bit(1) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `agreement_action_id` bigint(20) DEFAULT NULL,
  `agreement_term_id` bigint(20) DEFAULT NULL,
  `tx_chart_id` bigint(20) NOT NULL,
  `tx_line_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_TxAccount_Account` (`account_id`),
  KEY `FK77BE7B72F29E4264` (`tx_line_id`),
  KEY `FK77BE7B72F5545BCE` (`agreement_term_id`),
  KEY `FK77BE7B72642B7A8E` (`agreement_action_id`),
  KEY `FK77BE7B72DB515B79` (`account_id`),
  KEY `FK77BE7B726F6B5D10` (`tx_chart_id`),
  CONSTRAINT `FK77BE7B726F6B5D10` FOREIGN KEY (`tx_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK77BE7B72642B7A8E` FOREIGN KEY (`agreement_action_id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FK77BE7B72DB515B79` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK77BE7B72F29E4264` FOREIGN KEY (`tx_line_id`) REFERENCES `tx_line` (`id`),
  CONSTRAINT `FK77BE7B72F5545BCE` FOREIGN KEY (`agreement_term_id`) REFERENCES `agreement_term` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_balance`
--

DROP TABLE IF EXISTS `tx_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_balance` (
  `id` bigint(20) NOT NULL,
  `allocated` bigint(20) NOT NULL,
  `allocation_method` varchar(255) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `amount_limit` bigint(20) DEFAULT NULL,
  `capture_date` datetime DEFAULT NULL,
  `fully_allocated` bit(1) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `account_id` bigint(20) NOT NULL,
  `provision_chart` bigint(20) DEFAULT NULL,
  `source_agreement_id` bigint(20) DEFAULT NULL,
  `source_agreement_action_id` bigint(20) DEFAULT NULL,
  `source_agreement_term_id` bigint(20) DEFAULT NULL,
  `tx_chart_id` bigint(20) DEFAULT NULL,
  `tx_line_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tx_line_id` (`tx_line_id`),
  UNIQUE KEY `source_agreement_id` (`source_agreement_id`,`source_agreement_term_id`,`provision_chart`),
  KEY `IX_TxBalance_SourceAgreementTerm` (`source_agreement_term_id`),
  KEY `IX_TxBalance_SourceAgreementAction` (`source_agreement_action_id`),
  KEY `FKA9B36021F29E4264` (`tx_line_id`),
  KEY `FKA9B360211FA208D` (`provision_chart`),
  KEY `FKA9B36021B3A8546A` (`source_agreement_action_id`),
  KEY `FKA9B360214F4EFC3D` (`source_agreement_id`),
  KEY `FKA9B36021DB515B79` (`account_id`),
  KEY `FKA9B360216F6B5D10` (`tx_chart_id`),
  KEY `FKA9B3602116B5FCAA` (`source_agreement_term_id`),
  KEY `IX_TxBalance_SourceAgreement` (`source_agreement_id`),
  KEY `IX_TxBalance_Account` (`account_id`),
  KEY `IX_TxBalance_TxChart` (`tx_chart_id`),
  CONSTRAINT `FKA9B3602116B5FCAA` FOREIGN KEY (`source_agreement_term_id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FKA9B360211FA208D` FOREIGN KEY (`provision_chart`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKA9B360214F4EFC3D` FOREIGN KEY (`source_agreement_id`) REFERENCES `agreement` (`id`),
  CONSTRAINT `FKA9B360216F6B5D10` FOREIGN KEY (`tx_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKA9B36021B3A8546A` FOREIGN KEY (`source_agreement_action_id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FKA9B36021DB515B79` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKA9B36021F29E4264` FOREIGN KEY (`tx_line_id`) REFERENCES `tx_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_balance_link`
--

DROP TABLE IF EXISTS `tx_balance_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_balance_link` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `source_agreement_id` bigint(20) NOT NULL,
  `tx_balance_id` bigint(20) NOT NULL,
  `tx_change_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_TxBalanceLink_SourceAgreement` (`source_agreement_id`),
  KEY `FK7D25F558E8F766D0` (`tx_balance_id`),
  KEY `FK7D25F55876783664` (`tx_change_id`),
  KEY `FK7D25F5584F4EFC3D` (`source_agreement_id`),
  CONSTRAINT `FK7D25F5584F4EFC3D` FOREIGN KEY (`source_agreement_id`) REFERENCES `agreement` (`id`),
  CONSTRAINT `FK7D25F55876783664` FOREIGN KEY (`tx_change_id`) REFERENCES `tx_change` (`id`),
  CONSTRAINT `FK7D25F558E8F766D0` FOREIGN KEY (`tx_balance_id`) REFERENCES `tx_balance` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_change`
--

DROP TABLE IF EXISTS `tx_change`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_change` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `balance_allocated` bigint(20) DEFAULT NULL,
  `balance_fully_allocated` bit(1) DEFAULT NULL,
  `capture_date` datetime DEFAULT NULL,
  `instalment_allocated` bigint(20) DEFAULT NULL,
  `instalment_fully_allocated` bit(1) DEFAULT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `account_id` bigint(20) NOT NULL,
  `source_agreement` bigint(20) NOT NULL,
  `source_agreement_action` bigint(20) DEFAULT NULL,
  `tx_chart` bigint(20) NOT NULL,
  `tx_line` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK30D665CB726DA0F` (`source_agreement`),
  KEY `FK30D665CBF4ADD0A8` (`tx_line`),
  KEY `FK30D665CBDB515B79` (`account_id`),
  KEY `FK30D665CBB39706E` (`source_agreement_action`),
  KEY `FK30D665CBA00D56FC` (`tx_chart`),
  KEY `IX_TxChange_SourceAgreement` (`source_agreement`),
  CONSTRAINT `FK30D665CBA00D56FC` FOREIGN KEY (`tx_chart`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK30D665CB726DA0F` FOREIGN KEY (`source_agreement`) REFERENCES `agreement` (`id`),
  CONSTRAINT `FK30D665CBB39706E` FOREIGN KEY (`source_agreement_action`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FK30D665CBDB515B79` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK30D665CBF4ADD0A8` FOREIGN KEY (`tx_line`) REFERENCES `tx_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_chart`
--

DROP TABLE IF EXISTS `tx_chart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_chart` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `IX_TxChart_Name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_chart_aud`
--

DROP TABLE IF EXISTS `tx_chart_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_chart_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `REVTYPE` tinyint(4) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK4D3916D4DF74E053` (`REV`),
  CONSTRAINT `FK4D3916D4DF74E053` FOREIGN KEY (`REV`) REFERENCES `revinfo` (`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_header`
--

DROP TABLE IF EXISTS `tx_header`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_header` (
  `id` bigint(20) NOT NULL,
  `capture_date` datetime NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `reference_type` varchar(255) NOT NULL,
  `transaction_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_header_tx_line`
--

DROP TABLE IF EXISTS `tx_header_tx_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_header_tx_line` (
  `tx_header_id` bigint(20) NOT NULL,
  `txLines_id` bigint(20) NOT NULL,
  UNIQUE KEY `txLines_id` (`txLines_id`),
  KEY `FK4FBE8038A26A9CB8` (`txLines_id`),
  KEY `FK4FBE80381B61ED44` (`tx_header_id`),
  CONSTRAINT `FK4FBE80381B61ED44` FOREIGN KEY (`tx_header_id`) REFERENCES `tx_header` (`id`),
  CONSTRAINT `FK4FBE8038A26A9CB8` FOREIGN KEY (`txLines_id`) REFERENCES `tx_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_instalment`
--

DROP TABLE IF EXISTS `tx_instalment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_instalment` (
  `id` bigint(20) NOT NULL,
  `allocated` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `arrears_penalty_charged` bit(1) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `effective_date` datetime NOT NULL,
  `fully_allocated` bit(1) DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `agreement_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK252EFA6AF2B699` (`agreement_id`),
  KEY `IX_TxInstalment_Agreement` (`agreement_id`),
  CONSTRAINT `FK252EFA6AF2B699` FOREIGN KEY (`agreement_id`) REFERENCES `agreement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_instalment_line`
--

DROP TABLE IF EXISTS `tx_instalment_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_instalment_line` (
  `id` bigint(20) NOT NULL,
  `allocated` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `fully_allocated` bit(1) DEFAULT NULL,
  `agreement_term_id` bigint(20) NOT NULL,
  `tx_chart` bigint(20) DEFAULT NULL,
  `tx_instalment_id` bigint(20) NOT NULL,
  `portion_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3D6C60A9F5545BCE` (`agreement_term_id`),
  KEY `FK3D6C60A960F2A904` (`tx_instalment_id`),
  KEY `FK3D6C60A9A00D56FC` (`tx_chart`),
  KEY `IX_TxInstalmentLine_AgreementTerm` (`agreement_term_id`),
  KEY `IX_TxInstalmentLine_TxInstalment` (`tx_instalment_id`),
  CONSTRAINT `FK3D6C60A960F2A904` FOREIGN KEY (`tx_instalment_id`) REFERENCES `tx_instalment` (`id`),
  CONSTRAINT `FK3D6C60A9A00D56FC` FOREIGN KEY (`tx_chart`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FK3D6C60A9F5545BCE` FOREIGN KEY (`agreement_term_id`) REFERENCES `agreement_term` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_instalment_link`
--

DROP TABLE IF EXISTS `tx_instalment_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_instalment_link` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `agreement` bigint(20) NOT NULL,
  `tx_change_id` bigint(20) NOT NULL,
  `tx_instalment_id` bigint(20) NOT NULL,
  `tx_instalment_line_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK3D6C60AF3E9A3079` (`tx_instalment_line_id`),
  KEY `FK3D6C60AF60F2A904` (`tx_instalment_id`),
  KEY `FK3D6C60AF76783664` (`tx_change_id`),
  KEY `FK3D6C60AFEC989D33` (`agreement`),
  KEY `IX_TxInstalmentLine_SourceAgreement` (`agreement`),
  KEY `IX_TxInstalmentLine_TransactionDate` (`transaction_date`),
  KEY `IX_TxInstalmentLink_SourceAgreement` (`agreement`),
  KEY `IX_TxInstalmentLink_TransactionDate` (`transaction_date`),
  CONSTRAINT `FK3D6C60AFEC989D33` FOREIGN KEY (`agreement`) REFERENCES `agreement` (`id`),
  CONSTRAINT `FK3D6C60AF3E9A3079` FOREIGN KEY (`tx_instalment_line_id`) REFERENCES `tx_instalment_line` (`id`),
  CONSTRAINT `FK3D6C60AF60F2A904` FOREIGN KEY (`tx_instalment_id`) REFERENCES `tx_instalment` (`id`),
  CONSTRAINT `FK3D6C60AF76783664` FOREIGN KEY (`tx_change_id`) REFERENCES `tx_change` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_line`
--

DROP TABLE IF EXISTS `tx_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_line` (
  `id` bigint(20) NOT NULL,
  `credit` bigint(20) NOT NULL,
  `debit` bigint(20) NOT NULL,
  `narrative` varchar(255) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `reference_type` varchar(255) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `accounting_period_id` bigint(20) NOT NULL,
  `source_agreement` bigint(20) DEFAULT NULL,
  `tx_chart_id` bigint(20) NOT NULL,
  `tx_header_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKCA85CCCF726DA0F` (`source_agreement`),
  KEY `FKCA85CCCFDB515B79` (`account_id`),
  KEY `FKCA85CCCF6F6B5D10` (`tx_chart_id`),
  KEY `FKCA85CCCFD90855E6` (`accounting_period_id`),
  KEY `FKCA85CCCF1B61ED44` (`tx_header_id`),
  CONSTRAINT `FKCA85CCCF1B61ED44` FOREIGN KEY (`tx_header_id`) REFERENCES `tx_header` (`id`),
  CONSTRAINT `FKCA85CCCF6F6B5D10` FOREIGN KEY (`tx_chart_id`) REFERENCES `tx_chart` (`id`),
  CONSTRAINT `FKCA85CCCF726DA0F` FOREIGN KEY (`source_agreement`) REFERENCES `agreement` (`id`),
  CONSTRAINT `FKCA85CCCFD90855E6` FOREIGN KEY (`accounting_period_id`) REFERENCES `accounting_period` (`id`),
  CONSTRAINT `FKCA85CCCFDB515B79` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_principal`
--

DROP TABLE IF EXISTS `tx_principal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_principal` (
  `id` bigint(20) NOT NULL,
  `allocated` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `capture_date` datetime DEFAULT NULL,
  `is_fully_allocated` bit(1) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `account_id` bigint(20) NOT NULL,
  `source_agreement_id` bigint(20) NOT NULL,
  `source_agreement_term_id` bigint(20) NOT NULL,
  `tx_line_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK82F22433F29E4264` (`tx_line_id`),
  KEY `FK82F224334F4EFC3D` (`source_agreement_id`),
  KEY `FK82F22433DB515B79` (`account_id`),
  KEY `FK82F2243316B5FCAA` (`source_agreement_term_id`),
  KEY `IX_TxPrincipal_FullyAllocated` (`is_fully_allocated`),
  KEY `IX_TxPrincipal_SourceAgreement` (`source_agreement_id`),
  CONSTRAINT `FK82F2243316B5FCAA` FOREIGN KEY (`source_agreement_term_id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FK82F224334F4EFC3D` FOREIGN KEY (`source_agreement_id`) REFERENCES `agreement` (`id`),
  CONSTRAINT `FK82F22433DB515B79` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK82F22433F29E4264` FOREIGN KEY (`tx_line_id`) REFERENCES `tx_line` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_principal_link`
--

DROP TABLE IF EXISTS `tx_principal_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_principal_link` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `disbursement_id` bigint(20) NOT NULL,
  `tx_balance_id` bigint(20) NOT NULL,
  `tx_principal_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK4F38EC86E8F766D0` (`tx_balance_id`),
  KEY `FK4F38EC8634A9509B` (`disbursement_id`),
  KEY `FK4F38EC86D46EC010` (`tx_principal_id`),
  KEY `IX_TxPrincipalLink_TransactionDate` (`transaction_date`),
  KEY `IX_TxPrincipalLink_TxPrincipal` (`tx_principal_id`),
  KEY `IX_TxPrincipalLink_Disbursement` (`disbursement_id`),
  CONSTRAINT `FK4F38EC86D46EC010` FOREIGN KEY (`tx_principal_id`) REFERENCES `tx_principal` (`id`),
  CONSTRAINT `FK4F38EC8634A9509B` FOREIGN KEY (`disbursement_id`) REFERENCES `disbursement` (`id`),
  CONSTRAINT `FK4F38EC86E8F766D0` FOREIGN KEY (`tx_balance_id`) REFERENCES `tx_balance` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tx_recognition`
--

DROP TABLE IF EXISTS `tx_recognition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_recognition` (
  `id` bigint(20) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `transaction_date` datetime DEFAULT NULL,
  `source_agreement_term_id` bigint(20) DEFAULT NULL,
  `tx_balance_id` bigint(20) NOT NULL,
  `source_agreement_action_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1B16467CE8F766D0` (`tx_balance_id`),
  KEY `FK1B16467C16B5FCAA` (`source_agreement_term_id`),
  KEY `IX_TxRecognition_SourceAgreementTerm` (`source_agreement_term_id`),
  KEY `FK1B16467CB3A8546A` (`source_agreement_action_id`),
  CONSTRAINT `FK1B16467CB3A8546A` FOREIGN KEY (`source_agreement_action_id`) REFERENCES `agreement_action` (`id`),
  CONSTRAINT `FK1B16467C16B5FCAA` FOREIGN KEY (`source_agreement_term_id`) REFERENCES `agreement_term` (`id`),
  CONSTRAINT `FK1B16467CE8F766D0` FOREIGN KEY (`tx_balance_id`) REFERENCES `tx_balance` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-08-22 15:51:15
