use masterdata;
UPDATE `masterdata`.`trading_entity` SET `lending_trading_entity`=1 WHERE `id`='2002';
UPDATE `masterdata`.`trading_entity` SET `lending_trading_entity`=1 WHERE `id`='2003';
UPDATE `masterdata`.`trading_entity` SET `lending_trading_entity`=1 WHERE `id`='2004';
UPDATE `masterdata`.`trading_entity` SET `entity_identifier`='libraval' WHERE `id`='2002';
UPDATE `masterdata`.`trading_entity` SET `entity_identifier`='colpatria' WHERE `id`='2003';
UPDATE `masterdata`.`trading_entity` SET `entity_identifier`='sudameris' WHERE `id`='2004';

DELETE from check_list_definition where id in(32,33,34);
INSERT INTO `masterdata`.`check_list_definition` (`id`, `version`, `name`) VALUES ('32', '0', 'libravalEntityOrigination');
INSERT INTO `masterdata`.`check_list_definition` (`id`, `version`, `name`) VALUES ('33', '0', 'colpatriaEntityOrigination');
INSERT INTO `masterdata`.`check_list_definition` (`id`, `version`, `name`) VALUES ('34', '0', 'sudamerisEntityOrigination');