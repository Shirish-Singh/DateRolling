use flexifinproduct;

 -- Add months to fee mapping as well
DELETE FROM `fee_mapping` WHERE `id`='100042' and `fee_type`='Aval';
DELETE FROM `fee_mapping` WHERE `id`='100043' and `fee_type`='Insurance';
DELETE FROM `fee_mapping` WHERE `id`='100044' and `fee_type`='GPF';
DELETE FROM `fee_mapping` WHERE `id`='100045' and `fee_type`='AdminFeeAmortised';


INSERT INTO `fee_mapping`
(`id`, `modified_by`, `version`, `default_boolean`, `default_option`, `domain_property`, `enable_item`, `fee_type`, `option_name`, `options`, `show_item`)
VALUES ('100042',NULL,'0',0,'0','months',0,'Aval', NULL, NULL, 0),
 ('100043',NULL,'0',0,'0','months',0,'Insurance', NULL, NULL, 0),
 ('100044',NULL,'0',0,'0','months',0,'GPF', NULL, NULL, 0),
 ('100045',NULL,'0',0,'0','months',0,'AdminFeeAmortised', NULL, NULL, 0);
