use accounting;

INSERT INTO `accounting_dto_to_class_binding` (`id`, `version`, `class_name`, `dto_name`, `relevant_entity_name`) VALUES ('1', '0', 'com.qualica.flexifin.accounting.domain.ThirdPartyDisbursementAuthorisation', 'com.qualica.flexifin.accounting.shared.dto.ThirdPartyDisbursementAuthorisationDTO', 'com.qualica.flexifin.accounting.domain.AccountingNote');

