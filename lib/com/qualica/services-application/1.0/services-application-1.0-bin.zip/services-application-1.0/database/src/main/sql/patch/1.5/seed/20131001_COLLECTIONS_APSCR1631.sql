USE collections;

UPDATE `collection_global_variable` SET `variable_value`='0' WHERE `id`='1';



