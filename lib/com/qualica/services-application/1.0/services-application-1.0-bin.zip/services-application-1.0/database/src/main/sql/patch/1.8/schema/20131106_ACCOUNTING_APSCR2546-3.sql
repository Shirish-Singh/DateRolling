SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.add_column;

CREATE TABLE IF NOT EXISTS agreement_term_immediate_r_no_recovery(
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DELIMITER $$

CREATE PROCEDURE accounting.add_column(
  IN tableName VARCHAR(100),
  IN columnName VARCHAR(100),
  IN columnType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = columnName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

      SET @Statement = CONCAT('UPDATE `accounting`.`', tableName, '` SET `', columnName, '` = ''accounting.config.bank_payment.descr''');
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.add_column('agreement_term_admin_fee_iaf', 'bank_payment_descr', 'VARCHAR(255)');


DROP PROCEDURE IF EXISTS accounting.add_column ;

SET SQL_MODE=@OLD_SQL_MODE ;


