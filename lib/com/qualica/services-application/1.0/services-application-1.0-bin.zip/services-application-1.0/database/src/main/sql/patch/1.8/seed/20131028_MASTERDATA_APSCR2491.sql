use masterdata;
SET foreign_key_checks = 0;
DELETE from role_permission where permission_id BETWEEN 133 AND 144;
DELETE from permission where id BETWEEN 133 AND 144;
DELETE from role where id BETWEEN 400 AND 411;
SET foreign_key_checks = 1;

INSERT INTO permission (id, modified_by, version, name) VALUES (133, '', 0, 'wf.manageBlackListEntries');
INSERT INTO permission (id, modified_by, version, name) VALUES (134, '', 0, 'wf.manageLoanProduct');
INSERT INTO permission (id, modified_by, version, name) VALUES (135, '', 0, 'wf.manageLookups');
INSERT INTO permission (id, modified_by, version, name) VALUES (136, '', 0, 'wf.manageOulets');
INSERT INTO permission (id, modified_by, version, name) VALUES (137, '', 0, 'wf.manageUsers');
INSERT INTO permission (id, modified_by, version, name) VALUES (138, '', 0, 'wf.manageAgents');
INSERT INTO permission (id, modified_by, version, name) VALUES (139, '', 0, 'wf.manageThirdParties');
INSERT INTO permission (id, modified_by, version, name) VALUES (140, '', 0, 'wf.manageSystemBanks');
INSERT INTO permission (id, modified_by, version, name) VALUES (141, '', 0, 'wf.manageBanks');
INSERT INTO permission (id, modified_by, version, name) VALUES (142, '', 0, 'wsf.manageLoanProductFees');
INSERT INTO permission (id, modified_by, version, name) VALUES (143, '', 0, 'wf.editEmployer');
INSERT INTO permission (id, modified_by, version, name) VALUES (144, '', 0, 'wf.manageReasonCodes');


INSERT INTO role (id, modified_by, version, name) VALUES (400, '', 0, 'ManageBlackListEntries');
INSERT INTO role (id, modified_by, version, name) VALUES (401, '', 0, 'ManageLoanProduct');
INSERT INTO role (id, modified_by, version, name) VALUES (402, '', 0, 'ManageLookups');
INSERT INTO role (id, modified_by, version, name) VALUES (403, '', 0, 'ManageOulets');
INSERT INTO role (id, modified_by, version, name) VALUES (404, '', 0, 'ManageUsers');
INSERT INTO role (id, modified_by, version, name) VALUES (405, '', 0, 'ManageAgents');
INSERT INTO role (id, modified_by, version, name) VALUES (406, '', 0, 'ManageThirdParties');
INSERT INTO role (id, modified_by, version, name) VALUES (407, '', 0, 'ManageSystemBanks');
INSERT INTO role (id, modified_by, version, name) VALUES (408, '', 0, 'ManageBanks');
INSERT INTO role (id, modified_by, version, name) VALUES (409, '', 0, 'ManageLoanProductFees');
INSERT INTO role (id, modified_by, version, name) VALUES (410, '', 0, 'EditEmployer');
INSERT INTO role (id, modified_by, version, name) VALUES (411, '', 0, 'ManageReasonCodes');

INSERT INTO role_permission (role_id, permission_id) VALUES (400, 133);
INSERT INTO role_permission (role_id, permission_id) VALUES (401, 134);
INSERT INTO role_permission (role_id, permission_id) VALUES (402, 135);
INSERT INTO role_permission (role_id, permission_id) VALUES (403, 136);
INSERT INTO role_permission (role_id, permission_id) VALUES (404, 137);
INSERT INTO role_permission (role_id, permission_id) VALUES (405, 138);
INSERT INTO role_permission (role_id, permission_id) VALUES (406, 139);
INSERT INTO role_permission (role_id, permission_id) VALUES (407, 140);
INSERT INTO role_permission (role_id, permission_id) VALUES (408, 141);
INSERT INTO role_permission (role_id, permission_id) VALUES (409, 142);
INSERT INTO role_permission (role_id, permission_id) VALUES (410, 143);
INSERT INTO role_permission (role_id, permission_id) VALUES (411, 144);