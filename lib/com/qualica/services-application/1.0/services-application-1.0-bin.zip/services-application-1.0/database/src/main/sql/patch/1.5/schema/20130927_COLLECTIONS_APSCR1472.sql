USE collections;

DROP TABLE IF EXISTS `collection_file_column_template_desc`;

--
-- Table structure for table `collection_file_column_template_source_property`
--

DROP TABLE IF EXISTS `collection_file_column_template_source_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_file_column_template_source_property` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `i18n_key` varchar(255) DEFAULT NULL,
  `max_size` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `collection_file_column_template`
--

DROP TABLE IF EXISTS `collection_file_column_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_file_column_template` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `enabled` bit(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `collection_file_column_template_desc`
--


/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collection_file_column_template_desc` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `collection_file_column_template_id` bigint(20) DEFAULT NULL,
  `collection_file_column_template_source_property_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK46EDC68F76E60FBA` (`collection_file_column_template_source_property_id`),
  KEY `FK46EDC68FE0197744` (`collection_file_column_template_id`),
  CONSTRAINT `FK46EDC68FE0197744` FOREIGN KEY (`collection_file_column_template_id`) REFERENCES `collection_file_column_template` (`id`),
  CONSTRAINT `FK46EDC68F76E60FBA` FOREIGN KEY (`collection_file_column_template_source_property_id`) REFERENCES `collection_file_column_template_source_property` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;;
/*!40101 SET character_set_client = @saved_cs_client */;


