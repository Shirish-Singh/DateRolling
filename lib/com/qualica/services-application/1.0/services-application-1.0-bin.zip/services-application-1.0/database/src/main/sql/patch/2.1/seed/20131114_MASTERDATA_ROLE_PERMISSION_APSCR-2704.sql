use masterdata;

SET foreign_key_checks = 0;

UPDATE `masterdata`.`permission` SET name = 'wf.assignCollectionAgent' WHERE name = 'AssignCollectionAgent' and id = 4046;

SET foreign_key_checks = 1;

