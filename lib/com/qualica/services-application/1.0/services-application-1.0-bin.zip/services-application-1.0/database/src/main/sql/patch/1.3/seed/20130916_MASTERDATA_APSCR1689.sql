use masterdata;

UPDATE `check_list_item_definition` SET `required`=0 WHERE `id`='120';
