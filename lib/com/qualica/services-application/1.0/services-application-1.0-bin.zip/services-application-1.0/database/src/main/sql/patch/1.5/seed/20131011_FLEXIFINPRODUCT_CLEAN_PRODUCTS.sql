USE flexifinproduct;

delete from product_fee where id in (1, 2, 3, 4, 5, 6);
delete from fee where id in (1, 2, 3, 4, 5);
delete from product_classification where id in (1, 2);
delete from loan_product where id in (1, 2);
delete from product where id in (1, 2);

