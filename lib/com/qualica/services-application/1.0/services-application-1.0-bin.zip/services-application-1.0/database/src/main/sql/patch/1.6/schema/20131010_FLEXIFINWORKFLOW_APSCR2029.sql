SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE flexifinworkflow;

DROP PROCEDURE IF EXISTS flexifinworkflow.add_column ;

DELIMITER $$

CREATE PROCEDURE flexifinworkflow.add_column(
  IN tableName VARCHAR(100),
  IN columnName VARCHAR(100),
  IN columnType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = columnName
      AND table_name = tableName
      AND table_schema = 'flexifinworkflow'
      )
  THEN

      SET @Statement = CONCAT('ALTER TABLE `flexifinworkflow`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL flexifinworkflow.add_column('process_context', 'outlet', 'VARCHAR(255)');

DROP PROCEDURE IF EXISTS flexifinworkflow.add_column ;

SET SQL_MODE=@OLD_SQL_MODE ;
