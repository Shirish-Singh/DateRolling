USE accounting;

ALTER TABLE `receipt_batch` ADD COLUMN `receipting_due_id` BIGINT(20)  NULL DEFAULT NULL AFTER `trading_entity_id`;


ALTER TABLE `receipt_batch` ADD CONSTRAINT `FK_receipt_batch_2` FOREIGN KEY `FK_receipt_batch_2` (`receipting_due_id`)
  REFERENCES `receipting_due` (`id`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT;


ALTER TABLE `receipt_batch_aud` ADD COLUMN `receipting_due_id` BIGINT(20)  NULL DEFAULT NULL AFTER `trading_entity_id`;

ALTER TABLE `receipt_batch_aud` ADD CONSTRAINT `FK_receipt_batch_aud_2` FOREIGN KEY `FK_receipt_batch_aud_2` (`receipting_due_id`)
  REFERENCES `receipt_batch` (`receipting_due_id`)
  ON DELETE RESTRICT
  ON UPDATE RESTRICT;
