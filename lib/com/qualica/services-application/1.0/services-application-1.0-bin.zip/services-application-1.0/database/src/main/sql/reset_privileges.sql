--
-- Basic flexifin user
--
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';
USE flexifin ;
DROP PROCEDURE IF EXISTS flexifin.drop_user_if_exists ;
DELIMITER $$
CREATE PROCEDURE flexifin.drop_user_if_exists()
BEGIN
  DECLARE foo BIGINT DEFAULT 0 ;
  SELECT COUNT(*)
  INTO foo
    FROM mysql.user
      WHERE User = 'flexifin' and  Host = 'localhost';
   IF foo > 0 THEN
         DROP USER 'flexifin'@'localhost' ;
  END IF;
END ;$$
DELIMITER ;
CALL flexifin.drop_user_if_exists() ;
DROP PROCEDURE IF EXISTS flexifin.drop_users_if_exists ;
SET SQL_MODE=@OLD_SQL_MODE ;

CREATE USER `flexifin`@`localhost` IDENTIFIED BY 'flexifin';

GRANT ALL PRIVILEGES ON flexifin.* TO `flexifin`@`localhost`;
GRANT ALL PRIVILEGES ON flexifinproduct.* TO `flexifin`@`localhost`;
GRANT ALL PRIVILEGES ON masterdata.* TO `flexifin`@`localhost`;
GRANT ALL PRIVILEGES ON flexifinworkflow.* TO `flexifin`@`localhost`;
GRANT ALL PRIVILEGES ON accounting.* TO `flexifin`@`localhost`;
GRANT ALL PRIVILEGES ON collections.* TO `flexifin`@`localhost`;
GRANT ALL PRIVILEGES ON datamigration.* TO `flexifin`@`localhost`;
--
-- read only user for reports
--
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';
USE flexifin ;
DROP PROCEDURE IF EXISTS flexifin.drop_user_if_exists ;
DELIMITER $$
CREATE PROCEDURE flexifin.drop_user_if_exists()
BEGIN
  DECLARE foo BIGINT DEFAULT 0 ;
  SELECT COUNT(*)
  INTO foo
    FROM mysql.user
      WHERE User = 'reporter' and  Host = 'localhost';
   IF foo > 0 THEN
         DROP USER 'reporter'@'localhost' ;
  END IF;
END ;$$
DELIMITER ;
CALL flexifin.drop_user_if_exists() ;
DROP PROCEDURE IF EXISTS flexifin.drop_users_if_exists ;
SET SQL_MODE=@OLD_SQL_MODE ;

CREATE USER `reporter`@`localhost` IDENTIFIED BY 'reporter';

GRANT SELECT ON *.* TO `reporter`@`localhost`;

FLUSH PRIVILEGES;
