use masterdata;


UPDATE `masterdata`.`application_approval_status` SET `description`='Origination initial', `name`='origination_new' WHERE `id`='0';
UPDATE `masterdata`.`application_approval_status` SET `description`='Pending review', `name`='review_pending' WHERE `id`='1';
UPDATE `masterdata`.`application_approval_status` SET `description`='Pending Underwriting', `name`='underwriting_pending' WHERE `id`='2';
UPDATE `masterdata`.`application_approval_status` SET `description`='In Recovery', `name`='recovery' WHERE `id`='3';
UPDATE `masterdata`.`application_approval_status` SET `description`='Recovery Failed', `name`='recovery_failed' WHERE `id`='4';
UPDATE `masterdata`.`application_approval_status` SET `description`='Approved', `name`='approved' WHERE `id`='5';
UPDATE `masterdata`.`application_approval_status` SET `description`='Rejected', `name`='rejected' WHERE `id`='6';
UPDATE `masterdata`.`application_approval_status` SET `description`='Cancelled', `name`='cancelled' WHERE `id`='7';

