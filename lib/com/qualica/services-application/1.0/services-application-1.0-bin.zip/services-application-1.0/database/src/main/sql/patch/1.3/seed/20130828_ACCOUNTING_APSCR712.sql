use accounting;
DELETE FROM `deduct_column_template_source_property` WHERE `id`='18';
DELETE FROM `deduct_column_template_source_property` WHERE `id`='19';
DELETE FROM `deduct_column_template_source_property` WHERE `id`='20';
DELETE FROM `deduct_column_template_source_property` WHERE `id`='21';