
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DROP PROCEDURE IF EXISTS accounting.alter_column ;

DELIMITER $$

CREATE PROCEDURE accounting.alter_column(
  IN tableName VARCHAR(100),
  IN oldColName VARCHAR(100),
  IN newColName VARCHAR(100),
  IN newColType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = newColName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      IF EXISTS (
          SELECT * FROM information_schema.COLUMNS
          WHERE column_name = oldColName
          AND table_name = tableName
          AND table_schema = 'accounting'
          )
      THEN
          SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` CHANGE COLUMN `', oldColName, '` `', newColName ,'` ', newColType);
          prepare DynamicStatement from @Statement ;
          execute DynamicStatement ;
          deallocate prepare DynamicStatement ;
      END IF;
  END IF;
END ;$$

DELIMITER ;

CALL accounting.alter_column('loan_analysis_batch_line', 'last_payment', 'last_payment_date', 'DATE DEFAULT NULL');
CALL accounting.alter_column('receipting_due', 'date_file_due', 'file_due_date', 'DATE DEFAULT NULL');
CALL accounting.alter_column('submission_due', 'date_file_due', 'file_due_date', 'DATE DEFAULT NULL');
CALL accounting.alter_column('deduction_batch_result', 'date_created', 'created_date', 'DATE DEFAULT NULL');
CALL accounting.alter_column('disbursement_batch', 'date_created', 'created_date', 'DATE DEFAULT NULL');
CALL accounting.alter_column('disbursement_batch_line', 'date_created', 'created_date', 'DATE DEFAULT NULL');
CALL accounting.alter_column('disbursement_batch_line', 'date_completed', 'completed_date', 'DATE DEFAULT NULL');

DROP PROCEDURE IF EXISTS accounting.alter_column ;

SET SQL_MODE=@OLD_SQL_MODE ;

