SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE flexifinproduct;

DROP PROCEDURE IF EXISTS flexifinproduct.add_column ;

DELIMITER $$

CREATE PROCEDURE flexifinproduct.add_column(
  IN tableName VARCHAR(100),
  IN columnName VARCHAR(100),
  IN columnType VARCHAR(100)
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = columnName
      AND table_name = tableName
      AND table_schema = 'flexifinproduct'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `flexifinproduct`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;
  END IF;
END ;$$

DELIMITER ;

CALL flexifinproduct.add_column('fee', 'months', 'int(11) null');

DROP PROCEDURE IF EXISTS flexifinproduct.add_columns ;

SET SQL_MODE=@OLD_SQL_MODE ;

