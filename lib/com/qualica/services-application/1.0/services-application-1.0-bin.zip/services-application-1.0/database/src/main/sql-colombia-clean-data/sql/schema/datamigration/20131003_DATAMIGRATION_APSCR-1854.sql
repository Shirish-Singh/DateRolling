SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE datamigration;

DROP PROCEDURE IF EXISTS datamigration.add_column ;

DELIMITER $$

CREATE PROCEDURE datamigration.add_column(
  IN tableName VARCHAR(100) character set utf8,
  IN columnName VARCHAR(100) character set utf8,
  IN columnType VARCHAR(100) character set utf8
)
  BEGIN
    IF NOT EXISTS (

        SELECT * FROM information_schema.COLUMNS
        WHERE column_name = columnName
              AND table_name = tableName
              AND table_schema = 'datamigration'
    )
    THEN
      SET @Statement = CONCAT('ALTER TABLE `datamigration`.`', tableName, '` ADD COLUMN `', columnName, '` ', columnType);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;
    END IF;
  END ;$$

DELIMITER ;

CALL datamigration.add_column('staging_account', 'is_active', 'bit(1) DEFAULT NULL');

DROP PROCEDURE IF EXISTS datamigration.add_columns ;

SET SQL_MODE=@OLD_SQL_MODE ;


