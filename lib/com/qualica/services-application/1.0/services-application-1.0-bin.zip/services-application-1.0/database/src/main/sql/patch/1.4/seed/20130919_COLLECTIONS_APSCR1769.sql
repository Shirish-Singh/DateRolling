use collections;

SET FOREIGN_KEY_CHECKS=0;

LOCK TABLES `contact_attempt_type` WRITE;
/*!40000 ALTER TABLE `contact_attempt_type` DISABLE KEYS */;
DELETE FROM `contact_attempt_type` WHERE id in (6);
INSERT INTO `collections`.`contact_attempt_type` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`, `is_active`)
VALUES (6, 'hrishikesh', '0', 'INBOUND', 1, 'INBOUND', 1);
/*!40000 ALTER TABLE `contact_attempt_type` ENABLE KEYS */;
SET FOREIGN_KEY_CHECKS=1;

UNLOCK TABLES;
