USE flexifinproduct;

 -- Add months to fee mapping as well
 DELETE FROM `fee_mapping` WHERE `id`='100041' and `fee_type`='IAF';

INSERT INTO `fee_mapping`
(`id`, `modified_by`, `version`, `default_boolean`, `default_option`, `domain_property`, `enable_item`, `fee_type`, `option_name`, `options`, `show_item`)
VALUES ('100041',NULL,'0',0,'2','months',1,'IAF', NULL, NULL, 1);

