USE accounting;

ALTER TABLE accounting_period CHANGE COLUMN date_from date_from date not null;
ALTER TABLE accounting_period CHANGE COLUMN date_to date_to date not null;

ALTER TABLE accounting_period_aud CHANGE COLUMN date_from date_from date default null;
ALTER TABLE accounting_period_aud CHANGE COLUMN date_to date_to date default null;