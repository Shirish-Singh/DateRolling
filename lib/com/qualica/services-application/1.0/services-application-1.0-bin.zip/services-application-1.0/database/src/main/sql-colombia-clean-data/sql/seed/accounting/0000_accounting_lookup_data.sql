use accounting;

SET character_set_client = utf8;
-- MySQL dump 10.13  Distrib 5.6.10, for osx10.7 (i386)
--
-- Host: localhost    Database: accounting
-- ------------------------------------------------------
-- Server version	5.6.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

LOCK TABLES `disbursement_reason_code` WRITE;
/*!40000 ALTER TABLE `disbursement_reason_code` DISABLE KEYS */;
UPDATE disbursement_reason_code SET enabled = false WHERE id = 1;
UPDATE disbursement_reason_code SET enabled = false WHERE id = 2;

delete from disbursement_reason_code where id in (3,4,5);

INSERT INTO disbursement_reason_code (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES
(3,NULL,1,'Número de Cuenta bancaria no corresponde',true,'Número de Cuenta bancaria no corresponde'),
(4,NULL,1,'Información no corresponde',true,'Información no corresponde'),
(5,NULL,1,'No confirmación de datos bancarios para pagar una cartera',true,'No confirmación de datos bancarios para pagar una cartera');

/*!40000 ALTER TABLE `disbursement_reason_code` ENABLE KEYS */;
UNLOCK TABLES