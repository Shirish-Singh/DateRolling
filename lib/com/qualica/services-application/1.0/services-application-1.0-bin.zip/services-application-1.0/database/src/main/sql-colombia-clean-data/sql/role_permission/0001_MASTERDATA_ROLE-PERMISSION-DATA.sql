use masterdata;
SET character_set_client = utf8;
SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM `role_permission`;
DELETE FROM `permission`;
DELETE FROM `role`;

INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (401,'Rosa',0,'Super usuario');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (402,'Rosa',0,'Coordinador Comercial General');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (403,'Rosa',0,'Director Regional');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (404,'Rosa',0,'Gerente Nacional de ventas');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (405,'Rosa',0,'Auxiliar de códigos');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (406,'Rosa',0,'Coordinador de Códigos');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (407,'Rosa',0,'Gerente General');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (408,'Rosa',0,'Auxiliar de codigos+ coordinador');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (409,'Rosa',0,'Gerente Nacional+ coordinador');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (410,'Rosa',0,'Auxiliar Comercial-Regionales');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (411,'Rosa',0,'Confirmacion huellas de consulta');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (412,'Rosa',0,'Analista de control de calidad- Regionales');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (413,'Rosa',0,'Coordinador Comercial Originacion');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (414,'Rosa',0,'Auxiliar Comercial-Sucursales');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (415,'Rosa',0,'Auxiliar de visación');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (416,'Rosa',0,'Auxiliar de crédito');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (417,'Rosa',0,'Analista de crédito');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (418,'Rosa',0,'Coordinador de crédito');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (419,'Rosa',0,'Gerente de crédito');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (420,'Rosa',0,'Director de crédito');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (421,'Rosa',0,'Analista de recuperacion');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (422,'Rosa',0,'Analista  y recuperacion');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (423,'Rosa',0,'Gerente y Director de Credito');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (424,'Rosa',0,'Auxiliar de Referenciacion(con huellas)');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (425,'Rosa',0,'Analista de compras de cartera');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (426,'Rosa',0,'Coordinador de compras de cartera');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (427,'Rosa',0,'Auxiliar de compras de cartera');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (428,'Rosa',0,'Subir documentacion compras de cartera');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (429,'Rosa',0,'Auxiliar de tesoreria');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (430,'Rosa',0,'Coordinador de tesoreria');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (431,'Rosa',0,'Auxiliar de recaudo');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (432,'Rosa',0,'Coordinador de recaudo');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (433,'Rosa',0,'Coordinador de novedades');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (434,'Rosa',0,'Auxiliar de novedades');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (435,'Rosa',0,'Auxiliar de novedades y Coordinador');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (436,'Rosa',0,'Asesor de cobranzas');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (437,'Rosa',0,'Coordinador de cobranzas');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (438,'Rosa',0,'Gerente de cobranzas');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (439,'Rosa',0,'Analisis de Pagadurias');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (440,'Rosa',0,'Analista Planeacion Financiera');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (441,'Rosa',0,'Analista Recursos Humanos');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (442,'Rosa',0,'Coordinador Recursos Humanos');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (443,'Rosa',0,'IT');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (444,'Rosa',0,'Manejo Sucursales');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (445,'Rosa',0,'Manejo Reporte Centrales de Riesgo');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (446,'Rosa',0,'Cambio FEID Cliente');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (447,'Rosa',0,'Editar Datos Clientes');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (448,'Rosa',0,'Habilitar/ Desabilitar Cliente');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (449,'Rosa',0,'Certificaciones De Cuenta');
INSERT INTO `masterdata`.`role` (id,modified_by,version,name) VALUES (450,'Rosa',0,'Usuario');

INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4001,'Rosa',0,'Administrator');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4002,'Rosa',0,'EmployerBranchRepresentative');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4003,'Rosa',0,'EmployerCEO');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4004,'Rosa',0,'EmployerClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4005,'Rosa',0,'EmployerDirector');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4006,'Rosa',0,'EmployerOfficer');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4007,'Rosa',0,'EmployerCodesCoordinator');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4008,'Rosa',0,'EmployerCodesClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4009,'Rosa',0,'EmployerNationalSalesManager');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4010,'Rosa',0,'EmployerTeamLeader');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4011,'Rosa',0,'OriginationClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4012,'Rosa',0,'OriginationCreditAnalyst');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4013,'Rosa',0,'OriginationOutsourcingUser');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4014,'Rosa',0,'OriginationQualityControl');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4015,'Rosa',0,'OriginationTeamLeader');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4016,'Rosa',0,'UnderwritingBranchRep');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4017,'Rosa',0,'UnderwritingCEO');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4018,'Rosa',0,'UnderwritingConfirmationClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4019,'Rosa',0,'UnderwritingCoordinator');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4020,'Rosa',0,'UnderwritingCreditAnalyst');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4021,'Rosa',0,'UnderwritingCreditClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4022,'Rosa',0,'UnderwritingCreditCoordinator');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4023,'Rosa',0,'UnderwritingCreditDirector');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4024,'Rosa',0,'UnderwritingHead');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4025,'Rosa',0,'UnderwritingRecoveryAnalyst');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4026,'Rosa',0,'UnderwritingReferenceClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4027,'Rosa',0,'UnderwritingTeamLeader');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4028,'Rosa',0,'TreasuryClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4029,'Rosa',0,'ThirdPartyManagedClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4030,'Rosa',0,'ThirdPartyManagedExternalClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4031,'Rosa',0,'ThirdPartyManagedAnalyst');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4032,'Rosa',0,'ThirdPartyManagedUploadClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4033,'Rosa',0,'ReceiptingClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4034,'Rosa',0,'SubmissionsClerk');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4035,'Rosa',0,'SubmissionsCoordinator');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4036,'Rosa',0,'ui.create_disbursement_batch');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4037,'Rosa',0,'ui.submissions_pending_queue');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4038,'Rosa',0,'ui.capture_employer_response');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4039,'Rosa',0,'ui.receipting_pending_queue');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4040,'Rosa',0,'ui.collections_assign_agent');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4041,'Rosa',0,'CollectionAgent');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4042,'Rosa',0,'CollectionCoordinator');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4043,'Rosa',0,'SueDebtorCollectionAgent');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4044,'Rosa',0,'PhoneClientCollectionAgent');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4045,'Rosa',0,'ui.collections_case_search');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4046,'Rosa',0,'AssignCollectionAgent');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4047,'Rosa',0,'ui.collections_credit_listing_batch');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4048,'Rosa',0,'ui.collections_configuration');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4049,'Rosa',0,'ui.collections_discounts');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4050,'Rosa',0,'ui.collections_download_csv');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4051,'Rosa',0,'ui.change_collection_status');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4052,'Rosa',0,'ui.employer_application');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4053,'Rosa',0,'ui.employer_loan_analysis');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4054,'Rosa',0,'ui.settings_employers');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4055,'Rosa',0,'ui.settings_loan_products');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4056,'Rosa',0,'ui.settings.loan_product_fees');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4057,'Rosa',0,'ui.settings_blacklist_entries');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4058,'Rosa',0,'ui.settings_banks');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4059,'Rosa',0,'ui.settings_system_banks');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4060,'Rosa',0,'ui.settings_third_parties');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4061,'Rosa',0,'ui.settings_agents');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4062,'Rosa',0,'ui.settings_users');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4063,'Rosa',0,'ui.settings_reason_codes');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4064,'Rosa',0,'ui.settings_outlets');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4065,'Rosa',0,'ui.settings_lookups');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4066,'Rosa',0,'ui.settings_base_rate');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4067,'Rosa',0,'ui.settings_base_rate_history');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4068,'Rosa',0,'ui.client_servicing_origination');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4069,'Rosa',0,'ui.client_servicing_feid');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4070,'Rosa',0,'ui.client_servicing_edit');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4071,'Rosa',0,'ui.client_servicing_enable_disable');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4072,'Rosa',0,'ui.client_servicing_statement');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4073,'Rosa',0,'ui.client_servicing_replace_disbursements');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4074,'Rosa',0,'ROLE_USER');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4075,'Rosa',0,'wf.uploadProofOfPayment');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4076,'Rosa',0,'wf.assignCollectionCase');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4077,'Rosa',0,'wf.assignVisitingAgent');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4078,'Rosa',0,'wf.visitDebtor');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4079,'Rosa',0,'wf.manageBlackListEntries');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4080,'Rosa',0,'wf.manageLoanProduct');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4081,'Rosa',0,'wf.manageLookups');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4082,'Rosa',0,'wf.manageOulets');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4083,'Rosa',0,'wf.manageUsers');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4084,'Rosa',0,'wf.manageAgents');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4085,'Rosa',0,'wf.manageThirdParties');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4086,'Rosa',0,'wf.manageSystemBanks');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4087,'Rosa',0,'wf.manageBanks');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4088,'Rosa',0,'wsf.manageLoanProductFees');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4089,'Rosa',0,'wf.editEmployer');
INSERT INTO `masterdata`.`permission` (id,modified_by,version,name) VALUES (4090,'Rosa',0,'wf.manageReasonCodes');

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(450,4074);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4075);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4076);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4077);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4078);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4079);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4080);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4081);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4082);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4083);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4084);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4085);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4086);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4087);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4088);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4089);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4090);


INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4001);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4002);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4003);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4004);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4005);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4006);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4007);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4008);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4009);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4010);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4011);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4012);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4013);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4014);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4015);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4016);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4017);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4018);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4019);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4020);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4021);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4022);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4023);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4024);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4025);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4026);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4027);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4028);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4029);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4030);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4031);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4032);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4033);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4034);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4035);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4036);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4037);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4039);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4047);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4048);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4050);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4053);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4054);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4055);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4056);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4057);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4058);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4059);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4060);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4061);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4062);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4063);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4064);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4065);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4066);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4067);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4068);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4069);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4070);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4071);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4072);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(401,4073);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(402,4002);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(402,4010);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(402,4027);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(402,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(403,4002);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(403,4010);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(403,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(404,4002);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(404,4003);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(404,4005);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(404,4009);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(404,4010);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(404,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(405,4002);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(405,4004);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(405,4008);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(405,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(405,4054);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(406,4002);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(406,4006);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(406,4007);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(406,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(406,4054);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(407,4003);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(407,4017);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4002);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4004);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4006);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4007);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4008);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(408,4054);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(409,4005);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(409,4006);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(409,4007);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(409,4009);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(409,4052);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(409,4054);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(410,4011);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(410,4068);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(411,4013);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(412,4012);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(412,4014);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(412,4015);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(412,4016);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(413,4012);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(413,4014);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(413,4015);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(414,4011);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(414,4016);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(414,4068);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(415,4018);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(416,4021);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(417,4020);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(418,4019);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(418,4022);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(418,4057);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(419,4024);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(419,4057);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(420,4023);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(421,4025);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(422,4020);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(422,4025);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(423,4023);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(423,4024);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(424,4013);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(424,4026);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(425,4030);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(425,4031);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(425,4032);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(425,4060);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(426,4029);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(426,4030);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(426,4031);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(426,4032);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(426,4060);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(427,4029);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(427,4030);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(427,4031);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(427,4060);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(428,4030);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(428,4031);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(429,4028);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(429,4036);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(430,4028);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(430,4036);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(430,4058);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(430,4059);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(430,4073);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(431,4033);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(431,4039);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(432,4033);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(432,4039);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(433,4035);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(433,4037);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(433,4038);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(434,4034);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(434,4037);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(434,4038);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(435,4034);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(435,4035);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(435,4037);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(435,4038);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4041);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4043);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4044);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4045);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(436,4051);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4040);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4042);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4043);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4045);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4046);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4049);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4050);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(437,4051);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4040);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4042);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4043);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4045);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4046);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4048);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4049);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4050);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(438,4051);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(439,4053);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(440,4055);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(440,4056);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(440,4066);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(440,4067);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(441,4061);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(442,4061);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(443,4062);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(443,4063);
INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(443,4065);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(444,4064);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(445,4047);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(446,4069);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(447,4070);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(448,4071);

INSERT INTO `masterdata`.`role_permission`(`role_id`,`permission_id`)VALUES(449,4072);


SET FOREIGN_KEY_CHECKS = 1;