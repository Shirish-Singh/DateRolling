USE accounting;

ALTER TABLE agreement CHANGE COLUMN first_instalment_due_date first_instalment_due_date date not null;