use flexifinworkflow;

INSERT INTO `ACT_GE_PROPERTY` (NAME_, VALUE_, REV_) VALUES
('historyLevel', '2', 1),
('next.dbid', '1', 1),
('schema.history', 'create(5.10)', 1),
('schema.version', '5.10', 1);
