use masterdata;

ALTER TABLE `masterdata`.`payslip_line_item_definition` MODIFY COLUMN `id` BIGINT(20) NOT NULL DEFAULT 0,
MODIFY COLUMN `employer_id` BIGINT(20);
