USE `flexifinworkflow`;
ALTER TABLE `process_context`
ADD COLUMN `child_process_instance_id` VARCHAR(255) NULL DEFAULT NULL  AFTER `start_date` ,
ADD COLUMN `parent_process_instance_id` VARCHAR(255) NULL DEFAULT NULL  AFTER `child_process_instance_id` ;
