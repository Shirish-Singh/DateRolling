
USE `accounting`;

DROP PROCEDURE IF EXISTS accounting.add_column ;

DELIMITER $$

CREATE PROCEDURE accounting.add_column(
  IN tableName VARCHAR(100) character set utf8,
  IN colName VARCHAR(100) character set utf8,
  IN colType VARCHAR(100) character set utf8,
  IN defaultValue VARCHAR(100) character set utf8
)
BEGIN
  IF NOT EXISTS (
      SELECT * FROM information_schema.COLUMNS
      WHERE column_name = colName
      AND table_name = tableName
      AND table_schema = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` ADD COLUMN `', colName, '` ', colType, defaultValue);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.add_column('quote_disbursement', 'is_top_up', 'bit(1)', 'DEFAULT 0');

DROP PROCEDURE IF EXISTS accounting.add_column ;

SET SQL_MODE='ANSI';

