USE accounting;

ALTER TABLE base_rate CHANGE COLUMN effective_date effective_date DATE DEFAULT NULL;
ALTER TABLE base_rate_aud CHANGE COLUMN effective_date effective_date DATE DEFAULT NULL;

ALTER TABLE deduction_batch_line CHANGE COLUMN first_expected_instalment_date first_expected_instalment_date DATE DEFAULT NULL;
ALTER TABLE deduction_batch_line CHANGE COLUMN loan_end_term_date loan_end_term_date DATE DEFAULT NULL;
ALTER TABLE deduction_batch_line CHANGE COLUMN employed_date employed_date DATE DEFAULT NULL;
ALTER TABLE deduction_batch_line CHANGE COLUMN final_disbursement_date final_disbursement_date DATE DEFAULT NULL;

