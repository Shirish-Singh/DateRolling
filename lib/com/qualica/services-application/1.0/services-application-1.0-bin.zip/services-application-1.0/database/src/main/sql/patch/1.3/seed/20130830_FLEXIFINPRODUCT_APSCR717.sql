use flexifinproduct;

INSERT INTO `product_dto_to_class_binding` (`id`, `version`, `class_name`, `dto_name`, `relevant_entity_name`) VALUES ('1', '0', 'com.qualica.flexifin.product.domain.core.LoanProduct', 'com.qualica.flexifin.product.shared.dto.LoanProductDTO', 'com.qualica.flexifin.product.domain.core.ProductNote');