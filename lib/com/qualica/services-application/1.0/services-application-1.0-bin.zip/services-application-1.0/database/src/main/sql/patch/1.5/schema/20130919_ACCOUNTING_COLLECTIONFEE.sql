SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';


USE accounting;



DROP PROCEDURE IF EXISTS accounting.drop_fk ;

DELIMITER $$

CREATE PROCEDURE accounting.drop_fk(
  IN tableName VARCHAR(100),
  IN constraintName VARCHAR(100)
)
BEGIN
  IF EXISTS (
      SELECT * FROM information_schema.TABLE_CONSTRAINTS
WHERE information_schema.TABLE_CONSTRAINTS.CONSTRAINT_NAME = constraintName
AND information_schema.TABLE_CONSTRAINTS.TABLE_NAME = tableName
AND information_schema.TABLE_CONSTRAINTS.TABLE_SCHEMA = 'accounting'
      )
  THEN
      SET @Statement = CONCAT('ALTER TABLE `accounting`.`', tableName ,'` DROP FOREIGN KEY  ', constraintName);
      prepare DynamicStatement from @Statement ;
      execute DynamicStatement ;
      deallocate prepare DynamicStatement ;

  END IF;
END ;$$

DELIMITER ;

CALL accounting.drop_fk('agreement_query_settlement_collections', 'FK1ED36AEB28F5C6C3') ;
CALL accounting.drop_fk('agreement_query_settlement_collections_aud', 'FK602AA75CDEDF1557') ;


DROP PROCEDURE IF EXISTS accounting.drop_fk ;
SET SQL_MODE=@OLD_SQL_MODE;

DROP TABLE IF EXISTS `agreement_query_settlement_collections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_settlement_collections` (
  `date1` date DEFAULT NULL,
  `discount1` bigint(20) DEFAULT NULL,
  `id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK1ED36AEB28F5C6C3` (`id`),
  CONSTRAINT `FK1ED36AEB28F5C6C3` FOREIGN KEY (`id`) REFERENCES `agreement_query_settlement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `agreement_query_settlement_collections_aud`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agreement_query_settlement_collections_aud` (
  `id` bigint(20) NOT NULL,
  `REV` int(11) NOT NULL,
  `date1` date DEFAULT NULL,
  `discount1` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`,`REV`),
  KEY `FK602AA75CDEDF1557` (`id`,`REV`),
  CONSTRAINT `FK602AA75CDEDF1557` FOREIGN KEY (`id`, `REV`) REFERENCES `agreement_query_settlement_aud` (`id`, `REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;