use collections;

--
-- Dumping data for table `collections_dto_to_class_binding`
--


LOCK TABLES `collections_dto_to_class_binding` WRITE;
/*!40000 ALTER TABLE `collections_dto_to_class_binding` DISABLE KEYS */;

SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM `collections_dto_to_class_binding` WHERE id = 2;

INSERT INTO `collections_dto_to_class_binding` (`id`, `modified_by`, `version`, `class_name`, `dto_name`, `relevant_entity_name`)
  VALUES
  (2,NULL,0,'com.qualica.flexifin.collections.domain.CollectionInstance','com.qualica.flexifin.collections.shared.dto.CollectionInstanceDTO','com.qualica.flexifin.collections.domain.CollectionsNote');

SET FOREIGN_KEY_CHECKS = 1;

/*!40000 ALTER TABLE `collections_dto_to_class_binding` ENABLE KEYS */;
UNLOCK TABLES;





