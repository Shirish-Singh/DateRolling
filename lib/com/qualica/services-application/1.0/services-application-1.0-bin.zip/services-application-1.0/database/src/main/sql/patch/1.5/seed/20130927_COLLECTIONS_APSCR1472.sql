USE collections;

DELETE FROM `collection_file_column_template_desc` WHERE id in (1,2,3,4,5,6,7,8,9,10,11,12);
DELETE FROM `collection_file_column_template` WHERE id in (1);
DELETE FROM `collection_file_column_template_source_property` WHERE id in (1,2,3,4,5,6,7,8,9,10,11,12);
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('1', '0', 'Simco Legacy ', 1, 'legacySimcoAccount', 'filetemplatesourceproperty.simco', '1');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('2', '0', 'Loan AccountId', 1, 'loanAccountId', 'filetemplatesourceproperty.loanAccountId', '1');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('3', '0', 'Client Full Name', 1, 'clientFullName', 'filetemplatesourceproperty.clientFullName', '1');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('4', '0', 'Client Id', 1, 'clientId', 'filetemplatesourceproperty.clientId', '1');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('5', '0', 'Address', 1, 'addresses', 'filetemplatesourceproperty.addresses', '2');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('6', '0', 'Region', 1, 'region', 'filetemplatesourceproperty.region', '2');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('7', '0', 'City', 1, 'city', 'filetemplatesourceproperty.city', '2');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('8', '0', 'Suburb', 1, 'suburb', 'filetemplatesourceproperty.suburb', '2');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('9', '0', 'Email Address', 1, 'emailAddresses', 'filetemplatesourceproperty.emailAddresses', '2');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('10', '0', 'Contact Number', 1, 'contactNumbers', 'filetemplatesourceproperty.contactNumbers', '2');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('11', '0', 'Arrears Amount', 1, 'arrearsAmount', 'filetemplatesourceproperty.arrearsAmount', '1');
INSERT INTO `collections`.`collection_file_column_template_source_property` (`id`, `version`, `description`, `enabled`, `name`, `i18n_key`, `max_size`) VALUES ('12', '0', 'Days In Arrears', 1, 'daysInArrears', 'filetemplatesourceproperty.daysInArrears', '1');







INSERT INTO `collection_file_column_template` (`id`, `modified_by`, `version`, `description`, `enabled`, `name`) VALUES ('1', 'Sharad', '0', 'CSV File Template', 1, 'CSV File Template');


INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('1', '0', '1', '1');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('2', '0', '1', '2');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('3', '0', '1', '3');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('4', '0', '1', '4');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('5', '0', '1', '5');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('6', '0', '1', '6');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('7', '0', '1', '7');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('8', '0', '1', '8');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('9', '0', '1', '9');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('10', '0', '1', '10');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('11', '0', '1', '11');
INSERT INTO `collections`.`collection_file_column_template_desc` (`id`, `version`, `collection_file_column_template_id`, `collection_file_column_template_source_property_id`) VALUES ('12', '0', '1', '12');








