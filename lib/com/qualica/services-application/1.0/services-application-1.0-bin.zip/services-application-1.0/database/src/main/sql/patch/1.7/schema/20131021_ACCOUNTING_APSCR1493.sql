use accounting;


--
-- Table structure for table `account_recency_history`
--
DROP TABLE IF EXISTS `account_recency_history`;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_recency_history` (
  `id` bigint(20) NOT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `recency` varchar(255) NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `employer_Period_id` bigint(20) NOT NULL,
  `recency_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Account_RecencyHistory` (`account_id`),
  KEY `FK_EmployerPeriod_RecencyHistory` (`account_id`),
  KEY `IX_Recency_Account` (`account_id`),
  KEY `IX_Recency_Employer_Period` (`employer_Period_id`),
  CONSTRAINT `FK_Account_RecencyHistory` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_EmployerPeriod_RecencyHistory` FOREIGN KEY (`employer_Period_id`) REFERENCES `employer_period` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

