#!/bin/bash


./reset.sh $1 $2 flexifinproduct
./reset.sh $1 $2 masterdata
./reset.sh $1 $2 flexifinworkflow
./reset.sh $1 $2 accounting
./reset.sh $1 $2 collections
./reset.sh $1 $2 datamigration
