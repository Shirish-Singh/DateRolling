mysql -uflexifin -pflexifin < backup.sql
