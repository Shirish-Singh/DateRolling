USE accounting;

ALTER TABLE agreement_aud CHANGE COLUMN first_instalment_due_date first_instalment_due_date date default null;