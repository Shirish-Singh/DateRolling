SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ANSI';

USE accounting;

DELIMITER $$

DROP PROCEDURE IF EXISTS drop_index_if_exists $$

CREATE PROCEDURE drop_index_if_exists(IN tableName varchar(128), IN indexName varchar(128) )
BEGIN
 IF((SELECT COUNT(*) AS index_exists FROM information_schema.statistics WHERE TABLE_SCHEMA = DATABASE() and table_name =
tableName AND index_name = indexName) > 0) THEN
   SET @s = CONCAT('DROP INDEX `' , indexName , '` ON `' , tableName, '`');
   PREPARE stmt FROM @s;
   EXECUTE stmt;
 END IF;
END ;$$

DELIMITER ;

-- create index for bank_account_id on disbursement

CALL drop_index_if_exists('disbursement', 'BANK_ACCOUNT_ID_1_INDEX');

Create Index BANK_ACCOUNT_ID_1_INDEX on accounting.disbursement (bank_account_id);

-- create index for payment_resource_id on quote_disbursement

CALL drop_index_if_exists('quote_disbursement', 'BANK_ACCOUNT_ID_2_INDEX');

Create Index BANK_ACCOUNT_ID_2_INDEX on quote_disbursement (payment_resource_id);

DROP PROCEDURE IF EXISTS drop_index_if_exists;


SET SQL_MODE=@OLD_SQL_MODE;