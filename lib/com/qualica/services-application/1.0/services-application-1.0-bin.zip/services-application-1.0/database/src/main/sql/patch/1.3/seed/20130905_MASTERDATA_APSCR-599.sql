use masterdata;

insert into role values (135, 'rahul', 0, 'ReportingAnalyst');
insert into permission values (2003, 'rahul', 0, 'ReportingAnalyst');
insert into role_permission values(135, 2003);