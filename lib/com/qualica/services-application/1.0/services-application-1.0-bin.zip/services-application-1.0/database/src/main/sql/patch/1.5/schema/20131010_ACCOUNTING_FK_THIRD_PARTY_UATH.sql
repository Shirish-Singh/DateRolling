use accounting;
alter table third_party_disbursement_authorisation DROP FOREIGN KEY FK335DC65334A9509B;