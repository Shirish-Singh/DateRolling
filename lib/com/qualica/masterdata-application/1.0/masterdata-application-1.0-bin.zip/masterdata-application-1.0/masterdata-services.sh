#!/bin/bash

DEFAULT_PID_DIR='/var/run'
DEFAULT_LOG_DIR='/var/log/qualica'
DEFAULT_CONFIG_DIR='/usr/local/qualica/flexifin-config'

if [[ -z ${JAVA_HOME} ]]; then
    JAVACMD=`which java`
else 
    JAVACMD="${JAVA_HOME}/bin/java"
fi

if [[ -z ${FLEXIFIN_PID_DIR} ]]; then
    FLEXIFIN_PID_DIR="${DEFAULT_PID_DIR}"
fi

if [[ -z ${FLEXIFIN_LOG_DIR} ]]; then
    FLEXIFIN_LOG_DIR="${DEFAULT_LOG_DIR}"
fi

if [[ -z ${FLEXIFIN_CONFIG_DIR} ]]; then
    FLEXIFIN_CONFIG_DIR="${DEFAULT_CONFIG_DIR}"
fi


JAVA_OPTS="-Dspring.profiles.active=production -Dlog.dir=${FLEXIFIN_LOG_DIR} -Dlog4j.configuration=file:///${FLEXIFIN_CONFIG_DIR}/flexifin-masterdata.properties -Dcore.config=${FLEXIFIN_CONFIG_DIR}/coreconfig.xml"
DEBUG_OPTS='-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=5006'
JMX_OPTS='-Dcom.sun.management.jmxremote -Dcom.sun.management.jmxremote.port=9010 -Dcom.sun.management.jmxremote.local.only=false -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false'
JAVA_OPTS="${JAVA_OPTS} ${DEBUG_OPTS} ${JMX_OPTS}"

${JAVACMD} ${JAVA_OPTS} -jar masterdata-application-1.0.jar > ${FLEXIFIN_LOG_DIR}/masterdata-stdout.log 2>&1 &

echo $! > ${FLEXIFIN_PID_DIR}/flexifin-masterdata.pid
